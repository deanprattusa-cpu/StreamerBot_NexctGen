import pygame
import cv2
import os
import time
import math
import ctypes
import wave
from ctypes import wintypes

def main():
    pygame.init()
    
    avatar_path = "avatar.png"
    if not os.path.exists(avatar_path):
        print(f"[Overlay Error] Could not find {avatar_path}. Please ensure it is in the folder.")
        return
        
    idle_surface = pygame.image.load(avatar_path)
    
    target_size = 384
    idle_surface = pygame.transform.smoothscale(idle_surface, (target_size, target_size))
    
    screen = pygame.display.set_mode((target_size, target_size), pygame.NOFRAME)
    pygame.display.set_caption("AI Avatar Overlay")
    
    hwnd = pygame.display.get_wm_info()["window"]
    dragging = False
    offset_x, offset_y = 0, 0
    
    # Pure green for the green screen avatar background
    transparent_color = (0, 255, 0) 
    
    trigger_file = "play_avatar.txt"
    print("\n===================================================")
    print("🟢 VTuber Overlay Ready (DJ Bypass Enabled)!")
    print("Listening for video signals from Main Bot...")
    print("===================================================\n")
    
    clock = pygame.time.Clock()
    running = True
    
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                
            # 🖱️ IDLE DRAG LOGIC
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                dragging = True
                offset_x, offset_y = event.pos
            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                dragging = False
            elif event.type == pygame.MOUSEMOTION and dragging:
                pt = wintypes.POINT()
                ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
                ctypes.windll.user32.SetWindowPos(hwnd, 0, pt.x - offset_x, pt.y - offset_y, 0, 0, 0x0015)
                
        if os.path.exists(trigger_file):
            try:
                with open(trigger_file, "r", encoding="utf-8") as f:
                    # Read the absolute paths sent by the main bot
                    data = f.read().strip().split('|')
                    video_path = data[0]
                    
                os.remove(trigger_file) # Consume the signal
                
                if not os.path.exists(video_path):
                    print(f"❌ [Error] Overlay cannot find video: {video_path}")
                else:
                    print(f"▶️ [Overlay] Playing Video: {os.path.basename(video_path)}")
                    cap = cv2.VideoCapture(video_path)
                    
                    fps = cap.get(cv2.CAP_PROP_FPS)
                    if fps == 0 or fps > 60: fps = 25
                    
                    # 🛡️ THE FIX 1: Get exact audio duration so the mouth stops instantly!
                    audio_path = video_path.replace(".mp4", ".wav")
                    video_duration = 5.0 # Fallback
                    try:
                        with wave.open(audio_path, 'r') as w:
                            video_duration = w.getnframes() / float(w.getframerate())
                    except Exception:
                        # If we can't read the audio, fallback to video frames
                        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
                        video_duration = (total_frames / fps) if fps > 0 else 5.0
                    
                    frame_clock = pygame.time.Clock()
                    start_time = time.time()
                    
                    while cap.isOpened():
                        # ⚡ THE FIX 2: DJ BYPASS - Check if you mashed a new hotkey!
                        if os.path.exists(trigger_file):
                            print("⚡ [DJ Bypass] New hotkey detected! Cutting video instantly.")
                            break
                            
                        current_time = time.time() - start_time
                        if current_time > video_duration:
                            break # Time's up! Audio finished exactly.
                            
                        ret, frame = cap.read()
                        if not ret:
                            break
                            
                        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                        frame = cv2.resize(frame, (target_size, target_size))
                        surf = pygame.surfarray.make_surface(frame.swapaxes(0, 1))
                        
                        screen.fill(transparent_color)
                        screen.blit(surf, (0, 0))
                        pygame.display.flip()
                        
                        frame_clock.tick(fps)
                        
                        for event in pygame.event.get():
                            if event.type == pygame.QUIT:
                                running = False
                                cap.release()
                                break
                            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                                dragging = True
                                offset_x, offset_y = event.pos
                            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                                dragging = False
                            elif event.type == pygame.MOUSEMOTION and dragging:
                                pt = wintypes.POINT()
                                ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
                                ctypes.windll.user32.SetWindowPos(hwnd, 0, pt.x - offset_x, pt.y - offset_y, 0, 0, 0x0015)
                                
                    cap.release()
            except Exception as e:
                print(f"[Overlay Error] {e}")
                
        if running:
            screen.fill(transparent_color)
            
            t = time.time()
            breathe_scale = 0.99 + math.sin(t * 2.5) * 0.01 
            new_w = int(target_size * breathe_scale)
            new_h = int(target_size * breathe_scale)
            
            bob_y = math.sin(t * 1.5) * 4 
            
            scaled_idle = pygame.transform.smoothscale(idle_surface, (new_w, new_h))
            
            x = (target_size - new_w) // 2
            y = (target_size - new_h) // 2 + bob_y
            
            screen.blit(scaled_idle, (x, y))
            pygame.display.flip()
            
            clock.tick(30)
            
    pygame.quit()

if __name__ == "__main__":
    main()