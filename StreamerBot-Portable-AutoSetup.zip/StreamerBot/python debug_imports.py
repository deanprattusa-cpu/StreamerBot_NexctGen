print("1. Starting imports...")
try:
    import tkinter
    print(" - Tkinter OK")
except Exception as e: print(f" ! Tkinter Fail: {e}")

try:
    import pyaudio
    print(" - PyAudio OK")
except Exception as e: print(f" ! PyAudio Fail: {e}")

try:
    import sounddevice
    print(" - SoundDevice OK")
except Exception as e: print(f" ! SoundDevice Fail: {e}")

try:
    from google.cloud import texttospeech
    print(" - Google Cloud TTS OK")
except Exception as e: print(f" ! Google Cloud TTS Fail: {e}")

try:
    import speech_recognition
    print(" - SpeechRecognition OK")
except Exception as e: print(f" ! SpeechRecognition Fail: {e}")

print("2. Imports finished. Attempting to init audio...")
try:
    p = pyaudio.PyAudio()
    print(f" - PyAudio Init OK. Default Input Device: {p.get_default_input_device_info()['name']}")
    p.terminate()
except Exception as e:
    print(f" ! PyAudio Init Failed: {e}")

print("Done.")