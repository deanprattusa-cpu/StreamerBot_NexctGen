import os
import sys
import subprocess
import traceback
import shutil
import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox

# This is the master list of core packages your bot needs to run.
REQUIRED_PACKAGES = [
    "pygame-ce", # Drop-in replacement for pygame. Has modern Python 3.12/3.13 binary wheels!
    "SpeechRecognition", 
    "sounddevice", 
    "google-generativeai", 
    "groq", 
    "edge-tts", 
    "pyttsx3", 
    "scipy", 
    "numpy", 
    "requests", 
    "python-dotenv", 
    "google-api-python-client", 
    "google-auth-oauthlib", 
    "google-cloud-texttospeech", 
    "openai", 
    "pydub", 
    "beautifulsoup4",
    "keyboard"
]

# These packages occasionally fail to build on experimental Python versions (like 3.13 or 3.14)
# We isolate them so they don't crash the entire installation.
OPTIONAL_PACKAGES = [
    "pywebview"
]

VENV_DIR = "venv"

def get_portable_python():
    """Gets the path to the portable virtual environment Python executable."""
    # Dynamically find the current folder this launcher is sitting in (any drive)
    base_dir = os.path.dirname(os.path.abspath(__file__))
    if os.name == 'nt':
        return os.path.join(base_dir, VENV_DIR, "Scripts", "python.exe")
    else:
        return os.path.join(base_dir, VENV_DIR, "bin", "python")

def ensure_venv():
    """Creates a portable virtual environment in the current folder if it doesn't exist."""
    venv_python = get_portable_python()
    if not os.path.exists(venv_python):
        print(f"\n[+] Portable environment not found. Building isolated '{VENV_DIR}' folder on this drive...")
        try:
            # Create the venv using the system's base python
            subprocess.check_call([sys.executable, "-m", "venv", VENV_DIR])
            print("[+] Portable environment created successfully!")
        except Exception as e:
            print(f"❌ Failed to create virtual environment: {e}")
            sys.exit(1)
    return venv_python

def run_patcher_app():
    """Runs the AI Smart Code Patcher GUI."""
    class SmartCodePatcher:
        def __init__(self, root):
            self.root = root
            self.root.title("AI Smart Code Patcher")
            self.root.geometry("900x750")
            self.root.configure(bg="#1e1e1e")
            
            self.file_path_var = tk.StringVar()
            
            self.setup_ui()

        def setup_ui(self):
            # --- Header ---
            header_frame = tk.Frame(self.root, bg="#2d2d2d", pady=10)
            header_frame.pack(fill="x")
            
            tk.Label(header_frame, text="🧠 AI Smart Code Patcher", font=("Arial", 16, "bold"), bg="#2d2d2d", fg="#00FFFF").pack()
            tk.Label(header_frame, text="Safely inject AI code fixes without breaking your files. Auto-creates backups (.bak)", font=("Arial", 10), bg="#2d2d2d", fg="gray").pack()

            # --- File Selector ---
            file_frame = tk.Frame(self.root, bg="#1e1e1e", pady=15)
            file_frame.pack(fill="x", padx=20)
            
            tk.Label(file_frame, text="1. Select File to Patch (.py, .html, .json):", font=("Arial", 11, "bold"), bg="#1e1e1e", fg="white").pack(anchor="w")
            
            entry_frame = tk.Frame(file_frame, bg="#1e1e1e")
            entry_frame.pack(fill="x", pady=5)
            tk.Entry(entry_frame, textvariable=self.file_path_var, bg="#333", fg="white", font=("Arial", 11), insertbackground="white").pack(side="left", fill="x", expand=True, ipady=4)
            tk.Button(entry_frame, text="📂 Browse", bg="#0080FF", fg="white", font=("Arial", 10, "bold"), command=self.browse_file).pack(side="left", padx=10, ipady=2)

            # --- Paned Window for Split View ---
            paned = ttk.PanedWindow(self.root, orient=tk.VERTICAL)
            paned.pack(fill="both", expand=True, padx=20, pady=5)

            # --- Target Code Box ---
            frame_target = tk.Frame(paned, bg="#1e1e1e")
            tk.Label(frame_target, text="2. Code to REMOVE / HIGHLIGHT (Target block):", font=("Arial", 10, "bold"), bg="#1e1e1e", fg="#FF4444").pack(anchor="w", pady=5)
            self.txt_target = scrolledtext.ScrolledText(frame_target, bg="#111", fg="#FF8888", font=("Consolas", 10), insertbackground="white", undo=True)
            self.txt_target.pack(fill="both", expand=True)
            paned.add(frame_target, weight=1)

            # --- Replacement Code Box ---
            frame_replace = tk.Frame(paned, bg="#1e1e1e")
            tk.Label(frame_replace, text="3. Code to INSERT / OVERWRITE (New block):", font=("Arial", 10, "bold"), bg="#1e1e1e", fg="#00FF00").pack(anchor="w", pady=5)
            self.txt_replace = scrolledtext.ScrolledText(frame_replace, bg="#111", fg="#88FF88", font=("Consolas", 10), insertbackground="white", undo=True)
            self.txt_replace.pack(fill="both", expand=True)
            paned.add(frame_replace, weight=1)

            # --- Action Buttons ---
            btn_frame = tk.Frame(self.root, bg="#1e1e1e", pady=15)
            btn_frame.pack(fill="x", padx=20)
            
            tk.Button(btn_frame, text="✨ Apply Smart Patch ✨", bg="#008000", fg="white", font=("Arial", 14, "bold"), command=self.apply_patch).pack(fill="x", ipady=5)

        def browse_file(self):
            filepath = filedialog.askopenfilename(filetypes=[("Python Files", "*.py"), ("All Files", "*.*")])
            if filepath:
                self.file_path_var.set(filepath)

        def apply_patch(self):
            filepath = self.file_path_var.get().strip()
            target_code = self.txt_target.get("1.0", "end").strip("\n")
            new_code = self.txt_replace.get("1.0", "end").strip("\n")

            if not filepath or not os.path.exists(filepath):
                return messagebox.showerror("Error", "Please select a valid file to patch.")
            
            if not target_code:
                return messagebox.showerror("Error", "Please paste the target code you want to replace.")

            try:
                # 1. Read original file
                with open(filepath, "r", encoding="utf-8") as f:
                    original_content = f.read()

                # Normalize line endings to prevent matching errors
                normalized_content = original_content.replace("\r\n", "\n")
                normalized_target = target_code.replace("\r\n", "\n")
                normalized_new = new_code.replace("\r\n", "\n")

                # 2. Attempt Exact Match First
                if normalized_target in normalized_content:
                    patched_content = normalized_content.replace(normalized_target, normalized_new)
                else:
                    # 3. Fallback: Smart Strip Match (Ignores leading/trailing blank lines in the copy/paste)
                    smart_target = normalized_target.strip()
                    if smart_target in normalized_content:
                        patched_content = normalized_content.replace(smart_target, normalized_new)
                    else:
                        return messagebox.showerror(
                            "Match Failed", 
                            "Could not find the exact 'Code to Remove' inside the file.\n\n"
                            "Check if you copied the HIGHLIGHT block exactly as provided, including indentations."
                        )

                # 4. Create Backup
                backup_path = filepath + ".bak"
                shutil.copy2(filepath, backup_path)

                # 5. Write Patched File
                with open(filepath, "w", encoding="utf-8", newline="\n") as f:
                    f.write(patched_content)

                messagebox.showinfo(
                    "Success! 🎉", 
                    f"File successfully patched!\n\n"
                    f"A backup of your original file was saved as:\n{os.path.basename(backup_path)}"
                )

                # Clear boxes on success
                self.txt_target.delete("1.0", "end")
                self.txt_replace.delete("1.0", "end")

            except Exception as e:
                messagebox.showerror("Critical Error", f"Failed to patch file:\n\n{e}")

    root = tk.Tk()
    app = SmartCodePatcher(root)
    root.mainloop()

def main():
    # If the script was called with the --run-patcher flag, instantly run the GUI and exit.
    if len(sys.argv) > 1 and sys.argv[1] == "--run-patcher":
        run_patcher_app()
        return

    print("="*60)
    print(" 🤖 STREAMER BOT: PORTABLE 1-CLICK LAUNCHER")
    print("="*60)
    
    # [FIX: Move the menu to the very top so the Patcher is instantly accessible!]
    print("\n WHAT WOULD YOU LIKE TO DO?")
    print(" [1] Start StreamerBot (Updates packages & Launches)")
    print(" [2] Open AI Smart Code Patcher (Instant access)")
    print("="*60)
    
    choice = input("\nEnter 1 or 2 (Press Enter for 1): ").strip()
    
    if choice == '2':
        print("\n[System] Launching AI Smart Code Patcher...")
        run_patcher_app()
        return
        
    print("\n[System] Preparing StreamerBot Environment...\n")
    
    try:
        # 1. SETUP PORTABLE VENV
        # This completely isolates the bot to the current folder/drive.
        venv_python = ensure_venv()

        # 2. AUTO-INSTALLER (Bypasses pip.exe restrictions)
        print("\n[1] Verifying System Dependencies inside portable environment...")
        print("    (Using safe 'python -m pip' to bypass Windows Device Guard)\n")
        
        # Pre-install: Update core build tools so no wheels fail to compile
        print("    Updating core build tools (pip, setuptools, wheel)...")
        subprocess.check_call([venv_python, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
        
        # We run the install command using the isolated venv python.
        print("\n    Installing StreamerBot CORE packages...")
        cmd = [venv_python, "-m", "pip", "install", "--upgrade"] + REQUIRED_PACKAGES
        subprocess.check_call(cmd)

        # Safely try to install UI extensions
        print("\n    Installing StreamerBot OPTIONAL UI packages...")
        for opt_pkg in OPTIONAL_PACKAGES:
            try:
                # We suppress the output of this one to prevent massive red error walls if it fails
                subprocess.check_call(
                    [venv_python, "-m", "pip", "install", "--upgrade", opt_pkg],
                    stdout=subprocess.DEVNULL, 
                    stderr=subprocess.DEVNULL
                )
            except subprocess.CalledProcessError:
                print(f"\n    ⚠️ WARNING: Could not install '{opt_pkg}'.")
                print("    -> (Since you are on an experimental Python version, some UI extensions like 'pythonnet' cannot compile yet).")
                print("    -> The bot will still work perfectly! Only the standalone YouTube Player overlay will be disabled.\n")
        
        print("\n✅ All critical background packages are installed!")
        print("\n[2] Launching StreamerBot...\n")
        
        # 3. FILE CHECK
        base_dir = os.path.dirname(os.path.abspath(__file__))
        controller_path = os.path.join(base_dir, "controller.py")
        
        if not os.path.exists(controller_path):
            print("❌ ERROR: 'controller.py' was not found in this folder!")
            print("   Please make sure you placed Launcher.py inside the exact same folder as your bot code.")
            input("\nPress Enter to exit...")
            return
            
        # 4. LAUNCH THE BOT
        # This hands over control to your main bot script USING the portable venv.
        subprocess.check_call([venv_python, "controller.py"])
        
    except subprocess.CalledProcessError as e:
        print(f"\n❌ PROCESS ERROR: A command failed to execute properly.")
        print(f"Details: {e}")
        input("\nPress Enter to exit so you can read the error...")
        
    except KeyboardInterrupt:
        print("\n[System] Launcher cancelled by user.")
        
    except Exception as e:
        print("\n❌ CRITICAL CRASH IN LAUNCHER:")
        traceback.print_exc()
        input("\nPress Enter to exit so you can read the error...")

if __name__ == "__main__":
    main()