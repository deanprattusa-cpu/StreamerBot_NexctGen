# StreamerBot Studio — Windows port

You play the game. Your AI character watches, reacts in first person, answers viewers and performs on stream.

This is the first functional Windows port: a **C#/.NET 10 WinUI 3 shell** with a **modular Python engine** and a dashboard shared through WebView2. It runs alongside the original application. Game assistance, training and autonomous controls are outside this phase.

## Start on Windows 11 x64

### Recommended: automatic portable setup

Extract the **updated complete ZIP** to a writable folder on a local drive, then double-click **`Start-StreamerBot.bat`**. No preinstalled Python, .NET SDK or WebView2 is required. Do not copy only the BAT from an older download: it now needs `Start-Portable.ps1`, `windows/Portable-Runtime.ps1` and `windows/portable-runtimes.json` from this release.

On first launch it downloads pinned x64 builds of uv, standalone Python 3.12, the .NET 10 SDK and the WebView2 fixed runtime. Downloaded runtime archives are checked against hashes before extraction. Python dependencies come from `uv.lock`. Keep the terminal open; downloads and the desktop build can take several minutes. Allow roughly **6 GB of free space** and an internet connection on first setup or when repairing/updating dependencies.

Runtimes, the isolated Python environment, caches and downloaded archives stay in **`.portable/`** beside the launcher. Nothing is added to the system PATH, Python registry or machine-wide runtime installation. The process-only PowerShell policy override does not change your saved policy. The WebView2 folder receives the read/execute permissions required by Microsoft's fixed-runtime sandbox. Run as your normal user in a folder you own; administrator access is not requested.

Each launch checks runtime executables, synchronizes locked Python dependencies and checks package imports. Missing/broken Python environments are rebuilt. Desktop files are checked and rebuilt after source changes. Failed downloads retry up to three times; incomplete downloads are discarded and valid archives are reused. If desktop preparation or native launch fails, the browser dashboard starts instead, without native global shortcuts. Errors remain visible if preparation cannot finish.

For a full repair, from the extracted folder in PowerShell:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Start-Portable.ps1 -Repair
```

To skip the native build and use the browser dashboard directly:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Start-Portable.ps1 -Dashboard
```

After moving the folder to a new location, launch the BAT again so it can repair absolute Python paths. Keep the complete source folder, including `windows/` and `streamerbot/`. Runtime portability does not move existing settings/history: those remain in `%LOCALAPPDATA%\StreamerBot`, as described below. Downloaded runtimes are pinned rather than automatically updated on every launch; future project releases must update the runtime manifest to receive newer runtime/security fixes. Offline launch can reuse an intact setup; missing packages or first-time builds still need internet.

### Manual setup (optional)

If you prefer your installed tools, install **64-bit Python 3.12**, the **.NET 10 SDK** and **Microsoft Edge WebView2 Runtime**, then run:

```powershell
.\Setup-Windows.ps1
.\Launch-Windows.ps1
```

For Python available as `python` instead of `py -3.12`, pass `-Python python -PythonArguments @()` to setup. Manual setup keeps its original `.venv`; portable setup uses a separate `.portable/venv`.

To try the isolated offline demonstration after preparation:

```powershell
.\Launch-Dashboard.ps1 -Demo -OpenBrowser
```

**Demo mode uses synthetic scenes and silent animated captions.** It does not capture your screen, call providers or generate speech. Restart without `-Demo` to configure a live session. Normal first launch also starts in demo mode, but Settings can select live mode.

### First live session

1. Before your first settings save, use **Settings → Import settings** to select `bot_config.json` or `sbv2_config.json`. You can also configure a new character manually.
2. Review your character, game and personality. Select **Live** mode.
3. Enable a provider and enter its current commentary model ID and API key. Set a vision-capable model ID for screen reactions. Model IDs are configurable rather than hard-coded to a release that may retire.
4. Select the monitor and vision request limit. Start at six observations per minute; this is commentary cadence, not a gameplay controller.
5. Select **Windows SAPI** for offline system speech, **Edge** for internet speech, or **Captions only**. SAPI uses the Windows default voice/output. Edge supports a voice ID and an output device name.
6. Save, return to Live studio and start the session. Screen images are sent only to your configured vision providers while a live capture session is running. A session can also run with capture disabled, using chat and manual reactions.

The native shell reserves port **8765**, keeping the OBS URL stable across restarts. Close any standalone dashboard on that port before starting the desktop app. Closing the native window stops the worker and its active speech.

### OBS

Add a Browser Source with URL **http://127.0.0.1:8765/overlay**, width **800**, height **800**. The page has a transparent background. Append `?captions=0` to hide captions. Add the default Windows audio output, or the Edge output device you selected, to OBS's audio sources.

The overlay displays the existing `avatar.png` when launched through the Windows scripts. Otherwise it uses the bundled illustration. Its animation follows speech start/end; this is a lightweight image animation, not phoneme-level lip sync. The overlay itself plays no sound, so adding it does not duplicate the engine's audio.

### Native global shortcuts

Hold **Ctrl+Alt** with:

| Key | Action |
| --- | --- |
| 1 | React to death |
| 2 | React to winning |
| 3 | React to a close call |
| 4 | Introduce the stream |
| M | Mute/unmute character speech |
| S | Interrupt speech and clear queued reactions |
| F8 | Start/stop the session |

These shortcuts use Windows `RegisterHotKey`; they do not inject game input. The native window reports if another app has reserved a shortcut. The browser-only dashboard uses its on-screen buttons.

### YouTube chat

Supply the stream's **live chat ID** and the path to an existing **authorized-user OAuth token JSON file** in Settings. The token must permit YouTube reads. The adapter reads new text messages, respects YouTube's polling interval and skips the initial historical batch. It does **not post** to chat or create an OAuth login flow. Reauthorization is required when the existing token cannot refresh.

## Migration and feature coverage

Import reads the selected file and creates new settings. It never changes the source. It imports supported names, personality, provider keys/models, auto-reply and basic voice settings. It keeps demo mode selected and reports unsupported voice engines. It does not guess a vision model or import account credentials, hotkey audio paths, music playlists or heavy model state. Import refuses to overwrite already-saved port settings.

| Capability | This port |
| --- | --- |
| Screen observation → first-person commentary | Implemented with bounded capture cadence and provider requests |
| Gemini, Groq, OpenRouter, SambaNova, local compatible servers | Configurable models, key rotation, fallback and cooldowns |
| Priority speech, mute, interruption and stale reaction dropping | Implemented |
| Windows SAPI / Edge speech / captions | Implemented; Windows audio still needs device verification |
| Transparent OBS avatar and captions | Implemented |
| Dashboard chat, manual reactions and native global shortcuts | Implemented |
| Read-only YouTube live chat | Implemented; live OAuth/provider verification outstanding |
| Saved observations and commentary by game | SQLite, bounded to 10,000 events |
| Microphone transcription / game-audio event detection | Not ported in this release |
| Bark, RVC, Fish, Kokoro and other legacy voice integrations | Use the original app |
| Legacy soundboard/cache workflows, music, rendered avatar videos and extra windows | Use the original app |
| Game assistance, training or game controls | Deferred by design |

The original `controller.py`, `model.py`, `view.py`, launchers and requirements are preserved. `README_v2.md` describes an older v2 package that is absent from this checkout; use the commands in this README for the new port.

## Settings, memory and upgrades

Normal settings and SQLite memory live in `%LOCALAPPDATA%\StreamerBot` on Windows and `$XDG_DATA_HOME/streamerbot` (or `~/.local/share/streamerbot`) elsewhere. API keys are saved locally in `settings.json`; they are not encrypted at rest. The dashboard only receives key counts. An empty key field retains existing keys; **Clear saved keys** explicitly removes them on save.

Back up that directory to preserve the character's settings and history. Demo runs use temporary data by default; `--demo --data-dir PATH` uses a separate `PATH/demo` directory. No automatic import of repository secrets or `.env` takes place.

Upgrade source and double-click `Start-StreamerBot.bat` to synchronize portable dependencies and rebuild changed desktop files. For manual installations, rerun `Setup-Windows.ps1`. Python runtime dependencies are pinned in `uv.lock` and exported to `requirements-port.txt`. Provider models stay user-configurable. The local HTTP API and worker readiness handshake carry `api_version: 1`; the desktop host rejects incompatible workers.

```text
WinUI shell (lifecycle + OS shortcuts)
                  │ versioned local HTTP
                  ▼
Dashboard ─── Python engine ─── OBS overlay (WebSocket)
                  │
     capture → observation → commentary → speech
                  │
         settings + SQLite memory
```

The shared dashboard keeps browser and native controls consistent. Screen capture currently uses an isolated MSS adapter; a Windows Graphics Capture implementation can replace it later without changing the director or UI. HTTP was chosen for the first bridge because the same worker serves the OBS overlay and dashboard. No game-control interfaces are exposed in this phase.

## Development and verification

```bash
uv sync --all-extras --frozen
uv run ruff check streamerbot tests/port
uv run python -m unittest discover -s tests/port -v
uv run python -m streamerbot --demo
# Open http://127.0.0.1:8765/
```

To verify the actual C# worker lifecycle with an isolated demo:

```bash
dotnet run --project windows/StreamerBot.Host.Check -- /absolute/path/to/python /absolute/path/to/repo
```

The `Windows port` workflow runs engine checks and the C# bridge on Linux, then builds/publishes the WinUI application on Windows. Its Windows artifact includes `Setup-Published.ps1`: extract the complete folder, install Python/WebView2, run that script, then open `StreamerBot.Desktop.exe`.

**Verification limits:** tests and synthetic previews do not establish real-game recognition quality, Windows audio behavior or frame-rate impact on your RTX 4070 Ti. Portable provisioning and Windows packaging require verification on a Windows PC; the Linux sandbox cannot execute Windows runtimes or SDK tools. Automatic repair handles the checks described above; it cannot bypass network failures, device problems or operating-system policies. A Linux compile check is not a completed Windows build or device test. Provider contract tests use synthetic HTTP fixtures; live vision, Edge speech and YouTube require separate provider/device checks.
