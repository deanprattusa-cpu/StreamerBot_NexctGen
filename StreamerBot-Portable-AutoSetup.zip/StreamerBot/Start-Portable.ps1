[CmdletBinding()]
param(
    [switch]$Studio,
    [switch]$Dashboard,
    [switch]$PrepareOnly,
    [switch]$Repair
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
Set-Location $PSScriptRoot
. (Join-Path $PSScriptRoot 'windows/Portable-Runtime.ps1')
. (Join-Path $PSScriptRoot 'windows/Portable-Original.ps1')

function Start-PortableStudio {
    param([string]$Root, [switch]$Studio, [switch]$Dashboard, [switch]$PrepareOnly, [switch]$Repair)
    Assert-PortablePlatform $Root
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $portableHome = Join-Path $Root '.portable'
    New-Item -ItemType Directory -Path (Join-Path $portableHome 'downloads') -Force | Out-Null
    # Prevent simultaneous launchers from modifying an environment/build in use.
    $lock = $null
    try {
        try { $lock = [IO.File]::Open((Join-Path $portableHome 'launcher.lock'), 'OpenOrCreate', 'ReadWrite', 'None') }
        catch { throw 'Another portable launcher is running. Close it before starting or repairing this copy.' }
        $manifest = Get-Content -LiteralPath (Join-Path $Root 'windows/portable-runtimes.json') -Raw | ConvertFrom-Json
        if (-not $Studio -and -not $Dashboard) {
            Write-Host 'Preparing the ORIGINAL desktop interface and complete original feature set...'
            $python = Initialize-PortableOriginal $Root $portableHome $manifest -Repair:$Repair
            if (-not $PrepareOnly) { & (Join-Path $Root 'Launch-Windows.ps1') -Python $python }
            return
        }
        Write-Host 'Checking experimental Studio packages...'
        $python = Initialize-PortablePython $Root $portableHome $manifest -Repair:$Repair
        $env:STREAMERBOT_PYTHON = $python
        $browserRuntime = $null
        if (-not $Dashboard) {
            try {
                Write-Host 'Checking the Windows desktop build...'
                $null = Initialize-PortableDesktop $Root $portableHome $manifest -Repair:$Repair
                Write-Host 'Checking portable WebView2...'
                $browserRuntime = Initialize-PortableWebView $portableHome $manifest.webview2 -Repair:$Repair
            } catch {
                if ($PrepareOnly) { throw }
                Write-Warning ("Desktop preparation failed: " + $_.Exception.Message)
                Write-Host 'Opening the browser dashboard instead. Native global shortcuts are unavailable in this mode.'
                $Dashboard = $true
            }
        }
        if ($PrepareOnly) {
            Write-Host 'Portable preparation finished. Double-click Start-StreamerBot.bat to launch.'
            return
        }
        if ($Dashboard) {
            # Open only after this worker reports readiness; avoid an arbitrary startup delay.
            & (Join-Path $Root 'Launch-Dashboard.ps1') -Python $python -OpenBrowser
        } else {
            $env:WEBVIEW2_BROWSER_EXECUTABLE_FOLDER = $browserRuntime
            try { & (Join-Path $Root 'Launch-Studio.ps1') }
            catch {
                Write-Warning ("Native launch failed: " + $_.Exception.Message)
                Write-Host 'Starting the browser dashboard instead.'
                & (Join-Path $Root 'Launch-Dashboard.ps1') -Python $python -OpenBrowser
            }
        }
    } finally {
        if ($null -ne $lock) { $lock.Dispose() }
    }
}

if ($MyInvocation.InvocationName -ne '.') {
    try { Start-PortableStudio $PSScriptRoot -Studio:$Studio -Dashboard:$Dashboard -PrepareOnly:$PrepareOnly -Repair:$Repair }
    catch {
        Write-Host "`nStreamerBot could not start: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host 'Check your internet connection and free disk space, then double-click Start-StreamerBot.bat to retry.'
        Write-Host 'For a full portable repair: powershell -NoProfile -ExecutionPolicy Bypass -File .\Start-Portable.ps1 -Repair'
        exit 1
    }
}
