import os
import subprocess
import time

class SadTalkerEngine:
    def __init__(self, sadtalker_path="D:\\BARKAIMODELS\\SadTalker"):
        """
        Initializes the SadTalker video generator.
        """
        self.sadtalker_path = sadtalker_path
        self.inference_script = os.path.join(self.sadtalker_path, "inference.py")
        
    def generate_talking_head(self, audio_path, image_path, output_dir="outputs"):
        """
        Takes a .wav file and a static .png image, and uses your GPU 
        to render a fully animated .mp4 video of the avatar speaking.
        """
        if not os.path.exists(self.inference_script):
            print(f"[ERROR] SadTalker not found at {self.sadtalker_path}!")
            print("Please run install_sadtalker.bat first.")
            return None

        # Convert everything to absolute paths so Windows doesn't get lost
        abs_audio_path = os.path.abspath(audio_path)
        abs_image_path = os.path.abspath(image_path)
        abs_output_dir = os.path.abspath(output_dir)

        os.makedirs(abs_output_dir, exist_ok=True)
        print(f"[SadTalker] 🎬 Initializing GPU Video Rendering for {os.path.basename(audio_path)}...")
        
        start_time = time.time()
        
        # We use a subprocess to keep the massive rendering engine separated from the main bot
        command = [
            "python", self.inference_script,
            "--driven_audio", abs_audio_path,
            "--source_image", abs_image_path,
            "--result_dir", abs_output_dir,
            "--still", # Keeps the head mostly still/stable while the mouth moves
            "--preprocess", "full", 
            "--batch_size", "8" # ⚡ MAX SPEED: Forces your GPU to render 8 frames at once
            # 🛑 REMOVED GFPGAN: This skips the heavy 45-second post-processing step entirely!
        ]
        
        try:
            # Run the AI rendering process
            subprocess.run(command, check=True, cwd=self.sadtalker_path)
            
            elapsed = round(time.time() - start_time, 1)
            print(f"[SadTalker] ✅ Video Rendered Successfully in {elapsed} seconds!")
            
            # SadTalker outputs to a specific timestamped subfolder, we need to grab the newest .mp4
            return self._get_latest_mp4(abs_output_dir)
            
        except subprocess.CalledProcessError as e:
            print(f"[SadTalker Error] GPU Rendering Failed: {e}")
            return None

    def _get_latest_mp4(self, directory):
        """Finds the newly generated video file."""
        if not os.path.exists(directory):
            return None
            
        files = []
        for dirpath, _, filenames in os.walk(directory):
            for f in filenames:
                if f.endswith('.mp4'):
                    files.append(os.path.join(dirpath, f))
        
        if not files:
            return None
            
        # Return the most recently created video
        latest_file = max(files, key=os.path.getctime)
        return latest_file