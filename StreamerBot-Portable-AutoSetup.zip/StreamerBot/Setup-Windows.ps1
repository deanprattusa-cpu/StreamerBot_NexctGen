[CmdletBinding()]
param(
    [string]$Python = "py",
    [string[]]$PythonArguments = @("-3.12"),
    [switch]$SkipDesktop,
    [switch]$Studio
)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (-not $Studio) {
    & (Join-Path $PSScriptRoot "Start-Portable.ps1") -PrepareOnly
    return
}

function Assert-Exit([string]$Message) {
    if ($LASTEXITCODE -ne 0) { throw $Message }
}

Get-Command $Python -ErrorAction Stop | Out-Null
& $Python @PythonArguments -c "import sys; assert (3,11) <= sys.version_info[:2] < (3,15), 'Python 3.11-3.14 required'"
Assert-Exit "Install 64-bit Python 3.12, or specify -Python and -PythonArguments for another supported version."

$VenvPython = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $VenvPython)) {
    & $Python @PythonArguments -m venv .venv
    Assert-Exit "Could not create the isolated Python environment."
}
# Preparation is explicit; normal launch does not install packages or alter legacy dependencies.
& $VenvPython -m pip install --require-hashes -r requirements-port.txt
Assert-Exit "Could not install the locked streaming engine dependencies."
& $VenvPython -m pip install --no-deps .
Assert-Exit "Could not install the streaming engine dependencies."

if (-not $SkipDesktop) {
    Get-Command dotnet -ErrorAction Stop | Out-Null
    & dotnet build windows/StreamerBot.Desktop/StreamerBot.Desktop.csproj -c Release
    Assert-Exit "The Windows desktop build failed. Install the .NET 10 SDK and check the build output."
}
Write-Host "Ready. Run Launch-Windows.ps1, or Launch-Dashboard.ps1 for the browser dashboard."
