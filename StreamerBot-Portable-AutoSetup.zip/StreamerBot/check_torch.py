"""Exit 0 if PyTorch can use the GPU, 1 if not. Also: `python check_torch.py pin` writes constraints.txt
so later installs cannot swap the CUDA build for the CPU one."""
import sys
try:
    import torch
except Exception as e:
    print(f"[torch] not importable: {e}"); sys.exit(1)
ok = bool(torch.cuda.is_available())
print(f"[torch] {torch.__version__} | CUDA build: {torch.version.cuda} | GPU visible: {ok}"
      + (f" | {torch.cuda.get_device_name(0)}" if ok else ""))
if "pin" in sys.argv and ok:
    lines = [f"torch=={torch.__version__}"]
    for mod in ("torchvision", "torchaudio"):
        try:
            m = __import__(mod); lines.append(f"{mod}=={m.__version__}")
        except Exception:
            pass
    open("constraints.txt", "w").write("\n".join(lines) + "\n")
    print("[torch] pinned:", ", ".join(lines))
sys.exit(0 if ok else 1)
