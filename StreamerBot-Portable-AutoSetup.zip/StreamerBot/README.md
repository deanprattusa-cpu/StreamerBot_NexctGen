# StreamerBot — original Windows desktop app

**The default app is your original desktop interface, not the browser dashboard.** Its controller, model, view, hotkey definitions, voice menu, settings loader/saver and helper modules are preserved byte for byte from repository revision `e40eb6f47c7de169a0d895602ca07e7633733659`.

This release adds a compiled, self-contained **Windows x64 `StreamerBot.exe` launcher** and private runtime preparation around that original app. The visible interface is the original **Tkinter desktop UI**. It is not a completed WinUI 3 rewrite. No game-assistance, training or autonomous-play features are added.

## Run on Windows 11 x64

1. Extract the **complete updated ZIP** to a writable local folder.
2. Double-click **`StreamerBot.exe`**. First launch opens a preparation terminal; keep it open while dependencies download.
3. The original desktop window opens after preparation. Future launches reuse its private runtimes.

You can also double-click **`Start-StreamerBot.bat`** to see setup and application output in a terminal. No global Python or .NET installation is required. The EXE contains its .NET runtime; original-app Python, dependencies, browser runtimes and caches are prepared under `.portable/`.

This is a complete application folder, not an EXE that can be copied away from its source/runtime files. Initial setup needs internet and several GB of disk space. CUDA packages, optional native dependencies and model weights can require substantially more space and time. Model weights, reference audio, API keys and service logins are not supplied by the archive.

The main app does not run in your browser. Original YouTube/embedded-service windows and Typecast/ElevenLabs browser integrations still use browser components because those features already did.

## Keep every original setting

To retain your working setup, extract the update **into a copy of your original application folder**, keeping your original private files and model/cache folders. The download deliberately excludes credentials and live profiles, so it will not supply or replace them.

The app uses the **same original files and paths**:

- `bot_config.json`, your game `*_config.json` profiles and the original **Load Config / Save Config As** commands;
- `.env`, `credentials/`, account/channel configuration and existing browser profiles;
- voice/model paths, hotkey bindings, prompts, overrides, soundboard audio and cached speech;
- music folders/playlists and saved window/overlay geometry.

No subset importer is used and no fields are converted into the experimental dashboard schema. The original saver retains its existing behavior. Settings created only in the experimental dashboard under `%LOCALAPPDATA%\StreamerBot` are a different format; use your original profiles for this app.

## Original controls retained

- Full smart hotkeys, 15 custom slots, 12 instant-reaction slots, system/overlay/music/YouTube shortcuts and their existing per-key options.
- All 13 voice selections: ElevenLabs, Fish, Kokoro, Voicebox, TikTok, Typecast, ElevenLabs Ghost, RVC, Soprano, Edge, Google, Bark and Windows offline speech.
- Original voice presets, device/volume controls, Bark GPU/small/low-VRAM settings, voice caches and batch cache builder.
- Original AI backends/key configuration, prompt/directive/persona controls, chat/review/selector windows, microphone/STT and live-stream workflows.
- Original music players, YouTube controls, avatars, overlay/ghost windows, video-rendering bridges and tools.

The source parity inventory is in `windows/original-parity.json`. Preserving code and controls does not establish that every external service, model, driver or device works on a different machine.

### Existing source limitations

The repository baseline itself has incomplete voice paths: Soprano has no model-loader/playback implementation, RVC refers to a client that this checkout does not initialize, and the controller supplies diagnostic stubs for missing Edge/Google playback functions. This release preserves those existing paths and reports dependency problems. It does not claim to have repaired or validated those engines by displaying their menu entries.

## Dependencies and repair

The original app has its **own Python 3.11 environment** at `.portable/original/venv`, separate from the experimental port. Core Windows dependencies are pinned with hashes in `windows/original-core-lock.txt`. The original full `requirements.txt` inventory is still used for optional dependencies through an adapter to `setup_deps.py`; installs target the private venv, never `--user` or global Python.

The original `constraints.txt` names a different set of Torch package versions. For this isolated compatibility environment only, `windows/original-constraints.txt` selects a matched Torch 2.5.1 / torchvision 0.20.1 / torchaudio 2.5.1 set, CUDA 12.4 when NVIDIA tooling is detected, plus compatible NumPy/Transformers dependencies. Your original requirements/constraints and working Python environments are not rewritten. These compatibility versions intentionally prioritize the existing voice integrations over choosing the newest ML packages.

Some optional original dependencies need C++ build tools or incompatible legacy packages. Setup records failures in **`.portable/original/dependency-report.json`** and prints them; failed dependencies are not evidence that the affected feature works. It retains the complete original UI and never substitutes the reduced dashboard if original preparation fails.

For a full retry:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Start-Portable.ps1 -Repair
```

Cached failed optional installs are retried with `-Repair`. Network failures, third-party account access, model downloads, driver installation and source-level gaps cannot all be fixed by installing a runtime. Keep your existing model/cache paths to avoid unnecessary downloads.

## Repair CPU-only PyTorch / CUDA

The initial package could choose CPU Torch when `nvidia-smi` was missing from PATH, and optional dependencies could change Torch after its first check. Updated setup checks Windows video-controller names and NVIDIA PCI vendor IDs as well as NVSMI; it verifies the final environment after optional installs. An unavailable Windows GPU inventory no longer silently selects CPU-only packages.

For the RTX 4070 Ti or another supported NVIDIA card:

1. Close StreamerBot. Extract the CUDA repair update **into your existing complete app folder**, so `Repair-CUDA.bat` sits beside `StreamerBot.exe`.
2. Double-click **`Repair-CUDA.bat`** and keep its console open. It explicitly reinstalls `torch 2.5.1+cu124`, `torchvision 0.20.1+cu124` and `torchaudio 2.5.1+cu124` in `.portable/original/venv`.
3. Wait for the **CUDA tensor test passed** message. Start **`StreamerBot.exe` from the same folder**, which uses that venv. Original `run.bat` may use a different Python installation.

Results are written to `.portable/original/gpu-report.json`, including the Torch build, CUDA build and GPU name when validation succeeds. A driver/runtime/kernel failure returns an error; setup does not claim GPU success or substitute CPU Torch. The repair downloads several GB and requires internet. It preserves your profiles, model files, Bark settings and other Python installations. If **Use CPU** is deliberately enabled in the original Bark menu, change that setting yourself to use the GPU.

This repairs the PyTorch CUDA runtime packages. It does not install an NVIDIA display driver or the separate CUDA development toolkit. Those are different components; the screenshot of `2.5.1+cpu` establishes the installed Torch build, not that the system CUDA toolkit was removed. Driver compatibility and the actual tensor operation must pass on your Windows PC. Matched CUDA 12.4 wheels are documented in the [official PyTorch previous versions instructions](https://pytorch.org/get-started/previous-versions/#v251).

For intentionally CPU-only machines, set `STREAMERBOT_GPU_MODE=cpu` before normal setup. Normal default is `auto`; `Repair-CUDA.bat` always requests CUDA explicitly. Python remains part of this compatibility package; the full C# application rewrite has not been completed.

## Build the Windows EXE from source

The complete download includes a built EXE. To rebuild it with an installed .NET 10 SDK:

```powershell
dotnet publish windows/StreamerBot.Original -c Release -o .portable/original/host
Copy-Item .portable/original/host/StreamerBot.exe . -Force
```

The EXE is a small Windows process host for the preserved Python desktop app. It is self-contained with respect to .NET; the private Python runtime and application files remain part of the application folder. First-time dependency preparation is performed on the Windows PC.

## Experimental Studio

The previous WinUI/WebView2 prototype remains available explicitly with:

```powershell
.\Start-Portable.ps1 -Studio
# Browser-only experimental dashboard:
.\Start-Portable.ps1 -Dashboard
```

It has fewer features and is not the default or a parity replacement. Its previous instructions are in `docs/EXPERIMENTAL-STUDIO.md`; manual Studio setup now requires `Setup-Windows.ps1 -Studio` and uses `Launch-Studio.ps1`.

## Verification

Windows EXE cross-publishing, original-source parity, provisioning logic and synthetic checks can run in this Linux sandbox. Actual Windows launch/device behavior, all hotkey combinations and each voice/service/rendering integration still require Windows verification. A successful EXE build is not a completed device or full feature-parity test.
