@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File %~dp0switch_account.ps1
