"""Streaming orchestration. There is deliberately no game-input/control module."""

from __future__ import annotations

import asyncio
import copy
import time
from collections import deque

from .capture import ScreenCapture
from .memory import Memory
from .providers import ProviderError, Providers
from .speech import Speech
from .youtube import YouTubeChat

DEMO_MOMENTS = [
    (
        {"facts": ["A boss attack narrowly misses the player."], "emotion": "panic"},
        "That was way too close. I definitely meant to dodge that late.",
    ),
    (
        {"facts": ["The player reaches a quiet checkpoint."], "emotion": "neutral"},
        "A checkpoint. Finally, a chance to breathe before I make another questionable decision.",
    ),
    (
        {"facts": ["The player wins the encounter."], "emotion": "hype"},
        "There it is! That last attempt finally paid off.",
    ),
]


class Engine:
    def __init__(self, store, memory: Memory, providers: Providers):
        self.store = store
        self.memory = memory
        self.providers = providers
        self.config = copy.deepcopy(store.value)
        self.capture = ScreenCapture()
        self.speech = Speech(self.publish, self.error)
        self.listeners: set[asyncio.Queue] = set()
        self.log = deque(maxlen=80)
        self.queue = asyncio.PriorityQueue(maxsize=12)
        self.serial = 0
        self.tasks: list[asyncio.Task] = []
        self.running = False
        self.muted = False
        self.speaking = False
        self.active_line = ""
        self.emotion = "neutral"
        self.observation = None
        self.last_error = ""
        self.started_at = None
        self.last_vision_at = None
        self.last_reply_at = None
        self.lifecycle = asyncio.Lock()
        self.generation = 0

    def status(self) -> dict:
        return {
            "running": self.running,
            "muted": self.muted,
            "speaking": self.speaking,
            "active_line": self.active_line,
            "emotion": self.emotion,
            "mode": self.config["mode"] if self.running else self.store.value["mode"],
            "streamer_name": self.config["streamer_name"]
            if self.running
            else self.store.value["streamer_name"],
            "game_name": self.config["game_name"] if self.running else self.store.value["game_name"],
            "observation": self.observation,
            "provider": self.providers.last,
            "last_error": self.last_error,
            "started_at": self.started_at,
            "last_vision_at": self.last_vision_at,
            "last_reply_at": self.last_reply_at,
            "pending": self.queue.qsize(),
            "events": list(self.log),
        }

    async def publish(self, kind: str, payload: dict):
        if kind == "speech_start":
            self.speaking = True
            self.active_line = payload["text"]
            self.emotion = payload["emotion"]
        elif kind == "speech_end":
            self.speaking = False
            self.active_line = ""
        event = {"kind": kind, "timestamp": time.time(), "payload": payload}
        if kind not in ("speech_start", "speech_end", "status"):
            self.log.append(event)
        for listener in tuple(self.listeners):
            if listener.full():
                listener.get_nowait()
            listener.put_nowait(event)

    async def error(self, message: str):
        self.last_error = message
        await self.publish("error", {"text": message})

    async def start(self):
        async with self.lifecycle:
            if self.running:
                return
            config = copy.deepcopy(self.store.value)
            if config["mode"] == "live":
                enabled = [
                    p for p in config["providers"] if p["enabled"] and (p["keys"] or p["id"] == "local")
                ]
                if not any(p["model"] for p in enabled):
                    raise ValueError("Select an enabled commentary model and API key in Settings first.")
                if config["capture"]["enabled"] and not any(p["vision_model"] for p in enabled):
                    raise ValueError("Select a vision-capable model before enabling screen capture.")
                if config["youtube"]["enabled"] and not all(
                    config["youtube"][k].strip() for k in ("live_chat_id", "token_file")
                ):
                    raise ValueError("YouTube requires a live chat ID and an OAuth token file.")
            self.config = config
            self.capture = ScreenCapture()
            self.last_error = ""
            self.observation = None
            self.providers.last = {}
            self.started_at = time.time()
            self.running = True
            self.speech.muted = self.muted
            self.speech.start()
            self.tasks = [asyncio.create_task(self._director())]
            if config["mode"] == "demo":
                self.tasks.append(asyncio.create_task(self._demo()))
            else:
                if config["capture"]["enabled"]:
                    self.tasks.append(asyncio.create_task(self._watch()))
                if config["youtube"]["enabled"]:
                    chat = YouTubeChat(self.providers.session, self.chat, self.error)
                    self.tasks.append(asyncio.create_task(chat.run(config["youtube"])))
            await self.publish("session", {"text": f"{config['mode'].title()} session started."})

    async def stop(self):
        async with self.lifecycle:
            self.running = False
            for task in self.tasks:
                task.cancel()
            await asyncio.gather(*self.tasks, return_exceptions=True)
            self.tasks.clear()
            while not self.queue.empty():
                self.queue.get_nowait()
            await self.speech.close()
            self.observation = None
            await self.publish("session", {"text": "Session stopped."})

    async def mute(self, muted: bool):
        self.muted = muted
        self.speech.muted = muted
        if muted:
            await self.interrupt()
        await self.publish("status", {})

    async def interrupt(self):
        self.generation += 1
        while not self.queue.empty():
            self.queue.get_nowait()
        await self.speech.interrupt()

    async def submit(self, event: dict, priority=3, ttl=30):
        if not self.running:
            raise ValueError("Start a session first.")
        if self.queue.full():
            await self.publish("notice", {"text": "Reaction queue is busy; the new event was skipped."})
            return
        self.serial += 1
        self.queue.put_nowait((priority, self.serial, time.monotonic() + ttl, event))

    async def chat(self, author: str, text: str, source="dashboard"):
        event = {"type": "chat", "author": author, "text": text, "source": source}
        await self.publish("chat", event)
        if self.config["auto_reply"]:
            await self.submit(event, priority=3)

    async def reaction(self, kind: str):
        facts = {
            "death": ("The player reports that their character just died.", "sad"),
            "win": ("The player reports winning the encounter.", "hype"),
            "close": ("The player reports a narrow escape.", "panic"),
            "intro": ("The player requests a brief stream introduction.", "neutral"),
        }
        if kind not in facts:
            raise ValueError("Unknown reaction")
        fact, emotion = facts[kind]
        await self.submit(
            {"type": "reaction", "facts": [fact], "emotion": emotion, "source": "player"},
            priority=1 if kind in ("death", "win") else 2,
        )

    async def _demo(self):
        index = 0
        while True:
            observation, line = DEMO_MOMENTS[index % len(DEMO_MOMENTS)]
            self.observation = {**observation, "noteworthy": True, "source": "demo"}
            self.last_vision_at = time.time()
            await self.publish("observation", self.observation)
            await self.submit({"type": "observation", **self.observation, "demo_line": line}, priority=2)
            index += 1
            await asyncio.sleep(14)

    async def _watch(self):
        interval = 60 / self.config["capture"]["max_calls_per_min"]
        last_look = 0
        while True:
            started = time.monotonic()
            try:
                image, change = await asyncio.to_thread(self.capture.frame, self.config["capture"]["monitor"])
                if change >= 0.02 or time.monotonic() - last_look > 30:
                    observation = await self.providers.observe(self.config, image)
                    last_look = time.monotonic()
                    self.last_vision_at = time.time()
                    self.observation = {**observation, "source": "screen"}
                    self.memory.add(self.config["game_name"], "observation", self.observation)
                    await self.publish("observation", self.observation)
                    if observation["noteworthy"] and observation["facts"]:
                        await self.submit({"type": "observation", **observation}, priority=2, ttl=20)
            except asyncio.CancelledError:
                raise
            except ProviderError as exc:
                await self.error(str(exc))
            except Exception:
                await self.error(
                    "Screen capture is unavailable. Check the monitor and use borderless/windowed mode."
                )
            await asyncio.sleep(max(0.1, interval - (time.monotonic() - started)))

    async def _director(self):
        while True:
            priority, _, expires, event = await self.queue.get()
            generation = self.generation
            if expires < time.monotonic():
                continue
            try:
                if self.config["mode"] == "demo":
                    if event["type"] == "chat":
                        line = (
                            f"{event['author']}, good to have you here. Let's see how this next attempt goes."
                        )
                    else:
                        line = event.get("demo_line") or {
                            "sad": "Okay, that one got me. Let's reset and try again.",
                            "hype": "Let's go! That was the finish I wanted.",
                            "panic": "That was close. I need a second to breathe.",
                        }.get(event.get("emotion"), "I'm here, the game's ready, and we're getting started.")
                else:
                    line = await self.providers.comment(
                        self.config, event, self.memory.recent(self.config["game_name"], limit=20)
                    )
                if expires < time.monotonic() or generation != self.generation:
                    continue
                recent = [
                    r["payload"].get("text")
                    for r in self.memory.recent(self.config["game_name"], 8)
                    if r["kind"] == "commentary"
                ]
                if self.config["mode"] == "demo":
                    recent = recent[-1:]
                if line in recent:
                    continue
                payload = {
                    "text": line,
                    "emotion": event.get("emotion", "neutral"),
                    "source": event.get("source", "screen"),
                }
                self.memory.add(self.config["game_name"], "commentary", payload)
                self.last_reply_at = time.time()
                await self.publish("commentary", payload)
                speech = self.config["speech"].copy()
                if self.config["mode"] == "demo":
                    speech["engine"] = "off"
                self.speech.enqueue(
                    line, payload["emotion"], priority, speech, ttl=max(0, expires - time.monotonic())
                )
            except asyncio.CancelledError:
                raise
            except ProviderError as exc:
                await self.error(str(exc))
            except Exception:
                await self.error("Commentary could not be generated; the event was skipped.")
