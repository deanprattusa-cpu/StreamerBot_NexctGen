"""Versioned settings. Migration reads legacy files; it never changes them."""

from __future__ import annotations

import copy
import json
import math
import os
import tempfile
from pathlib import Path
from urllib.parse import urlsplit

PROVIDERS = {
    "gemini": "https://generativelanguage.googleapis.com/v1beta/openai",
    "groq": "https://api.groq.com/openai/v1",
    "openrouter": "https://openrouter.ai/api/v1",
    "sambanova": "https://api.sambanova.ai/v1",
    "local": "http://127.0.0.1:1234/v1",
}

DEFAULTS = {
    "schema_version": 1,
    "mode": "demo",
    "streamer_name": "Nova",
    "game_name": "My game",
    "game_notes": "",
    "persona": "An expressive, warm gamer with dry humor. Use natural, brief first-person commentary.",
    "max_words": 28,
    "auto_reply": True,
    "providers": [
        {"id": name, "base_url": url, "model": "", "vision_model": "", "keys": [], "enabled": False}
        for name, url in PROVIDERS.items()
    ],
    "capture": {"enabled": True, "monitor": 1, "max_calls_per_min": 6},
    "speech": {"engine": "sapi", "voice": "en-US-SteffanNeural", "volume": 0.8, "device": ""},
    "youtube": {"enabled": False, "live_chat_id": "", "token_file": ""},
    "migration": {"source": "", "notes": []},
}


def data_directory() -> Path:
    if os.name == "nt":
        return Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / "StreamerBot"
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "streamerbot"


def merge(base: dict, updates: dict) -> dict:
    result = copy.deepcopy(base)
    for key, value in updates.items():
        if key not in base:
            raise ValueError(f"Unknown settings field: {key}")
        if isinstance(base[key], dict):
            if not isinstance(value, dict):
                raise ValueError(f"{key} must be an object")
            result[key] = merge(base[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


def _number(value, low: float, high: float, name: str, integer=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name} must be a number")
    if not low <= value <= high or (integer and not isinstance(value, int)):
        raise ValueError(f"{name} must be {'an integer ' if integer else ''}between {low} and {high}")


def validate(config: dict) -> dict:
    c = merge(DEFAULTS, config)
    if type(c["schema_version"]) is not int or c["schema_version"] != 1 or c["mode"] not in ("demo", "live"):
        raise ValueError("Unsupported settings version or mode")
    for key, maximum in [("streamer_name", 80), ("game_name", 160), ("game_notes", 4000), ("persona", 4000)]:
        if not isinstance(c[key], str) or len(c[key]) > maximum:
            raise ValueError(f"{key} must be text of at most {maximum} characters")
    if not c["streamer_name"].strip() or not c["game_name"].strip():
        raise ValueError("Streamer and game names are required")
    for obj, key in [(c, "auto_reply"), (c["capture"], "enabled"), (c["youtube"], "enabled")]:
        if not isinstance(obj[key], bool):
            raise ValueError(f"{key} must be true or false")
    _number(c["max_words"], 5, 100, "max_words", integer=True)
    _number(c["capture"]["monitor"], 1, 16, "monitor", integer=True)
    _number(c["capture"]["max_calls_per_min"], 1, 30, "max_calls_per_min", integer=True)
    _number(c["speech"]["volume"], 0, 1, "volume")
    if c["speech"]["engine"] not in ("sapi", "edge", "off"):
        raise ValueError("Speech engine must be sapi, edge, or off")
    for key in ("voice", "device"):
        if not isinstance(c["speech"][key], str) or len(c["speech"][key]) > 200:
            raise ValueError(f"Invalid speech {key}")
    for key in ("live_chat_id", "token_file"):
        if not isinstance(c["youtube"][key], str) or len(c["youtube"][key]) > 1024:
            raise ValueError(f"Invalid YouTube {key}")
    migration = c["migration"]
    if (
        not isinstance(migration["source"], str)
        or len(migration["source"]) > 200
        or not isinstance(migration["notes"], list)
        or len(migration["notes"]) > 20
        or any(not isinstance(n, str) or len(n) > 500 for n in migration["notes"])
    ):
        raise ValueError("Invalid migration metadata")
    if not isinstance(c["providers"], list) or len(c["providers"]) > 10:
        raise ValueError("At most ten providers are supported")
    seen = set()
    for p in c["providers"]:
        if not isinstance(p, dict) or set(p) != {
            "id",
            "base_url",
            "model",
            "vision_model",
            "keys",
            "enabled",
        }:
            raise ValueError("Invalid provider fields")
        if p["id"] not in PROVIDERS or p["id"] in seen:
            raise ValueError("Provider ids must be supported and unique")
        seen.add(p["id"])
        if not isinstance(p["enabled"], bool):
            raise ValueError("Provider enabled must be true or false")
        for key in ("base_url", "model", "vision_model"):
            if not isinstance(p[key], str) or len(p[key]) > 500:
                raise ValueError(f"Invalid provider {key}")
        url = urlsplit(p["base_url"])
        if (
            url.scheme not in ("https", "http")
            or not url.hostname
            or url.username
            or url.password
            or url.query
            or url.fragment
        ):
            raise ValueError("Provider URL must be HTTP(S), without credentials, a query or a fragment")
        if url.scheme == "http" and url.hostname not in ("127.0.0.1", "localhost", "::1"):
            raise ValueError("Only local providers may use unencrypted HTTP")
        if not isinstance(p["keys"], list) or len(p["keys"]) > 20:
            raise ValueError("Provider keys must be a list of at most twenty strings")
        if any(not isinstance(k, str) or not k.strip() or len(k) > 1000 for k in p["keys"]):
            raise ValueError("Invalid API key")
    return c


class ConfigStore:
    def __init__(self, directory: Path):
        self.directory = directory
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.path = directory / "settings.json"
        self.value = (
            validate(json.loads(self.path.read_text("utf-8")))
            if self.path.exists()
            else copy.deepcopy(DEFAULTS)
        )

    def public(self) -> dict:
        value = copy.deepcopy(self.value)
        for p in value["providers"]:
            p["key_count"] = len(p.pop("keys"))
        return value

    def update(self, updates: dict) -> dict:
        updates = copy.deepcopy(updates)
        if "providers" in updates:
            previous = {p["id"]: p for p in self.value["providers"]}
            if not isinstance(updates["providers"], list):
                raise ValueError("Providers must be a list")
            for p in updates["providers"]:
                if not isinstance(p, dict):
                    raise ValueError("Invalid provider")
                p.pop("key_count", None)
                if "keys" not in p:
                    p["keys"] = copy.deepcopy(previous.get(p.get("id"), {}).get("keys", []))
        value = validate(merge(self.value, updates))
        descriptor, temporary = tempfile.mkstemp(dir=self.directory, prefix="settings-", suffix=".tmp")
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
                json.dump(value, stream, ensure_ascii=False, indent=2)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
        finally:
            Path(temporary).unlink(missing_ok=True)
        self.value = value
        return self.public()

    def import_legacy(self, path: Path) -> dict:
        return self.import_legacy_data(json.loads(path.read_text("utf-8-sig")), path.name)

    def import_legacy_data(self, old: dict, source_name: str) -> dict:
        if self.path.exists():
            raise ValueError("Settings already exist; use a new data directory to import without overwriting")
        if not isinstance(old, dict):
            raise ValueError("Legacy settings must be an object")
        if not isinstance(old.get("keys", {}), dict) or not isinstance(old.get("tts", {}), dict):
            raise ValueError("Invalid legacy settings structure")
        c = copy.deepcopy(DEFAULTS)
        for key in ("streamer_name", "game_name", "game_notes", "persona", "max_words"):
            if key in old:
                c[key] = old[key]
        notes = ["Imported settings stay in demo mode until you configure and select live mode."]
        for p in c["providers"]:
            keys = old.get(f"{p['id']}_keys", old.get("keys", {}).get(p["id"], []))
            if isinstance(keys, str):
                keys = [k.strip() for k in keys.split(",") if k.strip()]
            if not isinstance(keys, list):
                raise ValueError("Invalid legacy provider keys")
            p["keys"] = [k.get("key", k.get("api_key", "")) if isinstance(k, dict) else k for k in keys]
            p["keys"] = list(dict.fromkeys(k for k in p["keys"] if isinstance(k, str) and k.strip()))
            p["model"] = str(old.get(f"{p['id']}_model", ""))
            p["enabled"] = bool(p["model"] and (p["keys"] or p["id"] == "local"))
        selected = old.get("ai_mode")
        c["providers"].sort(key=lambda p: p["id"] != selected)
        engine = old.get("tts_mode", old.get("tts", {}).get("engine", "sapi"))
        if engine in ("sapi", "edge", "off"):
            c["speech"]["engine"] = engine
        else:
            notes.append(
                f"Legacy voice engine '{engine}' is available in the original app; the port uses SAPI."
            )
        voices = old.get("tts", {}).get("voices", {})
        if not isinstance(voices, dict):
            raise ValueError("Invalid legacy voice settings")
        c["speech"]["voice"] = old.get("edge_voice", voices.get("edge", c["speech"]["voice"]))
        c["speech"]["volume"] = old.get("volume", c["speech"]["volume"])
        c["auto_reply"] = old.get("automated_replies", True)
        notes.append("Review vision models and monitor selection before enabling capture.")
        c["migration"] = {"source": source_name[:200], "notes": notes}
        return self.update(c)
