"""Screen capture stays isolated from the UI and model providers."""

import base64
import io

from PIL import Image, ImageChops, ImageStat


class ScreenCapture:
    def __init__(self):
        self.previous = None

    def frame(self, monitor: int) -> tuple[str, float]:
        # MSS must be created and used on the same thread (including on Windows).
        import mss

        with mss.mss() as screens:
            if monitor >= len(screens.monitors):
                raise RuntimeError("Selected monitor is unavailable. Review capture settings.")
            shot = screens.grab(screens.monitors[monitor])
            image = Image.frombytes("RGB", shot.size, shot.rgb)
        small = image.resize((64, 36)).convert("L")
        change = 1.0
        if self.previous is not None:
            change = ImageStat.Stat(ImageChops.difference(small, self.previous)).mean[0] / 255
        self.previous = small
        image.thumbnail((960, 540))
        data = io.BytesIO()
        image.save(data, format="JPEG", quality=70)
        return base64.b64encode(data.getvalue()).decode("ascii"), change
