"""One bounded speech queue; cancellation always stops the active output."""

from __future__ import annotations

import asyncio
import heapq
import itertools
import os
import tempfile
import time
from pathlib import Path


class Speech:
    def __init__(self, publish, on_error):
        self.publish = publish
        self.on_error = on_error
        self.pending = []
        self.serial = itertools.count()
        self.wakeup = asyncio.Event()
        self.current: asyncio.Task | None = None
        self.current_priority = 999
        self.worker: asyncio.Task | None = None
        self.process = None
        self.mixer = None
        self.muted = False

    def start(self):
        self.worker = asyncio.create_task(self._run())

    def enqueue(self, text: str, emotion: str, priority: int, config: dict, *, ttl=20):
        if self.muted:
            return
        item = (priority, next(self.serial), time.monotonic() + ttl, text, emotion, config.copy())
        if len(self.pending) >= 8:
            worst = max(self.pending, key=lambda x: (x[0], -x[1]))
            if priority >= worst[0]:
                return
            self.pending.remove(worst)
            heapq.heapify(self.pending)
        heapq.heappush(self.pending, item)
        if self.current and priority < self.current_priority:
            self.current.cancel()
        self.wakeup.set()

    async def interrupt(self):
        self.pending.clear()
        if self.current:
            self.current.cancel()
            await asyncio.gather(self.current, return_exceptions=True)
        await self.publish("speech_end", {})

    async def close(self):
        await self.interrupt()
        if self.worker:
            self.worker.cancel()
            await asyncio.gather(self.worker, return_exceptions=True)
            self.worker = None
        if self.mixer:
            self.mixer.quit()
            self.mixer = None

    async def _run(self):
        while True:
            await self.wakeup.wait()
            while self.pending:
                priority, _, expires, text, emotion, config = heapq.heappop(self.pending)
                if expires < time.monotonic() or self.muted:
                    continue
                self.current_priority = priority
                self.current = asyncio.create_task(self._speak(text, emotion, config))
                try:
                    await self.current
                except asyncio.CancelledError:
                    if asyncio.current_task().cancelling():
                        raise
                except Exception:
                    await self.on_error("Speech failed. Check the selected engine and audio output.")
                finally:
                    self.current = None
                    self.current_priority = 999
            self.wakeup.clear()

    async def _speak(self, text: str, emotion: str, config: dict):
        engine = config["engine"]
        try:
            if engine == "edge":
                import edge_tts
                import pygame

                with tempfile.TemporaryDirectory(prefix="streamerbot-voice-") as directory:
                    path = Path(directory) / "line.mp3"
                    await edge_tts.Communicate(text, config["voice"]).save(str(path))
                    if self.mixer is None:
                        self.mixer = pygame.mixer
                    self.mixer.quit()
                    self.mixer.init(devicename=config["device"] or None)
                    self.mixer.music.load(str(path))
                    self.mixer.music.set_volume(config["volume"])
                    await self.publish("speech_start", {"text": text, "emotion": emotion})
                    self.mixer.music.play()
                    try:
                        while self.mixer.music.get_busy():
                            await asyncio.sleep(0.04)
                    finally:
                        self.mixer.music.stop()
                        self.mixer.music.unload()
            elif engine == "sapi":
                if os.name != "nt":
                    raise RuntimeError("Windows SAPI is only available on Windows")
                # Speech text is passed through stdin, never interpolated into PowerShell code.
                script = (
                    "Add-Type -AssemblyName System.Speech; "
                    "[Console]::InputEncoding = New-Object System.Text.UTF8Encoding; "
                    "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                    f"$s.Volume = {round(config['volume'] * 100)}; "
                    "$s.Speak([Console]::In.ReadToEnd()); $s.Dispose()"
                )
                self.process = await asyncio.create_subprocess_exec(
                    "powershell.exe",
                    "-NoProfile",
                    "-NonInteractive",
                    "-Command",
                    script,
                    stdin=asyncio.subprocess.PIPE,
                    stdout=asyncio.subprocess.DEVNULL,
                    stderr=asyncio.subprocess.DEVNULL,
                    creationflags=0x08000000,
                )
                await self.publish("speech_start", {"text": text, "emotion": emotion})
                await self.process.communicate(text.encode("utf-8"))
                if self.process.returncode:
                    raise RuntimeError("SAPI failed")
            else:
                await self.publish("speech_start", {"text": text, "emotion": emotion})
                await asyncio.sleep(min(8, max(1.5, len(text.split()) / 3)))
        finally:
            if self.process:
                if self.process.returncode is None:
                    self.process.kill()
                    await self.process.wait()
                self.process = None
            await self.publish("speech_end", {})
