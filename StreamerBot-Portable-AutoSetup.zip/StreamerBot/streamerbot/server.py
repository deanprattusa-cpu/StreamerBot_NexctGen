"""Local, versioned HTTP bridge shared by WinUI, the dashboard and OBS."""

from __future__ import annotations

import asyncio
import json
import secrets
from pathlib import Path
from urllib.parse import urlsplit

from aiohttp import web

from . import API_VERSION, __version__

WEB = Path(__file__).parent / "web"


def create_app(
    engine,
    *,
    public_preview=False,
    demo_locked=False,
    avatar: Path | None = None,
    shutdown=None,
    owner_token="",
) -> web.Application:
    @web.middleware
    async def boundary(request, handler):
        if not public_preview and request.url.host not in ("localhost", "127.0.0.1", "::1"):
            raise web.HTTPForbidden(text="Local access only")
        origin = request.headers.get("Origin")
        if origin and urlsplit(origin).netloc != request.host:
            raise web.HTTPForbidden(text="Origin is not allowed")
        if request.method not in ("GET", "HEAD"):
            if request.headers.get("X-StreamerBot-Client") != "dashboard":
                raise web.HTTPForbidden(text="Client header required")
            if request.content_type != "application/json":
                raise web.HTTPUnsupportedMediaType(text="JSON required")
        try:
            response = await handler(request)
        except (ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
            # ValueErrors are deliberately written without request values or provider response bodies.
            return web.json_response(
                {
                    "error": str(exc)
                    if isinstance(exc, ValueError) and not isinstance(exc, json.JSONDecodeError)
                    else "Invalid request"
                },
                status=400,
            )
        except web.HTTPException:
            raise
        except Exception:
            return web.json_response(
                {"error": "The operation failed. Check settings and try again."}, status=500
            )
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Cache-Control"] = "no-store"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            "connect-src 'self'; media-src 'self'; frame-ancestors 'self'; base-uri 'none'"
        )
        return response

    app = web.Application(middlewares=[boundary], client_max_size=128 * 1024)

    async def health(request):
        return web.json_response({"api_version": API_VERSION, "version": __version__, "status": "ready"})

    async def state(request):
        return web.json_response(
            {
                "api_version": API_VERSION,
                "status": engine.status(),
                "public_preview": public_preview,
                "demo_locked": demo_locked or public_preview,
            }
        )

    async def history(request):
        game = engine.config["game_name"] if engine.running else engine.store.value["game_name"]
        return web.json_response({"game": game, "events": engine.memory.recent(game, 50)})

    async def settings(request):
        if request.method == "GET":
            return web.json_response(engine.store.public())
        if engine.running:
            raise ValueError("Stop the session before changing settings.")
        data = await request.json()
        if not isinstance(data, dict):
            raise ValueError("Settings must be an object")
        if (demo_locked or public_preview) and (
            data.get("mode", "demo") != "demo" or "providers" in data or "youtube" in data
        ):
            raise ValueError("The shared preview only supports synthetic demo data.")
        return web.json_response(engine.store.update(data))

    async def start(request):
        await engine.start()
        return web.json_response(engine.status())

    async def import_settings(request):
        if demo_locked or public_preview:
            raise ValueError("Settings import is disabled in the isolated demo.")
        if engine.running:
            raise ValueError("Stop the session before importing settings.")
        data = await request.json()
        if not isinstance(data, dict) or not isinstance(data.get("name"), str):
            raise ValueError("Select a legacy JSON settings file")
        return web.json_response(engine.store.import_legacy_data(data.get("settings"), data["name"]))

    async def stop(request):
        await engine.stop()
        return web.json_response(engine.status())

    async def mute(request):
        data = await request.json()
        if not isinstance(data, dict) or not isinstance(data.get("muted"), bool):
            raise ValueError("muted must be true or false")
        await engine.mute(data["muted"])
        return web.json_response(engine.status())

    async def interrupt(request):
        await engine.interrupt()
        return web.json_response({"ok": True})

    async def chat(request):
        data = await request.json()
        if not isinstance(data, dict):
            raise ValueError("Chat must be an object")
        author, text = data.get("author", "You"), data.get("text", "")
        if not isinstance(author, str) or not 1 <= len(author.strip()) <= 80:
            raise ValueError("Author must contain 1–80 characters")
        if not isinstance(text, str) or not 1 <= len(text.strip()) <= 1000:
            raise ValueError("Message must contain 1–1000 characters")
        if not engine.running:
            raise ValueError("Start a session first.")
        await engine.chat(author.strip(), text.strip())
        return web.json_response({"ok": True})

    async def reaction(request):
        data = await request.json()
        if not isinstance(data, dict) or not isinstance(data.get("kind"), str):
            raise ValueError("A reaction kind is required")
        await engine.reaction(data["kind"])
        return web.json_response({"ok": True})

    async def events(request):
        socket = web.WebSocketResponse(heartbeat=20, max_msg_size=1024)
        await socket.prepare(request)
        listener = asyncio.Queue(maxsize=32)
        engine.listeners.add(listener)
        sender = None
        try:
            await socket.send_json({"kind": "snapshot", "payload": engine.status()})

            async def send():
                while True:
                    await socket.send_json(await listener.get())

            sender = asyncio.create_task(send())
            async for _ in socket:
                pass
        finally:
            engine.listeners.discard(listener)
            if sender:
                sender.cancel()
                await asyncio.gather(sender, return_exceptions=True)
        return socket

    async def asset(request):
        name = request.match_info["name"]
        if name not in ("app.js", "overlay.js", "style.css", "avatar.svg"):
            raise web.HTTPNotFound()
        return web.FileResponse(WEB / name)

    async def image(request):
        return web.FileResponse(avatar if avatar and avatar.is_file() else WEB / "avatar.svg")

    async def dashboard(request):
        return web.FileResponse(WEB / "index.html")

    async def overlay(request):
        return web.FileResponse(WEB / "overlay.html")

    async def end_process(request):
        supplied = request.headers.get("X-StreamerBot-Owner", "")
        if not owner_token or not secrets.compare_digest(supplied, owner_token):
            raise web.HTTPForbidden()
        if shutdown:
            shutdown.set()
        return web.json_response({"ok": True})

    app.router.add_get("/api/health", health)
    app.router.add_get("/api/state", state)
    app.router.add_get("/api/history", history)
    app.router.add_get("/api/settings", settings)
    app.router.add_put("/api/settings", settings)
    app.router.add_post("/api/import", import_settings)
    app.router.add_post("/api/session/start", start)
    app.router.add_post("/api/session/stop", stop)
    app.router.add_post("/api/mute", mute)
    app.router.add_post("/api/interrupt", interrupt)
    app.router.add_post("/api/chat", chat)
    app.router.add_post("/api/reaction", reaction)
    app.router.add_post("/api/shutdown", end_process)
    app.router.add_get("/api/events", events)
    app.router.add_get("/assets/{name}", asset)
    app.router.add_get("/avatar", image)
    app.router.add_get("/", dashboard)
    app.router.add_get("/overlay", overlay)
    return app
