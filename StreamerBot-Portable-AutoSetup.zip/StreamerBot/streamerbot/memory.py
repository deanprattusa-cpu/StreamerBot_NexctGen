"""Small durable event history, scoped to game and session."""

import json
import sqlite3
import time
import uuid
from pathlib import Path


class Memory:
    def __init__(self, path: Path):
        self.db = sqlite3.connect(path)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("""CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY, session TEXT NOT NULL, game TEXT NOT NULL,
            kind TEXT NOT NULL, timestamp REAL NOT NULL, payload TEXT NOT NULL)""")
        self.db.execute("CREATE INDEX IF NOT EXISTS events_game ON events(game, id)")
        self.db.commit()
        self.session = uuid.uuid4().hex

    def add(self, game: str, kind: str, payload: dict):
        self.db.execute(
            "INSERT INTO events(session,game,kind,timestamp,payload) VALUES(?,?,?,?,?)",
            (self.session, game, kind, time.time(), json.dumps(payload, ensure_ascii=False)),
        )
        # Keep a bounded history without deleting another game's most recent events first.
        self.db.execute(
            "DELETE FROM events WHERE id IN (SELECT id FROM events ORDER BY id DESC LIMIT -1 OFFSET 10000)"
        )
        self.db.commit()

    def recent(self, game: str, limit: int = 30) -> list[dict]:
        rows = self.db.execute(
            "SELECT kind,timestamp,payload FROM events WHERE game=? ORDER BY id DESC LIMIT ?", (game, limit)
        ).fetchall()
        return [
            {"kind": kind, "timestamp": stamp, "payload": json.loads(payload)}
            for kind, stamp, payload in reversed(rows)
        ]

    def close(self):
        self.db.close()
