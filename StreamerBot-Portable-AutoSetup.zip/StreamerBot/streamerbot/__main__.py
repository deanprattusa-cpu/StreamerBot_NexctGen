"""Entry point for both the Windows shell and a standalone local dashboard."""

import argparse
import asyncio
import json
import os
import signal
import tempfile
import webbrowser
from pathlib import Path

import aiohttp
from aiohttp import web

from . import API_VERSION
from .config import ConfigStore, data_directory
from .engine import Engine
from .memory import Memory
from .providers import Providers
from .server import create_app


async def serve(args):
    temporary = (
        tempfile.TemporaryDirectory(prefix="streamerbot-demo-") if args.demo and not args.data_dir else None
    )
    directory = Path(args.data_dir or (temporary.name if temporary else data_directory())).resolve()
    if args.demo and args.data_dir:
        directory = directory / "demo"
    store = ConfigStore(directory)
    if args.import_legacy:
        store.import_legacy(Path(args.import_legacy))
    if args.demo:
        # Demo never exposes or uses credentials from a previous live configuration.
        store.value["mode"] = "demo"
        store.value["providers"] = []
        store.value["youtube"] = {"enabled": False, "live_chat_id": "", "token_file": ""}
    memory = Memory(directory / "memory.sqlite3")
    stopped = asyncio.Event()
    try:
        loop = asyncio.get_running_loop()
        for name in ("SIGINT", "SIGTERM"):
            try:
                loop.add_signal_handler(getattr(signal, name), stopped.set)
            except (NotImplementedError, ValueError):
                pass
        async with aiohttp.ClientSession(trust_env=False) as session:
            engine = Engine(store, memory, Providers(session))
            app = create_app(
                engine,
                public_preview=args.public_preview,
                demo_locked=args.demo,
                avatar=Path(args.avatar).resolve() if args.avatar else None,
                shutdown=stopped,
                owner_token=os.environ.get("SB_DESKTOP_TOKEN", ""),
            )
            runner = web.AppRunner(app, access_log=None, shutdown_timeout=2)
            await runner.setup()
            try:
                site = web.TCPSite(runner, args.host, args.port)
                await site.start()
                port = site._server.sockets[0].getsockname()[1]
                print(
                    json.dumps(
                        {"event": "ready", "api_version": API_VERSION, "url": f"http://127.0.0.1:{port}/"}
                    ),
                    flush=True,
                )
                if args.open_browser:
                    await asyncio.to_thread(webbrowser.open, f"http://127.0.0.1:{port}/")
                await stopped.wait()
            finally:
                await engine.stop()
                await runner.cleanup()
    finally:
        memory.close()
        if temporary:
            temporary.cleanup()


def main():
    parser = argparse.ArgumentParser(description="StreamerBot desktop streaming engine")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--data-dir")
    parser.add_argument("--avatar", help="Path to the avatar image (not uploaded to an AI provider)")
    parser.add_argument(
        "--open-browser", action="store_true", help="Open the dashboard after the server is ready"
    )
    parser.add_argument("--import-legacy", help="Read v1/v2 JSON settings into a new data directory")
    parser.add_argument(
        "--demo", action="store_true", help="Synthetic offline session; no capture, API or speech calls"
    )
    parser.add_argument(
        "--public-preview", action="store_true", help="Allow a shared cloud preview, demo only"
    )
    args = parser.parse_args()
    if args.public_preview and not args.demo:
        parser.error("--public-preview requires --demo")
    if args.host not in ("127.0.0.1", "localhost", "::1") and not args.public_preview:
        parser.error("Non-loopback binding is only supported for a synthetic --demo --public-preview")
    if not 0 <= args.port <= 65535:
        parser.error("Port must be between 0 and 65535")
    try:
        asyncio.run(serve(args))
    except KeyboardInterrupt:
        pass
    except (ValueError, OSError):
        parser.exit(
            1, "Unable to start. Check the data directory, settings format, import source and port.\n"
        )


if __name__ == "__main__":
    main()
