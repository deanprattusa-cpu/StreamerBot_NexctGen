"""Read-only YouTube live chat. Uses an explicit OAuth token file, never posts."""

import asyncio
from pathlib import Path

import aiohttp


class YouTubeChat:
    def __init__(self, session: aiohttp.ClientSession, submit, on_error):
        self.session = session
        self.submit = submit
        self.on_error = on_error

    @staticmethod
    def _credentials(path: str):
        from google.auth.transport.requests import Request
        from google.oauth2.credentials import Credentials

        credentials = Credentials.from_authorized_user_file(str(Path(path).expanduser()))
        if not credentials.valid:
            credentials.refresh(Request())
        return credentials

    async def run(self, settings: dict):
        page = None
        first = True
        seen = set()
        failures = 0
        while True:
            try:
                credentials = await asyncio.to_thread(self._credentials, settings["token_file"])
                params = {
                    "liveChatId": settings["live_chat_id"],
                    "part": "snippet,authorDetails",
                    "maxResults": "200",
                }
                if page:
                    params["pageToken"] = page
                async with self.session.get(
                    "https://www.googleapis.com/youtube/v3/liveChat/messages",
                    params=params,
                    headers={"Authorization": f"Bearer {credentials.token}"},
                    timeout=aiohttp.ClientTimeout(total=15),
                    allow_redirects=False,
                ) as response:
                    if response.status != 200:
                        raise RuntimeError("YouTube rejected the request")
                    data = await response.json()
                for item in data.get("items", []):
                    identity = item.get("id")
                    if not identity or identity in seen:
                        continue
                    seen.add(identity)
                    if first or item.get("snippet", {}).get("type") != "textMessageEvent":
                        continue
                    snippet = item["snippet"]
                    author = item.get("authorDetails", {}).get("displayName", "Viewer")
                    await self.submit(author[:80], snippet.get("displayMessage", "")[:1000], source="youtube")
                if len(seen) > 2000:
                    seen = {i["id"] for i in data.get("items", []) if "id" in i}
                first = False
                page = data.get("nextPageToken")
                failures = 0
                await asyncio.sleep(max(1, float(data.get("pollingIntervalMillis", 5000)) / 1000))
            except asyncio.CancelledError:
                raise
            except Exception:
                failures += 1
                await self.on_error(
                    "YouTube chat is unavailable. Check chat ID, OAuth token and optional dependencies."
                )
                await asyncio.sleep(min(60, 5 * 2 ** min(failures, 4)))
