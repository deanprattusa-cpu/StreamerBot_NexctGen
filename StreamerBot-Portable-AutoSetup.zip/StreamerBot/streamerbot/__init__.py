"""StreamerBot's modular desktop streaming engine."""

__version__ = "0.1.0"
API_VERSION = 1
