"use strict";

const $ = (id) => document.getElementById(id);
let settings = null;
let state = null;
let demoLocked = false;
let busy = false;
let lastEvents = "";
let toastTimer;

function toast(message) {
  $("toast").textContent = message;
  $("toast").hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    $("toast").hidden = true;
  }, 4500);
}

async function api(path, method = "GET", body) {
  const response = await fetch(`/api/${path}`, {
    method,
    headers: {
      "X-StreamerBot-Client": "dashboard",
      ...(method !== "GET" ? { "Content-Type": "application/json" } : {}),
    },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  });
  let data;
  try {
    data = await response.json();
  } catch {
    throw new Error("The engine returned an invalid response.");
  }
  if (!response.ok)
    throw new Error(data.error || "The operation could not be completed.");
  return data;
}

function page(name) {
  for (const element of document.querySelectorAll(".page"))
    element.hidden = element.id !== `page-${name}`;
  for (const button of document.querySelectorAll(".nav-button"))
    button.classList.toggle("active", button.dataset.page === name);
  $("page-title").textContent = {
    studio: "Live studio",
    settings: "Settings",
    history: "Session history",
  }[name];
  if (name === "history") loadHistory().catch((error) => toast(error.message));
}
for (const button of document.querySelectorAll("[data-page]"))
  button.addEventListener("click", () => page(button.dataset.page));

function eventRow(event) {
  const row = document.createElement("div");
  row.className = "event-row";
  row.dataset.kind = event.kind;
  const icon = document.createElement("span");
  icon.className = "event-icon";
  icon.textContent =
    { observation: "◉", commentary: "✧", chat: "↳", error: "!", session: "◌" }[
      event.kind
    ] || "·";
  const body = document.createElement("div");
  body.className = "event-body";
  const title = document.createElement("div");
  title.className = "event-title";
  const label = document.createElement("span");
  label.textContent =
    {
      observation: "OBSERVATION",
      commentary: "CHARACTER",
      chat: event.payload.author || "VIEWER",
      error: "ENGINE",
      session: "SESSION",
    }[event.kind] || "NOTICE";
  const time = document.createElement("time");
  time.textContent = new Date(event.timestamp * 1000).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
  const content = document.createElement("p");
  content.textContent =
    event.payload.text || (event.payload.facts || []).join(" ");
  title.append(label, time);
  body.append(title, content);
  row.append(icon, body);
  return row;
}

function render(current) {
  state = current;
  const running = current.running;
  const demo = current.mode === "demo";
  $("start").disabled = busy || running;
  $("stop").disabled = busy || !running;
  $("interrupt").disabled = !running;
  for (const button of document.querySelectorAll("[data-reaction]"))
    button.disabled = !running;
  $("chat-message").disabled = !running;
  $("chat-form").querySelector("button").disabled = !running;
  $("session-badge").textContent = running
    ? demo
      ? "DEMO RUNNING"
      : "SESSION RUNNING"
    : "STANDBY";
  $("session-badge").classList.toggle("live", running);
  $("demo-banner").hidden = !demo;
  $("character-name").textContent = current.streamer_name;
  $("game-name").textContent = current.game_name;
  $("mode-detail").textContent = demo
    ? "Demo · synthetic game moments"
    : "Live · player controls the game";
  $("vision-source").textContent = demo
    ? "Demo scenes"
    : settings?.capture.enabled
      ? "Screen capture"
      : "Manual events";
  $("provider-name").textContent = demo
    ? "Offline demo"
    : current.provider.provider || "Waiting for model";
  $("latency").textContent = current.provider.latency_ms
    ? `${current.provider.latency_ms.toLocaleString()} ms`
    : "—";
  $("caption").textContent =
    current.active_line ||
    (running ? "Watching for the next moment…" : "Ready when you are.");
  $("avatar").classList.toggle("talking", current.speaking);
  $("emotion-label").textContent = current.emotion;
  $("speech-dot").classList.toggle("connected", current.speaking);
  $("speech-status").textContent = current.muted
    ? "Character muted"
    : current.speaking
      ? demo || settings?.speech.engine === "off"
        ? "Caption preview"
        : "Character speaking"
      : running
        ? "Listening for the next moment"
        : "Waiting for a session";
  $("mute").setAttribute("aria-pressed", String(current.muted));
  $("mute").setAttribute(
    "aria-label",
    current.muted ? "Unmute character speech" : "Mute character speech",
  );
  $("mute").textContent = current.muted ? "♪̸" : "♫";
  $("settings-fields").disabled = running;
  $("save-settings").disabled = running;
  $("settings-lock").hidden = !running;
  $("engine-error").hidden = !current.last_error;
  $("engine-error").textContent = current.last_error;
  const facts = current.observation?.facts || [];
  $("facts-label").textContent = current.observation
    ? demo
      ? "SYNTHETIC DEMO"
      : "LATEST FRAME"
    : "WAITING";
  $("facts").replaceChildren(
    ...(facts.length ? facts : ["Observed game facts will appear here."]).map(
      (fact) => {
        const item = document.createElement("li");
        item.textContent = fact;
        return item;
      },
    ),
  );
  const identity = JSON.stringify(current.events);
  if (identity !== lastEvents) {
    lastEvents = identity;
    $("event-count").textContent = current.events.length;
    if (current.events.length) {
      $("activity").replaceChildren(...current.events.map(eventRow));
      $("activity").scrollTop = $("activity").scrollHeight;
    }
  }
}

async function refresh() {
  try {
    const data = await api("state");
    if (data.api_version !== 1)
      throw new Error("Engine version mismatch. Restart the desktop app.");
    demoLocked = data.demo_locked;
    $("connection-error").hidden = true;
    $("connection-dot").classList.add("connected");
    $("connection-label").textContent = "Engine connected";
    render(data.status);
  } catch {
    $("connection-error").hidden = false;
    $("connection-dot").classList.remove("connected");
    $("connection-label").textContent = "Engine disconnected";
    $("start").disabled = true;
    $("stop").disabled = true;
  }
}

async function action(path, body = {}) {
  if (busy) return;
  busy = true;
  if (state) render(state);
  try {
    await api(path, "POST", body);
  } catch (error) {
    toast(error.message);
  } finally {
    busy = false;
    await refresh();
  }
}
$("start").addEventListener("click", () => action("session/start"));
$("stop").addEventListener("click", () => action("session/stop"));
$("mute").addEventListener("click", () =>
  action("mute", { muted: !state?.muted }),
);
$("interrupt").addEventListener("click", () => action("interrupt"));
for (const button of document.querySelectorAll("[data-reaction]"))
  button.addEventListener("click", () =>
    action("reaction", { kind: button.dataset.reaction }),
  );
$("chat-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const text = $("chat-message").value.trim();
  if (!text || busy) return;
  try {
    await api("chat", "POST", { author: "You", text });
    $("chat-message").value = "";
    await refresh();
  } catch (error) {
    toast(error.message);
  }
});

$("overlay-url").value = new URL("/overlay", location.href).href;
$("copy-overlay").addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText($("overlay-url").value);
    toast("Overlay URL copied.");
  } catch {
    $("overlay-url").select();
    toast("Select and copy the overlay URL.");
  }
});

function inputLabel(label, name, value, type = "text") {
  const wrapper = document.createElement("label");
  wrapper.textContent = label;
  const input = document.createElement("input");
  input.name = name;
  input.type = type;
  input.value = value;
  input.maxLength = type === "password" ? 20000 : 500;
  if (type === "password") {
    input.autocomplete = "new-password";
    input.placeholder = "Leave blank to retain saved keys";
  }
  wrapper.append(input);
  return wrapper;
}

function loadForm(value) {
  settings = value;
  const form = $("settings-form");
  for (const key of [
    "streamer_name",
    "game_name",
    "game_notes",
    "persona",
    "mode",
    "max_words",
  ])
    form.elements[key].value = value[key];
  form.elements.auto_reply.checked = value.auto_reply;
  form.elements.capture_enabled.checked = value.capture.enabled;
  form.elements.monitor.value = value.capture.monitor;
  form.elements.vision_rate.value = value.capture.max_calls_per_min;
  form.elements.speech_engine.value = value.speech.engine;
  form.elements.voice.value = value.speech.voice;
  form.elements.volume.value = value.speech.volume;
  form.elements.device.value = value.speech.device;
  form.elements.youtube_enabled.checked = value.youtube.enabled;
  form.elements.live_chat_id.value = value.youtube.live_chat_id;
  form.elements.token_file.value = value.youtube.token_file;
  $("provider-fields").replaceChildren();
  $("primary-provider").replaceChildren();
  for (const p of value.providers) {
    const option = document.createElement("option");
    option.value = p.id;
    option.textContent = p.id;
    $("primary-provider").append(option);
    const section = document.createElement("div");
    section.className = "provider-block";
    section.dataset.provider = p.id;
    const head = document.createElement("div");
    head.className = "provider-head";
    const heading = document.createElement("h3");
    heading.textContent = p.id;
    const enabled = document.createElement("label");
    enabled.className = "check-label";
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.name = `${p.id}_enabled`;
    checkbox.checked = p.enabled;
    enabled.append(checkbox, document.createTextNode("Enabled"));
    head.append(heading, enabled);
    const grid = document.createElement("div");
    grid.className = "provider-grid";
    grid.append(
      inputLabel("API base URL", `${p.id}_url`, p.base_url),
      inputLabel("Commentary model ID", `${p.id}_model`, p.model),
      inputLabel("Vision model ID", `${p.id}_vision`, p.vision_model),
      inputLabel("API keys (comma-separated)", `${p.id}_keys`, "", "password"),
    );
    const note = document.createElement("div");
    note.className = "key-note";
    const count = document.createElement("span");
    count.textContent = `${p.key_count} saved key${p.key_count === 1 ? "" : "s"}`;
    const clear = document.createElement("button");
    clear.type = "button";
    clear.className = "clear-keys";
    clear.textContent = "Clear saved keys";
    clear.addEventListener("click", () => {
      section.dataset.clearKeys = "true";
      count.textContent = "Keys will be cleared on save";
    });
    note.append(count, clear);
    section.append(head, grid, note);
    $("provider-fields").append(section);
  }
  if (value.providers.length)
    $("primary-provider").value = value.providers[0].id;
  $("migration-notes").hidden = !value.migration.notes.length;
  $("migration-notes").textContent = value.migration.notes.join(" ");
  if (demoLocked) {
    form.elements.mode.querySelector('[value="live"]').disabled = true;
    $("provider-fields").textContent =
      "Connections are disabled in this isolated demo. Restart without --demo to configure live providers.";
    $("primary-provider").disabled = true;
    form.elements.youtube_enabled.disabled = true;
    $("legacy-file").disabled = true;
    $("import-settings").disabled = true;
    $("import-status").textContent =
      "Import is disabled in this isolated demo. Restart without --demo to import your settings.";
  }
}

$("import-settings").addEventListener("click", async () => {
  const file = $("legacy-file").files[0];
  if (!file) {
    toast("Select your legacy JSON settings file first.");
    return;
  }
  if (file.size > 100000) {
    toast("The settings file must be smaller than 100 KB.");
    return;
  }
  try {
    const imported = await api("import", "POST", {
      name: file.name,
      settings: JSON.parse(await file.text()),
    });
    loadForm(imported);
    $("import-status").textContent =
      "Settings imported. Review your models and capture settings before using live mode.";
    toast("Settings imported; the original file is unchanged.");
    await refresh();
  } catch (error) {
    $("import-status").textContent = error.message;
  }
});

$("settings-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const values = new FormData(form);
  const update = {
    streamer_name: values.get("streamer_name"),
    game_name: values.get("game_name"),
    game_notes: values.get("game_notes"),
    persona: values.get("persona"),
    mode: values.get("mode"),
    max_words: Number(values.get("max_words")),
    auto_reply: form.elements.auto_reply.checked,
    capture: {
      enabled: form.elements.capture_enabled.checked,
      monitor: Number(values.get("monitor")),
      max_calls_per_min: Number(values.get("vision_rate")),
    },
    speech: {
      engine: values.get("speech_engine"),
      voice: values.get("voice"),
      volume: Number(values.get("volume")),
      device: values.get("device"),
    },
  };
  if (!demoLocked) {
    update.youtube = {
      enabled: form.elements.youtube_enabled.checked,
      live_chat_id: values.get("live_chat_id"),
      token_file: values.get("token_file"),
    };
    update.providers = settings.providers.map((p) => {
      const entry = {
        id: p.id,
        enabled: form.elements[`${p.id}_enabled`].checked,
        base_url: values.get(`${p.id}_url`),
        model: values.get(`${p.id}_model`),
        vision_model: values.get(`${p.id}_vision`),
      };
      const keys = values.get(`${p.id}_keys`).trim();
      const section = document.querySelector(`[data-provider="${p.id}"]`);
      if (keys)
        entry.keys = keys
          .split(",")
          .map((key) => key.trim())
          .filter(Boolean);
      else if (section.dataset.clearKeys === "true") entry.keys = [];
      return entry;
    });
    const primary = $("primary-provider").value;
    update.providers.sort(
      (a, b) => Number(b.id === primary) - Number(a.id === primary),
    );
  }
  $("save-settings").disabled = true;
  try {
    loadForm(await api("settings", "PUT", update));
    $("settings-status").textContent = "Settings saved";
    toast("Settings saved.");
    await refresh();
  } catch (error) {
    $("settings-status").textContent = error.message;
  } finally {
    $("save-settings").disabled = Boolean(state?.running);
  }
});

async function loadHistory() {
  const data = await api("history");
  $("history-game").textContent = data.game;
  if (data.events.length)
    $("history-list").replaceChildren(...data.events.reverse().map(eventRow));
  else {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = "No saved moments for this game yet.";
    $("history-list").replaceChildren(empty);
  }
}
$("refresh-history").addEventListener("click", () =>
  loadHistory().catch((error) => toast(error.message)),
);

async function boot() {
  await refresh();
  try {
    loadForm(await api("settings"));
  } catch (error) {
    toast(error.message);
  }
  // A single sequential poll prevents requests accumulating when the engine is slow or disconnected.
  while (true) {
    await new Promise((resolve) => setTimeout(resolve, 1000));
    await refresh();
  }
}
boot();
