"use strict";
const avatar = document.getElementById("overlay-avatar");
const caption = document.getElementById("overlay-caption");
const captions = new URLSearchParams(location.search).get("captions") !== "0";
let reconnect;
function show(text, speaking) {
  avatar.classList.toggle("talking", speaking);
  caption.textContent = captions ? text : "";
}
function connect() {
  const url = new URL("/api/events", location.href);
  url.protocol = location.protocol === "https:" ? "wss:" : "ws:";
  const socket = new WebSocket(url);
  socket.onopen = () => {
    document.getElementById("overlay-connection").hidden = true;
  };
  socket.onmessage = (message) => {
    const event = JSON.parse(message.data);
    if (event.kind === "snapshot")
      show(event.payload.active_line, event.payload.speaking);
    if (event.kind === "speech_start") show(event.payload.text, true);
    if (event.kind === "speech_end") show("", false);
  };
  socket.onclose = () => {
    show("", false);
    document.getElementById("overlay-connection").hidden = false;
    clearTimeout(reconnect);
    reconnect = setTimeout(connect, 2000);
  };
  socket.onerror = () => socket.close();
}
connect();
