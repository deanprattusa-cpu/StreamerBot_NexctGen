@echo off
title Batch Video Cache Generator
color 0d

echo Starting Batch Video Generator...
python batch_video_generator.py

pause