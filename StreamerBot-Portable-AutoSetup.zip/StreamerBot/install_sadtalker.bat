@echo off
title SadTalker Auto-Installer
color 0b

echo ===================================================
echo Downloading SadTalker Repository...
echo ===================================================
echo.

cd /d D:\BARKAIMODELS
:: Download the SadTalker repository safely
if not exist "SadTalker" (
git clone https://github.com/OpenTalker/SadTalker.git
)

cd SadTalker

echo.
echo ===================================================
echo Downloading SadTalker AI Checkpoints...
echo ===================================================
echo (This will open a new window to download the models. Let it finish!)
echo.

:: Run the official model downloader
call scripts\download_models.bat

echo.
color 0a
echo ===================================================
echo DONE! SadTalker is fully installed at D:\BARKAIMODELS\SadTalker
echo ===================================================
pause