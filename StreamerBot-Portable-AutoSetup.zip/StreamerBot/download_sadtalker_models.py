import os
import sys
import urllib.request
import urllib.error
import zipfile

def download_file(url, dest_path):
    print(f"Downloading {url.split('/')[-1]} ...")
    
    # We must pretend to be a browser to bypass GitHub bot blockers
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    
    try:
        with urllib.request.urlopen(req) as response:
            total_size = int(response.headers.get('Content-Length', 0))
            downloaded = 0
            
            with open(dest_path, 'wb') as file:
                while True:
                    chunk = response.read(8192 * 4)
                    if not chunk:
                        break
                    file.write(chunk)
                    downloaded += len(chunk)
                    
                    if total_size > 0:
                        percent = int(100 * downloaded / total_size)
                        sys.stdout.write(f"\rProgress: [{percent}%] {downloaded//(1024*1024)}MB / {total_size//(1024*1024)}MB")
                        sys.stdout.flush()
        print("\n✅ Download complete!")
        
    except urllib.error.HTTPError as e:
        print(f"\n[ERROR] Failed to download file: HTTP Error {e.code}: {e.reason}")
        if os.path.exists(dest_path):
            os.remove(dest_path)
        sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] Failed to download file: {e}")
        if os.path.exists(dest_path):
            os.remove(dest_path)
        sys.exit(1)

def main():
    print("===================================================")
    print("🎬 SadTalker Direct File Downloader (Final Fix)")
    print("===================================================")
    
    sadtalker_dir = r"D:\BARKAIMODELS\SadTalker"
    checkpoints_dir = os.path.join(sadtalker_dir, "checkpoints")
    gfpgan_dir = os.path.join(sadtalker_dir, "gfpgan", "weights")
    
    os.makedirs(checkpoints_dir, exist_ok=True)
    os.makedirs(gfpgan_dir, exist_ok=True)
    
    checkpoints = {
        "mapping_00109-model.pth.tar": "https://github.com/OpenTalker/SadTalker/releases/download/v0.0.2-rc/mapping_00109-model.pth.tar",
        "mapping_00229-model.pth.tar": "https://github.com/OpenTalker/SadTalker/releases/download/v0.0.2-rc/mapping_00229-model.pth.tar",
        "SadTalker_V0.0.2_256.safetensors": "https://github.com/OpenTalker/SadTalker/releases/download/v0.0.2-rc/SadTalker_V0.0.2_256.safetensors",
        "SadTalker_V0.0.2_512.safetensors": "https://github.com/OpenTalker/SadTalker/releases/download/v0.0.2-rc/SadTalker_V0.0.2_512.safetensors",
        "auido2exp_00300-model.pth": "https://github.com/Winfredy/SadTalker/releases/download/v0.0.2/auido2exp_00300-model.pth",
        "auido2pose_00140-model.pth": "https://github.com/Winfredy/SadTalker/releases/download/v0.0.2/auido2pose_00140-model.pth",
        "epoch_20.pth": "https://github.com/Winfredy/SadTalker/releases/download/v0.0.2/epoch_20.pth",
        "facevid2vid_00189-model.pth.tar": "https://github.com/Winfredy/SadTalker/releases/download/v0.0.2/facevid2vid_00189-model.pth.tar",
        "shape_predictor_68_face_landmarks.dat": "https://github.com/Winfredy/SadTalker/releases/download/v0.0.2/shape_predictor_68_face_landmarks.dat",
        "wav2lip.pth": "https://github.com/Winfredy/SadTalker/releases/download/v0.0.2/wav2lip.pth",
        "BFM_Fitting.zip": "https://github.com/Winfredy/SadTalker/releases/download/v0.0.2/BFM_Fitting.zip",
        "hub.zip": "https://github.com/Winfredy/SadTalker/releases/download/v0.0.2/hub.zip"
    }
    
    gfpgan_weights = {
        "GFPGANv1.4.pth": "https://github.com/TencentARC/GFPGAN/releases/download/v1.3.0/GFPGANv1.4.pth",
        "alignment_WFLW_4HG.pth": "https://github.com/xinntao/facexlib/releases/download/v0.1.0/alignment_WFLW_4HG.pth",
        "detection_Resnet50_Final.pth": "https://github.com/xinntao/facexlib/releases/download/v0.1.0/detection_Resnet50_Final.pth",
        "parsing_parsenet.pth": "https://github.com/xinntao/facexlib/releases/download/v0.2.2/parsing_parsenet.pth"
    }
    
    print("\n[System] Verifying and Downloading core checkpoints...")
    for filename, url in checkpoints.items():
        if filename == "BFM_Fitting.zip" and os.path.exists(os.path.join(checkpoints_dir, "BFM_Fitting")):
            print(f"✅ {filename} already extracted, skipping.")
            continue
        if filename == "hub.zip" and os.path.exists(os.path.join(checkpoints_dir, "hub")):
            print(f"✅ {filename} already extracted, skipping.")
            continue
            
        dest_path = os.path.join(checkpoints_dir, filename)
        if not os.path.exists(dest_path):
            download_file(url, dest_path)
            
            if filename in ["BFM_Fitting.zip", "hub.zip"]:
                print(f"\n[System] Extracting {filename}...")
                try:
                    with zipfile.ZipFile(dest_path, 'r') as zip_ref:
                        zip_ref.extractall(checkpoints_dir)
                    try: os.remove(dest_path)
                    except: pass
                    print(f"✅ {filename} extracted successfully!")
                except zipfile.BadZipFile:
                    print(f"[ERROR] {filename} is corrupted. Deleting...")
                    try: os.remove(dest_path)
                    except: pass
                    sys.exit(1)
        else:
            print(f"✅ {filename} already exists, skipping.")
            
    print("\n[System] Verifying and Downloading GFPGAN Face Enhancer weights...")
    for filename, url in gfpgan_weights.items():
        dest_path = os.path.join(gfpgan_dir, filename)
        if not os.path.exists(dest_path):
            download_file(url, dest_path)
        else:
            print(f"✅ {filename} already exists, skipping.")
            
    print("\n===================================================")
    print("✅ SUCCESS! ALL SadTalker models are installed and ready.")
    print("===================================================")

if __name__ == "__main__":
    main()