[CmdletBinding()]
param([string]$Python)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not $Python) { $Python = Join-Path $PSScriptRoot '.portable/original/venv/Scripts/python.exe' }
if (-not (Test-Path -LiteralPath $Python)) { throw 'Double-click StreamerBot.exe or Start-StreamerBot.bat to prepare the original desktop app.' }
$OriginalHome = Join-Path $PSScriptRoot '.portable/original'
$env:PLAYWRIGHT_BROWSERS_PATH = Join-Path $OriginalHome 'browsers'
$env:PATH = (Split-Path -Parent $Python) + ';' + (Join-Path $OriginalHome 'bin') + ';' + $env:PATH
$WebView = Join-Path $PSScriptRoot '.portable/webview2'
if (Test-Path -LiteralPath (Join-Path $WebView 'msedgewebview2.exe')) { $env:WEBVIEW2_BROWSER_EXECUTABLE_FOLDER = $WebView }
& $Python (Join-Path $PSScriptRoot 'controller.py')
if ($LASTEXITCODE -ne 0) { throw 'The original app exited with an error. Check CRASH_LOG.txt and FATAL_NATIVE_CRASH_LOG.txt in the project folder.' }
