@echo off
title AI App Launcher
color 0a
cd /d "%~dp0"

echo ===================================================
echo Starting Auto-Setup Launcher...
echo ===================================================
echo.

:: Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
color 0c
echo [ERROR] Python is not installed or not added to your system PATH!
echo Please install Python and ensure you check the "Add Python to PATH" box during the installer setup.
echo.
pause
exit /b
)

:: ---------------------------------------------------------------------
:: Model folders (set BEFORE anything runs; the app also reads these)
:: ---------------------------------------------------------------------
set SB_MODEL_ROOT=D:\BARKAIMODELS
set HF_HOME=%SB_MODEL_ROOT%\HuggingFaceCache
set HF_HUB_CACHE=%SB_MODEL_ROOT%\HuggingFaceCache\hub
set TRANSFORMERS_CACHE=%SB_MODEL_ROOT%\HuggingFaceCache
set XDG_CACHE_HOME=%SB_MODEL_ROOT%\BarkCache
set TORCH_HOME=%SB_MODEL_ROOT%\TorchCache

:: Auto-generate requirements.txt (torch is NOT in here on purpose: it is handled separately below)
color 0e
echo [System] Generating/Verifying requirements.txt for your Python version...
(
echo setuptools
echo numpy^<2.0.0
echo requests
echo pygame-ce
echo keyboard
echo groq
echo google-generativeai
echo SpeechRecognition
echo sounddevice
echo pywebview
echo duckduckgo-search
echo mss
echo Pillow
echo openai
echo python-dotenv
echo google-auth
echo google-auth-oauthlib
echo google-api-python-client
echo google-cloud-texttospeech
echo pydub
echo pyttsx3
echo edge-tts
echo scipy
echo gradio-client
echo networkx==2.8.8
echo suno-bark
echo rvc-python
echo faiss-cpu
echo fairseq
echo transformers
echo huggingface-hub
echo torchgeometry
echo kornia
echo insightface
echo opencv-python
echo imageio
echo imageio-ffmpeg
echo pyyaml
echo tqdm
echo librosa
echo ffmpeg-python
echo rich
echo mediapipe
echo facexlib
echo gfpgan
echo basicsr
echo yacs
echo safetensors
echo scikit-image
echo tensorboard
echo kokoro
echo soundfile
echo playwright
echo selenium
echo pynput
) > requirements.txt

color 0b
python -m pip install --user setuptools wheel >nul 2>&1
python -m pip install --user "pip<24.1" >nul 2>&1

:: ---------------------------------------------------------------------
:: GPU PYTORCH  (the old launcher used --extra-index-url pypi.org, which let PyPI's newer
:: CPU-only torch win over the CUDA one. That is why the app said "No GPU".)
:: ---------------------------------------------------------------------
echo.
echo [System] Checking GPU-accelerated PyTorch...
nvidia-smi >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARN] nvidia-smi not found: no NVIDIA driver detected. Install/update the driver from nvidia.com. Continuing on CPU.
    goto :after_torch
)
python check_torch.py
if %errorlevel% equ 0 goto :torch_ok

echo [System] PyTorch cannot see your GPU. Replacing it with the CUDA build (one-time, large download)...
python -m pip uninstall -y torch torchvision torchaudio >nul 2>&1
for %%C in (cu126 cu124 cu121) do (
    python check_torch.py >nul 2>&1
    if errorlevel 1 (
        echo [System] Trying PyTorch %%C ...
        python -m pip install --user --force-reinstall --no-cache-dir torch torchvision torchaudio --index-url https://download.pytorch.org/whl/%%C
    )
)
python check_torch.py
if errorlevel 1 (
    color 0c
    echo [WARN] Still no GPU in PyTorch. Check: nvidia-smi works, and Python is 64-bit 3.10-3.12 or 3.13. The app will run on CPU.
    color 0b
)

:torch_ok
python check_torch.py pin >nul 2>&1

:after_torch
echo.
echo [System] Installing and verifying required Python modules (one failure no longer stops the rest)...
if exist constraints.txt (set CONSTRAINT=-c constraints.txt) else (set CONSTRAINT=)
for /f "usebackq delims=" %%p in ("requirements.txt") do (
    python -m pip install --user "%%p" %CONSTRAINT% >nul 2>&1
    if errorlevel 1 echo [WARN] could not install %%p ^(skipped^)
)

:: If any package quietly swapped torch for the CPU build, put the CUDA one back
nvidia-smi >nul 2>&1
if %errorlevel% equ 0 (
    python check_torch.py >nul 2>&1
    if errorlevel 1 (
        echo [System] A package replaced the GPU PyTorch; restoring it...
        python -m pip install --user --force-reinstall --no-deps torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu126
    )
)

:: ---------------------------------------------------------------------
:: PLAYWRIGHT BROWSER INSTALL (REQUIRED FOR TYPECAST GHOST ENGINE)
:: ---------------------------------------------------------------------
color 0d
echo [System] Installing Playwright Chromium browser binaries (Ghost Engine)...
python -m playwright install chromium

:: ---------------------------------------------------------------------
:: PATCH THE BROKEN BASICSR LIBRARY (Torchvision bug)
:: ---------------------------------------------------------------------
echo [System] Applying automated patch to broken basicsr library...
echo import os, re, importlib.util > patch_basicsr.py
echo spec = importlib.util.find_spec('basicsr') >> patch_basicsr.py
echo if spec and spec.submodule_search_locations: >> patch_basicsr.py
echo      base = spec.submodule_search_locations[0] >> patch_basicsr.py
echo      f = os.path.join(base, 'data', 'degradations.py') >> patch_basicsr.py
echo      if os.path.exists(f): >> patch_basicsr.py
echo          with open(f, 'r', encoding='utf-8') as file: c = file.read() >> patch_basicsr.py
echo          c = re.sub(r'from torchvision.transforms.functional_tensor import rgb_to_grayscale', 'from torchvision.transforms.functional import rgb_to_grayscale', c) >> patch_basicsr.py
echo          with open(f, 'w', encoding='utf-8') as file: file.write(c) >> patch_basicsr.py
echo          print('[System] Successfully patched degradations.py') >> patch_basicsr.py
python patch_basicsr.py
del patch_basicsr.py

echo.
color 0a
echo ===================================================
echo Launching Application...
echo ===================================================
python controller.py

echo.
color 0e
echo ===================================================
echo Application closed.
echo ===================================================
pause
