import os

def clear_cache():
    print("=========================================")
    print("🧹 Cleaning Old Video Cache...")
    print("=========================================")
    
    deleted_count = 0
    
    # Walk through the current directory and all subdirectories
    for root, dirs, files in os.walk("."):
        # Skip the SadTalker outputs folder to avoid deleting raw renders by mistake
        if "outputs" in root or "SadTalker" in root:
            continue
            
        for file in files:
            # Check if the file is an mp4
            if file.endswith(".mp4"):
                # If there is a matching .wav file, this is a cached hotkey video
                wav_version = file.replace(".mp4", ".wav")
                if wav_version in files:
                    file_path = os.path.join(root, file)
                    try:
                        os.remove(file_path)
                        print(f"[Deleted] {file}")
                        deleted_count += 1
                    except Exception as e:
                        print(f"[Error] Could not delete {file}: {e}")

    print("=========================================")
    if deleted_count > 0:
        print(f"✅ Success! Deleted {deleted_count} old videos.")
        print("The next time you use your hotkeys, new videos will be rendered!")
    else:
        print("ℹ️ No cached videos found. You are ready to go!")
    print("=========================================")

if __name__ == "__main__":
    clear_cache()
    input("\nPress Enter to close...")