from playwright.sync_api import sync_playwright
import sys
import time

"""
PREREQUISITES:
1. Install Python
2. Open CMD and run: pip install playwright
3. Open CMD and run: playwright install chromium
"""

def send_to_typecast(ai_message):
    print(f"Starting Ghost Mode for message: '{ai_message}'")
    
    with sync_playwright() as p:
        # We launch headless=False because true headless mode often mutes audio output.
        # Instead, we push the window completely off-screen (-2000, -2000) so it's a "ghost".
        browser = p.chromium.launch(
            headless=False, 
            args=["--window-position=-2000,-2000", "--window-size=800,600"]
        )
        
        # Note: To route this to your stream (OBS), you should use Windows Settings 
        # to route Chrome/Python audio to a Virtual Audio Cable.
        context = browser.new_context()
        page = context.new_page()
        
        print("Navigating to Typecast...")
        page.goto("https://typecast.ai/login")
        
        # --- IMPORTANT LOGIN NOTE ---
        # You will need to inspect the Typecast login page and replace these selectors
        # with your actual login credentials, or load a saved browser profile (cookies)
        # so you don't have to log in every time.
        try:
            page.fill('input[type="email"]', 'YOUR_EMAIL@example.com')
            page.fill('input[type="password"]', 'YOUR_PASSWORD')
            page.click('button[type="submit"]')
            page.wait_for_url("**/editor**", timeout=10000) # Wait for editor to load
        except Exception as e:
            print("Login step skipped or failed. Assuming already in editor.")

        print("Injecting AI message...")
        
        # Find the main text editor box in Typecast (you may need to update this CSS selector 
        # based on Typecast's current HTML layout).
        editor_selector = ".typecast-editor-textarea" # Example selector
        
        page.wait_for_selector(editor_selector)
        
        # Clear previous text and type the new AI message
        page.fill(editor_selector, "") 
        page.type(editor_selector, ai_message)
        
        print("Pressing Ctrl+Enter...")
        # Simulate the exact hotkey inside the ghost browser
        page.keyboard.press("Control+Enter")
        
        # We need to calculate how long to keep the browser open based on text length.
        # Average reading speed is ~3 words per second.
        words = len(ai_message.split())
        estimated_audio_time = (words / 3) + 5 # Add 5 seconds buffer for generation time
        
        print(f"Waiting {estimated_audio_time} seconds for audio to play...")
        time.sleep(estimated_audio_time)
        
        print("Closing Ghost Mode.")
        browser.close()

if __name__ == "__main__":
    # This allows your Streamer Bot to trigger this script via CMD like this:
    # python streamer_tts_bridge.py "Hello chat, thanks for the follow!"
    
    if len(sys.argv) > 1:
        message = sys.argv[1]
        send_to_typecast(message)
    else:
        print("Error: No message provided. Use: python streamer_tts_bridge.py 'Your message'")