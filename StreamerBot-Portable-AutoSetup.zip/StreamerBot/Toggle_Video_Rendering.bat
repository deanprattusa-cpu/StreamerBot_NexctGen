@echo off
title Video Rendering Toggle
:: THIS FORCES WINDOWS TO STAY IN THE BOT FOLDER!
cd /d "%~dp0"

if exist "enable_video.txt" (
del "enable_video.txt"
color 0c
echo ==========================================
echo [DISABLED] Video Rendering is now OFF.
echo The bot will only play existing cached videos.
echo ==========================================
) else (
echo 1 > "enable_video.txt"
color 0a
echo ==========================================
echo [ENABLED] Video Rendering is now ON.
echo The bot will generate new videos for new audio.
echo ==========================================
)
pause