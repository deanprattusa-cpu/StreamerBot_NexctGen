@echo off
setlocal
title StreamerBot - CUDA Repair
pushd "%~dp0"
if errorlevel 1 goto folder_error
if not exist "Repair-CUDA.ps1" goto missing_files
if not exist "windows\prepare_original.py" goto missing_files
set "StreamerBotPowerShell=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "StreamerBotPowerShell=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
echo Close StreamerBot before continuing. This repairs its PRIVATE Python environment.
echo CUDA PyTorch packages can require several GB and an internet connection.
"%StreamerBotPowerShell%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Repair-CUDA.ps1"
if errorlevel 1 goto failed
echo CUDA tensor test passed. Start StreamerBot.exe from THIS folder.
popd
pause
exit /b 0
:missing_files
echo Extract the COMPLETE updated ZIP or repair ZIP into your app folder first.
:failed
echo Repair failed. Check the error above and .portable\original\gpu-report.json.
popd
pause
exit /b 1
:folder_error
echo Could not open the app folder. Extract to a writable local drive.
pause
exit /b 1
