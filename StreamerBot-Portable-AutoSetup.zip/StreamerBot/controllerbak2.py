# ==============================================================================
# AI SYSTEM DIRECTIVE - DO NOT DELETE OR MODIFY THIS COMMENT
# TO ANY FUTURE AI MODIFYING THIS CODE: 
# DO NOT STRIP, CUT, OR REMOVE ANY EXISTING LOGIC, FEATURES, OR CODE BLOCKS.
# RETAIN ALL ERROR HANDLING, MVC STRUCTURE, AND HARDCODED OVERRIDES.
# ONLY ADD OR MODIFY WHAT THE USER EXPLICITLY PROMPTS YOU TO CHANGE.
# ==============================================================================

import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import threading
import sys
import os
import json
import webbrowser
import queue
import time
from datetime import datetime
import glob
import numpy as np
import multiprocessing
import random 
import requests
import types
import re
import ctypes
import traceback

# 🛡️ THE ULTIMATE CRASH CATCHER: Writes fatal errors to a file before the app closes!
_CRASH_LOG_COUNT = [0]
def _log_crash(title, exctype, value, tb):
    """Appends (never overwrites) every error with a timestamp so you can see WHAT died and WHEN."""
    try:
        _CRASH_LOG_COUNT[0] += 1
        if _CRASH_LOG_COUNT[0] > 500: return   # don't let a repeating UI error fill the disk
        with open("CRASH_LOG.txt", "a", encoding="utf-8") as f:
            f.write(f"\n===== {datetime.now():%Y-%m-%d %H:%M:%S} | {title} =====\n")
            traceback.print_exception(exctype, value, tb, file=f)
    except Exception: pass

def _crash_logger(exctype, value, tb):
    _log_crash("MAIN THREAD CRASH", exctype, value, tb)
    sys.__excepthook__(exctype, value, tb)
sys.excepthook = _crash_logger

def _thread_crash_logger(args):
    _log_crash(f"BACKGROUND THREAD CRASH ({getattr(args.thread, 'name', '?')})", args.exc_type, args.exc_value, args.exc_traceback)
    print(f"[THREAD CRASH] {getattr(args.thread, 'name', '?')}: {args.exc_value}  (details in CRASH_LOG.txt)")
threading.excepthook = _thread_crash_logger

try:   # hard native crashes (CUDA / audio drivers) leave a trace here instead of vanishing
    import faulthandler
    _FATAL_LOG = open("FATAL_NATIVE_CRASH_LOG.txt", "a")
    faulthandler.enable(file=_FATAL_LOG, all_threads=True)
except Exception: pass

# 🛡️ THE SSL FIX: Force Python to ignore system proxies and Antivirus Web Shields
os.environ['HTTP_PROXY'] = ''
os.environ['HTTPS_PROXY'] = ''
os.environ['trust_env'] = '0'

# --- EARLY AUDIO INIT TO PREVENT BACKGROUND THREAD CRASHES ---
try:
    import pygame
    pygame.mixer.init()
except Exception as e:
    print(f"[Audio Warning] Could not init pygame mixer early: {e}")

# --- SUPPRESS PYGAME WELCOME MESSAGE ---
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"

# --- FORCE BARK GPU DEFAULTS BEFORE IMPORT ---
# (older Bark builds treat ANY non-empty value, even "0", as ON, so these are left unset = off)
os.environ.pop("SUNO_USE_CPU", None)
os.environ.pop("SUNO_OFFLOAD_CPU", None)
os.environ.pop("SUNO_ENABLE_MPS", None)
# --- DYNAMIC MODEL CACHE PATH ---
import os, json
try:
    with open("bot_config.json", "r") as f:
        _boot_cfg = json.load(f)
        _cache_path = _boot_cfg.get("global_model_path", "")
        if _cache_path and os.path.exists(_cache_path):
            os.environ["XDG_CACHE_HOME"] = os.path.join(_cache_path, "BarkCache")
            os.environ["HF_HOME"] = os.path.join(_cache_path, "HuggingFaceCache")
except Exception: 
    pass
# --- FALLBACK: user's models drive (used when bot_config.json has no valid global_model_path) ---
_sb_root = os.environ.get("SB_MODEL_ROOT") or r"D:\BARKAIMODELS"
if os.path.isdir(_sb_root) and not os.environ.get("XDG_CACHE_HOME"):
    os.environ["XDG_CACHE_HOME"] = os.path.join(_sb_root, "BarkCache")
    os.environ.setdefault("HF_HOME", os.path.join(_sb_root, "HuggingFaceCache"))

# --- FIX: TKINTER EMOJI CRASH SANITIZER ---
def _safe_tk_string(text):
    """Strips high-surrogate emojis that cause Windows Tkinter to instantly crash."""
    if not isinstance(text, str): return ""
    return "".join(c for c in text if ord(c) <= 0xFFFF)

# --- MONKEY PATCH FOR TORCH SECURITY & BARK INPLACE ERRORS ---
try:
    import torch
    if hasattr(torch, 'load'):
        _orig_torch_load = torch.load
        def _unsafe_torch_load(*args, **kwargs):
            if 'weights_only' not in kwargs: kwargs['weights_only'] = False
            return _orig_torch_load(*args, **kwargs)
        torch.load = _unsafe_torch_load
        
    # [FIX] Bypass Bark's PyTorch 2.1+ "Inplace update to inference tensor" crash
    if hasattr(torch, 'inference_mode') and hasattr(torch, 'no_grad'):
        torch.inference_mode = torch.no_grad
except ImportError: pass

try:
    from model import StreamerBotModel, get_lm_studio_client, check_lm_studio_ready, CONFIG_FILE
    import model as model_module
    
    # --- MONKEY PATCH: INVISIBLE CACHE BUSTER ---
    model_module.CLEAN_TEXT_REGEX = re.compile(r'[^\w\s.,?!:;\-\'\"\[\]\u200B]')
    
    # --- MONKEY PATCH: PURE PYGAME PLAYER (PREVENTS SCIPY CRASHES) ---
    global_abort_flag = [False]
    _audio_playback_lock = threading.Lock()
    
    def _patched_play_wav(wav_path, volume=1.0):
        import time
        try: import pygame
        except ImportError: return
        
        # FIX: Aggressive pre-lock kill switch to silence overlapping threads instantly
        global_abort_flag[0] = True 
        time.sleep(0.02)
        
        with _audio_playback_lock:
            try:
                if not pygame.mixer.get_init():
                    pygame.mixer.init()
                
                pygame.mixer.stop()
                global_abort_flag[0] = False
                
                sound = pygame.mixer.Sound(wav_path)
                sound.set_volume(min(1.0, volume * 1.5))
                channel = sound.play()
                
                if channel:
                    while channel.get_busy():
                        if global_abort_flag[0] or getattr(model_module, 'abort_generation', False):
                            pygame.mixer.stop()
                            break
                        time.sleep(0.01) 
                else:
                    for _ in range(int(sound.get_length() * 100)):
                        if global_abort_flag[0] or getattr(model_module, 'abort_generation', False): break
                        time.sleep(0.01)
            except Exception as e:
                print(f"[Pygame Playback Error] {e}")

    model_module.play_wav_winsound = _patched_play_wav

    # --- MONKEY PATCH: MISSING TTS ENGINE SHIELD ---
    # Prevents background workers from permanently crashing if the user's model.py is missing newer voice functions!
    for missing_func in ['play_tiktok_tts_audio', 'play_soprano_tts_audio', 'play_fish_tts_audio', 'play_edge_tts_audio_gui', 'play_google_tts_audio_gui']:
        if not hasattr(model_module, missing_func):
            def _dummy(*args, _name=missing_func, **kwargs):     # FIX: bind the name now, not when called (always showed the last one)
                print(f"[Audio Engine] ⚠️ '{_name}' is missing from your model.py file! Audio generation skipped to prevent crash.")
            setattr(model_module, missing_func, _dummy)

except ImportError as e:
    print(f"CRITICAL ERROR: Could not import 'model.py'. Details: {e}")
    sys.exit(1)

from view import StreamerBotView, TextRedirector

try: import keyboard
except ImportError:
    keyboard = None
    print("['keyboard' library not found. Hotkeys will be disabled. Run 'pip install keyboard' to enable.]")

try: from groq import Groq
except ImportError: Groq = None

try: import google.generativeai as genai
except ImportError: genai = None

import speech_recognition as sr
try: import sounddevice as sd
except ImportError: sd = None

# --- GLOBAL FUNCTION: YOUTUBE PLAYER WITH RESIZE & MEDIA CONTROLS ---
def _run_youtube_player_process(target_url, start_time=0.0, default_opacity=0.7, geo=None, geo_queue=None, cmd_queue=None, state_queue=None):
    try:
        import webview
        import sys
        import time
        import threading
        import ctypes
    except ImportError: return

    # Pull last known coordinates (safely fallback if missing)
    x = int(geo.get('x', 100)) if geo else 100
    y = int(geo.get('y', 100)) if geo else 100
    w = int(geo.get('width', 480)) if geo else 480
    h = int(geo.get('height', 320)) if geo else 320
    if not target_url: target_url = 'https://www.youtube.com'

    # The Master JavaScript: Handles UI, Ad-Skipping, and Geometry/Time Reporting
    js_inject = """
    // 1. Invisible Resize Grip
    var grip = document.createElement('div');
    grip.style.position = 'fixed'; grip.style.bottom = '0'; grip.style.right = '0';
    grip.style.width = '20px'; grip.style.height = '20px'; grip.style.background = 'transparent'; 
    grip.style.cursor = 'nwse-resize'; grip.style.zIndex = '2147483647';
    document.body.appendChild(grip);

    let isResizing = false; let startX, startY;
    grip.addEventListener('mousedown', function(e) { isResizing = true; startX = e.screenX; startY = e.screenY; e.preventDefault(); e.stopPropagation(); });
    document.addEventListener('mousemove', function(e) {
        if (!isResizing) return;
        const dx = e.screenX - startX; const dy = e.screenY - startY; startX = e.screenX; startY = e.screenY; 
        window.pywebview.api.resize_window(dx, dy);
    });
    document.addEventListener('mouseup', function() { isResizing = false; });
    document.addEventListener('dblclick', function(e) { if (e.ctrlKey) window.pywebview.api.close_window(); });
    
    let start_time = __START_TIME__;
    let init_seek_done = false;
    
    // 2. The 500ms Master Loop
    setInterval(function() {
        // --- AUTO AD-SKIPPER ---
        var skipClasses = ['.ytp-ad-skip-button', '.ytp-skip-ad-button', '.ytp-ad-skip-button-modern', '.videoAdUiSkipButton', '.ytp-ad-text.ytp-ad-skip-button-text'];
        for (var i = 0; i < skipClasses.length; i++) {
            var btn = document.querySelector(skipClasses[i]);
            if (btn) btn.click();
        }
        var overlayBtn = document.querySelector('.ytp-ad-overlay-close-button');
        if (overlayBtn) overlayBtn.click();
        var confirmBtn = document.getElementById('confirm-button');
        if (confirmBtn) confirmBtn.click();
        
        var player = document.querySelector('.html5-video-player');
        if (player && player.classList.contains('ad-showing')) {
            var v = document.querySelector('video');
            if (v && v.duration) { v.currentTime = v.duration - 0.1; } // Instantly finish unskippable ads
        }

        // --- TIME & GEOMETRY REPORTER ---
        var v_main = document.querySelector('video');
        if (v_main && !init_seek_done && start_time > 0 && !(player && player.classList.contains('ad-showing'))) {
            v_main.currentTime = start_time;
            init_seek_done = true;
        }
        
        if (window.pywebview && window.pywebview.api) {
            var t = v_main ? v_main.currentTime : 0;
            window.pywebview.api.report_state(window.location.href, t);
            // JS accurately reports screen dimensions, completely bypassing Python's scaling crash
            window.pywebview.api.report_geo(window.screenLeft || window.screenX, window.screenTop || window.screenY, window.outerWidth, window.outerHeight);
        }
    }, 500);
    """.replace("__START_TIME__", str(start_time))

    class Api:
        def close_window(self): window.destroy()
        def resize_window(self, dx, dy):
            try:
                new_w = window.width + int(dx); new_h = window.height + int(dy)
                if new_w > 100 and new_h > 100: window.resize(new_w, new_h)
            except: pass
        def report_state(self, url, time_val):
            if state_queue:
                try: state_queue.put_nowait({'url': url, 'time': float(time_val)})
                except: pass
        def report_geo(self, x, y, w, h):
            if geo_queue:
                try:
                    if int(w) > 100 and int(h) > 100: geo_queue.put_nowait({'x': int(x), 'y': int(y), 'width': int(w), 'height': int(h)})
                except: pass
                
    api = Api()
    window = webview.create_window(title='YouTube Overlay', url=target_url, width=w, height=h, x=x, y=y, on_top=True, confirm_close=False, text_select=True, frameless=True, easy_drag=True, resizable=True, js_api=api)
    
    def check_cmds():
        if not cmd_queue: return
        check_cmds.ghost_active = False
        check_cmds.current_opacity = int(default_opacity * 255)
        
        def reapply_ghost_mode():
            if not check_cmds.ghost_active: return
            try:
                user32 = ctypes.windll.user32
                hwnd = user32.FindWindowW(None, "YouTube Overlay")
                if hwnd:
                    GWL_EXSTYLE, WS_EX_TRANSPARENT, WS_EX_LAYERED, LWA_ALPHA = -20, 0x00000020, 0x00080000, 0x00000002
                    try: gwl = user32.GetWindowLongPtrW; swl = user32.SetWindowLongPtrW
                    except AttributeError: gwl = user32.GetWindowLongW; swl = user32.SetWindowLongW
                    gwl.argtypes, swl.argtypes = [ctypes.c_void_p, ctypes.c_int], [ctypes.c_void_p, ctypes.c_int, ctypes.c_size_t]
                    gwl.restype, swl.restype = ctypes.c_size_t, ctypes.c_size_t
                    style = gwl(ctypes.c_void_p(hwnd), GWL_EXSTYLE)
                    swl(ctypes.c_void_p(hwnd), GWL_EXSTYLE, style | WS_EX_TRANSPARENT | WS_EX_LAYERED)
                    user32.SetLayeredWindowAttributes(hwnd, 0, check_cmds.current_opacity, LWA_ALPHA)
            except: pass

        while True:
            try:
                cmd = cmd_queue.get() 
                if cmd == 'quit':
                    try: window.destroy()
                    except: pass
                    import os; os._exit(0)
                elif cmd == 'play_pause':
                    window.evaluate_js("var btn = document.querySelector('.ytp-play-button'); if (btn) { btn.click(); } else { document.dispatchEvent(new KeyboardEvent('keydown', {'key': 'k', 'keyCode': 75, 'code': 'KeyK', 'bubbles': true})); }")
                    reapply_ghost_mode()
                elif cmd == 'next':
                    window.evaluate_js("var btn = document.querySelector('.ytp-next-button'); if (btn) btn.click();")
                    reapply_ghost_mode()
                elif cmd == 'prev':
                    window.evaluate_js("var v = document.querySelector('video'); if (v && v.currentTime > 3) v.currentTime = 0; else history.back();")
                    reapply_ghost_mode()
                elif cmd == 'forward':
                    window.evaluate_js("var v = document.querySelector('video'); if(v) v.currentTime += 10;")
                    reapply_ghost_mode()
                elif cmd == 'rewind':
                    window.evaluate_js("var v = document.querySelector('video'); if(v) v.currentTime = Math.max(0, v.currentTime - 10);")
                    reapply_ghost_mode()
                elif cmd == 'focus': window.restore()
                elif cmd == 'hide':
                    try: window.hide()
                    except: pass
                elif cmd == 'show':
                    try: window.show()
                    except: pass
                elif cmd.startswith('opacity:'):
                    try:
                        check_cmds.current_opacity = int(cmd.split(':')[1])
                        if check_cmds.ghost_active: reapply_ghost_mode()
                    except: pass
                elif cmd == 'toggle_ghost':
                    try:
                        user32 = ctypes.windll.user32
                        hwnd = user32.FindWindowW(None, "YouTube Overlay")
                        if hwnd:
                            GWL_EXSTYLE, WS_EX_TRANSPARENT, WS_EX_LAYERED, LWA_ALPHA = -20, 0x00000020, 0x00080000, 0x00000002
                            try: gwl = user32.GetWindowLongPtrW; swl = user32.SetWindowLongPtrW
                            except AttributeError: gwl = user32.GetWindowLongW; swl = user32.SetWindowLongW
                            gwl.argtypes, swl.argtypes = [ctypes.c_void_p, ctypes.c_int], [ctypes.c_void_p, ctypes.c_int, ctypes.c_size_t]
                            gwl.restype, swl.restype = ctypes.c_size_t, ctypes.c_size_t
                                
                            style = gwl(ctypes.c_void_p(hwnd), GWL_EXSTYLE)
                            
                            if check_cmds.ghost_active:
                                swl(ctypes.c_void_p(hwnd), GWL_EXSTYLE, style & ~WS_EX_TRANSPARENT)
                                user32.SetLayeredWindowAttributes(hwnd, 0, 255, LWA_ALPHA)
                                check_cmds.ghost_active = False
                            else:
                                swl(ctypes.c_void_p(hwnd), GWL_EXSTYLE, style | WS_EX_TRANSPARENT | WS_EX_LAYERED)
                                user32.SetLayeredWindowAttributes(hwnd, 0, check_cmds.current_opacity, LWA_ALPHA)
                                check_cmds.ghost_active = True
                    except: pass
            except: pass

    threading.Thread(target=check_cmds, daemon=True).start()
    def on_moved(x, y):
        if geo_queue:
            try: geo_queue.put_nowait({'x': x, 'y': y, 'width': window.width, 'height': window.height})
            except: pass
    def on_resized(width, height):
        if geo_queue:
            try: geo_queue.put_nowait({'x': window.x, 'y': window.y, 'width': width, 'height': height})
            except: pass

    # FIX: these handlers were registered AFTER webview.start() returned (i.e. after the window had already
    # closed), so the overlay position/size was never remembered. A second webview.start() call also
    # referenced a variable that does not exist (js_inject_resize_and_close). Register first, start once.
    window.events.moved += on_moved
    window.events.resized += on_resized
    try: webview.start(func=lambda: window.evaluate_js(js_inject), private_mode=False)
    except: pass


def _bark_native_generate(model, text, voice_preset=None):
    """ONE Bark path for every hotkey / universal generator.
    - uses bark_fast (models stay loaded + warm, sentence-chunked generation)
    - honours BOTH spellings of the UI toggles (the Bark menu sets bark_small_models / bark_use_cpu,
      other code reads bark_use_small_models) and the voice the UI selected (bark_voice)."""
    voice = voice_preset or getattr(model, 'bark_voice', None) or getattr(model, 'bark_speaker', None) or 'v2/en_speaker_6'
    use_small = bool(getattr(model, 'bark_use_small_models', False) or getattr(model, 'bark_small_models', False)
                     or getattr(model, 'bark_low_vram', False))          # 1GB VRAM mode implies small models
    offload = bool(getattr(model, 'bark_use_cpu', False) or getattr(model, 'bark_low_vram', False))   # ...and CPU offload
    try:
        from bark_fast import get_engine, SAMPLE_RATE
        return get_engine(voice, use_small, offload).synth(text), SAMPLE_RATE
    except ImportError:
        pass                                    # bark_fast.py not installed: fall back to plain Bark
    from bark import SAMPLE_RATE, generate_audio, preload_models
    preload_models()
    return generate_audio(text, history_prompt=voice), SAMPLE_RATE


def _write_wav_int16(path, audio, sample_rate):
    """16-bit PCM WAV (float32 WAVs are not readable by every player we hand these files to)."""
    import numpy as np
    from scipy.io.wavfile import write as _write_wav
    _write_wav(path, sample_rate, (np.clip(np.asarray(audio, dtype=np.float32), -1.0, 1.0) * 32767).astype(np.int16))


class StreamerBotController:
    def __init__(self):
        self.root = tk.Tk()
        self.active_config_path = CONFIG_FILE
        
        self.soundboard_volume = 1.0
        self.soundboard_volume = 1.0
        self.auto_reply_output_mode = "V+T" # 🛡️ NEW: Default auto-reply mode
        self.global_ai_mute = False
        self.force_cache_only = False
        self.custom_length_enabled = False
        self.custom_length_val = 30
        self.vibe_check_enabled = True
        
        # Dual AI Directives
        self.global_directive_enabled = False
        self.global_directive_text = ""
        self.chat_directive_enabled = False
        self.chat_directive_text = ""
        
        self.overlay_opacity = 0.7 
        self.yt_current_time_cache = 0.0
        self.hotkeys_suspended = False
        
        # Cache Playback States
        self.cache_playback_mode = "shuffle" 
        self._last_played_cache = {}

        self.hk_bases = [
            "hk_idle", "hk_thanks", "hk_question", "hk_help", "hk_death", "hk_likes_thanks", "hk_brb", 
            "hk_tech_issue", "hk_game_request", "hk_taunt", "hk_intro", "hk_frustration", "hk_attack", 
            "hk_talk_viewers", "hk_shoutout_users", "hk_puzzle", "hk_boss_win", "hk_feeling_good", 
            "hk_feeling_bad", "hk_clip_that", "hk_panic", "hk_live_context"
        ] + [f"hk_custom_{i}" for i in range(1, 16)]
        
        self.gui_hks = [
            "hk_reply_last", "hk_open_list", "hk_stats", "hk_stats_ghost", "hk_hotkeys_window", "hk_strict_mode", 
            "hk_play_overlay", "hk_music_window", "hk_toggle_ai_mute", "hk_yt_play_pause", "hk_yt_next", 
            "hk_yt_prev", "hk_yt_forward", "hk_yt_rewind", "hk_yt_ghost", "hk_mp3_play_pause", 
            "hk_mp3_next", "hk_mp3_prev", "hk_mp3_forward", "hk_mp3_rewind", "hk_guide", "hk_guide_ghost",
            "hk_hide_overlays", "hk_open_context_window", "hk_suspend_hotkeys", "hk_stop_audio",
            "hk_sys_status", "hk_sys_status_ghost", "hk_toggle_cache_mode", "hk_vision", "hk_vision_mode",
            "hk_vision_toggle"
        ]

        for hk in self.hk_bases:
            setattr(self, hk, "")
            setattr(self, f"{hk}_mode", "V+T")
            setattr(self, f"{hk}_short", False)
            setattr(self, f"{hk}_custom", "")
            setattr(self, f"{hk}_prompt", "")
            setattr(self, f"{hk}_audio", "")
            setattr(self, f"{hk}_audio_enabled", False)
            setattr(self, f"{hk}_mute_ai", False)

        for hk in self.gui_hks:
            setattr(self, hk, "")

        self.hk_reply_last_mode = "V+T"
        self.hk_reply_last_short = False
        self.guide_geo_cache = "380x600+150+150" 
        self.saved_status_geo = "200x80+100+100"
        self.sys_status_geo_cache = "300x150+100+100"
        
        # Debounce tracking for UI stats to prevent Tkinter freezing
        self._pending_stats = None
        self._stats_timer_active = False
        self._pending_subs = None
        self._subs_timer_active = False

        defaults = {
            "hk_idle": "ctrl+f1", "hk_thanks": "ctrl+f2", "hk_question": "ctrl+f3",
            "hk_help": "ctrl+f4", "hk_death": "ctrl+f5", "hk_reply_last": "ctrl+q",
            "hk_open_list": "ctrl+w", "hk_stats": "ctrl+e", "hk_stats_ghost": "ctrl+alt+g", 
            "hk_guide": "ctrl+shift+h", "hk_guide_ghost": "ctrl+shift+g",
            "hk_hide_overlays": "ctrl+shift+x",
            "hk_open_context_window": "ctrl+shift+c",
            "hk_suspend_hotkeys": "ctrl+shift+s",
            "hk_stop_audio": "ctrl+shift+d",
            "hk_likes_thanks": "ctrl+f6", "hk_brb": "ctrl+f7", "hk_tech_issue": "ctrl+f8", 
            "hk_game_request": "ctrl+f9", "hk_hotkeys_window": "ctrl+h", "hk_strict_mode": "ctrl+f10", 
            
            "hk_sys_status": "ctrl+shift+v",
            "hk_sys_status_ghost": "ctrl+shift+b",
            "hk_toggle_cache_mode": "ctrl+shift+z",
            "hk_vision": "ctrl+alt+v",
            
            # 🔥 CRIMSON DESERT CUSTOM AI PROMPTS (1-15) 🔥
            "hk_custom_1_prompt": "React with pure hype to hitting a WWE-style suplex or brutal grapple on an enemy. Scream about how Kliff just broke that guy in half with the crazy physics!",
            "hk_custom_2_prompt": "Freak out because an enemy just used a crazy new attack, and Kliff just 'witnessed and learned' it mid-combat! Brag to the viewers that you're about to use it against them.",
            "hk_custom_3_prompt": "Lose your mind with excitement because you just unlocked and started piloting a dwarven mech or riding a dragon for the first time.",
            "hk_custom_4_prompt": "Get totally distracted from a serious mercenary mission because you found a cat to pet or a pig to carry around. Tell chat this is the real endgame.",
            "hk_custom_5_prompt": "Panic hilariously because you accidentally hit someone or stole a wagon in Hernand, and now the guards are hunting you. Beg chat for escape advice!",
            "hk_custom_6_prompt": "Pop off with hype because you just found a super rare Abyss Artifact. Talk about how insane the stat boost is going to be for your build.",
            "hk_custom_7_prompt": "Brag to the viewers about destroying a tough boss purely through raw combat skill and perfect parries, since there's no level scaling to carry you in this game.",
            "hk_custom_8_prompt": "Panic because you are climbing a massive cliff using the grappling hook, and your blue stamina bar is about to run out. Scream that you're going to fall!",
            "hk_custom_9_prompt": "Proudly show off your newly built Greymane mercenary camp to the stream. Flex about the furniture or the NPCs you've recruited.",
            "hk_custom_10_prompt": "Marvel at the crazy BlackSpace Engine physics. React to kicking an enemy so hard they flew into a horse or completely shattered a wooden watchtower.",
            "hk_custom_11_prompt": "Take a chill, cozy break. Tell the viewers you're just kicking back to do some cooking, fishing (without a rod!), and vibing in the open world of Pywel.",
            "hk_custom_12_prompt": "Scream 'PARRY GOD!' and hype up your own reflexes after hitting a flawless, perfectly-timed sword block against a huge enemy attack.",
            "hk_custom_13_prompt": "React to igniting your sword with fire or another elemental imbuement. Tell chat how incredibly cool the combat animations look right now.",
            "hk_custom_14_prompt": "Yell in shock because you just got ambushed and surrounded by a massive group of outlaws in the wild. Tell chat it's time to lock in and focus.",
            "hk_custom_15_prompt": "Stop moving for a second and just admire the insane graphics. Point out the dynamic weather, the mud physics, or how beautiful the world looks."
        }
        
        for k, v in defaults.items(): setattr(self, k, v)

        self.yt_cmd_queue = multiprocessing.Queue()
        
        self.overlay_process = None 
        self.overlay_url_cache = ""
        self.overlay_geo_queue = multiprocessing.Queue()
        self.overlay_state_queue = multiprocessing.Queue()
        self.overlay_geo_cache = {"x": 100, "y": 100, "width": 640, "height": 360}
        
        self.music_geo_cache = "300x120+100+100"
        self.review_geo_cache = "650x520+100+100"
        self.chat_history_buffer = []
        self.seen_messages_sig = set() 

        self._tap_timers = {}
        self._tap_counts = {}
        self._generation_counter = 0
        self._unplayed_cache_bags = {}

        self.model = StreamerBotModel()
        
        # --- MONKEY PATCH: STRIP TAGS FROM CHAT REPLIES ---
        # Intercepts outgoing chat messages and removes [laughs], [gasps], etc., so viewers don't read them in chat, but Bark still hears them!
        for m_name in ['send_chat_message', 'send_youtube_message', 'send_twitch_message', 'send_message', '_send_message', 'reply_to_chat', 'insert_message']:
            if hasattr(self.model, m_name):
                orig_chat_func = getattr(self.model, m_name)
                def _wrap_chat(f):
                    def _wrapped(*args, **kwargs):
                        # FIX: Now strips brackets [], asterisks **, and parentheses () from outgoing text messages
                        n_args = [re.sub(r'(\[.*?\]|\*.*?\*|\(.*?\))', '', a).strip() if isinstance(a, str) else a for a in args]
                        n_kwargs = {k: (re.sub(r'(\[.*?\]|\*.*?\*|\(.*?\))', '', v).strip() if isinstance(v, str) else v) for k, v in kwargs.items()}
                        return f(*n_args, **n_kwargs)
                    return _wrapped
                setattr(self.model, m_name, _wrap_chat(orig_chat_func))

        # --- UI ACTION QUEUE (PREVENTS TKINTER HOTKEY FREEZES) ---
        self.ui_action_queue = queue.Queue()
        def _tk_callback_error(exc, val, tb):
            _log_crash("TK CALLBACK ERROR", exc, val, tb)
            print(f"[UI Error] {val}  (details in CRASH_LOG.txt)")
        self.root.report_callback_exception = _tk_callback_error
        self._process_ui_actions()
        
       # --- MONKEY PATCH: DUAL AI DIRECTIVE INJECTOR & GEMINI OVERRIDE ---
        self.model._original_generate_ai_completion = self.model.generate_ai_completion
        def _patched_gen(*args, **kwargs):
            try:
                messages = kwargs.get('messages')
                if not messages and len(args) > 0:
                    messages = args[0]
                    
                if messages and isinstance(messages, list) and len(messages) > 0:
                    sys_msg = messages[0]
                    if sys_msg.get('role') == 'system':
                        is_hotkey = "YOU are currently holding the controller" in sys_msg.get('content', '')
                        
                        # --- PERSONA ENFORCER & HARDCODE STRIPPER ---
                        persona_name = getattr(self.model, 'current_persona', 'Default')
                        import re
                        if "pinoy" not in persona_name.lower():
                            # 🛡️ THE EXORCISM: Scrub hidden lore and heavily enforce pure English without mentioning forbidden words
                            sys_msg['content'] = re.sub(r'(?i)(filipino|pinoy|tagalog|taglish|philippines|manila|mabuhay|grabe|solid|nakakabaliw)', '', sys_msg['content'])
                            sys_msg['content'] = re.sub(r'(?i)talk exactly like a normal .*? gamer streamer\.?', '', sys_msg['content'])
                            
                            if "[CRITICAL RULE]: Your Persona is" not in sys_msg['content']:
                                sys_msg['content'] += f"\n\n[CRITICAL RULE]: Your Persona is '{persona_name}'. You are a native English speaker. You ONLY know the English language. Respond exclusively in standard English."
                        else:
                            if "[CRITICAL RULE]: Your Persona is" not in sys_msg['content']:
                                sys_msg['content'] += f"\n\n[CRITICAL RULE]: Your Persona is '{persona_name}'. You MUST speak in natural Taglish (Tagalog mixed with English) exactly like a Filipino streamer!"

                        if is_hotkey:
                            if getattr(self, 'global_directive_enabled', False) and getattr(self, 'global_directive_text', "").strip():
                                directive_str = f"\n\n[CRITICAL GLOBAL DIRECTIVE - YOU MUST OBEY THIS ABOVE ALL ELSE]:\n{self.global_directive_text.strip()}\n"
                                if "[CRITICAL GLOBAL DIRECTIVE" not in sys_msg['content']:
                                    sys_msg['content'] += directive_str
                                    print(f"[System] 👑 Hotkey Directive Injected into AI Prompt!")
                        else:
                            anti_hallucination = "\n\n[CRITICAL RULE]: YOU ARE JUST CHATTING. DO NOT narrate gameplay. DO NOT invent events. Reply DIRECTLY to what the viewer just said while STRICTLY obeying the requested word length and vibe."
                            if "[CRITICAL RULE]: YOU ARE JUST CHATTING" not in sys_msg['content']:
                                sys_msg['content'] += anti_hallucination

                        if getattr(self, 'chat_directive_enabled', False) and getattr(self, 'chat_directive_text', "").strip():
                            directive_str = f"\n\n[CRITICAL CHAT DIRECTIVE - YOU MUST OBEY THIS ABOVE ALL ELSE]:\n{self.chat_directive_text.strip()}\n"
                            if "[CRITICAL CHAT DIRECTIVE" not in sys_msg['content']:
                                sys_msg['content'] += directive_str
                                print(f"[System] 💬 Chat Directive Injected into AI Prompt!")
            # 🛡️ THE MISSING EXCEPT BLOCK:
            except Exception as e:
                print(f"[Directive Injector Error] {e}")

            # 🚀 NATIVE GEMINI BYPASS: Disables Google's Strict Safety Filters 🚀
            if getattr(self.model, 'ai_mode', '') == 'gemini':
                keys = getattr(self.model, 'gemini_api_keys', [])
                if not keys:
                    print("[Gemini Error] No API Key found in settings!")
                    return None
                
                if not hasattr(self.model, 'gemini_key_index'): 
                    self.model.gemini_key_index = 0
                
                for attempt in range(len(keys)):
                    current_key = keys[self.model.gemini_key_index]
                    try:
                        import requests
                        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={current_key}"

                        sys_text = ""
                        gemini_history = []
                        for m in messages:
                            if m.get('role') == 'system':
                                sys_text += m.get('content', '') + "\n"
                            elif m.get('role') in ['user', 'assistant']:
                                role = "user" if m.get('role') == 'user' else "model"
                                gemini_history.append({"role": role, "parts": [{"text": m.get('content', '')}]})
                        
                        if not gemini_history:
                            gemini_history.append({"role": "user", "parts": [{"text": "Hello"}]})
                            
                        payload = {
                            "contents": gemini_history,
                            "generationConfig": {
                                "temperature": kwargs.get('temperature', 0.8),
                                "maxOutputTokens": 500
                            },
                            "safetySettings": [
                                {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
                                {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
                                {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
                                {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"}
                            ]
                        }
                        
                        if sys_text:
                            payload["system_instruction"] = {"parts": [{"text": sys_text}]}
                        
                        resp = requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=15)
                        
                        if resp.status_code == 200:
                            return resp.json()['candidates'][0]['content']['parts'][0]['text'].strip()
                        elif resp.status_code == 429:
                            print(f"[Gemini] ⚠️ Key #{self.model.gemini_key_index + 1} hit quota. Trying next key...")
                            self.model.gemini_key_index = (self.model.gemini_key_index + 1) % len(keys)
                            continue
                        else:
                            print(f"[Gemini API Error] {resp.status_code}: {resp.text}")
                            return None
                    except Exception as e:
                        print(f"[Gemini Core Error] {e}")
                        self.model.gemini_key_index = (self.model.gemini_key_index + 1) % len(keys)
                        continue
                return None
                        
            res = self.model._original_generate_ai_completion(*args, **kwargs)
            if not res:
                print(f"\n[AI Error] ❌ Backend ({self.model.ai_mode.upper()}) failed to generate text! (The Review Window won't open if there is no text).")                
            return res
        self.model.generate_ai_completion = _patched_gen
        
       # --- MONKEY PATCH: PROTECT VRAM FROM AUTO REPLIES ---
        if not hasattr(self, '_ai_reply_lock'):
            import threading
            self._ai_reply_lock = threading.Lock()

        if hasattr(self.model, 'process_reply'):
            orig_process_reply = self.model.process_reply

            def _call_orig_process_reply(args, kwargs):
                """FIX: the old fallback retried with ONLY the positional args, silently dropping the voice/text/
                category/force_fresh flags. Now it drops just the keywords the model does not understand."""
                try:
                    return orig_process_reply(*args, **kwargs)
                except TypeError as e:
                    if "unexpected keyword argument" not in str(e): raise   # a real crash: let the crash logger see it
                    import inspect
                    ok = set(inspect.signature(orig_process_reply).parameters)
                    return orig_process_reply(*args, **{k: v for k, v in kwargs.items() if k in ok})

            def _safe_process_reply(*args, **kwargs):
                is_manual = kwargs.get('is_manual', False)
                if len(args) > 6: is_manual = args[6]
                
                # 🛡️ 1. THE FAST CHATTER BOUNCER (Auto-Replies Only)
                if not is_manual:
                    import time
                    now = time.time()
                    
                    # Rule A: Has it been 12 seconds since the last reply?
                    if now - getattr(self, '_last_auto_reply_time', 0) < getattr(self, 'auto_reply_cooldown', 12.0):
                        print("[Auto-Reply] ⏳ Reply dropped: auto-reply cooldown still active.")
                        return
                        
                    # Rule B: Is the AI currently busy? If yes, instantly drop the chat to prevent a crash!
                    if not self._ai_reply_lock.acquire(blocking=False):
                        print("[Auto-Reply] ⏳ Reply dropped: another auto-reply is still being processed.")
                        return

                    try:
                        self._last_auto_reply_time = time.time()

                        # Apply Auto Mode GUI Setting
                        auto_mode = getattr(self, 'auto_reply_output_mode', 'V+T')
                        if auto_mode == "V":
                            kwargs['force_voice_only'] = True
                            kwargs['force_text_only'] = False
                        elif auto_mode == "T":
                            kwargs['force_voice_only'] = False
                            kwargs['force_text_only'] = True
                        elif auto_mode == "V+T":
                            # FIX: False/False fell back to the GLOBAL bot mode, so V+T often posted nothing to chat
                            kwargs['force_voice_only'] = True
                            kwargs['force_text_only'] = True

                        if getattr(self, 'force_cache_only', False):
                            kwargs['force_text_only'] = True
                            kwargs['force_voice_only'] = False
                            kwargs['force_fresh'] = False
                        
                        if kwargs.get('force_text_only', False) and not kwargs.get('force_voice_only', False):
                            kwargs['force_cache_file'] = None
                            
                        return _call_orig_process_reply(args, kwargs)
                    finally:
                        self._ai_reply_lock.release() # Unlock when done!
                
                # 🛡️ 2. MANUAL REPLIES
                else:
                    if kwargs.get('force_text_only', False) and not kwargs.get('force_voice_only', False):
                        kwargs['force_cache_file'] = None
                        
                    return _call_orig_process_reply(args, kwargs)
            self.model.process_reply = _safe_process_reply
        
        self._bind_model_events()
        self.view = StreamerBotView(self.root, self)
        self.patch_view_components()
        
        print("[System] TIP: If hotkeys stop working in-game, try running this app as Administrator.")
        self._setup_realtime_listeners()
        
        self.guide_file_content = None
        self.last_search_index = 0
        self.last_search_query = ""
        self.is_generating = False

        self.log_redirector = TextRedirector(self.view.console_text)
        class CleanOutput:
            def __init__(self, target, ui_queue): 
                self.target = target
                self.ui_queue = ui_queue
                
            def write(self, text):
                text_len = len(text) if hasattr(text, '__len__') else 1
                if not isinstance(text, str): return text_len
                
                if "Loading weights:" in text or "it/s" in text or "Materializing param" in text: 
                    return text_len
                
                # 🛡️ THE OOM (Out of Memory) SHIELD: If the UI is backed up with more than 
                # 150 tasks, silently drop the background console prints to save the app!
                if self.ui_queue.qsize() > 150:
                    return text_len
                    
                safe_text = "".join(c for c in text if ord(c) <= 0xFFFF)
                try: self.ui_queue.put(lambda st=safe_text: self.target.write(st))
                except: pass
                
                return text_len
                
            def flush(self): 
                if self.ui_queue.qsize() > 150: return
                try: self.ui_queue.put(lambda: self.target.flush())
                except: pass
                
        self.clean_redirector = CleanOutput(self.log_redirector, self.ui_action_queue)
        sys.stdout = self.clean_redirector
        sys.stderr = self.clean_redirector

        self.load_config(silent=True)
        self.refresh_audio_menus()
        self.inject_save_as_menu()
        self._setup_console_menu()
        
        # 🔥 THE CRIMSON DESERT FORCE INJECTOR 🔥
        crimson_prompts = [
            "React with pure hype to hitting a WWE-style suplex or brutal grapple on an enemy. Scream about how Kliff just broke that guy in half with the crazy physics!",
            "Freak out because an enemy just used a crazy new attack, and Kliff just 'witnessed and learned' it mid-combat! Brag to the viewers that you're about to use it against them.",
            "Lose your mind with excitement because you just unlocked and started piloting a dwarven mech or riding a dragon for the first time.",
            "Get totally distracted from a serious mercenary mission because you found a cat to pet or a pig to carry around. Tell chat this is the real endgame.",
            "Panic hilariously because you accidentally hit someone or stole a wagon in Hernand, and now the guards are hunting you. Beg chat for escape advice!",
            "Pop off with hype because you just found a super rare Abyss Artifact. Talk about how insane the stat boost is going to be for your build.",
            "Brag to the viewers about destroying a tough boss purely through raw combat skill and perfect parries, since there's no level scaling to carry you in this game.",
            "Panic because you are climbing a massive cliff using the grappling hook, and your blue stamina bar is about to run out. Scream that you're going to fall!",
            "Proudly show off your newly built Greymane mercenary camp to the stream. Flex about the furniture or the NPCs you've recruited.",
            "Marvel at the crazy BlackSpace Engine physics. React to kicking an enemy so hard they flew into a horse or completely shattered a wooden watchtower.",
            "Take a chill, cozy break. Tell the viewers you're just kicking back to do some cooking, fishing (without a rod!), and vibing in the open world of Pywel.",
            "Scream 'PARRY GOD!' and hype up your own reflexes after hitting a flawless, perfectly-timed sword block against a huge enemy attack.",
            "React to igniting your sword with fire or another elemental imbuement. Tell chat how incredibly cool the combat animations look right now.",
            "Yell in shock because you just got ambushed and surrounded by a massive group of outlaws in the wild. Tell chat it's time to lock in and focus.",
            "Stop moving for a second and just admire the insane graphics. Point out the dynamic weather, the mud physics, or how beautiful the world looks."
        ]
        
        for i, text in enumerate(crimson_prompts, start=1):
            attr = f"hk_custom_{i}_prompt"
            # Only force inject if the box is currently blank
            if not getattr(self, attr, "").strip():
                setattr(self, attr, text)
                # Visually update the UI text boxes instantly
                if hasattr(self.view, 'hk_var_refs'):
                    for var, var_name in self.view.hk_var_refs:
                        if var_name == attr:
                            try: var.set(text)
                            except: pass
        
        # Save them permanently to the new config file!
        self.save_config()

        self.root.after(1000, self._check_overlay_queue)
        self.root.after(1000, self._update_sys_status_overlay)
        
        # 🚀 START REMOTE COMPANION SERVER
        self._start_remote_companion_server()
        
        self.root.mainloop()

    def _start_remote_companion_server(self):
        import http.server
        import socketserver
        import threading
        import json
        import urllib.parse
        import os
        import socket

        class CompanionAPIHandler(http.server.BaseHTTPRequestHandler):
            controller = self

            def do_OPTIONS(self):
                self.send_response(200)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                self.end_headers()

            def do_GET(self):
                parsed = urllib.parse.urlparse(self.path)
                self.send_response(200)
                self.send_header('Access-Control-Allow-Origin', '*')
                
                if parsed.path == '/sounds':
                    self.send_header('Content-type', 'application/json')
                    self.end_headers()
                    sound_dir = "soundboard_audio"
                    os.makedirs(sound_dir, exist_ok=True)
                    files = [f for f in os.listdir(sound_dir) if f.lower().endswith(('.mp3', '.wav', '.ogg'))]
                    self.wfile.write(json.dumps(files).encode('utf-8'))
                    
                elif parsed.path == '/playlists':
                    self.send_header('Content-type', 'application/json')
                    self.end_headers()
                    sound_dir = "soundboard_audio"
                    playlist_file = os.path.join(sound_dir, "playlists.json")
                    playlists = {"All Sounds": []} 
                    if os.path.exists(playlist_file):
                        try:
                            with open(playlist_file, "r") as f:
                                playlists = json.load(f)
                        except: pass
                    self.wfile.write(json.dumps(playlists).encode('utf-8'))

                elif parsed.path == '/hotkeys':
                    self.send_header('Content-type', 'application/json')
                    self.end_headers()
                    # 🤖 Dynamically load all available StreamerBot Hotkeys
                    actions = [
                        {"id": "hk_vision", "label": "👁️ Vision Reaction"},
                        {"id": "hk_reply_last", "label": "💬 Reply Last"},
                        {"id": "hk_idle", "label": "Idle Chat"},
                        {"id": "hk_thanks", "label": "Greet / Thanks"},
                        {"id": "hk_question", "label": "Game Question"},
                        {"id": "hk_help", "label": "Ask for Help"},
                        {"id": "hk_death", "label": "Death / Rage"},
                        {"id": "hk_likes_thanks", "label": "Thanks for Likes"},
                        {"id": "hk_brb", "label": "BRB / AFK"},
                        {"id": "hk_intro", "label": "Stream Intro"},
                        {"id": "hk_panic", "label": "Panic / Scream"},
                        {"id": "hk_clip_that", "label": "Clip That!"},
                    ]
                    
                    # 🚀 THE UPGRADE: Sends the full prompt to your phone for live editing
                    for i in range(1, 16):
                        prompt = getattr(self.controller, f"hk_custom_{i}_prompt", "")
                        custom = getattr(self.controller, f"hk_custom_{i}_custom", "")
                        lbl = custom if custom else (prompt if prompt else f"Custom Slot {i}")
                        lbl = lbl[:25] + "..." if len(lbl) > 25 else lbl
                        actions.append({
                            "id": f"hk_custom_{i}", 
                            "label": lbl, 
                            "is_custom": True, 
                            "full_prompt": prompt
                        })
                    self.wfile.write(json.dumps(actions).encode('utf-8'))

                elif parsed.path == '/play':
                    self.send_header('Content-type', 'application/json')
                    self.end_headers()
                    query = urllib.parse.parse_qs(parsed.query)
                    file = query.get('file', [None])[0]
                    if file:
                        filepath = os.path.join("soundboard_audio", file)
                        if os.path.exists(filepath):
                            self.controller.play_soundboard_audio(filepath)

                elif parsed.path == '/trigger':
                    self.send_header('Content-type', 'application/json')
                    self.end_headers()
                    query = urllib.parse.parse_qs(parsed.query)
                    action_id = query.get('id', [None])[0]
                    if action_id:
                        method_map = {
                            "hk_idle": self.controller.trigger_hotkey_idle,
                            "hk_thanks": self.controller.trigger_hotkey_thanks,
                            "hk_question": self.controller.trigger_hotkey_game_q,
                            "hk_help": self.controller.trigger_hotkey_help,
                            "hk_death": self.controller.trigger_hotkey_death,
                            "hk_likes_thanks": self.controller.trigger_hotkey_likes_thanks,
                            "hk_brb": self.controller.trigger_hotkey_brb,
                            "hk_intro": self.controller.trigger_hotkey_intro,
                            "hk_panic": self.controller.trigger_hotkey_panic,
                            "hk_clip_that": self.controller.trigger_hotkey_clip_that,
                            "hk_vision": self.controller.trigger_hotkey_vision_reaction,
                            "hk_reply_last": self.controller.trigger_hotkey_reply_last,
                        }
                        if action_id in method_map:
                            threading.Thread(target=method_map[action_id], daemon=True).start()
                        elif action_id.startswith("hk_custom_"):
                            slot = action_id.split("_")[-1]
                            threading.Thread(target=lambda: self.controller._trigger_shared_hotkey(action_id, "", f"Custom Slot {slot}"), daemon=True).start()
                    self.wfile.write(json.dumps({"status": "ok"}).encode('utf-8'))
                    
                elif parsed.path == '/stop':
                    self.send_header('Content-type', 'application/json')
                    self.end_headers()
                    self.controller.stop_current_audio(flush_vram=False)
                    
                elif parsed.path == '/' or parsed.path == '/index.html':
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    # 🌐 The entirely upgraded Touch UI
                    html = """<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>Remote Companion</title>
<style>
body { background: #111; color: #fff; font-family: 'Segoe UI', sans-serif; margin: 0; padding: 20px; padding-bottom: 120px; user-select: none; }
h1 { text-align: center; color: #0ff; text-shadow: 0 0 10px rgba(0,255,255,0.5); margin-bottom: 10px; }
.tabs { display: flex; justify-content: center; gap: 10px; margin-bottom: 20px; }
.tab-btn { background: #222; color: #aaa; border: 2px solid #444; padding: 12px 20px; border-radius: 8px; font-size: 18px; font-weight: bold; cursor: pointer; transition: 0.2s; flex: 1; max-width: 250px;}
.tab-btn.active { background: #0080ff; color: #fff; border-color: #00aaff; box-shadow: 0 0 10px rgba(0,128,255,0.5); }
.controls { display: flex; justify-content: center; gap: 10px; margin-bottom: 30px; flex-wrap: wrap;}
select, button.ctrl-btn { background: #222; color: #fff; border: 1px solid #444; padding: 10px 15px; border-radius: 8px; font-size: 16px; cursor: pointer; }
.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 25px; }
.btn { 
    border-radius: 50%; aspect-ratio: 1; border: none; color: #fff; font-weight: 800; font-size: 15px; 
    text-shadow: 1px 1px 3px rgba(0,0,0,0.8); box-shadow: inset 0 -10px 0 rgba(0,0,0,0.3), 0 8px 15px rgba(0,0,0,0.6);
    cursor: pointer; transition: all 0.1s; display: flex; align-items: center; justify-content: center; padding: 15px;
    word-break: break-word; position: relative;
}
.btn:active { box-shadow: inset 0 -3px 0 rgba(0,0,0,0.4), 0 2px 5px rgba(0,0,0,0.5); transform: translateY(7px); }
.btn .add-to-playlist { position: absolute; top: -5px; right: -5px; background: #333; color: white; border-radius: 50%; width: 25px; height: 25px; border: 2px solid #111; font-size: 14px; display: none; align-items: center; justify-content: center;}
body.edit-mode .btn .add-to-playlist { display: flex; }
.c0 { background: radial-gradient(circle at 30% 30%, #ff4d4d, #cc0000); }
.c1 { background: radial-gradient(circle at 30% 30%, #4dff4d, #009900); }
.c2 { background: radial-gradient(circle at 30% 30%, #4da6ff, #0000cc); }
.c3 { background: radial-gradient(circle at 30% 30%, #ffff4d, #b3b300); }
.c4 { background: radial-gradient(circle at 30% 30%, #ff4dff, #990099); }
.c5 { background: radial-gradient(circle at 30% 30%, #4dffff, #008080); }
.c6 { background: radial-gradient(circle at 30% 30%, #ff9933, #cc6600); }
.stop-bar { position: fixed; bottom: 0; left: 0; right: 0; background: #222; padding: 20px; display: flex; justify-content: center; border-top: 2px solid #444; }
.stop-btn { background: linear-gradient(180deg, #ff3333, #990000); color: #fff; font-size: 24px; font-weight: bold; border: none; border-radius: 15px; padding: 20px 40px; width: 100%; max-width: 600px; box-shadow: inset 0 -5px 0 rgba(0,0,0,0.3), 0 5px 15px rgba(255,0,0,0.5); cursor: pointer; transition: all 0.1s; text-shadow: 1px 1px 2px black; }
.stop-btn:active { box-shadow: inset 0 -2px 0 rgba(0,0,0,0.4), 0 2px 5px rgba(0,0,0,0.5); transform: translateY(3px); }
</style></head><body>
<h1>📱 Remote Companion</h1>

<div class="tabs">
    <button onclick="setTab('sounds')" id="tab-sounds" class="tab-btn active">🎵 Soundboard</button>
    <button onclick="setTab('actions')" id="tab-actions" class="tab-btn">🤖 AI Actions</button>
</div>

<div class="controls" id="top-controls">
    <select id="playlist-select" onchange="renderGrid()"></select>
    <button class="ctrl-btn" onclick="toggleEditMode()" id="edit-btn">✏️ Edit Playlists</button>
    <button class="ctrl-btn" onclick="createPlaylist()" id="new-pl-btn">➕ New Playlist</button>
    <button class="ctrl-btn" onclick="deleteCurrentPlaylist()" id="del-pl-btn">🗑️ Delete Playlist</button>
</div>

<div class="grid" id="grid"></div>
<div class="stop-bar"><button class="stop-btn" onclick="fetch('/stop')">🛑 STOP ALL AUDIO</button></div>

<script>
let currentTab = 'sounds';
let allSounds = [];
let aiActions = [];
let playlists = {"All Sounds": []};
let currentPlaylist = "All Sounds";
let isEditMode = false;

function setTab(tab) {
    currentTab = tab;
    document.getElementById('tab-sounds').className = tab === 'sounds' ? 'tab-btn active' : 'tab-btn';
    document.getElementById('tab-actions').className = tab === 'actions' ? 'tab-btn active' : 'tab-btn';
    
    // Hide playlist controls when in AI Actions tab
    document.getElementById('playlist-select').style.display = tab === 'sounds' ? 'inline-block' : 'none';
    document.getElementById('new-pl-btn').style.display = tab === 'sounds' ? 'inline-block' : 'none';
    document.getElementById('del-pl-btn').style.display = tab === 'sounds' ? 'inline-block' : 'none';
    
    isEditMode = false;
    document.body.classList.remove('edit-mode');
    document.getElementById('edit-btn').innerText = tab === 'sounds' ? '✏️ Edit Playlists' : '✏️ Edit AI Prompts';
    renderGrid();
}

function toggleEditMode() {
    isEditMode = !isEditMode;
    document.body.classList.toggle('edit-mode', isEditMode);
    if (currentTab === 'sounds') {
        document.getElementById('edit-btn').innerText = isEditMode ? '✅ Done Editing' : '✏️ Edit Playlists';
    } else {
        document.getElementById('edit-btn').innerText = isEditMode ? '✅ Done Editing' : '✏️ Edit AI Prompts';
    }
    renderGrid();
}

function createPlaylist() {
    const name = prompt("Enter new playlist name:");
    if (name && !playlists[name]) {
        playlists[name] = [];
        savePlaylists();
        updatePlaylistDropdown();
        document.getElementById('playlist-select').value = name;
        renderGrid();
    }
}

function deleteCurrentPlaylist() {
    const name = document.getElementById('playlist-select').value;
    if (name !== "All Sounds") {
        if(confirm("Delete playlist '" + name + "'?")) {
            delete playlists[name];
            savePlaylists();
            updatePlaylistDropdown();
            renderGrid();
        }
    } else {
        alert("Cannot delete 'All Sounds'.");
    }
}

function toggleSoundInPlaylist(e, soundFile) {
    e.stopPropagation(); 
    const name = document.getElementById('playlist-select').value;
    if (name === "All Sounds") {
        alert("Select a custom playlist first to add/remove sounds.");
        return;
    }
    
    const index = playlists[name].indexOf(soundFile);
    if (index > -1) { playlists[name].splice(index, 1); } 
    else { playlists[name].push(soundFile); }
    savePlaylists();
    renderGrid();
}

function savePlaylists() {
    fetch('/save_playlists', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(playlists) });
}

function updatePlaylistDropdown() {
    const select = document.getElementById('playlist-select');
    const currentVal = select.value;
    select.innerHTML = '';
    for (const name in playlists) {
        const opt = document.createElement('option');
        opt.value = name;
        opt.innerText = name;
        select.appendChild(opt);
    }
    if (playlists[currentVal]) { select.value = currentVal; } 
    else { select.value = "All Sounds"; }
    currentPlaylist = select.value;
}

function renderGrid() {
    const g = document.getElementById('grid'); 
    g.innerHTML='';
    
    // 🤖 RENDER AI ACTIONS TAB
    if (currentTab === 'actions') {
        aiActions.forEach((a, i) => {
            const b = document.createElement('button');
            b.className = 'btn c' + (i % 7);
            b.innerText = a.label;
            
            // Allow prompt editing natively from the phone!
            if (isEditMode && a.is_custom) {
                const editIcon = document.createElement('div');
                editIcon.className = 'add-to-playlist';
                editIcon.innerText = '⚙️';
                editIcon.style.background = '#0080ff';
                b.appendChild(editIcon);
                
                b.onclick = (e) => {
                    const newPromptText = prompt("Live Edit AI Prompt for " + a.id + ":", a.full_prompt);
                    if (newPromptText !== null) {
                        fetch('/update_action', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({id: a.id, prompt: newPromptText})
                        }).then(() => fetchData());
                    }
                };
            } else {
                b.onclick = () => {
                    if (isEditMode) return;
                    b.style.transform = 'scale(0.9)';
                    setTimeout(() => b.style.transform = 'none', 100);
                    fetch('/trigger?id=' + a.id);
                };
            }
            g.appendChild(b);
        });
        return;
    }
    
    // 🎵 RENDER SOUNDBOARD TAB
    const activePlaylist = document.getElementById('playlist-select').value;
    let soundsToShow = activePlaylist === "All Sounds" ? allSounds : playlists[activePlaylist] || [];
    soundsToShow.sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()));

    if(!allSounds.length) { g.innerHTML='<h3 style="grid-column:1/-1;text-align:center;color:gray;">Add MP3/WAV files to the "soundboard_audio" folder on your Streaming PC!</h3>'; return; }
    if(!soundsToShow.length && activePlaylist !== "All Sounds" && !isEditMode) { g.innerHTML='<h3 style="grid-column:1/-1;text-align:center;color:gray;">No sounds in this playlist. Click Edit to add some!</h3>'; return; }
    
    const sourceList = isEditMode ? allSounds : soundsToShow;
    if (isEditMode) sourceList.sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()));

    sourceList.forEach((f, i) => {
        const b = document.createElement('button');
        b.className = 'btn c' + (i % 7);
        b.innerText = f.replace('.mp3','').replace('.wav','');
        b.onclick = () => fetch('/play?file=' + encodeURIComponent(f));
        
        const addBtn = document.createElement('div');
        addBtn.className = 'add-to-playlist';
        if (activePlaylist !== "All Sounds") {
             addBtn.innerText = (playlists[activePlaylist] || []).includes(f) ? '−' : '➕';
             addBtn.style.background = (playlists[activePlaylist] || []).includes(f) ? '#cc0000' : '#009900';
             addBtn.onclick = (e) => toggleSoundInPlaylist(e, f);
        } else {
             addBtn.innerText = '⚙️';
             addBtn.onclick = (e) => { e.stopPropagation(); alert("Select a custom playlist from the dropdown first to add/remove sounds."); };
        }
        b.appendChild(addBtn);
        g.appendChild(b);
    });
}

function fetchData() {
    if(isEditMode) return; 
    Promise.all([
        fetch('/sounds').then(r=>r.json()),
        fetch('/playlists').then(r=>r.json()),
        fetch('/hotkeys').then(r=>r.json())
    ]).then(([files, lists, actions]) => {
        allSounds = files;
        aiActions = actions;
        if(Object.keys(lists).length > 1) { 
            playlists = lists;
            if(!playlists["All Sounds"]) playlists["All Sounds"] = [];
        }
        updatePlaylistDropdown();
        renderGrid();
    });
}

fetchData(); 
setInterval(fetchData, 5000);
</script></body></html>"""
                    self.wfile.write(html.encode('utf-8'))

            def do_POST(self):
                parsed = urllib.parse.urlparse(self.path)
                
                # 🚀 THE UPGRADE: Endpoint to catch live prompt updates from your phone
                if parsed.path == '/update_action':
                    content_length = int(self.headers['Content-Length'])
                    post_data = self.rfile.read(content_length)
                    try:
                        data = json.loads(post_data.decode('utf-8'))
                        action_id = data.get("id")
                        new_prompt = data.get("prompt", "")
                        
                        if action_id and action_id.startswith("hk_custom_"):
                            attr_name = f"{action_id}_prompt"
                            
                            # 1. Instantly update the Controller Memory
                            setattr(self.controller, attr_name, new_prompt)
                            if hasattr(self.controller, 'model'):
                                setattr(self.controller.model, attr_name, new_prompt)
                            
                            # 2. Push it live to the physical Tkinter UI on your PC screen!
                            if hasattr(self.controller, 'ui_action_queue'):
                                def _push_to_ui():
                                    try:
                                        if hasattr(self.controller.view, 'hk_var_refs'):
                                            for var, v_name in self.controller.view.hk_var_refs:
                                                if v_name == attr_name:
                                                    var.set(new_prompt)
                                    except: pass
                                self.controller.ui_action_queue.put(_push_to_ui)
                            
                            # 3. Automatically save it forever to bot_config.json
                            if hasattr(self.controller, '_debounced_save'):
                                self.controller._debounced_save()
                            elif hasattr(self.controller, 'save_config'):
                                self.controller.save_config()
                                
                            print(f"[Remote UI] 📱 Synced & Saved new AI Prompt for {action_id}")
                            
                        self.send_response(200)
                    except Exception as e:
                        print(f"[Remote UI Error] Failed to update action: {e}")
                        self.send_response(500)
                    
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()

                elif parsed.path == '/save_playlists':
                    content_length = int(self.headers['Content-Length'])
                    post_data = self.rfile.read(content_length)
                    try:
                        playlists = json.loads(post_data.decode('utf-8'))
                        sound_dir = "soundboard_audio"
                        os.makedirs(sound_dir, exist_ok=True)
                        with open(os.path.join(sound_dir, "playlists.json"), "w") as f:
                            json.dump(playlists, f)
                        self.send_response(200)
                    except Exception as e:
                        print(f"Error saving playlists: {e}")
                        self.send_response(500)
                    
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()

            def log_message(self, format, *args): pass 

        def run_server():
            os.makedirs("soundboard_audio", exist_ok=True)
            
            local_ip = "127.0.0.1"
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(("8.8.8.8", 80))
                local_ip = s.getsockname()[0]
                s.close()
            except Exception:
                try: local_ip = socket.gethostbyname(socket.gethostname())
                except: pass

            port = 8080
            while port < 8090:
                try:
                    httpd = socketserver.TCPServer(("0.0.0.0", port), CompanionAPIHandler)
                    
                    msg = (f"\n=======================================================\n"
                           f"📱 REMOTE SOUNDBOARD ACTIVE!\n"
                           f"Open this exact link on your Legion Go or Phone:\n"
                           f"👉 http://{local_ip}:{port}\n"
                           f"=======================================================\n")
                    
                    print(msg)
                    
                    if hasattr(self, 'ui_action_queue') and hasattr(self, 'view') and hasattr(self.view, 'console_text'):
                        def _push_to_ui():
                            try:
                                self.view.console_text.config(state="normal")
                                self.view.console_text.insert("end", msg, "msg")
                                self.view.console_text.see("end")
                                self.view.console_text.config(state="disabled")
                            except: pass
                        self.ui_action_queue.put(_push_to_ui)

                    httpd.serve_forever()
                except OSError:
                    port += 1
        
        threading.Thread(target=run_server, daemon=True).start()

    def preload_bark(self):
        def _warmup():
            print("[System] Pre-warming audio engines in the background to prevent first-chat lag...")
            try:
                import pygame
                if not pygame.mixer.get_init(): pygame.mixer.init()
            except: pass
        threading.Thread(target=_warmup, daemon=True).start()

    def trigger_toggle_cache_mode(self):
        modes = ["shuffle", "repeat_all", "repeat_one"]
        idx = modes.index(getattr(self, 'cache_playback_mode', 'shuffle'))
        self.cache_playback_mode = modes[(idx + 1) % 3]
        print(f"[System] 🔄 Cache Playback Mode set to: {self.cache_playback_mode.upper()}")
        
        # Reset unplayed bags so new sorting/shuffling applies immediately
        self._unplayed_cache_bags.clear()
        self._debounced_save()

    def _update_sys_status_overlay(self):
        if getattr(self, 'sys_status_window', None) and self.sys_status_window.winfo_exists():
            try:
                self.lbl_sys_ai_mode.config(text=f"AI Engine: {self.model.ai_mode.upper()}")
                self.lbl_sys_tts_mode.config(text=f"TTS Engine: {self.model.tts_mode.upper()}")
                
                if self.global_ai_mute:
                    self.lbl_sys_mute.config(text="AI Mute: ON", fg="red")
                else:
                    self.lbl_sys_mute.config(text="AI Mute: OFF", fg="#00FF00")

                if getattr(self, 'force_cache_only', False):
                    self.lbl_sys_force_cache.config(text="Force Cache: ON", fg="yellow")
                else:
                    self.lbl_sys_force_cache.config(text="Force Cache: OFF", fg="gray")

                cache_mode_str = getattr(self, 'cache_playback_mode', 'shuffle').upper()
                self.lbl_sys_cache_mode.config(text=f"Cache Mode: {cache_mode_str}")
            except Exception:
                pass
        self.root.after(1000, self._update_sys_status_overlay)

    def trigger_sys_status(self):
        try:
            if getattr(self, 'sys_status_window', None) and hasattr(self.sys_status_window, 'winfo_exists') and self.sys_status_window.winfo_exists():
                self.sys_status_geo_cache = self.sys_status_window.geometry()
                self.sys_status_window.destroy()
                self.sys_status_window = None
                self._debounced_save()
                print("[System] System Status Overlay Closed")
                return

            print("[System] System Status Overlay Opening...")
            self.sys_status_window = tk.Toplevel(self.root)
            self.sys_status_window.title("System Status")
            safe_geo = self._clamp_geo(getattr(self, 'sys_status_geo_cache', "300x150+100+100"))
            self.sys_status_window.geometry(safe_geo if safe_geo else "300x150+100+100")
            self.sys_status_window.configure(bg="#111111")
            self.sys_status_window.attributes("-topmost", True)
            self.sys_status_window.overrideredirect(True)
            self.sys_status_window._is_ghost = False
            try: self.sys_status_window.attributes("-alpha", getattr(self, 'overlay_opacity', 0.85))
            except: pass

            def start_move(event):
                self.sys_status_window._drag_data = {'x': event.x, 'y': event.y}
            def stop_move(event):
                self.sys_status_window._drag_data = None
                if getattr(self, 'sys_status_window', None) and hasattr(self.sys_status_window, 'winfo_exists') and self.sys_status_window.winfo_exists():
                    self.sys_status_geo_cache = self.sys_status_window.geometry()
                    self._debounced_save()
            def do_move(event):
                if getattr(self.sys_status_window, '_drag_data', None):
                    x = self.sys_status_window.winfo_x() - self.sys_status_window._drag_data['x'] + event.x
                    y = self.sys_status_window.winfo_y() - self.sys_status_window._drag_data['y'] + event.y
                    self.sys_status_window.geometry(f"+{x}+{y}")
            
            content = tk.Frame(self.sys_status_window, bg="#111111")
            content.pack(fill="both", expand=True, pady=5, padx=5)
            
            lbl_title = tk.Label(content, text="STREAMER BOT STATUS", font=("Segoe UI", 10, "bold"), fg="#00FFFF", bg="#111111")
            lbl_title.pack(anchor="w")
            
            self.lbl_sys_ai_mode = tk.Label(content, text="AI Engine: --", font=("Segoe UI", 9), fg="white", bg="#111111")
            self.lbl_sys_ai_mode.pack(anchor="w")

            self.lbl_sys_tts_mode = tk.Label(content, text="TTS Engine: --", font=("Segoe UI", 9), fg="white", bg="#111111")
            self.lbl_sys_tts_mode.pack(anchor="w")

            self.lbl_sys_mute = tk.Label(content, text="AI Mute: OFF", font=("Segoe UI", 9, "bold"), fg="#00FF00", bg="#111111")
            self.lbl_sys_mute.pack(anchor="w")

            self.lbl_sys_force_cache = tk.Label(content, text="Force Cache: OFF", font=("Segoe UI", 9, "bold"), fg="gray", bg="#111111")
            self.lbl_sys_force_cache.pack(anchor="w")

            self.lbl_sys_cache_mode = tk.Label(content, text="Cache Mode: SHUFFLE", font=("Segoe UI", 9, "bold"), fg="orange", bg="#111111")
            self.lbl_sys_cache_mode.pack(anchor="w")

            # Bind drag to all elements inside
            for widget in [content, lbl_title, self.lbl_sys_ai_mode, self.lbl_sys_tts_mode, self.lbl_sys_mute, self.lbl_sys_force_cache, self.lbl_sys_cache_mode]:
                widget.bind("<ButtonPress-1>", start_move)
                widget.bind("<ButtonRelease-1>", stop_move)
                widget.bind("<B1-Motion>", do_move)

            # Add resize grip
            grip = tk.Frame(self.sys_status_window, bg="#111111", cursor="bottom_right_corner")
            grip.place(relx=1.0, rely=1.0, anchor="se", width=15, height=15)
            tk.Frame(grip, bg="#555", width=4, height=4).place(x=8, y=8)
            tk.Frame(grip, bg="#555", width=4, height=4).place(x=4, y=8)
            tk.Frame(grip, bg="#555", width=4, height=4).place(x=8, y=4)
            
            def start_resize(event):
                self.sys_status_window._resize_start_x = event.x_root
                self.sys_status_window._resize_start_y = event.y_root
                self.sys_status_window._resize_start_w = self.sys_status_window.winfo_width()
                self.sys_status_window._resize_start_h = self.sys_status_window.winfo_height()

            def do_resize(event):
                dx = event.x_root - self.sys_status_window._resize_start_x
                dy = event.y_root - self.sys_status_window._resize_start_y
                new_w = max(180, self.sys_status_window._resize_start_w + dx)
                new_h = max(120, self.sys_status_window._resize_start_h + dy)
                self.sys_status_window.geometry(f"{new_w}x{new_h}")
                
            grip.bind("<ButtonPress-1>", start_resize)
            grip.bind("<B1-Motion>", do_resize)
            grip.bind("<ButtonRelease-1>", lambda e: self._debounced_save())

            self._update_sys_status_overlay()
            print("[System] System Status Overlay Opened")
        except Exception as e: print(f"[Sys Status Overlay Error] {e}")

    def trigger_sys_status_ghost(self):
        if not getattr(self, 'sys_status_window', None) or not hasattr(self.sys_status_window, 'winfo_exists') or not self.sys_status_window.winfo_exists(): return
        try:
            import ctypes, sys
            hwnd = self.sys_status_window.winfo_id()
            user32 = ctypes.windll.user32
            LWA_ALPHA, WS_EX_LAYERED, GWL_EXSTYLE, WS_EX_TRANSPARENT = 0x00000002, 0x00080000, -20, 0x00000020

            try:
                gwl = user32.GetWindowLongPtrW
                swl = user32.SetWindowLongPtrW
            except AttributeError:
                gwl = user32.GetWindowLongW
                swl = user32.SetWindowLongW
                
            gwl.argtypes, swl.argtypes = [ctypes.c_void_p, ctypes.c_int], [ctypes.c_void_p, ctypes.c_int, ctypes.c_size_t]
            gwl.restype, swl.restype = ctypes.c_size_t, ctypes.c_size_t
                
            hwnd_root = user32.GetAncestor(hwnd, 2)
            style = gwl(ctypes.c_void_p(hwnd_root), GWL_EXSTYLE)
            if style is None: return
            
            is_ghost = getattr(self.sys_status_window, '_is_ghost', False)

            if is_ghost:
                new_style = style & ~WS_EX_TRANSPARENT
                swl(ctypes.c_void_p(hwnd_root), GWL_EXSTYLE, new_style)
                user32.SetLayeredWindowAttributes(hwnd_root, 0, 255, LWA_ALPHA)
                self.sys_status_window._is_ghost = False
                self.sys_status_window.attributes("-topmost", True)
                print("[System] System Stats Ghost Mode OFF")
            else:
                new_style = style | WS_EX_TRANSPARENT | WS_EX_LAYERED
                swl(ctypes.c_void_p(hwnd_root), GWL_EXSTYLE, new_style)
                opacity_byte = int(getattr(self, 'overlay_opacity', 0.7) * 255)
                user32.SetLayeredWindowAttributes(hwnd_root, 0, opacity_byte, LWA_ALPHA)
                self.sys_status_window._is_ghost = True
                self.sys_status_window.attributes("-topmost", True)
                print("[System] System Stats Ghost Mode ON")
        except Exception as e: print(f"[Ghost Mode Error] {e}")


    # --- OFF-SCREEN RESCUE SAFEGUARD ---
    def _clamp_geo(self, geo_str):
        if not geo_str or not isinstance(geo_str, str): return ""
        import re
        if "+-" in geo_str or "-+" in geo_str or "+-32000" in geo_str: return ""
        m = re.match(r"(\d+)x(\d+)\+([-]?\d+)\+([-]?\d+)", geo_str)
        if m:
            w, h, x, y = map(int, m.groups())
            try:
                screen_w = self.root.winfo_screenwidth()
                screen_h = self.root.winfo_screenheight()
                x = max(0, min(x, screen_w - 100))
                y = max(0, min(y, screen_h - 100))
                return f"{w}x{h}+{x}+{y}"
            except: pass
        return geo_str

    # --- THREAD-SAFE GLOBAL AUTO-SAVER ---
    def _debounced_save(self):
        if hasattr(self, '_save_timer') and self._save_timer is not None:
            self.root.after_cancel(self._save_timer)
        self._save_timer = self.root.after(1500, self.save_config)

    def _process_ui_actions(self):
        # 🛡️ THE FRAME LIMITER: Only process a maximum of 40 UI tasks per frame.
        # This guarantees the app will NEVER freeze, no matter how much data is spammed.
        count = 0
        while not self.ui_action_queue.empty() and count < 40:
            try:
                func = self.ui_action_queue.get_nowait()
                func()
            except Exception as e: 
                _log_crash("UI ACTION ERROR", type(e), e, e.__traceback__)   # file only (no console) to avoid recursion loops
            count += 1
            
        # Run slightly faster (every 30ms instead of 50ms) to keep up with the queue
        self.root.after(30, self._process_ui_actions)

    def stop_current_audio(self, flush_vram=False):
        self._generation_counter += 1
        self.is_generating = False
        global_abort_flag[0] = True
        try: setattr(self.model, 'abort_generation', True)
        except: pass
        try:
            import pygame
            if pygame.mixer.get_init(): pygame.mixer.stop() 
        except: pass
        
        # FIX: Removed 'review_decision_queue' from this list! Wiping it was permanently deadlocking the bot
        for q_name in ['manual_reply_queue', 'tts_queue', 'target_reply_queue']:
            try:
                q = getattr(self.model, q_name, None)
                if q:
                    with q.mutex: q.queue.clear()
            except: pass
            
        if flush_vram:
            def _flush_vram():
                import gc, sys, time
                def _abort_hook(*args, **kwargs): raise RuntimeError("AUDIO_INSTANTLY_ABORTED_BY_USER")
                try:
                    if 'bark.generation' in sys.modules:
                        import bark.generation
                        if hasattr(bark.generation, 'models'):
                            for val in bark.generation.models.values():
                                if hasattr(val, 'register_forward_pre_hook'): val.register_forward_pre_hook(_abort_hook)
                    if hasattr(self.model, 'kokoro_pipeline') and getattr(self.model, 'kokoro_pipeline', None):
                        if hasattr(self.model.kokoro_pipeline.model, 'register_forward_pre_hook'): self.model.kokoro_pipeline.model.register_forward_pre_hook(_abort_hook)
                except Exception: pass
                time.sleep(0.2)
                try:
                    if 'bark.generation' in sys.modules:
                        import bark.generation
                        if hasattr(bark.generation, 'models'): bark.generation.models.clear()
                        if hasattr(bark.generation, 'has_been_preloaded'): bark.generation.has_been_preloaded = False
                        try: bark.generation.clean_models()
                        except: pass
                except: pass
                try:
                    self.model.kokoro_pipeline = None
                    self.model.whisper_model = None
                except: pass
                try:
                    gc.collect()
                    if 'torch' in sys.modules:
                        import torch
                        if torch.cuda.is_available():
                            torch.cuda.empty_cache()
                            if hasattr(torch.cuda, 'ipc_collect'): torch.cuda.ipc_collect()
                            try: torch.cuda.reset_peak_memory_stats()
                            except: pass
                            print("\n[System] 🛑 Audio aborted and ALL VRAM physically flushed to 0%!")
                except Exception as e: print(f"[VRAM Flush Error] {e}")
            threading.Thread(target=_flush_vram, daemon=True).start()

    def play_soundboard_audio(self, filepath):
        def _play():
            try:
                import pygame
                if not pygame.mixer.get_init(): pygame.mixer.init()
                pygame.mixer.stop()
                vol = getattr(self, 'soundboard_volume', 1.0)
                try:
                    if filepath.lower().endswith(".wav"):
                        model_module.play_wav_winsound(filepath, vol)
                    else:
                        sound = pygame.mixer.Sound(filepath)
                        sound.set_volume(min(1.0, vol * 2.0))
                        sound.play()
                except Exception as e: print(f"\n[Soundboard Error] Failed to play audio. Note: Pygame strongly prefers .WAV files over .MP3! Error: {e}")
            except Exception as e: print(f"[Soundboard Critical Error] {e}")
        threading.Thread(target=_play, daemon=True).start()

    def set_overlay_opacity(self, val):
        try:
            self.overlay_opacity = float(val)
            opacity_byte = int(self.overlay_opacity * 255)
            
            for win_name in ['overlay_guide_window', 'overlay_status_window', 'mk1_guide_window', 'overlay_music_window', 'sys_status_window']:
                win = getattr(self, win_name, None)
                if win and hasattr(win, 'winfo_exists') and win.winfo_exists():
                    try: win.attributes("-alpha", self.overlay_opacity)
                    except: pass
            
            for win_name in ['guide_window', 'status_window', 'selector_window', 'music_window']:
                win = getattr(self.view, win_name, None)
                if win and hasattr(win, 'winfo_exists') and win.winfo_exists():
                    try: win.attributes("-alpha", self.overlay_opacity)
                    except: pass

            if getattr(self, 'yt_cmd_queue', None): 
                self.yt_cmd_queue.put(f'opacity:{opacity_byte}')
            
            self._debounced_save()
                
        except Exception as e: print(f"[Overlay Opacity Error] {e}")

    def patch_view_components(self):
        # Start the background UI syncer to automatically populate dropdowns!
        self.root.after(500, self._background_ui_syncer)

    def _background_ui_syncer(self):
        # Checks the dropdowns for Fish Speech, ElevenLabs, and RVC
        sync_targets = {
            'fish_preset_combo': 'fish_presets',
            'elevenlabs_preset_combo': 'elevenlabs_presets',
            'rvc_preset_combo': 'rvc_presets'
        }
        
        for combo_name, dict_name in sync_targets.items():
            if hasattr(self.view, combo_name) and getattr(self.model, dict_name, None) is not None:
                combo = getattr(self.view, combo_name)
                
                # 🛡️ THE FIX: Check if the user closed the window before trying to update!
                if not combo or not combo.winfo_exists():
                    continue 

                # Grab the actual saved names from the database
                target_vals = list(getattr(self.model, dict_name).keys())
                
                try:
                    # See what is currently displayed in the dropdown
                    raw_vals = combo.cget("values") if hasattr(combo, "cget") else combo["values"]
                    current_vals = list(raw_vals) if raw_vals else []
                except:
                    current_vals = []
                
                # If the dropdown is out of date, forcefully update it!
                if current_vals != target_vals:
                    try: combo.configure(values=target_vals)
                    except: combo['values'] = target_vals
                    
        # Loop this check every half-second silently in the background
        self.root.after(500, self._background_ui_syncer)

    def trigger_open_live_context(self):
        if hasattr(self, 'context_win') and self.context_win and self.context_win.winfo_exists():
            self.context_win.lift()
            return
            
        self.context_win = tk.Toplevel(self.root)
        self.context_win.title("Live Situation Context")
        self.context_win.geometry("400x250")
        self.context_win.attributes("-topmost", True)
        self.context_win.configure(bg="#1e1e1e")

        tk.Label(self.context_win, text="What is happening right now?", bg="#1e1e1e", fg="#00FFFF", font=("Arial", 10, "bold")).pack(pady=(10, 5))
        self.ctx_text = tk.Text(self.context_win, height=4, width=40, bg="#333", fg="white", font=("Arial", 10), insertbackground="white")
        self.ctx_text.pack(padx=10, pady=5)
        self.ctx_text.insert("1.0", getattr(self, "hk_live_context_prompt", ""))

        f = tk.Frame(self.context_win, bg="#1e1e1e")
        f.pack(pady=10)
        tk.Label(f, text="Trigger Keybind:", bg="#1e1e1e", fg="gray").pack(side="left")
        self.ctx_hk_var = tk.StringVar(value=getattr(self, "hk_live_context", ""))
        tk.Entry(f, textvariable=self.ctx_hk_var, width=15, bg="#222", fg="yellow", justify="center", insertbackground="white").pack(side="left", padx=5)

        def save_ctx():
            setattr(self, "hk_live_context_prompt", self.ctx_text.get("1.0", "end-1c").strip())
            setattr(self, "hk_live_context", self.ctx_hk_var.get().strip())
            self.save_config()
            self.toggle_hotkeys_logic()
            self.context_win.destroy()
            print("[System] Live Context Hotkey Saved!")

        tk.Button(self.context_win, text="💾 Save & Bind", bg="#008000", fg="white", font=("Arial", 9, "bold"), command=save_ctx).pack(pady=5)

    def _setup_console_menu(self):
        self.console_menu = tk.Menu(self.root, tearoff=0)
        self.console_menu.add_command(label="📂 Open Folder Location", command=self.open_selected_cache_folder)
        self.console_menu.add_command(label="❌ Delete Cache File on this Line", command=self.delete_selected_cache)
        def show_menu(event):
            self.view.console_text.mark_set("insert", f"@{event.x},{event.y}")
            try: self.console_menu.tk_popup(event.x_root, event.y_root)
            finally: self.console_menu.grab_release()
        self.view.console_text.bind("<Button-3>", show_menu)
        self.view.console_text.bind("<Delete>", lambda e: self.delete_selected_cache())

    def _get_selected_cache_path(self):
        line_text = self.view.console_text.get("insert linestart", "insert lineend")
        import re, os
        match = re.search(r'([a-zA-Z0-9_\-]+\.wav)', line_text)
        search_dirs = ["bark_cache", "kokoro_cache", "voicebox_cache", "rvc_cache", "fish_cache", "edge_cache", "tiktok_cache", "google_cache", "elevenlabs_cache"]
        
        if match:
            wav_name = match.group(1)
            for c_dir in search_dirs:
                if not os.path.exists(c_dir): continue
                for root, dirs, files in os.walk(c_dir):
                    if wav_name in files:
                        return os.path.join(root, wav_name)
                
        snippet = ""
        if "CACHE:" in line_text: snippet = line_text.split("CACHE:")[1]
        elif "audio chunk:" in line_text: snippet = line_text.split("audio chunk:")[1]
        elif "): " in line_text: snippet = line_text.split("): ")[1]
        snippet = snippet.replace("'", "").replace('"', "").replace("...", "").strip().lower()
        if snippet:
            for c_dir in search_dirs:
                if not os.path.exists(c_dir): continue
                for root, dirs, files in os.walk(c_dir):
                    for file in files:
                        if file.endswith('.txt'):
                            txt_path = os.path.join(root, file)
                            try:
                                with open(txt_path, "r", encoding="utf-8") as f:
                                    if f.read().strip().lower().startswith(snippet):
                                        potential_wav = txt_path.replace(".txt", ".wav")
                                        if os.path.exists(potential_wav): return potential_wav
                            except: pass
        return None

    def open_selected_cache_folder(self):
        found_path = self._get_selected_cache_path()
        if not found_path:
            return messagebox.showwarning("Not Found", "Could not find a linked cache file on this line.", parent=self.root)
        import os
        folder = os.path.dirname(os.path.abspath(found_path))
        try:
            os.startfile(folder)
        except AttributeError:
            import subprocess
            subprocess.Popen(['explorer', folder])

    def delete_selected_cache(self):
        try:
            found_path = self._get_selected_cache_path()
            if not found_path:
                return messagebox.showwarning("Not Found", "Could not find a linked cache file on this line.\nPlease right-click directly on a line containing a cached message.", parent=self.root)
            
            txt_path = found_path.replace(".wav", ".txt")
            if messagebox.askyesno("Confirm Delete", f"Are you sure you want to permanently delete this cached audio?\n\n{found_path}", parent=self.root):
                deleted = False
                import os
                if os.path.exists(found_path): os.remove(found_path); deleted = True
                if os.path.exists(txt_path): os.remove(txt_path)
                if deleted:
                    print(f"\n[System] 🗑️ Deleted cache file: {found_path}")
                    messagebox.showinfo("Deleted", "Cache file successfully deleted.", parent=self.root)
                else: messagebox.showwarning("Error", "File could not be deleted or was not found.", parent=self.root)
        except Exception as e: print(f"Delete Error: {e}")

    def _bind_model_events(self):
        # 🛡️ ROUTE ALL BACKGROUND EVENTS THROUGH THE THREAD-SAFE QUEUE
        self.model.on('chat_preview', lambda a, m: self.ui_action_queue.put(lambda: self._append_chat_preview(a, m)))
        self.model.on('viewer_count', lambda c: self.ui_action_queue.put(lambda: self.view.lbl_viewers.config(text=f"👁️ Viewers: {c}")))
        self.model.on('stats_display', lambda v, l: self.ui_action_queue.put(lambda: self._update_stats_display_safe(v, l)))
        self.model.on('sub_count', lambda c: self.ui_action_queue.put(lambda: self._update_sub_count_safe(c)))
        
        def _safe_review(t, c):
            safe_t = "".join(ch for ch in str(t) if ord(ch) <= 0xFFFF)
            safe_c = "".join(ch for ch in str(c) if ord(ch) <= 0xFFFF)
            self.ui_action_queue.put(lambda: self.view.show_review_ui(safe_t, safe_c))
        self.model.on('ask_review', _safe_review)
        
        def _safe_music(name):
            safe_name = "".join(ch for ch in str(name) if ord(ch) <= 0xFFFF)
            self.ui_action_queue.put(lambda: self._update_music_song_label(safe_name))
        self.model.on('music_song_changed', _safe_music)
        
        self.model.on('bot_stopped', lambda: self.ui_action_queue.put(self._on_bot_stopped))

    def _on_bot_stopped(self):
        def _reset_ui():
            self.view.start_btn.config(state="normal")
            if hasattr(self.view, 'sim_btn'): self.view.sim_btn.config(state="normal")
            self.view.stop_btn.config(state="disabled")
            self.view.channel_combo.config(state="normal")
            self.view.game_entry.config(state="normal")
        self.root.after(0, _reset_ui)

    def _update_stats_display_safe(self, viewers, likes):
        self._pending_stats = (viewers, likes)
        if not getattr(self, '_stats_timer_active', False):
            self._stats_timer_active = True
            self.root.after(500, self._apply_stats_display)

    def _apply_stats_display(self):
        self._stats_timer_active = False
        if not getattr(self, '_pending_stats', None): return
        viewers, likes = self._pending_stats
        
        if getattr(self.view, 'status_window', None) and hasattr(self.view.status_window, 'winfo_exists') and self.view.status_window.winfo_exists():
            try: self.view.lbl_stat_viewers_val.config(text=str(viewers))
            except: pass
            try: self.view.lbl_stat_likes_val.config(text=str(likes))
            except: pass
        
        if getattr(self, 'overlay_status_window', None) and hasattr(self.overlay_status_window, 'winfo_exists') and self.overlay_status_window.winfo_exists():
            try: self.lbl_hk_viewers.config(text=str(viewers) if int(viewers) >= 0 else "--")
            except: pass
            try: self.lbl_hk_likes.config(text=str(likes) if int(likes) >= 0 else "--")
            except: pass

    def _update_sub_count_safe(self, count):
        self._pending_subs = count
        if not getattr(self, '_subs_timer_active', False):
            self._subs_timer_active = True
            self.root.after(500, self._apply_sub_display)

    def _apply_sub_display(self):
        self._subs_timer_active = False
        count = getattr(self, '_pending_subs', None)
        if count is None: return
        
        if getattr(self.view, 'status_window', None) and hasattr(self.view.status_window, 'winfo_exists') and self.view.status_window.winfo_exists():
            try: self.view.lbl_stat_subs_val.config(text=str(count))
            except: pass
        if getattr(self, 'overlay_status_window', None) and hasattr(self.overlay_status_window, 'winfo_exists') and self.overlay_status_window.winfo_exists():
            try: self.lbl_hk_subs.config(text=str(count) if int(count) >= 0 else "--")
            except: pass
        
    def _update_music_song_label(self, name):
        if getattr(self.view, 'music_lbl_song', None) and hasattr(self.view.music_lbl_song, 'winfo_exists') and self.view.music_lbl_song.winfo_exists():
            self.view.music_lbl_song.config(text=f"Playing: {name[:20]}")
        if getattr(self, 'overlay_music_lbl_song', None) and hasattr(self.overlay_music_lbl_song, 'winfo_exists') and self.overlay_music_lbl_song.winfo_exists():
            self.overlay_music_lbl_song.config(text=f"Playing: {name[:20]}")

    def launch_youtube_player(self):
        try:
            import multiprocessing
            import time
            now = time.time()
            
            if now - getattr(self, '_last_yt_toggle', 0) < 1.5: return
            self._last_yt_toggle = now

            if getattr(self, 'overlay_process', None) and self.overlay_process.is_alive():
                print("[System] Closing YouTube Player Overlay...")
                
                self._check_overlay_queue()
                
                if self.yt_cmd_queue: self.yt_cmd_queue.put('quit')
                self.root.after(200, lambda: self.overlay_process.terminate() if self.overlay_process and self.overlay_process.is_alive() else None)
                self.overlay_process = None
                
                self.save_config()
                return

            target_url = getattr(self, 'overlay_url_cache', 'https://www.youtube.com')
            yt_time = getattr(self, 'yt_current_time_cache', 0.0)

            if "watch?v=" in target_url:
                import re
                target_url = re.sub(r'&t=\d+s?', '', target_url)
                if yt_time > 0:
                    target_url += f"&t={int(yt_time)}s"

            geo = getattr(self, 'overlay_geo_cache', {"x": 100, "y": 100, "width": 640, "height": 360})
            if not isinstance(geo, dict) or geo.get('x', -100) < -50 or geo.get('y', -100) < -50:
                geo = {"x": 100, "y": 100, "width": 640, "height": 360}

            self.overlay_process = multiprocessing.Process(
                target=_run_youtube_player_process,
                args=(target_url, yt_time, getattr(self, 'overlay_opacity', 0.7), geo, self.overlay_geo_queue, self.yt_cmd_queue, self.overlay_state_queue),
                daemon=True
            )
            self.overlay_process.start()
            print(f"[System] YouTube Player Overlay Launched -> {target_url} (Resuming at {yt_time}s)")
            
        except Exception as e:
            print(f"[YouTube Overlay Error] {e}")

    def _check_overlay_queue(self):
        changed = False
        while not self.overlay_geo_queue.empty():
            try: 
                geo = self.overlay_geo_queue.get_nowait()
                if geo and 'x' in geo:
                    safe_geo = {
                        'x': int(geo['x']),
                        'y': int(geo['y']),
                        'width': int(geo['width']),
                        'height': int(geo['height'])
                    }
                    if safe_geo['x'] >= -50 and safe_geo['y'] >= -50:
                        old_geo = getattr(self, 'overlay_geo_cache', {})
                        if safe_geo.get('x') != old_geo.get('x') or safe_geo.get('y') != old_geo.get('y') or safe_geo.get('width') != old_geo.get('width') or safe_geo.get('height') != old_geo.get('height'):
                            self.overlay_geo_cache = safe_geo
                            changed = True
            except queue.Empty: break
            except Exception: pass
            
        while not self.overlay_state_queue.empty():
            try: 
                state = self.overlay_state_queue.get_nowait()
                if state:
                    if 'url' in state and state['url'].startswith("http"): 
                        if getattr(self, 'overlay_url_cache', '') != state['url']:
                            self.overlay_url_cache = str(state['url'])
                            changed = True
                    if 'time' in state: 
                        new_time = float(state['time'])
                        if abs(getattr(self, 'yt_current_time_cache', 0.0) - new_time) > 2.0:
                            self.yt_current_time_cache = new_time
                            changed = True
            except queue.Empty: break
            except Exception: pass

        if changed:
            self._debounced_save()

        if getattr(self, 'root', None):
            self.root.after(1000, self._check_overlay_queue)

    def _setup_realtime_listeners(self):
        try:
            def _update_model_attr(attr, var): setattr(self.model, attr, var.get())
            
            # FIX: Clear cache bags immediately when game changes so fallback doesn't pull old games
            def _update_game_and_flush(*a):
                _update_model_attr('game_name', self.view.game_var)
                self._unplayed_cache_bags.clear()
                
            self.view.volume_level.trace_add("write", lambda *a: _update_model_attr('volume_level', self.view.volume_level))
            self.view.overlay_opacity_var.trace_add("write", lambda *a: self.set_overlay_opacity(self.view.overlay_opacity_var.get()))
            self.view.edge_voice_var.trace_add("write", lambda *a: _update_model_attr('edge_voice', self.view.edge_voice_var))
            self.view.bark_voice_var.trace_add("write", lambda *a: _update_model_attr('bark_voice', self.view.bark_voice_var))
            self.view.google_voice_var.trace_add("write", lambda *a: _update_model_attr('google_voice', self.view.google_voice_var))
            self.view.kokoro_voice_var.trace_add("write", lambda *a: _update_model_attr('kokoro_voice', self.view.kokoro_voice_var))
            if hasattr(self.view, 'soprano_voice_var'): self.view.soprano_voice_var.trace_add("write", lambda *a: _update_model_attr('soprano_voice', self.view.soprano_voice_var))
            if hasattr(self.view, 'tiktok_voice_var'): self.view.tiktok_voice_var.trace_add("write", lambda *a: _update_model_attr('tiktok_voice', self.view.tiktok_voice_var))
            if hasattr(self.view, 'voicebox_voice_var'): self.view.voicebox_voice_var.trace_add("write", lambda *a: _update_model_attr('voicebox_voice', self.view.voicebox_voice_var))
            if hasattr(self.view, 'game_var'): self.view.game_var.trace_add("write", _update_game_and_flush)
            
            self.view.tts_var.trace_add("write", lambda *a: self.set_tts_mode())
            self.view.stt_var.trace_add("write", lambda *a: self.set_stt_mode())
            self.view.out_var.trace_add("write", lambda *a: self.set_out_mode())
            self.view.auto_reply_var.trace_add("write", lambda *a: _update_model_attr('automated_replies_enabled', self.view.auto_reply_var))
            self.view.hotkeys_only_var.trace_add("write", lambda *a: _update_model_attr('hotkeys_only_mode', self.view.hotkeys_only_var))
            self.view.greet_viewers_var.trace_add("write", lambda *a: self.toggle_viewer_greeting())
            self.view.review_var.trace_add("write", lambda *a: self.toggle_review())
            self.view.idle_var.trace_add("write", lambda *a: self.toggle_idle())
            self.view.hotkeys_active.trace_add("write", lambda *a: self.toggle_hotkeys_logic())
            print("[System] Real-time setting listeners active.")
        except Exception as e: print(f"[System] Warning: Could not setup listeners: {e}")

    def inject_save_as_menu(self):
        try:
             menubar = self.root.nametowidget(self.root['menu'])
             children = menubar.winfo_children()
             if children:
                 file_menu = children[0]
                 file_menu.add_separator()
                 file_menu.add_command(label="💾 Save Config As...", command=self.save_config_as)
        except: pass

    def _append_chat_preview(self, author, message):
        try:
            # 🛡️ THE SPAM SHIELD: Physically reject UI drawing if chats are flooding in!
            import time
            now = time.time()
            if not hasattr(self, '_chat_ui_timer'):
                self._chat_ui_timer = now
                self._chat_ui_count = 0
                
            if now - self._chat_ui_timer > 1.0:
                self._chat_ui_timer = now
                self._chat_ui_count = 0
                
            self._chat_ui_count += 1
            if self._chat_ui_count > 5:
                return # Skip UI rendering this frame to prevent Tkinter from freezing!

            # Filter out bots...
            if hasattr(self.view, 'hide_bot_chat_var') and self.view.hide_bot_chat_var.get():
                author_lower = str(author).lower()
                bot_names = ['nightbot', 'streamelements', 'streamlabs', 'moobot', 'wizebot', 'fossabot', 'commanderroot']
                if author_lower in bot_names or 'bot' in author_lower:
                    return

            safe_author = "".join(c for c in str(author) if ord(c) <= 0xFFFF)
            safe_message = "".join(c for c in str(message) if ord(c) <= 0xFFFF)
            
            # Strip tags for the bot
            if safe_author == getattr(self.model, 'channel_name', '') or safe_author == "Me" or safe_author == "StreamerBot":
                import re
                safe_message = re.sub(r'(\[.*?\]|\*.*?\*)', '', safe_message).strip()

            self.view.chat_preview_text.configure(state='normal')
            
            # 🛡️ MEMORY LEAK SHIELD: Keep chat box under 100 lines!
            lines = int(self.view.chat_preview_text.index('end-1c').split('.')[0])
            if lines > 100:
                self.view.chat_preview_text.delete('1.0', f'{lines - 80}.0')

            from datetime import datetime
            ts = datetime.now().strftime("%H:%M")
            self.view.chat_preview_text.insert("end", f"[{ts}] ", "msg")
            tag = "bot" if safe_author == getattr(self.model, 'channel_name', '') or safe_author == "Me" else "author"
            self.view.chat_preview_text.insert("end", f"{safe_author}: ", tag)
            self.view.chat_preview_text.insert("end", f"{safe_message}\n", "msg")
            self.view.chat_preview_text.see("end")
            self.view.chat_preview_text.configure(state='disabled')
        except: pass

    def music_load_folder(self, folder_path=None):
        if not folder_path: folder_path = filedialog.askdirectory()
        if folder_path: self.model.music_load_folder(folder_path)

    def music_play(self, index): self.model.music_play(index)
    def music_toggle_pause(self): self.model.music_toggle_pause()
    def music_next(self): self.model.music_next()
    def music_prev(self): self.model.music_prev()
    def music_set_vol(self, val): self.model.music_set_vol(val)
    
    def stop_music_playback(self):
        self.model.music_paused = True
        try:
            import pygame
            if pygame.mixer.get_init(): pygame.mixer.music.pause()
        except: pass
    
    def music_toggle_repeat(self):
        new_mode = self.model.music_toggle_repeat()
        txt = {"none": "🔁 Off", "one": "🔂 1", "all": "🔁 All"}.get(new_mode, "🔁 Off")
        if hasattr(self.view, 'music_btn_repeat') and self.view.music_btn_repeat:
            self.view.music_btn_repeat.config(text=txt)
        if getattr(self, 'overlay_music_btn_repeat', None) and hasattr(self.overlay_music_btn_repeat, 'winfo_exists') and self.overlay_music_btn_repeat.winfo_exists():
            self.overlay_music_btn_repeat.config(text=txt)

    def select_fish_audio(self):
        p = filedialog.askopenfilename(filetypes=[("Audio Files", "*.wav *.mp3")])
        if p:
            self.model.fish_audio_path = p
            if hasattr(self.view, 'lbl_fish_audio'): self.view.lbl_fish_audio.config(text=os.path.basename(p))

    def select_fish_text(self):
        p = filedialog.askopenfilename(filetypes=[("Text Files", "*.txt")])
        if p:
            self.model.fish_text_path = p
            if hasattr(self.view, 'lbl_fish_text'): self.view.lbl_fish_text.config(text=os.path.basename(p))

    def save_fish_preset(self):
        if not hasattr(self.view, 'fish_preset_name_var'): return
        name = self.view.fish_preset_name_var.get().strip()
        if not name: return messagebox.showwarning("Warning", "Please enter a preset name.")
        if not getattr(self.model, 'fish_audio_path', ""): return messagebox.showwarning("Warning", "Please select an audio reference.")
        
        if not hasattr(self.model, 'fish_presets'): self.model.fish_presets = {}
        self.model.fish_presets[name] = {
            "audio": self.model.fish_audio_path,
            "text": getattr(self.model, 'fish_text_path', "")
        }
        self.save_config()
        
        # --- THE GHOST DROPDOWN FIX ---
        if hasattr(self.view, 'fish_preset_combo'):
            updated_list = list(self.model.fish_presets.keys())
            try:
                # Try CustomTkinter method first
                self.view.fish_preset_combo.configure(values=updated_list) 
            except:
                # Fallback to standard ttk Combobox method
                self.view.fish_preset_combo['values'] = updated_list
            
            # Auto-select the newly created preset!
            self.view.fish_preset_combo.set(name)
        # ------------------------------

        if hasattr(self.view, 'refresh_fish_presets_ui'): self.view.refresh_fish_presets_ui()
        messagebox.showinfo("Saved", f"Fish Speech Preset '{name}' saved successfully!")
    def load_fish_preset(self, name):
        if not name or not hasattr(self.model, 'fish_presets') or name not in self.model.fish_presets: return
        preset = self.model.fish_presets[name]
        self.model.fish_audio_path = preset.get("audio", "")
        self.model.fish_text_path = preset.get("text", "")
        
        if hasattr(self.view, 'lbl_fish_audio') and self.view.lbl_fish_audio.winfo_exists():
            self.view.lbl_fish_audio.config(text=os.path.basename(self.model.fish_audio_path) if self.model.fish_audio_path else "None")
            self.view.lbl_fish_text.config(text=os.path.basename(self.model.fish_text_path) if self.model.fish_text_path else "None")
            self.view.fish_preset_name_var.set(name)
        print(f"[Fish] Loaded Preset: {name}")

    def delete_fish_preset(self):
        if not hasattr(self.view, 'fish_preset_combo'): return
        name = self.view.fish_preset_combo.get()
        if not name or name not in getattr(self.model, 'fish_presets', {}): return
        if messagebox.askyesno("Delete", f"Delete preset '{name}'?"):
            del self.model.fish_presets[name]
            self.save_config()
            self.view.fish_preset_combo.set("")
            self.view.fish_preset_name_var.set("")
            if hasattr(self.view, 'refresh_fish_presets_ui'): self.view.refresh_fish_presets_ui()
            messagebox.showinfo("Deleted", f"Preset '{name}' deleted.")


    def select_rvc_model(self):
        p = filedialog.askopenfilename(filetypes=[("PyTorch Model", "*.pth")])
        if p:
            self.model.rvc_model_path = p
            if hasattr(self.view, 'lbl_rvc_model'): self.view.lbl_rvc_model.config(text=os.path.basename(p))
    def save_elevenlabs_preset(self):
        if not hasattr(self.view, 'elevenlabs_preset_name_var') or not hasattr(self.view, 'elevenlabs_preset_id_var'): return
        
        name = self.view.elevenlabs_preset_name_var.get().strip()
        voice_id = self.view.elevenlabs_preset_id_var.get().strip()
        
        # Pull the new API Key and Email boxes
        api_key = getattr(self.view, 'elevenlabs_api_key_var', tk.StringVar()).get().strip()
        email = getattr(self.view, 'elevenlabs_email_var', tk.StringVar()).get().strip()
        
        if not name: return messagebox.showwarning("Warning", "Please enter a preset name.")
        if not voice_id: return messagebox.showwarning("Warning", "Please enter the Voice ID.")
        if not api_key: return messagebox.showwarning("Warning", "Please enter the API Key.")
        
        if not hasattr(self.model, 'elevenlabs_presets'): self.model.elevenlabs_presets = {}
        
        # 💾 THE UPGRADE: Save everything together as a locked package!
        self.model.elevenlabs_presets[name] = {
            "voice_id": voice_id,
            "api_key": api_key,
            "email": email
        }
        
        self.model.elevenlabs_voice = name
        self.save_config()
        
        if hasattr(self.view, 'refresh_elevenlabs_presets_ui'): self.view.refresh_elevenlabs_presets_ui()
        messagebox.showinfo("Saved", f"ElevenLabs Preset '{name}' saved successfully!")

    def load_elevenlabs_preset(self, name):
        if not name or not hasattr(self.model, 'elevenlabs_presets') or name not in self.model.elevenlabs_presets: return
        
        preset_data = self.model.elevenlabs_presets[name]
        
        # Backwards compatibility check (in case an old preset is still a string)
        if isinstance(preset_data, str):
            voice_id = preset_data
            api_key = ""
            email = ""
        else:
            voice_id = preset_data.get("voice_id", "")
            api_key = preset_data.get("api_key", "")
            email = preset_data.get("email", "")
        
        self.model.elevenlabs_voice = name
        
        # Push the loaded data to the UI boxes!
        if hasattr(self.view, 'elevenlabs_preset_name_var'): self.view.elevenlabs_preset_name_var.set(name)
        if hasattr(self.view, 'elevenlabs_preset_id_var'): self.view.elevenlabs_preset_id_var.set(voice_id)
        if hasattr(self.view, 'elevenlabs_api_key_var'): self.view.elevenlabs_api_key_var.set(api_key)
        if hasattr(self.view, 'elevenlabs_email_var'): self.view.elevenlabs_email_var.set(email)
            
        print(f"[ElevenLabs] Loaded Preset: {name} (Email: {email if email else 'None'})")

    def delete_elevenlabs_preset(self):
        if not hasattr(self.view, 'elevenlabs_preset_combo'): return
        name = self.view.elevenlabs_preset_combo.get()
        if not name or name not in getattr(self.model, 'elevenlabs_presets', {}): return
        if messagebox.askyesno("Delete", f"Delete ElevenLabs preset '{name}'?"):
            del self.model.elevenlabs_presets[name]
            self.save_config()
            self.view.elevenlabs_preset_combo.set("")
            if hasattr(self.view, 'elevenlabs_preset_name_var'): self.view.elevenlabs_preset_name_var.set("")
            if hasattr(self.view, 'refresh_elevenlabs_presets_ui'): self.view.refresh_elevenlabs_presets_ui()
            messagebox.showinfo("Deleted", f"Preset '{name}' deleted.")
    def save_custom_tiktok_voice(self):
        if not hasattr(self.view, 'tiktok_custom_name_var') or not hasattr(self.view, 'tiktok_custom_id_var'): return
        
        name = self.view.tiktok_custom_name_var.get().strip()
        voice_id = self.view.tiktok_custom_id_var.get().strip()
        
        if not name: return messagebox.showwarning("Warning", "Please enter a Voice Name.")
        if not voice_id: return messagebox.showwarning("Warning", "Please enter the exact Voice ID.")
        
        if not hasattr(self.model, 'custom_tiktok_voices'): self.model.custom_tiktok_voices = {}
        
        self.model.custom_tiktok_voices[name] = voice_id
        self.save_config()
        
        if hasattr(self.view, 'refresh_tiktok_custom_voices_ui'): self.view.refresh_tiktok_custom_voices_ui()
        messagebox.showinfo("Saved", f"Custom TikTok Voice '{name}' saved successfully!")

    def delete_custom_tiktok_voice(self):
        if not hasattr(self.view, 'tiktok_custom_combo'): return
        name = self.view.tiktok_custom_combo.get()
        if not name or name not in getattr(self.model, 'custom_tiktok_voices', {}): return
        if messagebox.askyesno("Delete", f"Delete custom voice '{name}'?"):
            del self.model.custom_tiktok_voices[name]
            self.save_config()
            self.view.tiktok_custom_combo.set("")
            self.view.tiktok_custom_name_var.set("")
            self.view.tiktok_custom_id_var.set("")
            if hasattr(self.view, 'refresh_tiktok_custom_voices_ui'): self.view.refresh_tiktok_custom_voices_ui()
            messagebox.showinfo("Deleted", f"Custom Voice '{name}' deleted.")
            
    def load_custom_tiktok_voice(self, name):
        if not name or not hasattr(self.model, 'custom_tiktok_voices') or name not in self.model.custom_tiktok_voices: return
        voice_id = self.model.custom_tiktok_voices[name]
        if hasattr(self.view, 'tiktok_custom_name_var'): self.view.tiktok_custom_name_var.set(name)
        if hasattr(self.view, 'tiktok_custom_id_var'): self.view.tiktok_custom_id_var.set(voice_id)
        print(f"[TikTok] Loaded Custom Voice: {name}")
    def select_rvc_index(self):
        p = filedialog.askopenfilename(filetypes=[("Index File", "*.index")])
        if p:
            self.model.rvc_index_path = p
            if hasattr(self.view, 'lbl_rvc_index'): self.view.lbl_rvc_index.config(text=os.path.basename(p))

    def set_rvc_pitch(self, val): self.model.rvc_pitch = int(float(val))

    def save_rvc_preset(self):
        if not hasattr(self.view, 'rvc_preset_name_var'): return
        name = self.view.rvc_preset_name_var.get().strip()
        if not name: return messagebox.showwarning("Warning", "Please enter a preset name.")
        if not getattr(self.model, 'rvc_model_path', ""): return messagebox.showwarning("Warning", "Please select a .pth model first.")
        if not hasattr(self.model, 'rvc_presets'): self.model.rvc_presets = {}
        self.model.rvc_presets[name] = {"pth": self.model.rvc_model_path, "index": getattr(self.model, 'rvc_index_path', ""), "pitch": getattr(self.model, 'rvc_pitch', 0)}
        self.save_config()
        if hasattr(self.view, 'refresh_rvc_presets_ui'): self.view.refresh_rvc_presets_ui()
        messagebox.showinfo("Saved", f"Preset '{name}' saved successfully!")

    def load_rvc_preset(self, name):
        if not name or not hasattr(self.model, 'rvc_presets') or name not in self.model.rvc_presets: return
        preset = self.model.rvc_presets[name]
        self.model.rvc_model_path = preset.get("pth", "")
        self.model.rvc_index_path = preset.get("index", "")
        self.model.rvc_pitch = preset.get("pitch", 0)
        if hasattr(self.view, 'lbl_rvc_model') and self.view.lbl_rvc_model.winfo_exists():
            self.view.lbl_rvc_model.config(text=os.path.basename(self.model.rvc_model_path) if self.model.rvc_model_path else "None")
            self.view.lbl_rvc_index.config(text=os.path.basename(self.model.rvc_index_path) if self.model.rvc_index_path else "None")
            self.view.rvc_pitch_var.set(self.model.rvc_pitch)
            self.view.rvc_preset_name_var.set(name)
        print(f"[RVC] Loaded Preset: {name}")

    def delete_rvc_preset(self):
        if not hasattr(self.view, 'rvc_preset_combo'): return
        name = self.view.rvc_preset_combo.get()
        if not name or name not in getattr(self.model, 'rvc_presets', {}): return
        if messagebox.askyesno("Delete", f"Delete preset '{name}'?"):
            del self.model.rvc_presets[name]
            self.save_config()
            self.view.rvc_preset_combo.set("")
            self.view.rvc_preset_name_var.set("")
            if hasattr(self.view, 'refresh_rvc_presets_ui'): self.view.refresh_rvc_presets_ui()
            messagebox.showinfo("Deleted", f"Preset '{name}' deleted.")


    def start_bot(self):
        if self.model.bot_running: return
        chan_str = self.view.channel_combo.get()
        if not chan_str: return messagebox.showerror("Error", "Please select a channel.")
        
        self.model.edge_voice = self.view.edge_voice_var.get()
        self.model.bark_voice = self.view.bark_voice_var.get()
        self.model.google_voice = self.view.google_voice_var.get()
        self.model.kokoro_voice = self.view.kokoro_voice_var.get()
        if hasattr(self.view, 'soprano_voice_var'): self.model.soprano_voice = self.view.soprano_voice_var.get()
        if hasattr(self.view, 'tiktok_voice_var'): self.model.tiktok_voice = self.view.tiktok_voice_var.get()
            
        self.model.volume_level = self.view.volume_level.get()
        self.model.automated_replies_enabled = self.view.auto_reply_var.get() 
        self.model.hotkeys_only_mode = self.view.hotkeys_only_var.get()
        self.model.review_mode = self.view.review_var.get()
        self.model.greet_new_viewers = self.view.greet_viewers_var.get()
        
        chan_idx = chan_str.split(":")[0]
        self.model.channel_id = os.environ.get(f"CHANNEL_{chan_idx}_ID")
        self.model.channel_name = os.environ.get(f"CHANNEL_{chan_idx}_NAME")
        self.model.token_prefix = os.environ.get(f"CHANNEL_{chan_idx}_TOKEN_PREFIX")
        self.model.game_name = self.view.game_var.get()
        self.model.stop_event.clear()
        self.model.bot_running = True
        
        self.view.start_btn.config(state="disabled")
        if hasattr(self.view, 'sim_btn'): self.view.sim_btn.config(state="disabled")
        self.view.stop_btn.config(state="normal")
        self.view.channel_combo.config(state="disabled")
        self.view.game_entry.config(state="disabled")
        
        # Unlock hotkeys safely on start
        self.root.focus_set()
        self.hotkeys_suspended = False
        try:
            self.view._auto_suspended = False
            self.model.os_is_typing = False
        except: pass
        
        self.preload_bark()
        
        def safe_run_bot():
            try:
                self.model.run_bot_logic()
            except Exception as e:
                print(f"\n[FATAL ERROR] Background Engine crashed! Voices/AI will stop working. Error: {e}")
                import traceback
                traceback.print_exc()
                self.model.bot_running = False
                self.root.after(0, self._on_bot_stopped)
        
        threading.Thread(target=safe_run_bot, daemon=True).start()

    def start_simulation(self):
        if self.model.bot_running: return
        
        viewers = simpledialog.askinteger("Simulation Viewers", "Enter starting viewer count for Simulation\n(Used for caching 'Thanks for x viewers' greetings):", initialvalue=150, parent=self.root)
        if viewers is not None: self.model.current_viewer_count = viewers
            
        # 1. Grab the currently selected channel from the Dropdown Menu
        chan_str = self.view.channel_combo.get()
        default_channel = "SimulationUser"
        if chan_str and ":" in chan_str:
            chan_idx = chan_str.split(":")[0]
            env_name = os.environ.get(f"CHANNEL_{chan_idx}_NAME")
            if env_name: default_channel = env_name

        # 2. Ask for the Mock Name, but default to the Dropdown Channel if cancelled!
        mock_channel = simpledialog.askstring("Simulation Channel", f"Enter a Mock Channel Name for the AI to use\n(Leave blank to use '{default_channel}'):", initialvalue=default_channel, parent=self.root)
        
        selected_name = mock_channel.strip() if mock_channel and mock_channel.strip() else default_channel

        print(f"\n[System] Starting Offline Simulation Mode as '{selected_name}'...")
        
        self.model.edge_voice = self.view.edge_voice_var.get()
        self.model.bark_voice = self.view.bark_voice_var.get()
        self.model.google_voice = self.view.google_voice_var.get()
        self.model.kokoro_voice = self.view.kokoro_voice_var.get()
        if hasattr(self.view, 'soprano_voice_var'): self.model.soprano_voice = self.view.soprano_voice_var.get()
        if hasattr(self.view, 'tiktok_voice_var'): self.model.tiktok_voice = self.view.tiktok_voice_var.get()
        
        self.model.volume_level = self.view.volume_level.get()
        self.model.automated_replies_enabled = self.view.auto_reply_var.get() 
        self.model.hotkeys_only_mode = self.view.hotkeys_only_var.get()
        self.model.review_mode = self.view.review_var.get()
        self.model.greet_new_viewers = self.view.greet_viewers_var.get()

        # Inject the mock name directly into the AI's identity
        self.model.channel_id = "sim_id_123"
        self.model.channel_name = selected_name 
        self.model.token_prefix = "sim"
        self.model.game_name = self.view.game_var.get()
        self.model.stop_event.clear()
        self.model.bot_running = True
        
        self.view.start_btn.config(state="disabled")
        if hasattr(self.view, 'sim_btn'): self.view.sim_btn.config(state="disabled")
        self.view.stop_btn.config(state="normal")
        self.view.channel_combo.config(state="disabled")
        self.view.game_entry.config(state="disabled")
        
        # Unlock hotkeys safely on start
        self.root.focus_set()
        self.hotkeys_suspended = False
        try:
            self.view._auto_suspended = False
            self.model.os_is_typing = False
        except: pass
        
        self.preload_bark()
        
        def safe_run_bot():
            try:
                self.model.run_bot_logic()
            except Exception as e:
                print(f"\n[FATAL ERROR] Background Engine crashed! Voices/AI will stop working. Error: {e}")
                import traceback
                traceback.print_exc()
                self.model.bot_running = False
                self.root.after(0, self._on_bot_stopped)
        
        threading.Thread(target=safe_run_bot, daemon=True).start()

    def stop_bot(self):
        if not self.model.bot_running: return
        print("\nStopping bot... please wait for current cycle to finish.")
        self.model.stop_event.set()
        with self.model.manual_reply_queue.mutex: self.model.manual_reply_queue.queue.clear()
        with self.model.target_reply_queue.mutex: self.model.target_reply_queue.queue.clear()
        self.root.after(100, self._safe_stop_cleanup)
        self.model.bot_running = False
        self.view.start_btn.config(state="normal")
        if hasattr(self.view, 'sim_btn'): self.view.sim_btn.config(state="normal")
        self.view.stop_btn.config(state="disabled")
        self.view.channel_combo.config(state="normal")
        self.view.game_entry.config(state="normal")

    def _safe_stop_cleanup(self): print("[System] Bot logic paused safely.")

    def on_close(self):
        print("Shutting down...")
        self.save_config()
        self.model.stop_event.set()
        try:
            if keyboard: keyboard.unhook_all()
        except: pass
        if self.overlay_process and self.overlay_process.is_alive(): self.overlay_process.terminate()
        self.root.destroy()
        sys.exit(0)

    def trigger_suspend_hotkeys(self):
        self.hotkeys_suspended = not getattr(self, 'hotkeys_suspended', False)
        state = "SUSPENDED (Safe to type)" if self.hotkeys_suspended else "ACTIVE"
        print(f"\n========================================")
        print(f"🛑 GLOBAL HOTKEYS ARE NOW {state} 🛑")
        print(f"========================================\n")
        try:
            import winsound
            if self.hotkeys_suspended:
                winsound.Beep(400, 200)
                winsound.Beep(300, 200)
            else:
                winsound.Beep(300, 200)
                winsound.Beep(400, 200)
        except: pass

    def save_jina_keys(self, token_str):
        data = self.model.load_config() or {}
        data["jina_api_keys"] = token_str
        self.model.save_config(data)
        print(f"[Config] Jina API Keys saved.")

    def save_hf_token(self, token):
        data = self.model.load_config() or {}
        data["hf_token"] = token
        self.model.save_config(data)
        print(f"[Config] HF Token saved.")

    def save_tiktok_session(self, token):
        
        data = self.model.load_config() or {}
        data["tiktok_session_id"] = token
        self.model.save_config(data)
        os.environ["TIKTOK_SESSION_ID"] = token
        print(f"[Config] TikTok Session ID saved.")
        
    def save_global_model_path(self, path_str):
        if hasattr(self, 'model'):
            self.model.global_model_path = path_str
        self._debounced_save()
        print(f"[Config] Global AI Model Path saved to: {path_str}")

    def _gather_config_data(self):
        sel_geo = getattr(self.view, 'saved_selector_geo', "")
        if getattr(self.view, 'selector_window', None) and hasattr(self.view.selector_window, 'winfo_exists') and self.view.selector_window.winfo_exists(): 
            sel_geo = self.view.selector_window.geometry()
            
        stat_geo = getattr(self, 'saved_status_geo', "250x100+100+100")
        if getattr(self, 'overlay_status_window', None) and hasattr(self.overlay_status_window, 'winfo_exists') and self.overlay_status_window.winfo_exists():
            stat_geo = self.overlay_status_window.geometry()
            
        music_geo = getattr(self, 'music_geo_cache', "300x120+100+100")
        if getattr(self, 'overlay_music_window', None) and hasattr(self.overlay_music_window, 'winfo_exists') and self.overlay_music_window.winfo_exists():
            music_geo = self.overlay_music_window.geometry()
        elif getattr(self.view, 'music_window', None) and hasattr(self.view.music_window, 'winfo_exists') and self.view.music_window.winfo_exists(): 
            music_geo = self.view.music_window.geometry()
        
        guide_geo = getattr(self, 'guide_geo_cache', "380x600+150+150")
        if getattr(self, 'overlay_guide_window', None) and hasattr(self.overlay_guide_window, 'winfo_exists') and self.overlay_guide_window.winfo_exists():
            guide_geo = self.overlay_guide_window.geometry()
            
        mk1_geo = getattr(self, 'mk1_geo_cache', "380x600+150+150")
        if getattr(self, 'mk1_guide_window', None) and hasattr(self.mk1_guide_window, 'winfo_exists') and self.mk1_guide_window.winfo_exists():
            mk1_geo = self.mk1_guide_window.geometry()
            
        sys_stat_geo = getattr(self, 'sys_status_geo_cache', "300x150+100+100")
        if getattr(self, 'sys_status_window', None) and hasattr(self.sys_status_window, 'winfo_exists') and self.sys_status_window.winfo_exists():
            sys_stat_geo = self.sys_status_window.geometry()
            
        rev_geo = getattr(self, 'review_geo_cache', "650x520+100+100")
        if getattr(self.view, 'review_window', None) and hasattr(self.view.review_window, 'winfo_exists') and self.view.review_window.winfo_exists():
            rev_geo = self.view.review_window.geometry()
        
        current_url = getattr(self, 'overlay_url_cache', "https://www.youtube.com")
        self.overlay_url_cache = current_url

        def safe_get(obj, default):
            try:
                if obj is None or not hasattr(obj, 'get'): return default
                val = obj.get()
                if val is None or str(val).strip().lower() == "none" or str(val).strip() == "": return default
                if isinstance(default, bool): return str(val).lower() in ['true', '1', 't', 'y', 'yes']
                if isinstance(default, int): return int(float(val))
                if isinstance(default, float): return float(val)
                return str(val)
            except: return default
# 🛡️ THE SAVE FIX: Rip the game name straight out of the physical UI box
        try: real_game_name = self.view.game_entry.get().strip()
        except: real_game_name = safe_get(getattr(self.view, 'game_var', None), "Just Chatting")
        if not real_game_name: real_game_name = "Just Chatting"
        data = {
            "output_mode": safe_get(getattr(self.view, 'out_var', None), 3),
            "auto_reply_output_mode": getattr(self, 'auto_reply_output_mode', 'V+T'), # 🛡️ NEW
            "mic_index": safe_get(getattr(self.view, 'mic_var', None), getattr(self.model, 'mic_device_index', 0) or 0),
            "overlay_geo_cache": getattr(self, 'overlay_geo_cache', {"x": 100, "y": 100, "width": 640, "height": 360}),
            "yt_current_time_cache": getattr(self, 'yt_current_time_cache', 0.0),
            "overlay_url_cache": getattr(self, 'overlay_url_cache', "https://www.youtube.com"),
            "channel_index": getattr(self.view, 'channel_combo', None).current() if hasattr(self.view, 'channel_combo') else 0,
            "game_name": real_game_name,
            "persona": safe_get(getattr(self.view, 'persona_combo', None), "English"),
            "review_mode": safe_get(getattr(self.view, 'review_var', None), False),
            "idle_chat": safe_get(getattr(self.view, 'idle_var', None), True),
            "automated_replies": safe_get(getattr(self.view, 'auto_reply_var', None), True),
            "hotkeys_only_mode": safe_get(getattr(self.view, 'hotkeys_only_var', None), False),
            "greet_viewers": safe_get(getattr(self.view, 'greet_viewers_var', None), True),
            "tts_mode": safe_get(getattr(self.view, 'tts_var', None), "edge"),
            "stt_mode": safe_get(getattr(self.view, 'stt_var', None), "google"),
            "output_mode": safe_get(getattr(self.view, 'out_var', None), 3),
            "mic_index": safe_get(getattr(self.view, 'mic_var', None), getattr(self.model, 'mic_device_index', 0) or 0),
            "spk_index": safe_get(getattr(self.view, 'spk_var', None), getattr(self.model, 'speaker_device_index', 0) or 0),
            "bark_voice": safe_get(getattr(self.view, 'bark_voice_var', None), "v2/en_speaker_6"),
            "edge_voice": safe_get(getattr(self.view, 'edge_voice_var', None), "en-US-SteffanNeural"),
            "google_voice": safe_get(getattr(self.view, 'google_voice_var', None), "en-US-Wavenet-I"),
            "kokoro_voice": safe_get(getattr(self.view, 'kokoro_voice_var', None), "am_adam"),
            "soprano_voice": safe_get(getattr(self.view, 'soprano_voice_var', None), "Default (Female)"),
            "tiktok_voice": safe_get(getattr(self.view, 'tiktok_voice_var', None), "en_us_002"),
            "voicebox_voice": safe_get(getattr(self.view, 'voicebox_voice_var', None), "default"),
            "volume": safe_get(getattr(self.view, 'volume_level', None), 1.0),
            "bark_use_gpu": safe_get(getattr(self.view, 'bark_use_gpu_var', None), True),
            "bark_use_small_models": safe_get(getattr(self.view, 'bark_use_small_var', None), False),
            "bark_low_vram": safe_get(getattr(self.view, 'bark_low_vram_var', None), False),
            # the Bark menu's own variables (the two keys above point at variables the menu does not have)
            "bark_use_cpu": safe_get(getattr(self.view, 'bark_use_cpu_var', None), False),
            "bark_small_models": safe_get(getattr(self.view, 'bark_small_models_var', None), False),
            "hotkeys_active": safe_get(getattr(self.view, 'hotkeys_active', None), True),
            "overlay_opacity": safe_get(getattr(self.view, 'overlay_opacity_var', None), getattr(self, 'overlay_opacity', 0.7))
        }

        data.update({
            "voicebox_url": getattr(self.model, 'voicebox_url', "http://127.0.0.1:17493"),
            "soprano_model_path": getattr(self.model, 'soprano_model_path', ""),
            "rvc_model_path": getattr(self.model, 'rvc_model_path', ""),
            "rvc_index_path": getattr(self.model, 'rvc_index_path', ""),
            "rvc_pitch": getattr(self.model, 'rvc_pitch', 0),
            "rvc_presets": getattr(self.model, 'rvc_presets', {}),
            "fish_audio_path": getattr(self.model, 'fish_audio_path', ""),
            "fish_text_path": getattr(self.model, 'fish_text_path', ""),
            "fish_presets": getattr(self.model, 'fish_presets', {}),
            "elevenlabs_presets": getattr(self.model, 'elevenlabs_presets', {}),
            "soundboard_volume": getattr(self, 'soundboard_volume', 1.0),
            "global_ai_mute": getattr(self, 'global_ai_mute', False),
            "force_cache_only": getattr(self, 'force_cache_only', False),
            "custom_length_enabled": getattr(self, 'custom_length_enabled', False),
            "custom_length_val": getattr(self, 'custom_length_val', 30),
            "vibe_check_enabled": getattr(self, 'vibe_check_enabled', True),
            "cache_playback_mode": getattr(self, 'cache_playback_mode', 'shuffle'),
            "yt_current_time": getattr(self, 'yt_current_time_cache', 0.0),
            "ai_mode": getattr(self.model, 'ai_mode', 'local'),
            "groq_model": getattr(self.model, 'groq_model', ""),
            "groq_keys": getattr(self.model, 'groq_api_keys', []),
            "gemini_keys": getattr(self.model, 'gemini_api_keys', []),
            "sambanova_keys": getattr(self.model, 'sambanova_api_keys', []),
            "openrouter_keys": getattr(self.model, 'openrouter_api_keys', []),
            "elevenlabs_keys": getattr(self.model, 'elevenlabs_api_keys', []),
            "elevenlabs_voice_id": getattr(self.model, 'elevenlabs_voice_id', ""),
            "tts_voice": getattr(self.model, 'tts_voice', ""),
            "hf_token": os.environ.get("HF_TOKEN", ""),
            "global_model_path": getattr(self.model, 'global_model_path', ""),
            "jina_api_keys": os.environ.get("JINA_API_KEYS", os.environ.get("JINA_API_KEY", "")),
            "tiktok_session_id": os.environ.get("TIKTOK_SESSION_ID", ""),
            "global_directive_enabled": getattr(self, 'global_directive_enabled', False),
            "global_directive_text": getattr(self, 'global_directive_text', ""),
            "chat_directive_enabled": getattr(self, 'chat_directive_enabled', False),
            "chat_directive_text": getattr(self, 'chat_directive_text', ""),
            "overlay_url": current_url,
            "geo_selector": sel_geo,
            "geo_status": stat_geo,
            "geo_music": music_geo,
            "geo_mk1": mk1_geo,
            "geo_guide": guide_geo,
            "geo_sys_status": sys_stat_geo,
            "geo_review": rev_geo,
            "geo_overlay": getattr(self, 'overlay_geo_cache', {}),
            "hk_live_context_prompt": getattr(self, "hk_live_context_prompt", ""),
            "music_folder": getattr(self.model, 'music_folder_cache', ""),
            "music_index": getattr(self.model, 'music_index', 0),
            "music_time": getattr(self.model, 'get_music_time', lambda: 0.0)(),
            "music_volume": getattr(self.model, 'music_vol', 0.5),
            "music_repeat": getattr(self.model, 'music_repeat_mode', 0),
            "music_was_playing": not getattr(self.model, 'music_paused', True),
            "music_window_open": True if (getattr(self.view, 'music_window', None) and self.view.music_window.winfo_exists()) else False,
            "hk_reply_last_mode": getattr(self, "hk_reply_last_mode", "V+T"),
            "hk_reply_last_short": getattr(self, "hk_reply_last_short", False)
        })

        for base in self.hk_bases:
            data[base] = getattr(self, base, "")
            data[f"{base}_mode"] = getattr(self, f"{base}_mode", "V+T")
            data[f"{base}_short"] = getattr(self, f"{base}_short", False)
            data[f"{base}_custom"] = getattr(self, f"{base}_custom", "")
            data[f"{base}_prompt"] = getattr(self, f"{base}_prompt", "") 
            data[f"{base}_audio"] = getattr(self, f"{base}_audio", "")
            data[f"{base}_audio_enabled"] = getattr(self, f"{base}_audio_enabled", False)
            data[f"{base}_mute_ai"] = getattr(self, f"{base}_mute_ai", False)

        for ghk in self.gui_hks: data[ghk] = getattr(self, ghk, "")
        return data

    def save_config(self):
        data = self._gather_config_data()
        saved_local = False
        
        if hasattr(self, 'active_config_path') and self.active_config_path and self.active_config_path != CONFIG_FILE:
            try:
                with open(self.active_config_path, "w") as f: json.dump(data, f, indent=4)
                saved_local = True
            except Exception as e: print(f"[Config Warning] Failed to update custom profile: {e}")
            
        try:
            with open(CONFIG_FILE, "w") as f: json.dump(data, f, indent=4)
            if hasattr(self.model, 'config_data'): self.model.config_data = data
        except Exception as e:
            if not saved_local: messagebox.showerror("Error", f"Could not save config: {e}")

    def save_config_as(self):
        data = self._gather_config_data()
        file_path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")], title="Save Game Config As...", initialfile=f"{data['game_name'].replace(' ', '_')}_config.json")
        if file_path:
            self.active_config_path = file_path
            try:
                with open(file_path, 'w') as f: json.dump(data, f, indent=4)
                with open(CONFIG_FILE, 'w') as f: json.dump(data, f, indent=4)
                messagebox.showinfo("Success", f"Config saved to:\n{os.path.basename(file_path)}")
            except Exception as e: messagebox.showerror("Error", f"Failed to save config: {e}")

    def load_config(self, silent=False):
        file_path = None if silent else filedialog.askopenfilename(title="Select Config File", filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")], initialdir=os.getcwd())
        if not silent and not file_path: return
        data = self.model.load_config(custom_path=file_path)
        if not data:
            if not silent: messagebox.showinfo("Info", "No valid config file found or selected.")
            return
        if file_path: self.active_config_path = file_path
        self._apply_config_data(data, silent)

    def _apply_config_data(self, data, silent=False):
        try:
            self.load_channels() 
            if "channel_index" in data and data["channel_index"] < len(self.view.channel_combo['values']): self.view.channel_combo.current(data["channel_index"])
            if "custom_length_val" in data: self.custom_length_val = data["custom_length_val"]
            if "auto_reply_output_mode" in data: self.auto_reply_output_mode = data["auto_reply_output_mode"] # 🛡️ NEW
            if "vibe_check_enabled" in data: self.vibe_check_enabled = data["vibe_check_enabled"]
            if "game_name" in data:
                self.model.game_name = data["game_name"]
                try: self.view.game_var.set(data["game_name"])
                except: pass
                
                # 🛡️ THE LOAD FIX: Physically delete the default text and inject the saved text!
                try:
                    if hasattr(self.view, 'game_entry'):
                        self.view.game_entry.config(state="normal")
                        self.view.game_entry.delete(0, 'end')
                        self.view.game_entry.insert(0, data["game_name"])
                except Exception: pass

            if "persona" in data: self.view.persona_combo.set(data["persona"]); self.on_persona_change(None)
            if "review_mode" in data: self.view.review_var.set(data["review_mode"])
            if "idle_chat" in data: self.view.idle_var.set(data["idle_chat"])
            if "automated_replies" in data: self.view.auto_reply_var.set(data["automated_replies"])
            if "hotkeys_only_mode" in data: self.view.hotkeys_only_var.set(data["hotkeys_only_mode"])
            if "greet_viewers" in data: self.view.greet_viewers_var.set(data["greet_viewers"])
            if "tts_mode" in data: self.view.tts_var.set(data["tts_mode"])
            if "stt_mode" in data: self.view.stt_var.set(data["stt_mode"])
            if "output_mode" in data: self.view.out_var.set(data["output_mode"])
            if "mic_index" in data: self.model.mic_device_index = data["mic_index"]; self.view.mic_var.set(self.model.mic_device_index)
            if "spk_index" in data: self.model.speaker_device_index = data["spk_index"]; self.view.spk_var.set(self.model.speaker_device_index)
            if "bark_voice" in data: self.view.bark_voice_var.set(data["bark_voice"])
            if "edge_voice" in data: self.view.edge_voice_var.set(data["edge_voice"])
            if "google_voice" in data: self.view.google_voice_var.set(data["google_voice"])
            if "kokoro_voice" in data: self.view.kokoro_voice_var.set(data["kokoro_voice"])
            if "soprano_voice" in data and hasattr(self.view, 'soprano_voice_var'): self.view.soprano_voice_var.set(data["soprano_voice"])
            if "tiktok_voice" in data and hasattr(self.view, 'tiktok_voice_var'): self.view.tiktok_voice_var.set(data["tiktok_voice"])
            if "voicebox_voice" in data and hasattr(self.view, 'voicebox_voice_var'): self.view.voicebox_voice_var.set(data["voicebox_voice"])
            if "voicebox_url" in data: self.model.voicebox_url = data["voicebox_url"]
            
            if "soprano_model_path" in data: self.model.soprano_model_path = data["soprano_model_path"]
            if "rvc_model_path" in data: self.model.rvc_model_path = data["rvc_model_path"]
            if "rvc_index_path" in data: self.model.rvc_index_path = data["rvc_index_path"]
            if "rvc_pitch" in data: self.model.rvc_pitch = data["rvc_pitch"]
            if "rvc_presets" in data: self.model.rvc_presets = data["rvc_presets"]
                
            if "fish_audio_path" in data: self.model.fish_audio_path = data["fish_audio_path"]
            if "fish_text_path" in data: self.model.fish_text_path = data["fish_text_path"]
            if "fish_presets" in data: self.model.fish_presets = data["fish_presets"]
            if "elevenlabs_presets" in data: self.model.elevenlabs_presets = data["elevenlabs_presets"]    
            if "tiktok_session_id" in data: os.environ["TIKTOK_SESSION_ID"] = data["tiktok_session_id"]
            if "global_model_path" in data: getattr(self, 'model', self).global_model_path = data["global_model_path"]
            if "jina_api_keys" in data: os.environ["JINA_API_KEYS"] = data["jina_api_keys"]
            elif "jina_api_key" in data: os.environ["JINA_API_KEYS"] = data["jina_api_key"]
            if "volume" in data: self.view.volume_level.set(data["volume"])
            
            if "soundboard_volume" in data: self.soundboard_volume = data["soundboard_volume"]
            if "global_ai_mute" in data: self.global_ai_mute = data["global_ai_mute"]
            if "force_cache_only" in data: 
                self.force_cache_only = data["force_cache_only"]
                self.model.force_cache_only = data["force_cache_only"]
            
            if "custom_length_enabled" in data: self.custom_length_enabled = data["custom_length_enabled"]
            if "custom_length_val" in data: self.custom_length_val = data["custom_length_val"]
            if "vibe_check_enabled" in data: self.vibe_check_enabled = data["vibe_check_enabled"]
            if "cache_playback_mode" in data: self.cache_playback_mode = data["cache_playback_mode"]

            if "global_directive_enabled" in data: 
                self.global_directive_enabled = data["global_directive_enabled"]
                self.model.global_directive_enabled = data["global_directive_enabled"]
            if "global_directive_text" in data: 
                self.global_directive_text = data["global_directive_text"]
                self.model.global_directive_text = data["global_directive_text"]
                
            if "chat_directive_enabled" in data: 
                self.chat_directive_enabled = data["chat_directive_enabled"]
                self.model.chat_directive_enabled = data["chat_directive_enabled"]
            if "chat_directive_text" in data: 
                self.chat_directive_text = data["chat_directive_text"]
                self.model.chat_directive_text = data["chat_directive_text"]

            if "overlay_opacity" in data: self.overlay_opacity = data["overlay_opacity"]; self.view.overlay_opacity_var.set(self.overlay_opacity)
            if "yt_current_time" in data: self.yt_current_time_cache = data["yt_current_time"]
            if "hk_live_context_prompt" in data: self.hk_live_context_prompt = data["hk_live_context_prompt"]
            
            if "geo_selector" in data and isinstance(data["geo_selector"], str): self.view.saved_selector_geo = self._clamp_geo(data["geo_selector"])
            if "geo_status" in data: self.saved_status_geo = self._clamp_geo(data["geo_status"])
            if "geo_guide" in data: self.guide_geo_cache = self._clamp_geo(data["geo_guide"])
            if "geo_mk1" in data: self.mk1_geo_cache = self._clamp_geo(data["geo_mk1"])
            if "geo_music" in data: self.music_geo_cache = self._clamp_geo(data["geo_music"])
            if "geo_sys_status" in data: self.sys_status_geo_cache = self._clamp_geo(data["geo_sys_status"])
            if "geo_review" in data: self.review_geo_cache = self._clamp_geo(data["geo_review"])
            if "geo_overlay" in data and isinstance(data["geo_overlay"], dict) and 'x' in data["geo_overlay"]: self.overlay_geo_cache = data["geo_overlay"]
            if "overlay_url" in data: self.overlay_url_cache = data["overlay_url"]
            
            for base in self.hk_bases:
                if base in data: setattr(self, base, data[base])
                if f"{base}_mode" in data: setattr(self, f"{base}_mode", data[f"{base}_mode"])
                if f"{base}_short" in data: setattr(self, f"{base}_short", data[f"{base}_short"])
                if f"{base}_custom" in data: setattr(self, f"{base}_custom", data[f"{base}_custom"])
                if f"{base}_prompt" in data: setattr(self, f"{base}_prompt", data[f"{base}_prompt"]) 
                if f"{base}_audio" in data: setattr(self, f"{base}_audio", data[f"{base}_audio"])
                if f"{base}_audio_enabled" in data: setattr(self, f"{base}_audio_enabled", data[f"{base}_audio_enabled"])
                if f"{base}_mute_ai" in data: setattr(self, f"{base}_mute_ai", data[f"{base}_mute_ai"])

            for ghk in self.gui_hks:
                if ghk in data: setattr(self, ghk, data[ghk])
                
            if "hk_reply_last_mode" in data: self.hk_reply_last_mode = data["hk_reply_last_mode"]
            if "hk_reply_last_short" in data: self.hk_reply_last_short = data["hk_reply_last_short"]
            
            if "music_folder" in data and data["music_folder"]:
                d = data["music_folder"]
                self.model.music_folder_cache = d
                self.model.music_playlist = glob.glob(os.path.join(d, "*.mp3")) + glob.glob(os.path.join(d, "*.wav"))
                if "music_index" in data: self.model.music_index = data["music_index"]
                if "music_volume" in data and hasattr(self.model, 'music_set_vol'): self.model.music_set_vol(data["music_volume"])
                if "music_repeat" in data: self.model.music_repeat_mode = data["music_repeat"]
                
                if not data.get("music_was_playing", False):
                    self.model.music_paused = True
                elif hasattr(self.model, 'music_play'):
                    self.model.music_play(getattr(self.model, 'music_index', 0), data.get("music_time", 0.0))

            if hasattr(self.view, 'lbl_fish_audio') and self.view.lbl_fish_audio.winfo_exists() and getattr(self.model, 'fish_audio_path', ""):
                try: self.view.lbl_fish_audio.config(text=os.path.basename(self.model.fish_audio_path))
                except: pass
            if hasattr(self.view, 'lbl_fish_text') and self.view.lbl_fish_text.winfo_exists() and getattr(self.model, 'fish_text_path', ""):
                try: self.view.lbl_fish_text.config(text=os.path.basename(self.model.fish_text_path))
                except: pass
            if hasattr(self.view, 'lbl_rvc_model') and self.view.lbl_rvc_model.winfo_exists() and getattr(self.model, 'rvc_model_path', ""):
                try: self.view.lbl_rvc_model.config(text=os.path.basename(self.model.rvc_model_path))
                except: pass
            if hasattr(self.view, 'lbl_rvc_index') and self.view.lbl_rvc_index.winfo_exists() and getattr(self.model, 'rvc_index_path', ""):
                try: self.view.lbl_rvc_index.config(text=os.path.basename(self.model.rvc_index_path))
                except: pass
                    
            if data.get("music_window_open", False): self.trigger_hotkey_music_window()
            if hasattr(self.view, 'hotkey_window') and self.view.hotkey_window and self.view.hotkey_window.winfo_exists(): self.view.hotkey_window.destroy()
            
            if "hotkeys_active" in data:
                self.view.hotkeys_active.set(data["hotkeys_active"])
                if data["hotkeys_active"]: self.toggle_hotkeys_logic()
            elif "hotkeys" in data:
                self.view.hotkeys_active.set(data["hotkeys"])
                if data["hotkeys"]: self.toggle_hotkeys_logic()
            
            if "ai_mode" in data: self.set_ai_mode(data["ai_mode"])
            if "groq_model" in data: self.set_groq_model(data["groq_model"])
            if "groq_keys" in data: getattr(self.model, 'groq_api_keys', []).clear(); self.model.groq_api_keys = data["groq_keys"]
            if "gemini_keys" in data: getattr(self.model, 'gemini_api_keys', []).clear(); self.model.gemini_api_keys = data["gemini_keys"]
            if "sambanova_keys" in data: getattr(self.model, 'sambanova_api_keys', []).clear(); self.model.sambanova_api_keys = data["sambanova_keys"]
            if "openrouter_keys" in data: getattr(self.model, 'openrouter_api_keys', []).clear(); self.model.openrouter_api_keys = data["openrouter_keys"]
            if "elevenlabs_keys" in data: getattr(self.model, 'elevenlabs_api_keys', []).clear(); self.model.elevenlabs_api_keys = data["elevenlabs_keys"]
            if "elevenlabs_voice" in data: self.model.elevenlabs_voice = data["elevenlabs_voice"]
            
            if "bark_use_gpu" in data and hasattr(self.view, 'bark_use_gpu_var'): self.view.bark_use_gpu_var.set(data["bark_use_gpu"])
            if "bark_use_small_models" in data and hasattr(self.view, 'bark_use_small_var'): 
                self.view.bark_use_small_var.set(data["bark_use_small_models"])
                self.model.bark_use_small_models = data["bark_use_small_models"]
            
            # 👇 NEW 1GB VRAM LINE 👇
            if "bark_low_vram" in data and hasattr(self.view, 'bark_low_vram_var'): self.view.bark_low_vram_var.set(data["bark_low_vram"])
            # FIX: the Bark menu checkboxes were restored on screen but never copied to the model, so after a restart
            # "1GB VRAM" looked ticked while Bark ran with the full models. Copy all three to the model here.
            if "bark_use_cpu" in data and hasattr(self.view, 'bark_use_cpu_var'): self.view.bark_use_cpu_var.set(data["bark_use_cpu"])
            if "bark_small_models" in data and hasattr(self.view, 'bark_small_models_var'): self.view.bark_small_models_var.set(data["bark_small_models"])
            self._sync_bark_flags()
            
            self.set_tts_mode(); self.set_stt_mode(); self.set_out_mode()
            self.toggle_review(); self.toggle_idle(); self.toggle_auto_reply(); self.toggle_hotkeys_only_mode(); self.toggle_viewer_greeting()
            
            if hasattr(self, 'refresh_fish_presets_ui'): self.refresh_fish_presets_ui()
            if hasattr(self, 'refresh_elevenlabs_presets_ui'): self.refresh_elevenlabs_presets_ui()
            if hasattr(self, 'refresh_rvc_presets_ui'): self.refresh_rvc_presets_ui()

            print(f"[System] Config loaded.")
            if not silent: messagebox.showinfo("Success", "Config loaded.")
        except Exception as e:
            print(f"Load Config Error: {e}")
            if not silent: messagebox.showerror("Error", f"Could not load config: {e}")

    def save_session_log(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")], title="Save Log File")
        if file_path:
            try:
                log_content = self.view.console_text.get("1.0", tk.END)
                with open(file_path, "w", encoding="utf-8") as f: f.write(log_content)
                messagebox.showinfo("Saved", "Log file saved successfully.")
            except Exception as e: messagebox.showerror("Error", f"Could not save log: {e}")

    def load_channels(self):
        channels = [f"{i}: {os.environ.get(f'CHANNEL_{i}_NAME')}" for i in range(1, 21) if os.environ.get(f"CHANNEL_{i}_NAME")]
        self.view.channel_combo['values'] = channels
        if channels: self.view.channel_combo.current(0)

    def save_new_channel_to_env(self, name, cid, popup):
        success, idx_or_err = self.model.save_new_channel_to_env(name, cid)
        if success:
            self.load_channels()
            new_val = f"{idx_or_err}: {name}"
            if new_val in self.view.channel_combo['values']: self.view.channel_combo.set(new_val)
            messagebox.showinfo("Success", f"Channel '{name}' saved to .env as Channel #{idx_or_err}!")
            popup.destroy()
        else: messagebox.showerror("Error", f"Could not write to .env file:\n{idx_or_err}")

    def set_ai_mode(self, mode):
        self.model.ai_mode = mode
        self.view.ai_backend_var.set(mode)
        display = "LM Studio (Local)" if mode == "local" else f"Groq ({getattr(self.model, 'groq_model', 'Unknown')})" if mode == "groq" else "Google Gemini (Cloud)"
        self.view.ai_status_lbl.config(text=f"(Backend: {display})")
        print(f"AI Backend switched to: {display}")

    def set_groq_model(self, model_name):
        self.model.groq_model = model_name
        self.view.groq_model_var.set(model_name)
        if self.model.ai_mode == "groq": self.view.ai_status_lbl.config(text=f"(Backend: Groq {model_name})")
        print(f"Groq Model set to: {model_name}")

    def test_and_save_groq_keys(self, keys, popup):
        if not keys: return messagebox.showerror("Error", "No keys provided!")
        if Groq is None: return messagebox.showerror("Error", "'groq' library not found. Run: pip install groq")
        print("[System] Validating Groq Keys...")
        valid_keys = []
        def _test():
            for k in keys:
                try:
                    Groq(api_key=k).models.list()
                    valid_keys.append(k)
                    print(f" -> Key ...{k[-4:]} Valid.")
                except Exception as e: print(f" -> Key ...{k[-4:]} Invalid: {e}")
            self.model.groq_api_keys = valid_keys
            self.root.after(0, lambda: self._finish_groq_save(valid_keys, popup))
        threading.Thread(target=_test, daemon=True).start()

    def _finish_groq_save(self, valid_keys, popup):
        if not valid_keys: messagebox.showerror("Error", "All provided keys failed validation.")
        else:
            self.set_ai_mode("groq")
            if hasattr(self, 'save_config'): self.save_config()
            messagebox.showinfo("Success", f"Saved {len(valid_keys)} valid keys.\n\nBackend set to Groq.")
            popup.destroy()

    def test_and_save_gemini_keys(self, keys, popup):
        if not keys: return messagebox.showerror("Error", "No keys provided!")
        if genai is None: return messagebox.showerror("Error", "'google-generativeai' library not found. Run: pip install google-generativeai")
        print("[System] Validating Gemini Keys...")
        valid_keys = []
        def _test():
            for k in keys:
                try:
                    genai.configure(api_key=k)
                    list(genai.list_models())
                    valid_keys.append(k)
                    print(f" -> Key ...{k[-4:]} Valid.")
                except Exception as e: print(f" -> Key ...{k[-4:]} Invalid: {e}")
            self.model.gemini_api_keys = valid_keys
            self.root.after(0, lambda: self._finish_gemini_save(valid_keys, popup))
        threading.Thread(target=_test, daemon=True).start()

    def _finish_gemini_save(self, valid_keys, popup):
        if not valid_keys: messagebox.showerror("Error", "All provided keys failed validation.")
        else:
            self.set_ai_mode("gemini")
            messagebox.showinfo("Success", f"Saved {len(valid_keys)} valid keys.\n\nBackend set to Gemini.")
            popup.destroy()
    
    def test_and_save_openrouter_keys(self, keys, popup):
        if not keys: return messagebox.showerror("Error", "No keys provided!")
        print("[System] Validating OpenRouter Keys...")
        valid_keys = []
        def _test():
            import requests
            for k in keys:
                try:
                    headers = {"Authorization": f"Bearer {k}"}
                    # Smallest request to check if key works
                    resp = requests.get("https://openrouter.ai/api/v1/auth/key", headers=headers, timeout=10)
                    if resp.status_code == 200:
                        valid_keys.append(k)
                        print(f" -> Key ...{k[-4:]} Valid.")
                except: pass
            
            self.model.openrouter_api_keys = valid_keys
            self.root.after(0, lambda: self._finish_openrouter_save(valid_keys, popup))
        threading.Thread(target=_test, daemon=True).start()

    def _finish_openrouter_save(self, valid_keys, popup):
        if valid_keys:
            self.set_ai_mode("openrouter")
            self.save_config()
            messagebox.showinfo("Success", f"Saved {len(valid_keys)} OpenRouter keys!")
            popup.destroy()
        else:
            messagebox.showerror("Error", "Keys failed validation.")

    def prompt_elevenlabs_voice(self):
        from tkinter import simpledialog
        current = getattr(self.model, 'elevenlabs_voice', 'Pinoy Gamer Streamer')
        new_voice = simpledialog.askstring("ElevenLabs Voice", "Enter Voice ID (or 'Pinoy Gamer Streamer'):", initialvalue=current, parent=self.root)
        if new_voice is not None and new_voice.strip():
            self.model.elevenlabs_voice = new_voice.strip()
            self.save_config()
            messagebox.showinfo("Saved", f"ElevenLabs Voice set to:\n{new_voice.strip()}", parent=self.root)

    def refresh_audio_menus(self):
        self.view.mic_menu.delete(0, "end")
        self.view.spk_menu.delete(0, "end")
        try:
            for i, name in enumerate(sr.Microphone.list_microphone_names()):
                self.view.mic_menu.add_radiobutton(label=f"{i}: {name}", variable=self.view.mic_var, value=i, command=lambda x=i: self.set_mic_device(x))
        except Exception as e: self.view.mic_menu.add_command(label=f"Error: {e}")
            
        try:
            import sounddevice as sd
            devices = sd.query_devices()
            has_devices = False
            for i, dev in enumerate(devices):
                if dev['max_output_channels'] > 0:
                    self.view.spk_menu.add_radiobutton(label=f"{i}: {dev['name']}", variable=self.view.spk_var, value=i, command=lambda x=i: self.set_speaker_device(x))
                    has_devices = True
            if not has_devices: self.view.spk_menu.add_command(label="No devices found")
        except Exception as e: 
            self.view.spk_menu.add_command(label="Error loading devices (Check Console)")
            print(f"\n[Device Query Error] Failed to scan Windows Audio Devices: {e}")

    def set_mic_device(self, index): self.model.mic_device_index = index; self.view.mic_var.set(index)
    def set_speaker_device(self, index): self.model.speaker_device_index = index; self.view.spk_var.set(index)

    def run_mic_test(self):
        def _test_thread():
            print(f"*** MIC TEST STARTING (3s) on Mic ID: {self.model.mic_device_index} ***")
            try:
                text_result = self.model.transcribe_mic_audio(duration=3, phrase_time_limit=3)
                print(f"Mic Test Text: {text_result}")
                self.root.after(0, lambda: messagebox.showinfo("Mic Test Result", f"Heard via {self.model.stt_mode.upper()}:\n'{text_result}'"))
                print("*** MIC TEST COMPLETE ***")
            except Exception as e: print(f"Mic Test Failed: {e}")
        threading.Thread(target=_test_thread, daemon=True).start()

    def run_tts_test(self):
        def _test_thread():
            text = f"Hello! This is a test of the {self.model.tts_mode} voice engine."
            vol = self.view.volume_level.get()
            print(f"*** TTS TEST: {text} (Vol: {vol:.2f}) ***")
            try:
                voice_var = ""
                if self.model.tts_mode == "soprano" and hasattr(self.view, 'soprano_voice_var'): voice_var = getattr(self.view, 'soprano_voice_var').get()
                elif self.model.tts_mode == "voicebox" and hasattr(self.view, 'voicebox_voice_var'): voice_var = getattr(self.view, 'voicebox_voice_var').get()
                elif self.model.tts_mode == "kokoro": voice_var = self.view.kokoro_voice_var.get()
                elif self.model.tts_mode == "rvc": voice_var = "rvc_voice"
                elif self.model.tts_mode == "fish": voice_var = "fish_voice"
                elif self.model.tts_mode == "tiktok" and hasattr(self.view, 'tiktok_voice_var'): voice_var = getattr(self.view, 'tiktok_voice_var').get()
                elif self.model.tts_mode == "edge": voice_var = self.view.edge_voice_var.get()
                elif self.model.tts_mode == "google": voice_var = self.view.google_voice_var.get()
                else: voice_var = getattr(self.view, 'bark_voice_var').get() if hasattr(self.view, 'bark_voice_var') else ""
                
                # Push ALL audio tests perfectly to the queue so the Controller never crashes on an import error!
                self.model.tts_queue.put((text, self.model.tts_mode, voice_var, vol, self.model.speaker_device_index, False, "test", self.model.game_name, self.model.channel_name, True))
                print("*** TTS TEST QUEUED (Running sequentially to prevent GPU crash) ***")
                
                if not self.model.bot_running:
                    print(" -> NOTE: You MUST click 'Start' or 'Simulate' so the bot can process the TTS Queue!")
            except Exception as e: print(f"TTS Test Failed: {e}")
        threading.Thread(target=_test_thread, daemon=True).start()

    def _sync_bark_flags(self):
        """One source of truth: copy the Bark menu checkboxes onto the model so EVERY Bark code path sees them."""
        v, m = self.view, self.model
        try:
            m.bark_use_cpu = bool(v.bark_use_cpu_var.get()) if hasattr(v, 'bark_use_cpu_var') else getattr(m, 'bark_use_cpu', False)
            m.bark_small_models = bool(v.bark_small_models_var.get()) if hasattr(v, 'bark_small_models_var') else getattr(m, 'bark_small_models', False)
            m.bark_low_vram = bool(v.bark_low_vram_var.get()) if hasattr(v, 'bark_low_vram_var') else getattr(m, 'bark_low_vram', False)
            # 1GB VRAM mode = small models + offload; keep the legacy flag every other path reads in step
            m.bark_use_small_models = bool(m.bark_small_models or m.bark_low_vram)
        except Exception as e:
            print(f"[Bark] could not sync menu settings: {e}")

    def set_tts_mode(self):
        self.model.tts_mode = self.view.tts_var.get()
        print(f"TTS Engine switched to: {self.model.tts_mode.upper()}")
        
        if self.model.tts_mode == "bark_cpu":
            print("[System] Hiding GPU from Bark to force CPU mode...")
            os.environ["SUNO_USE_CPU"] = "True"
            os.environ["SUNO_OFFLOAD_CPU"] = "True"
        elif "bark" in self.model.tts_mode:
            self._sync_bark_flags()          # copy the Bark menu checkboxes (CPU / Small / 1GB) onto the model
            use_gpu_setting = getattr(self.view, 'bark_use_gpu_var', tk.BooleanVar(value=True)).get()
            # the menu variable is bark_small_models_var (bark_use_small_var never existed in the view)
            use_small_setting = getattr(self.view, 'bark_use_small_var', getattr(self.view, 'bark_small_models_var', tk.BooleanVar(value=False))).get()
            ultra_low_vram = getattr(self.view, 'bark_low_vram_var', tk.BooleanVar(value=False)).get()
            try:                              # tell the user straight away if PyTorch cannot see the GPU
                from bark_fast import gpu_report
                gpu_report(print_it=True)
            except Exception: pass
            force_cache = getattr(self, 'force_cache_only', False)
            
            # If 1GB mode is checked, FORCE small models to guarantee low memory
            if ultra_low_vram:
                use_small_setting = True
                if hasattr(self.view, 'bark_use_small_var'): self.view.bark_use_small_var.set(True)

            self.model.bark_use_small_models = use_small_setting
            if use_small_setting: os.environ["SUNO_USE_SMALL_MODELS"] = "True"
            else: os.environ.pop("SUNO_USE_SMALL_MODELS", None)
            
            # 🛡️ THE BARK HACK: Force the internal engine to accept the change instantly
            try:
                import bark.generation
                bark.generation.USE_SMALL_MODELS = use_small_setting
            except Exception: pass
            
            if not use_gpu_setting or force_cache:
                os.environ["SUNO_USE_CPU"] = "True"
                os.environ["SUNO_OFFLOAD_CPU"] = "True"
            else:
                os.environ.pop("SUNO_USE_CPU", None)
                if ultra_low_vram or getattr(self.model, 'bark_use_cpu', False): os.environ["SUNO_OFFLOAD_CPU"] = "True"
                else: os.environ.pop("SUNO_OFFLOAD_CPU", None)
                
            print(f"[System] Bark set to LAZY LOAD. (Small Models: {use_small_setting}, 1GB VRAM Mode: {ultra_low_vram})")
            
            # 🧹 THE VRAM FLUSH: Force PyTorch to give the hoarded memory back to Windows
            try:
                import torch
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                    torch.cuda.ipc_collect()
            except Exception: pass

        if self.model.tts_mode == "kokoro" and not getattr(self.model, 'kokoro_pipeline', None):
            def _load():
                try: 
                    from kokoro import KPipeline
                    try:
                        self.model.kokoro_pipeline = KPipeline(lang_code='a')
                    except TypeError:
                        import torch
                        self.model.kokoro_pipeline = KPipeline(lang_code='a', device='cuda' if torch.cuda.is_available() else 'cpu')
                    print("[System] Kokoro TTS Ready.")
                except Exception as e: print(f"[Error] Kokoro Init Failed: {e}")
            import threading
            threading.Thread(target=_load, daemon=True).start()
    def set_stt_mode(self):
        try:
            self.model.stt_mode = self.view.stt_var.get()
            print(f"STT Engine switched to: {self.model.stt_mode}")
        except Exception:
            pass

    def set_out_mode(self):
        self.model.current_bot_mode = self.view.out_var.get()
        print(f"Output Mode switched to: {self.model.current_bot_mode}")

    def on_persona_change(self, event):
        val = self.view.persona_combo.get()
        self.model.current_persona = val
        val_lower = val.lower()
        if "pinoy" in val_lower: 
            self.view.edge_voice_var.set("en-PH-JamesNeural")
            self.view.kokoro_voice_var.set("am_adam") 
        elif "kid" in val_lower: 
            self.view.edge_voice_var.set("en-US-AnaNeural")
            self.view.kokoro_voice_var.set("am_puck") 
        elif "roasting" in val_lower or "serious" in val_lower:
            self.view.edge_voice_var.set("en-US-GuyNeural")
            self.view.kokoro_voice_var.set("am_michael") 
        elif "genius" in val_lower or "joker" in val_lower:
            self.view.edge_voice_var.set("en-US-ChristopherNeural")
            self.view.kokoro_voice_var.set("am_fenrir") 
        else: 
            self.view.edge_voice_var.set("en-US-SteffanNeural")
            self.view.kokoro_voice_var.set("am_adam") 
        
        self.model.edge_voice = self.view.edge_voice_var.get()
        self.model.kokoro_voice = self.view.kokoro_voice_var.get()
        print(f"*** Persona switched to {self.model.current_persona.upper()} ***")

    def toggle_review(self): self.model.review_mode = self.view.review_var.get()
    def toggle_idle(self): self.model.idle_chat_enabled = self.view.idle_var.get()
    def toggle_auto_reply(self): self.model.automated_replies_enabled = self.view.auto_reply_var.get()
    def toggle_hotkeys_only_mode(self): self.model.hotkeys_only_mode = self.view.hotkeys_only_var.get()
    def toggle_viewer_greeting(self): self.model.greet_new_viewers = self.view.greet_viewers_var.get()

    def listen_to_mic(self, target_widget):
        if getattr(self, 'is_generating', False): return
        original_bg = target_widget.cget("bg")
        target_widget.config(bg="#330000")
        self.root.update_idletasks()
        def _listen_thread():
            try: text_out = self.model.transcribe_mic_audio(duration=None, phrase_time_limit=10)
            except: text_out = ""
            self.root.after(0, lambda: self._finish_listening(target_widget, text_out, original_bg))
        threading.Thread(target=_listen_thread, daemon=True).start()

    def _finish_listening(self, widget, text, orig_bg):
        widget.config(bg=orig_bg)
        if text:
            if isinstance(widget, tk.Text): widget.insert("end", " " + text)
            elif isinstance(widget, tk.Entry): widget.insert("end", " " + text)

    def start_ptt_mic(self, btn_widget, target_widget):
        if getattr(self, 'is_generating', False): return
        btn_widget.config(bg="red", text="🔴 Rec")
        if isinstance(target_widget, tk.Text): target_widget.config(bg="#330000")
        if hasattr(self.model, 'start_ptt_recording'): self.model.start_ptt_recording()

    def stop_ptt_mic(self, btn_widget, target_widget):
        btn_widget.config(bg="#333", text="🎤 Hold")
        if isinstance(target_widget, tk.Text): target_widget.config(bg="#1e1e1e")
        if not hasattr(self.model, 'stop_ptt_and_transcribe'): return
        def _process_ptt():
            print("[PTT] Processing audio...")
            text = self.model.stop_ptt_and_transcribe()
            if text:
                print(f"[PTT] Heard: {text}")
                self.root.after(0, lambda: self._append_to_widget(target_widget, text))
            else: print("[PTT] No speech detected or error.")
        threading.Thread(target=_process_ptt, daemon=True).start()
        
    def _append_to_widget(self, widget, text):
        if widget and widget.winfo_exists():
            widget.config(state="normal")
            current = widget.get("1.0", "end-1c").strip() if isinstance(widget, tk.Text) else widget.get().strip()
            widget.insert("end", " " + text if current else text)

    def toggle_loading(self, window, active, progress_bar=None, buttons=[]):
        self.is_generating = active
        state = "disabled" if active else "normal"
        for btn in buttons:
            try: btn.config(state=state)
            except: pass
        if progress_bar:
            if active: progress_bar.pack(side="bottom", fill="x", pady=2); progress_bar.start(10)
            else: progress_bar.stop(); progress_bar.pack_forget()

    def open_google_console(self): webbrowser.open("https://console.cloud.google.com/apis/credentials")

    def import_json_credential(self, popup):
        file_path = filedialog.askopenfilename(title="Select client_secret.json", filetypes=[("JSON Files", "*.json")])
        if not file_path: return
        try:
            with open(file_path, 'r') as f:
                content = json.load(f)
                if 'installed' not in content and 'web' not in content:
                    return messagebox.showwarning("Invalid File", "Not a valid Google OAuth client secret.")
            if not os.path.exists("credentials"): os.makedirs("credentials")
            existing_files = glob.glob(os.path.join("credentials", "client_secret_*.json"))
            max_idx = max([int(os.path.basename(f)[14:-5]) for f in existing_files if os.path.basename(f).startswith("client_secret_") and os.path.basename(f).endswith(".json")] + [0])
            dest_path = os.path.join("credentials", f"client_secret_{max_idx + 1}.json")
            with open(file_path, 'rb') as src, open(dest_path, 'wb') as dst: dst.write(src.read())
            messagebox.showinfo("Success", f"Imported to:\n{dest_path}")
            popup.destroy()
        except Exception as e: messagebox.showerror("Error", f"Failed to import: {e}")

    def request_chat_history(self):
        self.chat_history_buffer = []
        self.seen_messages_sig = set()
        self.view.refresh_chat_tree() 
        if hasattr(self.model, 'history_req_queue'): self.model.history_req_queue.put("FETCH")

    def check_history_queue(self):
        try:
            if not hasattr(self.model, 'history_resp_queue'): return
            if hasattr(self.view, 'chat_selector_voice_only_var'): self.model.chat_list_voice_only = self.view.chat_selector_voice_only_var.get()
            while True:
                data = self.model.history_resp_queue.get_nowait()
                if data: 
                    new_unique_msgs = []
                    for msg in data:
                        sig = (msg.get('author'), msg.get('message'), msg.get('publishedAt'))
                        if sig not in self.seen_messages_sig:
                            self.seen_messages_sig.add(sig)
                            
                            # Sanitizes message before insertion to prevent Tkinter crashes on Emojis
                            safe_msg = dict(msg)
                            safe_msg['author'] = _safe_tk_string(str(safe_msg.get('author', '')))
                            safe_msg['message'] = _safe_tk_string(str(safe_msg.get('message', '')))
                            
                            new_unique_msgs.append(safe_msg)
                            self.chat_history_buffer.append(safe_msg)
                    if new_unique_msgs: 
                        if hasattr(self.view, 'hide_bot_chat_var') and self.view.hide_bot_chat_var.get():
                            bot_names = ['nightbot', 'streamelements', 'streamlabs', 'moobot', 'wizebot', 'fossabot', 'commanderroot', getattr(self.model, 'channel_name', '').lower(), 'me']
                            filtered = [m for m in new_unique_msgs if str(m.get('author','')).lower() not in bot_names and 'bot' not in str(m.get('author','')).lower()]
                            if filtered: self.view._append_new_messages_to_tree(filtered)
                        else:
                            self.view._append_new_messages_to_tree(new_unique_msgs)
        except queue.Empty: pass
        finally:
            if getattr(self.view, 'selector_window', None) and hasattr(self.view.selector_window, 'winfo_exists') and self.view.selector_window.winfo_exists(): self.root.after(200, self.check_history_queue)

    def reply_to_selected_chat(self):
        if not getattr(self.view, 'chat_tree', None): return
        selected = self.view.chat_tree.selection()
        if not selected: return
        vals = self.view.chat_tree.item(selected[0])['values'] 
        is_voice_only = self.view.chat_selector_voice_only_var.get()
        
        if getattr(self, 'force_cache_only', False):
            print("[System] ⚡ Force Cache is ENABLED. Skipping fresh voice generation for targeted reply (no random voice will play).")
            self.model.target_reply_queue.put({'author': vals[1], 'message': vals[2], 'force_text_only': True, 'force_voice_only': False, 'force_fresh': True})
        else:
            self.model.target_reply_queue.put({'author': vals[1], 'message': vals[2], 'force_text_only': False, 'force_voice_only': is_voice_only, 'force_fresh': True})
        print(f"Targeted reply queued for: {vals[1]}")

    def cache_selector_text(self):
        if not getattr(self.view, 'selector_text', None): return
        text = self.view.selector_text.get("1.0", "end-1c").strip()
        if text:
            self.model.manual_reply_queue.put({'message': text, 'force_voice_only': True, 'force_text_only': False, 'silent_cache': True, 'force_fresh': True})
            self.view.selector_text.delete("1.0", "end")
            print(f"[System] Phrase queued for Silent Generation (Will save to TTS Cache).")

    

    def _close_review_safe(self):
        try:
            if getattr(self.view, 'review_window', None) and self.view.review_window.winfo_exists():
                if hasattr(self.view, 'rev_progress'): self.view.rev_progress.stop()
                self.view.review_window.destroy()
                self.view.review_window = None
        except Exception as e: print(f"[Review Close Error] {e}")

    def improve_current_text(self):
        """Revises the text while checking if the window still exists to prevent crashes."""
        if not hasattr(self.view, 'popup_text') or not self.view.popup_text.winfo_exists():
            return
            
        curr_val = self.view.popup_text.get("1.0", "end-1c").strip()
        if not curr_val or getattr(self, 'is_generating', False): return
        self.is_generating = True
        
        viewer_context = getattr(self.view, 'current_review_context', "Unknown Chat")
        
        # 🛡️ SAFETY CHECK before updating button
        if hasattr(self.view, 'btn_rev_improve') and self.view.btn_rev_improve.winfo_exists():
            self.view.btn_rev_improve.config(text="⏳ Wait...")
        
        def _imp():
            try:
                msgs = [
                    {"role": "system", "content": f"You are {self.model.channel_name}. Viewer said: '{viewer_context}'. Draft: '{curr_val}'. REWRITE the reply to be better. Reply ONLY with the final text."},
                    {"role": "user", "content": "Rewrite the response."}
                ]
                reply = self.model.generate_ai_completion(msgs, max_tokens=100)
                
                # 🛡️ THE MASTER SHIELD: Only update if the user hasn't closed the window yet!
                def _safe_update():
                    if hasattr(self.view, 'popup_text') and self.view.popup_text.winfo_exists():
                        self.view.popup_text.delete("1.0", tk.END)
                        # Sanitize AI output!
                        safe_reply = "".join(c for c in reply if ord(c) <= 0xFFFF)
                        self.view.popup_text.insert("1.0", safe_reply)
                    if hasattr(self.view, 'btn_rev_improve') and self.view.btn_rev_improve.winfo_exists():
                        self.view.btn_rev_improve.config(text="✨ REVISE")
                
                self.root.after(0, _safe_update)
            except Exception as e: 
                print(f"[Revise Error] {e}")
            finally:
                self.is_generating = False
                
        threading.Thread(target=_imp, daemon=True).start()

    def improve_selector_text(self):
        if not getattr(self.view, 'selector_text', None): return
        current_text = self.view.selector_text.get("1.0", "end-1c").strip()
        if not current_text or getattr(self, 'is_generating', False): return
        buttons = []
        if hasattr(self.view, 'btn_sel_improve'): buttons.append(self.view.btn_sel_improve)
        if hasattr(self.view, 'btn_sel_send'): buttons.append(self.view.btn_sel_send)
        
        self.toggle_loading(getattr(self.view, 'selector_window', None), True, getattr(self.view, 'sel_progress', None), buttons)
        self.view.selector_text.config(state="disabled")
        
        def run_improvement():
            try:
                # FIX: Stricter instruction to stop the AI from inventing entirely new responses
                msgs = [
                    {"role": "system", "content": "STRICTLY PRESERVE the exact original meaning of this text. Fix the grammar and keep it casual. DO NOT invent new information. Reply with ONLY the revised text."}, 
                    {"role": "user", "content": current_text}
                ]
                improved = self.model.generate_ai_completion(msgs, max_tokens=100)
                self.root.after(0, lambda: self.update_selector_text(improved or current_text))
            except Exception as e: self.root.after(0, lambda: self.update_selector_text(current_text))
        threading.Thread(target=run_improvement, daemon=True).start()

    def update_selector_text(self, new_text):
        if getattr(self.view, 'selector_text', None) and self.view.selector_text.winfo_exists():
            self.view.selector_text.config(state="normal")
            self.view.selector_text.delete("1.0", "end")
            # 🛡️ Sanitize AI output!
            safe_text = "".join(c for c in new_text if ord(c) <= 0xFFFF)
            self.view.selector_text.insert("1.0", safe_text)
            buttons = []
            if hasattr(self.view, 'btn_sel_improve'): buttons.append(self.view.btn_sel_improve)
            if hasattr(self.view, 'btn_sel_send'): buttons.append(self.view.btn_sel_send)
            self.toggle_loading(getattr(self.view, 'selector_window', None), False, getattr(self.view, 'sel_progress', None), buttons)

    def toggle_hotkeys_logic(self):
        if getattr(self, '_toggling_hotkeys', False): return
        self._toggling_hotkeys = True
        try:
            if not keyboard: return
            try: keyboard.unhook_all(); time.sleep(0.05) 
            except: pass

            if self.view.hotkeys_active.get():
                print("[System] Enabling Global Hotkeys (Low Latency Mode)...")
                
                # BIND UNSTICK AS A PERMANENT BYPASS TOGGLE
                self.typing_bypass = False
                def _toggle_bypass():
                    self.typing_bypass = not getattr(self, 'typing_bypass', False)
                    state = "OFF (Ignoring Discord/Chrome)" if self.typing_bypass else "ON (Normal)"
                    print(f"\n[System] ⌨️ Typing Detector is now {state}. Hotkeys will {'always' if self.typing_bypass else 'conditionally'} work!\n")
                
                # FIX: a bare 'ctrl+alt' hotkey fires on EVERY ctrl+alt+<key> press (Stats Ghost, Vision, ...),
                # flipping the typing-detector on/off by accident. It now has its own dedicated key.
                bypass_key = getattr(self, 'hk_typing_bypass', 'ctrl+alt+b') or 'ctrl+alt+b'
                try: keyboard.add_hotkey(bypass_key, _toggle_bypass)
                except Exception as e: print(f"  -> Failed to bind typing bypass '{bypass_key}': {e}")
                vision_toggle_key = getattr(self, 'hk_vision_toggle', 'ctrl+alt+w')
                try: keyboard.add_hotkey(vision_toggle_key, self.toggle_vision_mode)
                except: pass

                # [FIX: Hotkeys completely bypass the 50ms action queue to trigger instantly]
                def bind_safe(key_str, func, name, requires_ui=False):
                    if key_str and isinstance(key_str, str):
                        clean_key = key_str.strip().lower()
                        if clean_key and not clean_key.endswith('+') and not clean_key.startswith('+'):
                            try:
                                last_called = [0]
                                def make_wrapper(n, f, req_ui, lc):
                                    def wrapper(*args, **kwargs):
                                        now = time.time()
                                        if now - lc[0] < 0.25: return
                                        lc[0] = now
                                        
                                        # 🛡️ THE SUSPENSION SHIELD: Check ALL possible UI & Controller lock states
                                        is_suspended = getattr(self, 'hotkeys_suspended', False)
                                        bypass = getattr(self, 'typing_bypass', False)
                                        
                                        try:
                                            # Also check if the UI specifically triggered auto-suspension via typing
                                            if getattr(self.view, 'hotkeys_suspended', False):
                                                is_suspended = True
                                            if getattr(self.view, '_auto_suspended', False) and not bypass:
                                                is_suspended = True
                                        except Exception: pass
                                        
                                        if getattr(self, '_rebinding', False): return   # user is assigning a new key right now
                                        # If suspended, brutally drop the hotkey BEFORE it prints or executes!
                                        if is_suspended and n != "Suspend Hotkeys": 
                                            return
                                            
                                        print(f"[Hotkey Triggered] {n} -> Executing instantly")
                                        
                                        if req_ui: 
                                            self.ui_action_queue.put(f)   # root.after() from the keyboard thread is not thread-safe
                                        else: 
                                            threading.Thread(target=f, daemon=True).start()
                                    return wrapper
                                
                                keyboard.add_hotkey(clean_key, make_wrapper(name, func, requires_ui, last_called), suppress=False)
                                print(f"  -> Bound '{name}' to '{clean_key}'")
                            except Exception as e: print(f"  -> Failed to bind '{name}' to '{clean_key}': {e}")

                bindings = [
                    (self.hk_idle, self.trigger_hotkey_idle, "Idle Msg", False),
                    (self.hk_thanks, self.trigger_hotkey_thanks, "Thanks Msg", False),
                    (self.hk_question, self.trigger_hotkey_game_q, "Game Question", False),
                    (self.hk_help, self.trigger_hotkey_help, "Help Msg", False),
                    (self.hk_death, self.trigger_hotkey_death, "Death Msg", False),
                    (self.hk_likes_thanks, self.trigger_hotkey_likes_thanks, "Thanks Likes", False),
                    (self.hk_brb, self.trigger_hotkey_brb, "BRB Msg", False),
                    (self.hk_tech_issue, self.trigger_hotkey_tech_issue, "Tech Issue Msg", False),
                    (self.hk_game_request, self.trigger_hotkey_game_request, "Game Request Msg", False),
                    (self.hk_taunt, self.trigger_hotkey_taunt, "Taunt", False),
                    (self.hk_intro, self.trigger_hotkey_intro, "Intro", False),
                    (self.hk_frustration, self.trigger_hotkey_frustration, "Frustration", False),
                    (self.hk_attack, self.trigger_hotkey_attack, "Attack", False),
                    (self.hk_talk_viewers, self.trigger_hotkey_talk_viewers, "Talk Viewers", False),
                    (self.hk_puzzle, self.trigger_hotkey_puzzle, "Puzzle Solved", False),
                    (self.hk_boss_win, self.trigger_hotkey_boss_win, "Boss Defeated", False),
                    (self.hk_feeling_good, self.trigger_hotkey_feeling_good, "Feeling Good", False),
                    (self.hk_feeling_bad, self.trigger_hotkey_feeling_bad, "Feeling Bad", False),
                    (self.hk_clip_that, self.trigger_hotkey_clip_that, "Clip That", False),
                    (self.hk_panic, self.trigger_hotkey_panic, "Panic / Scream", False),
                    (self.hk_live_context, self.trigger_hotkey_live_context, "Live Context", False),
                    (self.hk_reply_last, self.trigger_hotkey_reply_last, "Reply Last", False),
                    (self.hk_yt_play_pause, self.trigger_yt_play_pause, "YT Play/Pause", False),
                    (self.hk_yt_next, self.trigger_yt_next, "YT Next", False),
                    (self.hk_yt_prev, self.trigger_yt_prev, "YT Prev", False),
                    (self.hk_yt_forward, self.trigger_yt_forward, "YT Forward", False),
                    (self.hk_yt_rewind, self.trigger_yt_rewind, "YT Rewind", False),
                    (self.hk_yt_ghost, self.trigger_yt_ghost, "YT Ghost Mode", False),
                    (self.hk_mp3_play_pause, self.trigger_mp3_play_pause, "MP3 Play/Pause", False),
                    (self.hk_mp3_next, self.trigger_mp3_next, "MP3 Next", False),
                    (self.hk_mp3_prev, self.trigger_mp3_prev, "MP3 Prev", False),
                    (self.hk_mp3_forward, self.trigger_mp3_forward, "MP3 Forward", False),
                    (self.hk_mp3_rewind, self.trigger_mp3_rewind, "MP3 Rewind", False),
                    (self.hk_open_list, self.trigger_hotkey_open_list, "Open List", True),
                    (self.hk_stats, self.trigger_hotkey_stats, "Open Stats", True),
                    (self.hk_stats_ghost, self.trigger_hotkey_stats_ghost, "Toggle Stats Ghost", True),
                    (self.hk_guide, self.trigger_hotkey_guide, "Open Guide", True),
                    (self.hk_guide_ghost, self.trigger_hotkey_guide_ghost, "Toggle Guide Ghost", True),
                    (self.hk_hotkeys_window, self.trigger_hotkey_open_hotkeys, "Open Keybinds", True),
                    (self.hk_strict_mode, self.trigger_hotkey_strict_mode, "Toggle Strict Mode", True),
                    (self.hk_play_overlay, self.trigger_hotkey_play_overlay, "Focus YouTube Overlay", True),
                    (self.hk_music_window, self.trigger_hotkey_music_window, "Music Window", True),
                    (self.hk_toggle_ai_mute, self.trigger_hotkey_toggle_ai_mute, "Toggle Global AI Mute", False),
                    (self.hk_hide_overlays, self.trigger_hide_overlays, "Hide All Overlays", True),
                    (self.hk_open_context_window, self.trigger_open_live_context, "Open Context Window", True),
                    (getattr(self, 'hk_suspend_hotkeys', ''), self.trigger_suspend_hotkeys, "Suspend Hotkeys", False),
                    (getattr(self, 'hk_stop_audio', ''), lambda: self.stop_current_audio(flush_vram=True), "Stop Audio", False),
                    (getattr(self, 'hk_sys_status', ''), self.trigger_sys_status, "Sys Status", True),
                    (getattr(self, 'hk_sys_status_ghost', ''), self.trigger_sys_status_ghost, "Sys Status Ghost", True),
                    (getattr(self, 'hk_toggle_cache_mode', ''), self.trigger_toggle_cache_mode, "Toggle Cache Mode", False),
                    (getattr(self, 'hk_shoutout_users', ''), self.trigger_hotkey_shoutout_users, "Shoutout Active Users", False),   # FIX: had a UI row + handler but was never bound
                    (getattr(self, 'hk_vision', '') or 'ctrl+alt+v', self.trigger_hotkey_vision_reaction, "AI Screen Vision", False),                 
                ]                 
               
                
                for i in range(1, 16):
                    b_attr = f"hk_custom_{i}"
                    bindings.append((getattr(self, b_attr, ""), lambda b=b_attr: self._trigger_shared_hotkey(b, "", f"Custom Slot {b.split('_')[-1]}"), f"Custom Slot {i}", False))
                
                _seen_keys = {}
                for key_str, func, name, req_ui in bindings:
                    _k = (key_str or '').strip().lower()
                    if not _k: continue
                    if _k in _seen_keys: print(f"  -> ⚠️ DUPLICATE HOTKEY '{_k}': '{name}' shares it with '{_seen_keys[_k]}' - BOTH will fire!")
                    else: _seen_keys[_k] = name
                for key_str, func, name, req_ui in bindings: bind_safe(key_str, func, name, req_ui)
            else: 
                print("[System] Global Hotkeys DISABLED")
                self._keyboard_unstick_active = False
        finally: self._toggling_hotkeys = False

    def toggle_global_ai_mute(self):
        self.global_ai_mute = not getattr(self, 'global_ai_mute', False)
        print(f"\n[System] 🔇 GLOBAL AI MUTE is now {'ON (AI Chat/Voice Disabled)' if self.global_ai_mute else 'OFF (AI Chat/Voice Resumed)'}")
        if self.global_ai_mute: self.stop_current_audio()

    def toggle_strict_mode(self):
        self.model.strict_repetition_mode = not getattr(self.model, 'strict_repetition_mode', False)
        print(f"\n[System] 🧠 Strict Anti-Repetition Mode is now {'ON (AI is forced to be creative)' if self.model.strict_repetition_mode else 'OFF'}")

    def run_dynamic_hotkey(self, messages, desc, mode="V+T", category="generic", custom_max_tokens=80, emotion_tag=None):
        current_gen = getattr(self, '_generation_counter', 0)
        is_custom_len = getattr(self, 'custom_length_enabled', False)
        target_words = getattr(self, 'custom_length_val', 30)
        rand_seed = random.randint(10000, 99999)
        
        # [FIX: Hotkey Memory Shield - Forces the AI to NOT repeat the last generated line for this specific hotkey]
        last_text = getattr(self, f"_last_text_{category}", "")
        anti_repeat_instruction = f"\n\nCRITICAL: You previously said '{last_text}'. DO NOT repeat this or say anything similar! Say something entirely new!" if last_text else ""
        
        if is_custom_len:
            # [FIX: Moves the instructions into the hidden System Prompt (messages[0]) so Dolphin doesn't accidentally read them out loud!]
            messages[0]["content"] += f"\n\nCRITICAL INSTRUCTION: You MUST reply with approximately {target_words} words. Focus strictly on the user's prompt! Random Seed: {rand_seed}{anti_repeat_instruction}"
            # FIX: Multiply by a massive safe buffer (4 tokens per word) to guarantee it never gets cut off mid-sentence
            custom_max_tokens = max(200, int(target_words * 4))
        else:
            if custom_max_tokens < 30: 
                messages[0]["content"] += f"\n\nCRITICAL INSTRUCTION: Your reply MUST be EXTREMELY SHORT (1 to 4 words max). Focus strictly on the prompt! Random Seed: {rand_seed}{anti_repeat_instruction}"
                custom_max_tokens = 60 # Give plenty of safe API headroom
            else: 
                # This now respects whatever Persona you selected in the UI!
                messages[0]["content"] += f"\n\nCRITICAL INSTRUCTION: Give a full, hype reaction (at least 2 to 3 sentences). Do not cut yourself off. Focus strictly on the prompt! Blend Vibe. Random Seed: {rand_seed}{anti_repeat_instruction}"
                custom_max_tokens = 300
            
        def _gen():
            try:
                if current_gen != getattr(self, '_generation_counter', 0): return
                print(f"\n[Hotkey] 🧠 Requesting Text from AI Backend ({self.model.ai_mode.upper()})...")
                start_t = time.time()
                reply = None
                for attempt in range(3):
                    if current_gen != getattr(self, '_generation_counter', 0): return
                    temp_reply = self.model.generate_ai_completion(messages=messages, max_tokens=custom_max_tokens, temperature=0.85 + (attempt * 0.1))
                    if not temp_reply: break
                    
                    # Check for exact matches (ignoring punctuation and capitalization)
                    clean_temp = re.sub(r'[^a-zA-Z0-9]', '', temp_reply).lower()
                    clean_last = re.sub(r'[^a-zA-Z0-9]', '', last_text).lower()
                    
                    if (clean_temp == clean_last and clean_temp) or (getattr(self.model, 'strict_repetition_mode', False) and self.model._check_repetition(temp_reply)):
                        print(f"[Hotkey] ♻️ Repetition detected ('{temp_reply[:30]}...'). Regenerating (Attempt {attempt+2}/3)...")
                        messages.append({"role": "assistant", "content": temp_reply})
                        messages.append({"role": "user", "content": "You literally just said that exact phrase. Say something completely different and unique!"})
                        continue
                    reply = temp_reply
                    break

                if current_gen != getattr(self, '_generation_counter', 0): return print(f"[Hotkey] 🛑 Skipped stale AI generation for {desc}.")

                if reply:
                    # FIX: Aggressive Bark Tag Enforcer. Bark is extremely strict about exact lowercase brackets.
                    if emotion_tag:
                        clean_reply = reply.strip()
                        # Aggressively slice off ANY brackets or asterisks the AI might have started with
                        clean_reply = re.sub(r'^\[.*?\]\s*', '', clean_reply)
                        clean_reply = re.sub(r'^\*.*?\*\s*', '', clean_reply)
                        
                        # If forcing a laugh, aggressively slice off typed laughter (Haha, Hehe) so Bark uses the physical laugh sound
                        if emotion_tag.lower() in ["[laughs]", "[laughter]"]:
                            clean_reply = re.sub(r'^(haha|hehe|hahaha|lol|lmao)[,\s]*', '', clean_reply, flags=re.IGNORECASE)
                            
                        reply = f"{emotion_tag.lower()} {clean_reply.strip()}"
                        print(f"[System] 🛡️ Bark Tag Enforcer applied: '{emotion_tag.lower()}'")
                    else:
                        # Auto-sanitize any naturally generated AI tags so Bark doesn't crash on them
                        reply = re.sub(r'\*(laughs|laughter|sighs|gasps|clears throat)\*', r'[\1]', reply, flags=re.IGNORECASE)
                        
                        # FIX: Brutally slice off all other hallucinated asterisks (like *muttering to self*)
                        reply = re.sub(r'\*.*?\*', '', reply).strip()
                        
                        # Ensure brackets are exactly lowercased and spelled correctly (fixes hallucinated [Llaughs])
                        reply = re.sub(r'\[(llaughs|laugh|laughs|laughter|sighs|gasps|clears throat|smacks lips)\]', lambda m: f"[{m.group(1).lower().replace('llaughs', 'laughs').replace('laugh', 'laughs')}]", reply, flags=re.IGNORECASE)
                        # Strip text laughs if an organic tag is present
                        if "[laughs]" in reply or "[laughter]" in reply:
                            reply = re.sub(r'(?i)^(haha|hehe|hahaha|lol)[,\s]*', '', reply)

                    # Save the successful reply to memory so it won't repeat it next time
                    setattr(self, f"_last_text_{category}", reply)
                    
                    print(f"[Hotkey] ✅ Text generated in {time.time() - start_t:.1f}s. Sending to Video Pipeline...")
                    
                    # 🚀 THE FIX: Instead of pushing to the old queue, route it directly to the new Video Pipeline!
                    self._inject_instant_hotkey(reply, mode, force_cache=False, category=category, original_prompt="", force_fresh=True)
                    
                else: print(f"[Hotkey Error] ❌ AI returned empty or timed out after {time.time() - start_t:.1f}s.")
            except Exception as e: print(f"[Hotkey Error] {desc}: {e}")
        threading.Thread(target=_gen, daemon=True).start()

    def _build_hotkey_msgs(self, user_prompt):
        is_chatting = self.model.game_name.lower() in ["just chatting", "none", ""]
        
        base_prompt = (f"Your name is {self.model.channel_name} and you are a live streamer. "
                       f"Speak directly to your viewers in the first-person ('I', 'me', 'my'). "
                       f"Persona: {self.model.current_persona}.\n")

        if is_chatting:
            base_prompt += f"You are currently doing a 'Just Chatting' stream, talking directly to your viewers.\n"
        else:
            base_prompt += f"YOU are currently holding a controller and actively playing the game {self.model.game_name} live on stream.\n"
                       
        anti_hallucination_rules = (
            f"CRITICAL INSTRUCTIONS (MUST OBEY):\n"
            f"1. REACT TO THE PROMPT: Address the situation in the prompt directly.\n"
            f"2. KEEP IT GENERIC: You do not know the specific names of the enemies, characters, or locations. Refer to them generically as 'the boss', 'that guy', or 'this area'. Only use specific names if they are explicitly provided in the prompt.\n"
            f"3. ACT HUMAN: Never say you are an AI or that you can't see the screen.\n"
            f"4. AUDIENCE: Never call the audience 'chat', always use 'viewers' or 'guys'.\n"
        )

        if getattr(self, 'vibe_check_enabled', True):
            vibe = getattr(self.model, 'get_random_vibe', lambda: "chill")()
            sys_p = base_prompt + (f"CURRENT VIBE: {vibe}\n") + anti_hallucination_rules
        else:
            sys_p = base_prompt + anti_hallucination_rules

        if getattr(self.model, 'strict_repetition_mode', False): 
            sys_p += "\n[STRICT MODE ACTIVE]: ABSOLUTELY FORBIDDEN to use any phrase used recently. Be completely original!"
        
        return [{"role": "system", "content": sys_p}, {"role": "user", "content": user_prompt}]

    def get_shuffled_cache_audio(self, category):
        import os, random, re
        if not hasattr(self, '_unplayed_cache_bags'):
            self._unplayed_cache_bags = {}
            
        # 🛡️ THE PHYSICAL RIP FIX: Grab the cache path straight from the UI!
        try:
            if hasattr(self.view, 'game_entry'): self.model.game_name = self.view.game_entry.get()
            elif hasattr(self.view, 'game_var'): self.model.game_name = self.view.game_var.get()
            
            if hasattr(self.view, 'channel_combo') and self.view.channel_combo.get():
                c_str = self.view.channel_combo.get()
                self.model.channel_name = c_str.split(": ")[-1] if ": " in c_str else c_str
        except: pass
            
        raw_chan = self.model.channel_name
        chan_safe = re.sub(r'[^a-zA-Z0-9_\- ]', '', str(raw_chan)).strip().replace(" ", "_") or "DefaultChannel"
        
        raw_game = self.model.game_name
        game_safe = re.sub(r'[^a-zA-Z0-9_\- ]', '', str(raw_game)).strip().replace(" ", "_") or "General"
        
        active_engine = getattr(self.model, 'tts_mode', 'bark').replace('_cpu', '')
        
        # 🛡️ STRICT ENGINE CACHE: Only look in the folder for the currently selected engine!
        engine_dirs = [f"{active_engine}_cache"]
        
        search_dirs = []
        for d in engine_dirs:
            if d not in search_dirs: search_dirs.append(d)
        
        bag_key = f"{active_engine}_{chan_safe}_{game_safe}_{category}"
            
        if bag_key not in self._unplayed_cache_bags or not self._unplayed_cache_bags[bag_key]:
            all_wavs = []
            
            for c_dir in search_dirs:
                if not os.path.exists(c_dir): continue
                
                game_path = os.path.join(c_dir, chan_safe, game_safe)
                if os.path.exists(game_path):
                    for root, dirs, files in os.walk(game_path):
                        if os.path.basename(root) == category:
                            for f in files:
                                if f.lower().endswith('.wav'): 
                                    all_wavs.append(os.path.join(root, f))
                
                if not all_wavs and game_safe not in ["General", "Just_Chatting"]:
                    for fallback_game in ["General", "Just_Chatting"]:
                        fallback_path = os.path.join(c_dir, chan_safe, fallback_game)
                        if os.path.exists(fallback_path):
                            for root, dirs, files in os.walk(fallback_path):
                                if os.path.basename(root) == category:
                                    for f in files:
                                        if f.lower().endswith('.wav'): 
                                            all_wavs.append(os.path.join(root, f))
                            if all_wavs: break
                                        
                if not all_wavs:
                    legacy_path = os.path.join(c_dir, category)
                    if os.path.exists(legacy_path):
                        for f in os.listdir(legacy_path):
                            if f.lower().endswith('.wav'):
                                all_wavs.append(os.path.join(legacy_path, f))
                                
                if all_wavs:
                    print(f"[System] 🔍 Found {len(all_wavs)} cache files for '{category}' in '{c_dir}'!")
                    break
            
            if not all_wavs:
                print(f"[Cache Warning] ⚠️ No cached audio found for '{category}' anywhere (Channel: '{chan_safe}', Game: '{game_safe}').")
                return None
                
            all_wavs = list(set(all_wavs))
            random.shuffle(all_wavs)
            self._unplayed_cache_bags[bag_key] = all_wavs
            print(f"[System] 🎒 Shuffled and loaded {len(all_wavs)} unique cached files for '{category}'.")
            
        if self._unplayed_cache_bags.get(bag_key):
            mode = getattr(self, 'cache_playback_mode', 'shuffle')
            if mode == "shuffle": return self._unplayed_cache_bags[bag_key].pop()
            elif mode == "repeat_all":
                item = self._unplayed_cache_bags[bag_key].pop(0)
                self._unplayed_cache_bags[bag_key].append(item)
                return item
            elif mode == "repeat_one": return self._unplayed_cache_bags[bag_key][0]
        return None

    def _universal_generate_audio(self, text, tts_engine):
        """🔥 THE MASTER DISPATCHER: Guarantees a physical .wav file is created for EVERY voice engine!"""
        import os, time, requests, base64
        print(f"[TTS] Routing to Universal Generator for '{tts_engine}'...")
        
        output_dir = "outputs"
        os.makedirs(output_dir, exist_ok=True)
        audio_path = os.path.join(output_dir, f"{tts_engine}_temp_{int(time.time())}.wav")
        
        # 1. TIKTOK DIRECT API
        if tts_engine == "tiktok":
            voice = getattr(self.model, 'tiktok_voice', 'en_us_002')
            print(f"[TikTok] Generating directly via API (Voice: {voice})...")
            try:
                headers = {"User-Agent": "Mozilla/5.0"}
                resp = requests.post("https://tiktok-tts.weilnet.workers.dev/api/generation", json={"text": text, "voice": voice}, headers=headers, timeout=15)
                if resp.status_code == 200 and 'data' in resp.json():
                    with open(audio_path, 'wb') as f:
                        f.write(base64.b64decode(resp.json()['data']))
                    return audio_path
                else: print(f"[TikTok API Error] {resp.text}")
            except Exception as e: print(f"[TikTok Error] {e}")

        # 2. ELEVENLABS DIRECT API
        elif tts_engine in ["elevenlabs", "pydub"]:
            voice_id = getattr(self.model, 'elevenlabs_voice_id', '')
            if not voice_id or voice_id == '21m00Tcm4TlvDq8ikWAM': voice_id = "XmFCYpS8xi3Tw8qdwUmD"
            api_key = None
            if hasattr(self.model, 'elevenlabs_api_keys') and self.model.elevenlabs_api_keys:
                try: api_key = self.model.elevenlabs_api_keys[getattr(self.model, 'elevenlabs_key_index', 0)]
                except: api_key = self.model.elevenlabs_api_keys[0]
            elif hasattr(self.model, 'elevenlabs_api_key'): api_key = self.model.elevenlabs_api_key
            if api_key:
                print(f"[ElevenLabs] Generating directly from API (Voice: {voice_id})...")
                url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
                headers = {"Accept": "audio/mpeg", "Content-Type": "application/json", "xi-api-key": api_key}
                data = {"text": text, "model_id": "eleven_multilingual_v2", "voice_settings": {"stability": 0.5, "similarity_boost": 0.5}}
                try:
                    resp = requests.post(url, json=data, headers=headers, timeout=15)
                    if resp.status_code == 200:
                        with open(audio_path, 'wb') as f: f.write(resp.content)
                        return audio_path
                except Exception as e: print(f"[ElevenLabs API Error] {e}")

        # 3. KOKORO NATIVE PIPELINE
        elif tts_engine == "kokoro":
            voice = getattr(self.model, 'kokoro_voice', 'am_adam')
            
            # 🛡️ THE JIT FIX: Auto-initialize Kokoro if it fell asleep or crashed during startup
            if not getattr(self.model, 'kokoro_pipeline', None):
                print("[Kokoro] Pipeline missing! Initializing now...")
                try:
                    from kokoro import KPipeline
                    try:
                        # Some versions of KPipeline don't take a device argument
                        self.model.kokoro_pipeline = KPipeline(lang_code='a')
                    except TypeError:
                        import torch
                        device = 'cuda' if torch.cuda.is_available() else 'cpu'
                        self.model.kokoro_pipeline = KPipeline(lang_code='a', device=device)
                    print("[Kokoro] Pipeline Loaded Successfully!")
                except Exception as e:
                    print(f"[Kokoro Init Error] {e}")

            if getattr(self.model, 'kokoro_pipeline', None):
                try:
                    import soundfile as sf
                    import numpy as np
                    print(f"[Kokoro] Generating audio (Voice: {voice})...")
                    
                    generator = self.model.kokoro_pipeline(
                        text, 
                        voice=voice, 
                        speed=1.0, 
                        split_pattern=r'\n+'
                    )
                    
                    audio_chunks = []
                    # 🛡️ THE FIX: Safely unpack the generator, regardless of Kokoro version tuple changes!
                    for i, result in enumerate(generator):
                        audio = result[-1] if isinstance(result, tuple) else result
                        if audio is not None:
                            if hasattr(audio, 'numpy'):
                                audio = audio.numpy()
                            audio_chunks.append(audio)
                            
                    if audio_chunks:
                        final_audio = np.concatenate(audio_chunks)
                        sf.write(audio_path, final_audio, 24000)
                        return audio_path
                    else:
                        print(f"[Kokoro Error] Generator yielded empty chunks for text: '{text}'")
                except Exception as e: 
                    print(f"[Kokoro Generation Error] {e}")
                    import traceback
                    traceback.print_exc()

        # 4. EDGE TTS NATIVE
        elif tts_engine == "edge_tts":
            voice = getattr(self.model, 'edge_tts_voice', getattr(self.model, 'edge_voice', 'en-US-ChristopherNeural'))
            if hasattr(self.model, 'generate_edge_tts'):
                return self.model.generate_edge_tts(text, voice)

        # 5. GOOGLE DIRECT
        elif tts_engine == "google":
            try:
                from gtts import gTTS
                print(f"[Google TTS] Generating audio...")
                mp3_path = audio_path.replace(".wav", ".mp3")
                tts = gTTS(text=text, lang='en', tld='com')
                tts.save(mp3_path)
                return mp3_path
            except Exception as e: print(f"[Google Error] {e}")
            
        # 6. BARK NATIVE
        elif tts_engine == "bark":
            try:
                print(f"[Bark TTS] Generating audio...")
                audio_array, _sr = _bark_native_generate(self.model, text)
                if audio_array is None: raise RuntimeError("Bark returned no audio")
                _write_wav_int16(audio_path, audio_array, _sr)
                return audio_path
            except Exception as e: print(f"[Bark Error] {e}")

        # 7. DYNAMIC FALLBACK FOR ALL OTHERS (Fish, Voicebox, Soprano, RVC)
        possible_funcs = [f"generate_{tts_engine}_tts", f"generate_{tts_engine}_audio", f"get_{tts_engine}_audio"]
        for func_name in possible_funcs:
            if hasattr(self.model, func_name):
                try:
                    voice = getattr(self.model, f"{tts_engine}_voice", None)
                    func = getattr(self.model, func_name)
                    path = func(text, voice) if voice else func(text)
                    if path and os.path.exists(path): return path
                except Exception as e: pass
                    
        # 8. PYTTSX3 (Absolute Last Resort)
        print(f"[TTS Error] Could not generate file for '{tts_engine}'. Falling back to Pyttsx3.")
        if hasattr(self.model, 'generate_pyttsx3_audio'):
            try: return self.model.generate_pyttsx3_audio(text)
            except: pass
            
        return None

    
    def _inject_instant_hotkey(self, text, mode, force_cache=False, category="generic", original_prompt="", force_fresh=False):
        import threading, time, os
        
        if force_cache and not force_fresh: 
            print(f"\n[Hotkey] ⚡ DIRECT CACHE PLAYBACK DETECTED! Searching for '{category}'...")
            def _instant_play_cache():
                chosen_wav = self.get_shuffled_cache_audio(category)
                if chosen_wav:
                    try:
                        self.stop_current_audio() 
                        time.sleep(0.05) 
                        
                        try:
                            global global_abort_flag
                            global_abort_flag[0] = False
                        except: pass
                        try: setattr(self.model, 'abort_generation', False)
                        except: pass

                        expected_mp4 = chosen_wav.replace(".wav", ".mp4")
                        if os.path.exists(expected_mp4):
                            try:
                                with open("play_avatar.txt", "w", encoding="utf-8") as f:
                                    f.write(f"{os.path.abspath(expected_mp4)}|{os.path.abspath(chosen_wav)}")
                            except: pass
                        
                        import model as model_module
                        model_module.play_wav_winsound(chosen_wav, self.model.volume_level)
                        print(f"[Cache] ✅ Played instantly via DJ Bypass: {os.path.basename(chosen_wav)}")
                        
                        if "T" in mode:
                            txt_path = chosen_wav.replace(".wav", ".txt")
                            if os.path.exists(txt_path):
                                with open(txt_path, "r", encoding="utf-8") as f: msg = f.read().strip()
                            else: msg = f"[Action: Uses {category.replace('_', ' ').title()} reaction]"
                            self.model.manual_reply_queue.put({'message': msg, 'force_voice_only': False, 'force_text_only': True, 'silent_cache': False, 'force_fresh': False})
                    except Exception as e: print(f"[Instant Play Error] {e}")
                else: 
                    print(f"[System Log] 🛑 FORCE CACHE ONLY is enabled. No cache found for '{category}'. Cannot generate new audio.")
            threading.Thread(target=_instant_play_cache, daemon=True).start()
            return
            
        def _generate_and_play():
            import time, os, requests, hashlib, shutil
            try:
                self.stop_current_audio()
                time.sleep(0.05)
                
                try:
                    global global_abort_flag
                    global_abort_flag[0] = False
                except: pass
                try: setattr(self.model, 'abort_generation', False)
                except: pass

                tts_engine = getattr(self.model, 'tts_mode', 'elevenlabs').replace('_cpu', '')
                print(f"\n[Hotkey] 🎙️ INSTANT GENERATION DETECTED! (Engine: {tts_engine.upper()})")
                
                audio_path = None
                
                if tts_engine == "elevenlabs" or tts_engine == "pydub":
                    voice_id = getattr(self.model, 'elevenlabs_voice_id', '')
                    if not voice_id or voice_id == '21m00Tcm4TlvDq8ikWAM':
                        voice_id = "XmFCYpS8xi3Tw8qdwUmD"
                    
                    api_key = None
                    if hasattr(self.model, 'elevenlabs_api_keys') and self.model.elevenlabs_api_keys:
                        try: api_key = self.model.elevenlabs_api_keys[getattr(self.model, 'elevenlabs_key_index', 0)]
                        except: api_key = self.model.elevenlabs_api_keys[0]
                    elif hasattr(self.model, 'elevenlabs_api_key'):
                        api_key = self.model.elevenlabs_api_key
                        
                    if not api_key:
                        print("[ElevenLabs Error] No API key found in settings!")
                    else:
                        print(f"[ElevenLabs] Generating audio directly from API using Voice: {voice_id}...")
                        url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
                        headers = {"Accept": "audio/mpeg", "Content-Type": "application/json", "xi-api-key": api_key}
                        data = {"text": text, "model_id": "eleven_multilingual_v2", "voice_settings": {"stability": 0.5, "similarity_boost": 0.5}}
                        try:
                            resp = requests.post(url, json=data, headers=headers, timeout=15)
                            if resp.status_code == 200:
                                os.makedirs("outputs", exist_ok=True)
                                audio_path = os.path.join("outputs", f"elevenlabs_temp_{int(time.time())}.wav")
                                with open(audio_path, 'wb') as f: f.write(resp.content)
                            else:
                                print(f"[ElevenLabs API Error] {resp.status_code}: {resp.text}")
                        except Exception as e: print(f"[ElevenLabs API Error] {e}")
                
                elif tts_engine == "kokoro":
                    print(f"[Kokoro] Generating native hotkey audio...")
                    try:
                        import soundfile as sf
                        import numpy as np
                        pipeline = getattr(self.model, 'kokoro_pipeline', None)
                        if pipeline:
                            voice = getattr(self.model, 'kokoro_voice', 'am_adam')
                            generator = pipeline(text, voice=voice, speed=1, split_pattern=r'\n+')
                            audio_pieces = [audio for _, _, audio in generator if audio is not None]
                            if audio_pieces:
                                final_audio = np.concatenate(audio_pieces)
                                os.makedirs("outputs", exist_ok=True)
                                audio_path = os.path.join("outputs", f"kokoro_temp_{int(time.time())}.wav")
                                sf.write(audio_path, final_audio, 24000)
                        else:
                            print("[Kokoro Error] Pipeline not loaded! Did you select it in the UI?")
                    except Exception as e: print(f"[Kokoro API Error] {e}")

                elif tts_engine == "tiktok":
                    print(f"[TikTok] Generating native hotkey audio...")
                    try:
                        import base64, urllib.parse, textwrap, time, os, io
                        from pydub import AudioSegment
                        import imageio_ffmpeg
                        import requests
                        
                        # Use the bundled ffmpeg binary so the user doesn't have to install it manually!
                        AudioSegment.converter = imageio_ffmpeg.get_ffmpeg_exe()
                        
                        voice = getattr(self.model, 'tiktok_voice', 'en_us_002')
                        session_id = os.environ.get("TIKTOK_SESSION_ID", "")
                        
                        text_chunks = textwrap.wrap(text, 250, break_long_words=False, replace_whitespace=False)
                        combined_audio = AudioSegment.empty()
                        success = False
                        
                        for chunk in text_chunks:
                            safe_text = urllib.parse.quote(chunk)
                            url = f"https://api16-normal-v6.tiktokv.com/media/api/text/speech/invoke/?text_speaker={voice}&req_text={safe_text}&speaker_map_type=0&aid=1233"
                            headers = {"Cookie": f"sessionid={session_id}"} if session_id else {}
                            
                            resp = requests.post(url, headers=headers, timeout=10)
                            if resp.status_code == 200:
                                data = resp.json()
                                if data.get("message") == "success":
                                    audio_bytes = base64.b64decode(data["data"]["v_str"])
                                    segment = AudioSegment.from_file(io.BytesIO(audio_bytes), format="mp3")
                                    combined_audio += segment
                                    success = True
                                else:
                                    print(f"[TikTok API Warning] {data}")
                        
                        if success:
                            os.makedirs("outputs", exist_ok=True)
                            audio_path = os.path.join("outputs", f"tiktok_temp_{int(time.time())}.wav")
                            combined_audio.export(audio_path, format="wav")
                        else:
                            print("[TikTok Error] API returned no audio. Check your TIKTOK_SESSION_ID!")
                            audio_path = None
                            
                    except Exception as e:
                        print(f"[TikTok Error] {e}")
                        audio_path = None
                
                elif tts_engine == "typecast":
                    print(f"[Typecast] Sending text to Ghost Browser...")
                    try:
                        from typecast_bridge import TypecastGhostEngine
                        engine = TypecastGhostEngine()
                        engine.play_ghost_audio(text)
                        audio_path = None # Audio plays natively through the hidden browser!
                    except Exception as e: 
                        print(f"[Typecast Macro Error] {e}")
                        audio_path = None

                elif tts_engine == "elevenlabs_ghost":
                    print(f"[ElevenLabs Ghost] Sending text to Stealth Browser...")
                    try:
                        from elevenlabs_ghost_bridge import ElevenLabsGhostEngine
                        engine = ElevenLabsGhostEngine()
                        engine.play_ghost_audio(text)
                        audio_path = None
                    except Exception as e: 
                        print(f"[ElevenLabs Ghost Error] {e}")
                        audio_path = None

                elif tts_engine == "bark":
                    print(f"[Bark] Generating native hotkey audio...")
                    try:
                        audio_array, _sr = _bark_native_generate(self.model, text)
                        if audio_array is None: raise RuntimeError("Bark returned no audio")
                        os.makedirs("outputs", exist_ok=True)
                        audio_path = os.path.join("outputs", f"bark_temp_{int(time.time())}.wav")
                        _write_wav_int16(audio_path, audio_array, _sr)
                    except Exception as e: print(f"[Bark Error] {e}")

                elif tts_engine == "voicebox":
                    print(f"[Voicebox] Generating native hotkey audio via Async Polling...")
                    try:
                        vb_url = getattr(self.model, 'voicebox_url', 'http://127.0.0.1:17493').rstrip('/')
                        voice_name = getattr(self.model, 'voicebox_voice', 'SamuelCCoF')
                        
                        actual_id = voice_name
                        try:
                            p_resp = requests.get(f"{vb_url}/profiles", timeout=5)
                            if p_resp.status_code == 200:
                                for p in p_resp.json():
                                    if p.get("name", "").lower() == voice_name.lower():
                                        actual_id = p.get("id", voice_name)
                                        print(f"[Voicebox] Auto-resolved '{voice_name}' to internal ID: {actual_id}")
                                        break
                        except: pass
                        
                        resp = requests.post(f"{vb_url}/generate", json={"text": text, "profile_id": actual_id}, timeout=10)
                        if resp.status_code == 200:
                            gen_id = resp.json().get("id")
                            import time
                            for _ in range(60):
                                status_resp = requests.get(f"{vb_url}/history/{gen_id}", timeout=5)
                                if status_resp.status_code == 200 and status_resp.json().get("status") == "completed":
                                    audio_resp = requests.get(f"{vb_url}/audio/{gen_id}", timeout=10)
                                    if audio_resp.status_code == 200:
                                        os.makedirs("outputs", exist_ok=True)
                                        audio_path = os.path.join("outputs", f"voicebox_temp_{int(time.time())}.wav")
                                        with open(audio_path, "wb") as f: f.write(audio_resp.content)
                                    break
                                time.sleep(0.5)
                        else: print(f"[Voicebox API Error] {resp.status_code}: {resp.text}")
                    except Exception as e: print(f"[Voicebox Error] {e}")

                elif hasattr(self.model, f'generate_{tts_engine}_tts'):
                    print(f"[{tts_engine.upper()}] Routing to native TTS generator...")
                    try: audio_path = getattr(self.model, f'generate_{tts_engine}_tts')(text)
                    except Exception as e: print(f"[{tts_engine.upper()} Error] {e}")

                elif hasattr(self.model, f'generate_{tts_engine}_audio'):
                    print(f"[{tts_engine.upper()}] Routing to native Audio generator...")
                    try: audio_path = getattr(self.model, f'generate_{tts_engine}_audio')(text)
                    except Exception as e: print(f"[{tts_engine.upper()} Error] {e}")

                elif "edge" in tts_engine and hasattr(self.model, 'generate_edge_tts'):
                    print(f"[{tts_engine.upper()}] Routing to Edge TTS...")
                    try:
                        voice = getattr(self.model, 'edge_tts_voice', 'en-US-ChristopherNeural')
                        audio_path = self.model.generate_edge_tts(text, voice)
                    except Exception as e: print(f"[Edge Error] {e}")

                elif "google" in tts_engine and hasattr(self.model, 'generate_google_tts'):
                    print(f"[{tts_engine.upper()}] Routing to Google TTS...")
                    try: audio_path = self.model.generate_google_tts(text)
                    except Exception as e: print(f"[Google Error] {e}")
                    
                elif "soprano" in tts_engine and hasattr(self.model, 'generate_soprano_tts'):
                    print(f"[{tts_engine.upper()}] Routing to Soprano TTS...")
                    try: audio_path = self.model.generate_soprano_tts(text)
                    except Exception as e: print(f"[Soprano Error] {e}")

                else:
                    if hasattr(self.model, 'generate_pyttsx3_audio'):
                        audio_path = self.model.generate_pyttsx3_audio(text)

                if audio_path and os.path.exists(audio_path):
                    expected_video_path = None
                    video_enabled = os.path.exists(os.path.abspath("enable_video.txt"))
                    
                    if category:
                        try:
                            text_hash = hashlib.md5(text.encode('utf-8')).hexdigest()
                            chan_safe = getattr(self.model, 'channel_name', 'General').replace(' ', '_')
                            game_safe = getattr(self.model, 'game_name', 'Just_Chatting').replace(' ', '_')
                            
                            active_engine = tts_engine.replace('_cpu', '')
                            cache_dir = f"{active_engine}_cache/{chan_safe}/{game_safe}/{category}"
                            os.makedirs(cache_dir, exist_ok=True)
                            
                            expected_video_path = os.path.join(cache_dir, f"{category}_{text_hash}.mp4")
                            cache_wav = expected_video_path.replace(".mp4", ".wav")
                            cache_txt = expected_video_path.replace(".mp4", ".txt")
                            
                            shutil.copy(audio_path, cache_wav)
                            with open(cache_txt, "w", encoding="utf-8") as f:
                                f.write(original_prompt if original_prompt else text)
                            print(f"[System] 💾 New hotkey saved to cache: {cache_wav}")
                        except Exception as e: print(f"[Cache Save Error] {e}")

                    import model as model_module
                                                                        
                    if video_enabled:
                        avatar_path = os.path.abspath("avatar.png")
                        if os.path.exists(avatar_path):
                            print(f"[System] 🎬 Video Rendering is ON. Sending to SadTalker...")
                            try:
                                from sadtalker_bridge import SadTalkerEngine
                                animator = SadTalkerEngine()
                                video_path = animator.generate_talking_head(audio_path, avatar_path)
                                
                                if video_path:
                                    if expected_video_path:
                                        try: shutil.copy(video_path, expected_video_path)
                                        except: pass
                                        print(f"[System] 🎬 Video Saved to Cache and Ready: {expected_video_path}")
                                        
                                    abs_vid = os.path.abspath(expected_video_path if expected_video_path else video_path)
                                    abs_aud = os.path.abspath(audio_path)
                                    try:
                                        with open("play_avatar.txt", "w", encoding="utf-8") as f:
                                            f.write(f"{abs_vid}|{abs_aud}")
                                    except: pass
                                else:
                                    print("[System] Video generation failed. Playing audio only.")
                            except Exception as st_err:
                                print(f"[SadTalker Error] {st_err}")
                        else:
                            print("[System] No avatar.png found. Playing audio only.")
                    else:
                        print("[System] 🎬 Video Rendering is OFF (or enable_video.txt is missing). Playing audio only.")
                    
                    model_module.play_wav_winsound(audio_path, self.model.volume_level)

                    if "T" in mode:
                        self.model.manual_reply_queue.put({'message': text, 'force_voice_only': False, 'force_text_only': True, 'silent_cache': False, 'force_fresh': False})
            
            except Exception as e:
                import traceback
                print(f"[Instant Gen Error] {e}\n{traceback.format_exc()}")
                
        import threading
        threading.Thread(target=_generate_and_play, daemon=True).start()

    def _search_and_react(self, query, desc, mode, category, emotion_tag, short_enabled, custom_instructions=None):
        try:
            global global_abort_flag
            global_abort_flag[0] = False
        except: pass
        
        try: setattr(self.model, 'abort_generation', False)
        except: pass
        
        print(f"\n[Hotkey] 🎙️ INSTANT GENERATION FOR OVERRIDE DETECTED!")
        
        def _instant_gen():
            import time, os, requests, shutil, hashlib
            try:
                self.stop_current_audio()
                
                tts_engine = getattr(self.model, 'tts_mode', 'elevenlabs').replace('_cpu', '')
                print(f"[TTS] Generating hotkey using: {tts_engine.upper()}")
                
                audio_path = None
                gen_text = custom_instructions if custom_instructions else f"Reacting to {query}"
                
                try:
                    if tts_engine == "bark":
                        print(f"[Bark TTS] Generating audio for: '{gen_text[:20]}...'")
                        audio_array, _sr = _bark_native_generate(self.model, gen_text)
                        if audio_array is None: raise RuntimeError("Bark returned no audio")
                        output_dir = "outputs"
                        os.makedirs(output_dir, exist_ok=True)
                        audio_path = os.path.join(output_dir, f"bark_temp_{int(time.time())}.wav")
                        _write_wav_int16(audio_path, audio_array, _sr)
                        
                    elif tts_engine == "kokoro":
                        print(f"[Kokoro] Generating native hotkey audio...")
                        import soundfile as sf
                        import numpy as np
                        pipeline = getattr(self.model, 'kokoro_pipeline', None)
                        if pipeline:
                            voice = getattr(self.model, 'kokoro_voice', 'am_adam')
                            generator = pipeline(gen_text, voice=voice, speed=1, split_pattern=r'\n+')
                            audio_pieces = [audio for _, _, audio in generator if audio is not None]
                            if audio_pieces:
                                final_audio = np.concatenate(audio_pieces)
                                os.makedirs("outputs", exist_ok=True)
                                audio_path = os.path.join("outputs", f"kokoro_temp_{int(time.time())}.wav")
                                sf.write(audio_path, final_audio, 24000)
                        else:
                            print("[Kokoro Error] Pipeline not loaded!")

                    elif tts_engine == "tiktok":
                        print(f"[TikTok] Generating native hotkey audio...")
                        try:
                            import base64, urllib.parse, textwrap, time, os, io
                            from pydub import AudioSegment
                            import imageio_ffmpeg
                            import requests
                            
                            # Use the bundled ffmpeg binary so the user doesn't have to install it manually!
                            AudioSegment.converter = imageio_ffmpeg.get_ffmpeg_exe()
                            
                            voice = getattr(self.model, 'tiktok_voice', 'en_us_002')
                            session_id = os.environ.get("TIKTOK_SESSION_ID", "")
                            
                            text_chunks = textwrap.wrap(gen_text, 250, break_long_words=False, replace_whitespace=False)
                            combined_audio = AudioSegment.empty()
                            success = False
                            
                            for chunk in text_chunks:
                                safe_text = urllib.parse.quote(chunk)
                                url = f"https://api16-normal-v6.tiktokv.com/media/api/text/speech/invoke/?text_speaker={voice}&req_text={safe_text}&speaker_map_type=0&aid=1233"
                                headers = {"Cookie": f"sessionid={session_id}"} if session_id else {}
                                
                                resp = requests.post(url, headers=headers, timeout=10)
                                if resp.status_code == 200:
                                    data = resp.json()
                                    if data.get("message") == "success":
                                        audio_bytes = base64.b64decode(data["data"]["v_str"])
                                        segment = AudioSegment.from_file(io.BytesIO(audio_bytes), format="mp3")
                                        combined_audio += segment
                                        success = True
                                    else:
                                        print(f"[TikTok API Warning] {data}")
                            
                            if success:
                                os.makedirs("outputs", exist_ok=True)
                                audio_path = os.path.join("outputs", f"tiktok_temp_{int(time.time())}.wav")
                                combined_audio.export(audio_path, format="wav")
                            else:
                                print("[TikTok Error] API returned no audio. Check your TIKTOK_SESSION_ID!")
                                audio_path = None
                                
                        except Exception as e:
                            print(f"[TikTok Error] {e}")
                            audio_path = None

                    elif tts_engine == "typecast":
                        print(f"[Typecast] Sending text to Ghost Browser...")
                        try:
                            from typecast_bridge import TypecastGhostEngine
                            engine = TypecastGhostEngine()
                            engine.play_ghost_audio(gen_text)
                            audio_path = None # Audio plays natively through the hidden browser!
                        except Exception as e: 
                            print(f"[Typecast Macro Error] {e}")
                            audio_path = None

                    elif tts_engine == "elevenlabs_ghost":
                        print(f"[ElevenLabs Ghost] Sending text to Stealth Browser...")
                        try:
                            from elevenlabs_ghost_bridge import ElevenLabsGhostEngine
                            engine = ElevenLabsGhostEngine()
                            engine.play_ghost_audio(gen_text)
                            audio_path = None
                        except Exception as e: 
                            print(f"[ElevenLabs Ghost Error] {e}")
                            audio_path = None

                    elif tts_engine == "voicebox":
                        print(f"[Voicebox] Generating native hotkey audio via Async Polling...")
                        try:
                            vb_url = getattr(self.model, 'voicebox_url', 'http://127.0.0.1:17493').rstrip('/')
                            voice_name = getattr(self.model, 'voicebox_voice', 'SamuelCCoF')
                            
                            actual_id = voice_name
                            try:
                                p_resp = requests.get(f"{vb_url}/profiles", timeout=5)
                                if p_resp.status_code == 200:
                                    for p in p_resp.json():
                                        if p.get("name", "").lower() == voice_name.lower():
                                            actual_id = p.get("id", voice_name)
                                            break
                            except: pass
                            
                            resp = requests.post(f"{vb_url}/generate", json={"text": gen_text, "profile_id": actual_id}, timeout=10)
                            if resp.status_code == 200:
                                gen_id = resp.json().get("id")
                                import time
                                for _ in range(60):
                                    status_resp = requests.get(f"{vb_url}/history/{gen_id}", timeout=5)
                                    if status_resp.status_code == 200 and status_resp.json().get("status") == "completed":
                                        audio_resp = requests.get(f"{vb_url}/audio/{gen_id}", timeout=10)
                                        if audio_resp.status_code == 200:
                                            os.makedirs("outputs", exist_ok=True)
                                            audio_path = os.path.join("outputs", f"voicebox_temp_{int(time.time())}.wav")
                                            with open(audio_path, "wb") as f: f.write(audio_resp.content)
                                        break
                                    time.sleep(0.5)
                            else: print(f"[Voicebox API Error] {resp.status_code}: {resp.text}")
                        except Exception as e: print(f"[Voicebox Error] {e}")

                    elif hasattr(self.model, f'generate_{tts_engine}_tts'):
                        print(f"[{tts_engine.upper()}] Routing to native TTS generator...")
                        try: audio_path = getattr(self.model, f'generate_{tts_engine}_tts')(gen_text)
                        except Exception as e: print(f"[{tts_engine.upper()} Error] {e}")

                    elif hasattr(self.model, f'generate_{tts_engine}_audio'):
                        print(f"[{tts_engine.upper()}] Routing to native Audio generator...")
                        try: audio_path = getattr(self.model, f'generate_{tts_engine}_audio')(gen_text)
                        except Exception as e: print(f"[{tts_engine.upper()} Error] {e}")

                    elif "edge" in tts_engine and hasattr(self.model, 'generate_edge_tts'):
                        print(f"[{tts_engine.upper()}] Routing to Edge TTS...")
                        try:
                            voice = getattr(self.model, 'edge_tts_voice', 'en-US-ChristopherNeural')
                            audio_path = self.model.generate_edge_tts(gen_text, voice)
                        except Exception as e: print(f"[Edge Error] {e}")

                    elif "google" in tts_engine and hasattr(self.model, 'generate_google_tts'):
                        print(f"[{tts_engine.upper()}] Routing to Google TTS...")
                        try: audio_path = self.model.generate_google_tts(gen_text)
                        except Exception as e: print(f"[Google Error] {e}")
                        
                    elif "soprano" in tts_engine and hasattr(self.model, 'generate_soprano_tts'):
                        print(f"[{tts_engine.upper()}] Routing to Soprano TTS...")
                        try: audio_path = self.model.generate_soprano_tts(gen_text)
                        except Exception as e: print(f"[Soprano Error] {e}")

                    else:
                        if hasattr(self.model, 'generate_pyttsx3_audio'):
                            audio_path = self.model.generate_pyttsx3_audio(gen_text)
                        
                except Exception as e:
                    print(f"[TTS Engine Error] Failed to generate: {e}")
                    return

                if audio_path and os.path.exists(audio_path):
                    expected_video_path = None
                    video_enabled = os.path.exists(os.path.abspath("enable_video.txt"))
                    
                    if category:
                        try:
                            text_hash = hashlib.md5(gen_text.encode('utf-8')).hexdigest()
                            active_engine = tts_engine.replace('_cpu', '')
                            cache_dir = f"{active_engine}_cache/{self.model.channel_name.replace(' ', '_')}/{self.model.game_name.replace(' ', '_')}/{category}"
                            os.makedirs(cache_dir, exist_ok=True)
                            expected_video_path = os.path.join(cache_dir, f"{category}_{text_hash}.mp4")
                            cache_wav = expected_video_path.replace(".mp4", ".wav")
                            cache_txt = expected_video_path.replace(".mp4", ".txt")
                            
                            shutil.copy(audio_path, cache_wav)
                            with open(cache_txt, "w", encoding="utf-8") as f:
                                f.write(gen_text)
                            print(f"[System] 💾 New hotkey saved to cache: {cache_wav}")
                        except Exception as e: print(f"[Cache Save Error] {e}")

                    time.sleep(0.05)
                    
                    import model as model_module
                    if video_enabled and getattr(self.model, 'tts_mode', '') != 'bark':
                        avatar_path = os.path.abspath("avatar.png")
                        if os.path.exists(avatar_path):
                            print(f"[System] 🎬 Video Rendering is ON. Sending to SadTalker...")
                            try:
                                from sadtalker_bridge import SadTalkerEngine
                                animator = SadTalkerEngine()
                                video_path = animator.generate_talking_head(audio_path, avatar_path)
                                
                                if video_path:
                                    if expected_video_path:
                                        try:
                                            shutil.copy(video_path, expected_video_path)
                                            print(f"[System] 🎬 Video Saved to Cache and Ready: {expected_video_path}")
                                        except: pass
                                        
                                    abs_vid = os.path.abspath(expected_video_path if expected_video_path else video_path)
                                    abs_aud = os.path.abspath(audio_path)
                                    try:
                                        with open("play_avatar.txt", "w", encoding="utf-8") as f:
                                            f.write(f"{abs_vid}|{abs_aud}")
                                    except: pass
                                    
                                    model_module.play_wav_winsound(audio_path, self.model.volume_level)
                                else:
                                    print("[System] Video generation failed. Playing audio only.")
                                    model_module.play_wav_winsound(audio_path, self.model.volume_level)
                            except Exception as st_err:
                                print(f"[SadTalker Error] {st_err}")
                                model_module.play_wav_winsound(audio_path, self.model.volume_level)
                        else:
                            print("[System] No avatar.png found. Playing audio only.")
                            model_module.play_wav_winsound(audio_path, self.model.volume_level)
                    else:
                        model_module.play_wav_winsound(audio_path, self.model.volume_level)

                    if "T" in mode:
                        self.model.manual_reply_queue.put({'message': gen_text, 'force_voice_only': False, 'force_text_only': True, 'silent_cache': False, 'force_fresh': False})
            except Exception as e:
                import traceback
                print(f"[Instant Gen Error] {e}\n{traceback.format_exc()}")
                
        import threading
        threading.Thread(target=_instant_gen, daemon=True).start()

    def _trigger_shared_hotkey(self, base_attr, prompt, desc, emotion_tag=None):
        # 🛡️ THE ANTI-ECHO FIX: Make the instruction incredibly natural so the AI doesn't get confused.
        prompt = f"I am currently doing this on stream: '{prompt}'. What do I say on the microphone right now? Reply ONLY with my exact spoken words. Do not narrate."
        # 🛡️ THE THREAD-SAFE FIX: Background threads crash if they touch physical UI boxes!
        try:
            if hasattr(self.view, 'game_var'): 
                self.model.game_name = self.view.game_var.get()
                
            if hasattr(self.view, 'channel_combo'):
                try:
                    c_str = self.view.channel_combo.get()
                    self.model.channel_name = c_str.split(": ")[-1] if ": " in c_str else c_str
                except: pass
        except Exception: pass

        category = base_attr.replace("hk_", "")
        import time
        now = time.time()
        last_raw = getattr(self, f"_last_raw_{category}", 0)
        
        if (now - last_raw) < 0.08: return 
        setattr(self, f"_last_raw_{category}", now)
        
        if category not in self._tap_counts: self._tap_counts[category] = 0
        if self._tap_counts[category] == 0: self.stop_current_audio()
            
        self._tap_counts[category] += 1
        current_count = self._tap_counts[category]
        print(f"\n[Hotkey Detected] '{desc}' Button Pressed! (Tap Count: {current_count})")
        
        if category in self._tap_timers and self._tap_timers[category] is not None:
            try: self._tap_timers[category].cancel()
            except: pass
            
        def _execute():
            try:
                count = self._tap_counts.get(category, 0)
                self._tap_counts[category] = 0
                self._tap_timers[category] = None
                
                mode = str(getattr(self, f"{base_attr}_mode", "V+T") or "V+T")
                global_mode = int(getattr(self.model, 'current_bot_mode', 3))
                if global_mode == 2 and mode == "T": mode = "V"
                elif global_mode == 1 and mode == "V": mode = "T"
                
                custom_msg = str(getattr(self, f"{base_attr}_custom", "") or "").strip()
                ai_prompt = str(getattr(self, f"{base_attr}_prompt", "") or "").strip()
                
                # 🛡️ FIX 1: Grab directly from the UI if you forgot to click "Save Settings"!
                try:
                    if hasattr(self, 'view') and hasattr(self.view, f"{base_attr}_custom_var"):
                        ui_custom = str(getattr(self.view, f"{base_attr}_custom_var").get()).strip()
                        if ui_custom: custom_msg = ui_custom
                except: pass
                
                audio_file = str(getattr(self, f"{base_attr}_audio", "") or "").strip()
                audio_enabled = bool(getattr(self, f"{base_attr}_audio_enabled", False))
                mute_ai = bool(getattr(self, f"{base_attr}_mute_ai", False))
                short_enabled = bool(getattr(self, f"{base_attr}_short", False))
                
                if mode == "T": print(f"    [Audio Engine] 🔇 Skipped audio generation because hotkey mode is set to Text-Only (T).")
                if getattr(self, 'custom_length_enabled', False): short_enabled = False
                
                global_mute = bool(getattr(self, 'global_ai_mute', False))
                force_cache_only = bool(getattr(self, 'force_cache_only', False))
                
                import os
                if mute_ai or global_mute:
                    if mode == "V+T": mode = "T"
                    elif mode == "V":
                        if audio_file and os.path.exists(audio_file) and audio_enabled:
                            print(f"[Soundboard] 🔊 Playing attached file (AI Muted): {os.path.basename(audio_file)}")
                            self.play_soundboard_audio(audio_file)
                        return
                
                if audio_file and os.path.exists(audio_file) and audio_enabled:
                    print(f"[Soundboard] 🔊 Playing attached file: {os.path.basename(audio_file)}")
                    self.play_soundboard_audio(audio_file)

                active_prompt = custom_msg if custom_msg else ai_prompt if ai_prompt else prompt
                is_exact_override = bool(custom_msg)
                
                # 🛡️ THE HALLUCINATION COLLAR: Force the AI to stick ONLY to your Live Context
                if category == "live_context" and ai_prompt:
                    active_prompt = f"I am currently: '{ai_prompt}'. React exclusively to this specific action. Keep your response completely grounded in what I just stated."
                
                local_emotion_tag = emotion_tag
                
                # --- NEW FIX: ONLY ALLOW EMOTION TAGS IF BARK IS ACTIVE ---
                if getattr(self.model, 'tts_mode', '') != 'bark':
                    local_emotion_tag = None
                    import re
                    active_prompt = re.sub(r'(\[(?:laughs|laughter|sighs|screams|gasps|clears throat|smacks lips|cries|hesitates)\])', '', active_prompt, flags=re.IGNORECASE).strip()
                
                if not local_emotion_tag and active_prompt:
                    import re
                    tag_match = re.search(r'(\[(?:laughs|laughter|sighs|screams|gasps|clears throat|smacks lips|cries|hesitates)\])', active_prompt, re.IGNORECASE)
                    if tag_match:
                        local_emotion_tag = tag_match.group(1).lower()
                    else:
                        start_match = re.match(r'^\s*(\[[a-zA-Z\s]+\])', active_prompt)
                        if start_match:
                            local_emotion_tag = start_match.group(1).lower()

                if count >= 2 or (count == 1 and force_cache_only and not is_exact_override):
                    if count >= 2: print(f"[Hotkey] ⚡ DOUBLE-TAP CONFIRMED: {desc}")
                    else: print(f"[Hotkey] ⚡ FORCE CACHE ENABLED: {desc}")
                    self._inject_instant_hotkey("", mode, force_cache=True, category=category, original_prompt=active_prompt)
                elif count == 1:
                    print(f"[Hotkey] 🟢 SINGLE-TAP CONFIRMED: {desc}")
                    import re
                    m1 = re.search(r'\[SEARCH:\s*(.*?)\](.*)', active_prompt, re.IGNORECASE | re.DOTALL)
                    m2 = re.search(r'\[SEARCH\](.*)', active_prompt, re.IGNORECASE | re.DOTALL)

                    import threading
                    if m1 or m2:
                        search_q = m1.group(1).strip() if m1 else "latest trends and rumors"
                        search_inst = m1.group(2).strip() if m1 else (m2.group(1).strip() if m2 else "")
                        final_query = f"{self.model.game_name} {search_q}" if self.model.game_name.lower() not in search_q.lower() else search_q
                        threading.Thread(target=self._search_and_react, args=(final_query, desc, mode, category, local_emotion_tag, short_enabled, search_inst), daemon=True).start()
                    elif is_exact_override:
                        if local_emotion_tag and not custom_msg.startswith(local_emotion_tag) and not custom_msg.startswith("["): custom_msg = f"{local_emotion_tag} {custom_msg}"
                        
                        # 🛡️ FIX 2: Removed invisible spaces so ElevenLabs stops crashing!
                        if not force_cache_only:
                            print(f"[Hotkey] 👑 OVERRIDE ACTIVE -> Bypassing AI to say exact text: '{custom_msg.strip()}' (Fresh audio forced)")
                            self._inject_instant_hotkey(custom_msg, mode, force_cache=False, category=category, force_fresh=True)
                        else:
                            print(f"[Hotkey] 👑 OVERRIDE ACTIVE -> Bypassing AI to say exact text: '{custom_msg.strip()}' (Using Exact Cache)")
                            self._inject_instant_hotkey(custom_msg, mode, force_cache=True, category=category, force_fresh=False)
                    elif active_prompt:
                        print(f"[Hotkey] 🧠 AI Prompt Active: '{active_prompt}'")
                        if short_enabled:
                            full_p = f"{active_prompt} Reply with ONLY 1 TO 4 WORDS MAXIMUM!"
                            if local_emotion_tag: full_p += f" Start with '{local_emotion_tag}'!"
                            self.run_dynamic_hotkey(self._build_hotkey_msgs(full_p), desc, mode, category=category, custom_max_tokens=15, emotion_tag=local_emotion_tag)
                        else:
                            full_p = active_prompt
                            if local_emotion_tag: full_p += f" IMPORTANT: Start your response with '{local_emotion_tag}'!"
                            self.run_dynamic_hotkey(self._build_hotkey_msgs(full_p), desc, mode, category=category, custom_max_tokens=80, emotion_tag=local_emotion_tag)
                    else: print(f"[{desc}] No text or prompt set. Triggering audio only (if attached).")
            except Exception as e: print(f"\n[Hotkey Fatal Error] CRITICAL THREAD FAILURE in _execute for '{desc}': {e}")

        timer = threading.Timer(0.40, _execute)
        self._tap_timers[category] = timer
        timer.start()

    # --- CHAT & REACTION TRIGGERS ---
    def trigger_hotkey_idle(self): self._trigger_shared_hotkey("hk_idle", "Say something random and entertaining to break the silence.", "Idle Msg")
    def trigger_hotkey_thanks(self): self._trigger_shared_hotkey("hk_thanks", f"Greet the {self.model.current_viewer_count} viewers currently watching.", "Thanks/Greet")
    def trigger_hotkey_game_q(self): self._trigger_shared_hotkey("hk_question", "Ask the viewers a general question about the game's mechanics.", "Game Question")
    def trigger_hotkey_help(self): self._trigger_shared_hotkey("hk_help", "Ask the viewers for tips on what you are currently doing.", "Help Msg")
    def trigger_hotkey_death(self): self._trigger_shared_hotkey("hk_death", "React with pure gamer frustration to losing or dying just now.", "Death Msg", "[screams]")
    def trigger_hotkey_likes_thanks(self): self._trigger_shared_hotkey("hk_likes_thanks", "Thank the viewers for the likes and support.", "Thanks Likes")
    def trigger_hotkey_brb(self): self._trigger_shared_hotkey("hk_brb", "Tell the viewers you will be right back.", "BRB Msg")
    def trigger_hotkey_tech_issue(self): self._trigger_shared_hotkey("hk_tech_issue", "Apologize for technical issues or lag.", "Tech Issue Msg")
    def trigger_hotkey_game_request(self): self._trigger_shared_hotkey("hk_game_request", "Ask the viewers what game they want to see next.", "Game Request Msg")
    def trigger_hotkey_taunt(self): self._trigger_shared_hotkey("hk_taunt", "Taunt the game itself for being too easy.", "Taunt")
    def trigger_hotkey_intro(self): self._trigger_shared_hotkey("hk_intro", f"Welcome everyone to the stream! Enthusiastically introduce yourself as {self.model.channel_name} and mention you are playing {self.model.game_name}.", "Intro")
    def trigger_hotkey_frustration(self): self._trigger_shared_hotkey("hk_frustration", "Express frustration with the game's general difficulty.", "Frustration", "[sighs]")
    def trigger_hotkey_attack(self): self._trigger_shared_hotkey("hk_attack", "Hype up your own gaming skills in a fight.", "Attack")
    def trigger_hotkey_talk_viewers(self): self._trigger_shared_hotkey("hk_talk_viewers", "Talk about current gaming trends with the viewers.", "Talk Viewers")
    def trigger_hotkey_puzzle(self): self._trigger_shared_hotkey("hk_puzzle", "React to solving a puzzle, praising your own brain.", "Puzzle Solved", "[laughs]")
    def trigger_hotkey_boss_win(self): self._trigger_shared_hotkey("hk_boss_win", "Celebrate a big win by hyping yourself up.", "Boss Defeated", "[laughs]")
    def trigger_hotkey_feeling_good(self): self._trigger_shared_hotkey("hk_feeling_good", "Express feeling good about the stream.", "Feeling Good")
    def trigger_hotkey_feeling_bad(self): self._trigger_shared_hotkey("hk_feeling_bad", "Express feeling down or bad.", "Feeling Bad", "[sighs]")
    def trigger_hotkey_clip_that(self): self._trigger_shared_hotkey("hk_clip_that", "Tell the viewers to clip that awesome moment.", "Clip That", "[laughs]")
    def trigger_hotkey_panic(self): self._trigger_shared_hotkey("hk_panic", "Panic about the game stressing you out.", "Panic / Scream", "[gasps]")
    
    def trigger_hotkey_live_context(self):
        ctx_prompt = getattr(self, "hk_live_context_prompt", "")
        if ctx_prompt: self._trigger_shared_hotkey("hk_live_context", f"I am currently doing this in the game: {ctx_prompt}. React dynamically to this exact situation!", "Live Context")
        else: print("[Hotkey] Live Context triggered but no context was set. Ignoring.")

    def trigger_hotkey_shoutout_users(self):
        active_users = list(set([m.get('author') for m in self.model.chat_memory if m.get('author') and m.get('author') != self.model.channel_name])) if getattr(self.model, 'chat_memory', None) else []
        names_str = ", ".join(active_users[:5]) if active_users else "the active chatters"
        self._trigger_shared_hotkey("hk_shoutout_users", f"Give a quick, hype shoutout to these active viewers: {names_str}.", "Shoutout Active Users")

    def trigger_hotkey_reply_last(self):
        if getattr(self, 'is_generating', False): return
        msg_obj = getattr(self.model, 'last_incoming_message', None)
        if not msg_obj: return
        
        # FIX: Create a deep copy of the dictionary to prevent background thread dictionary mutation crashes!
        msg_copy = dict(msg_obj)
        
        print(f"[Hotkey] Replying to LAST chat from: {msg_copy.get('author', 'Unknown')}")
        mode = getattr(self, 'hk_reply_last_mode', "V+T")
        
        # FIX: Forcefully override Hotkey Mode if it conflicts with Global Output Mode
        global_mode = int(getattr(self.model, 'current_bot_mode', 3))
        if global_mode == 2 and mode == "T": mode = "V"
        elif global_mode == 1 and mode == "V": mode = "T"
        
        if getattr(self, 'force_cache_only', False):
            print("[System] ⚡ Force Cache is ENABLED. Skipping fresh voice generation for Reply Last (no random voice will play).")
            msg_copy['force_voice_only'] = False
            msg_copy['force_text_only'] = True
            msg_copy['force_fresh'] = False
        else:
            msg_copy['force_voice_only'] = (mode == "V")
            msg_copy['force_text_only'] = (mode == "T")
            msg_copy['force_fresh'] = True
        
        if hasattr(self.model, 'target_reply_queue'):
            self.model.target_reply_queue.put(msg_copy)
    def toggle_vision_mode(self):
        """Toggles Vision between Normal Reaction and Quest Walkthrough"""
        current_mode = getattr(self, 'vision_walkthrough_mode', False)
        self.vision_walkthrough_mode = not current_mode
        
        mode_name = "QUEST WALKTHROUGH GUIDE" if self.vision_walkthrough_mode else "NORMAL REACTION"
        print(f"\n[System] 👁️ Vision Mode toggled to: {mode_name}")
        
        # --- NEW VISUAL POP-UP OVERLAY (No Sound) ---
        try:
            import tkinter as tk
            
            # Create a borderless, transparent window
            toast = tk.Toplevel(self.root)
            toast.overrideredirect(True) # Removes the standard Windows close/minimize borders
            toast.attributes("-topmost", True) # Forces it to sit ABOVE your game
            toast.attributes("-alpha", 0.9) # Makes it 10% transparent
            toast.configure(bg="#1e1e1e") # Sleek dark gray background
            
            # The Text inside the pop-up
            lbl = tk.Label(
                toast, 
                text=f"👁️ VISION SET TO:\n{mode_name}", 
                font=("Arial", 16, "bold"), 
                fg="#00ffcc", # Neon cyan text
                bg="#1e1e1e", 
                padx=20, pady=10
            )
            lbl.pack()
            
            # Automatically center it at the TOP of your screen
            toast.update_idletasks()
            screen_width = toast.winfo_screenwidth()
            x = (screen_width // 2) - (toast.winfo_width() // 2)
            toast.geometry(f"+{x}+50") # Drops it 50 pixels down from the top monitor edge
            
            # Destroy the pop-up automatically after 2.5 seconds (2500 ms)
            toast.after(2500, toast.destroy)
            
        except Exception as e: 
            print(f"[UI Error] Could not show overlay: {e}")
    def trigger_hotkey_vision_reaction(self):
        """Captures a 3-frame comic strip and asks the AI to react to the motion."""
        import time, threading, os
        
        # 🛡️ THE THREAD LOCK 
        if getattr(self, '_vision_active_lock', False):
            print("[Vision] ⏳ AI is processing. Ignoring click...")
            return 
            
        self._vision_active_lock = True
        print("\n[Hotkey Detected] 👁️ 'Video Vision' Triggered! Recording next 1 second...")
        
        try: self.stop_current_audio()
        except Exception: pass

        def _isolated_capture_and_api():
            try:
                import base64, gc, io
                import mss 
                from PIL import Image
                
                # 1. 📸 RECORD THE 5-FRAME "COMIC STRIP" SAFELY
                frames = []
                
                # 🛡️ THE FIX: Open the Windows capture hook ONLY ONCE!
                with mss.mss() as sct:
                    monitor = sct.monitors[1] if len(sct.monitors) > 1 else sct.monitors[0]
                    
                    # Take 5 screenshots spaced by 500ms
                    for i in range(5):
                        # Quietly grab the frame without rebuilding the hook
                        sct_img = sct.grab(monitor)
                        img = Image.frombytes("RGB", sct_img.size, sct_img.bgra, "raw", "BGRX")
                        img.thumbnail((640, 360)) 
                        frames.append(img)
                        
                        # Breathe for half a second
                        if i < 4: time.sleep(0.5)
                
                # Stitch them side-by-side
                total_width = sum(f.size[0] for f in frames)
                max_height = max(f.size[1] for f in frames)
                comic_strip = Image.new('RGB', (total_width, max_height))
                
                x_offset = 0
                for f in frames:
                    comic_strip.paste(f, (x_offset, 0))
                    x_offset += f.size[0]
                    f.close()
                
                # Compress to Base64 for the API
                buffered = io.BytesIO()
                comic_strip.save(buffered, format="JPEG", quality=75)
                base64_img = base64.b64encode(buffered.getvalue()).decode('utf-8')
                
                comic_strip.close(); del frames; gc.collect()
                
                # 2. 🧠 DYNAMIC WORD COUNT & MODE CHECK
                try: target_words = int(getattr(self, 'hk_custom_word_count', getattr(self.model, 'max_words', 25)))
                except: target_words = 25
                
                is_walkthrough = getattr(self, 'vision_walkthrough_mode', False)
                
                if is_walkthrough:
                    prompt = (
                        f"Look at this 5-panel comic strip of the game {self.model.game_name}. "
                        f"Read the UI, menus, or screen to identify the CURRENT ACTIVE QUEST, objective, or puzzle. "
                        f"Reply with ONLY a short search query formatted exactly like this: [SEARCH: Name of Quest]. "
                        f"Do not include any other text, greetings, or explanations."
                    )
                else:
                    vibe = getattr(self.model, 'get_random_vibe', lambda: "chill")()
                    prompt = (
                        f"You are {self.model.channel_name}, actively streaming {self.model.game_name}. "
                        f"CURRENT VIBE: {vibe}. Look at this 5-panel comic strip of your gameplay over the last 2.5 seconds (read left to right). "
                        f"CRITICAL RULE 1: Jump STRAIGHT into your commentary. NEVER start by narrating the image. "
                        f"CRITICAL RULE 2: CALIBRATE YOUR ENERGY. If there is intense combat, react with hype or panic. BUT if you are just walking, standing still, or looking at a menu, make a chill, casual observation. "
                        f"CRITICAL RULE 3: DO NOT hallucinate combat or enemies if there are none. "
                        f"CRITICAL RULE 4: Your response MUST be roughly {target_words} words long. You must finish your complete thought! "
                        f"CRITICAL RULE 5: ABSOLUTELY NO EMOJIS. Use words only. "
                    )
                
                start_t = time.time()
                
                # 3. 🚦 EXECUTE API CALL 
                reply = self.execute_vision_api_call(base64_img, prompt)
                
                del base64_img; gc.collect()
                
                if reply:
                    safe_reply = "".join(c for c in reply if ord(c) <= 0xFFFF)
                    print(f"[Vision] ✅ AI Video Analysis finished in {time.time() - start_t:.1f}s")
                    
                    try: setattr(self.model, 'abort_generation', False)
                    except: pass
                    
                    vision_mode = str(getattr(self, 'hk_vision_mode', 'V')).strip().upper()
                    
                    if is_walkthrough:
                        import re
                        clean_reply = safe_reply.replace('\n', ' ').replace('*', '').replace('"', '').strip()
                        match = re.search(r'(?:\[SEARCH:|SEARCH:)\s*(.*?)(?:\]|$)', clean_reply, re.IGNORECASE)
                        
                        if match: query = match.group(1).strip()
                        elif len(clean_reply) < 40 and "I " not in clean_reply: query = clean_reply
                        else: query = None
                        
                        if query:
                            print(f"[Vision] 👁️ Identified Quest: '{query}'. Triggering Web Search...")
                            full_query = f"{self.model.game_name} {query} quest walkthrough how to complete guide"
                            custom_inst = f"Look at these walkthrough search results for the quest '{query}' in {self.model.game_name}. I am stuck here. Read the guide and tell me EXACTLY what I need to do to complete this quest or objective. Be direct and helpful, like a co-op partner giving me the strategy. Keep it to about {target_words} words."
                            
                            self._search_and_react(
                                query=full_query, desc="Vision Quest Search", mode=vision_mode, 
                                category="vision", emotion_tag=None, short_enabled=False, custom_instructions=custom_inst
                            )
                        else:
                            print(f"[Vision Warning] AI didn't format the quest search right. AI said: {safe_reply}")
                            self.model.manual_reply_queue.put({'message': safe_reply, 'category': 'vision', 'force_voice_only': (vision_mode == "V"), 'force_fresh': True})
                    else:
                        print(f"[Vision] 👁️ Normal Reaction Generated.")
                        self.model.manual_reply_queue.put({
                            'message': safe_reply, 'category': 'vision',
                            'force_voice_only': (vision_mode == "V"), 
                            'force_text_only': (vision_mode == "T"), 
                            'force_fresh': True
                        })
                else:
                    print("[Vision Error] ❌ AI failed to analyze the screen.")
                    
            except Exception as e: 
                print(f"[Vision Error] Critical Failure in Video Vision Thread: {e}")
            finally: 
                self._vision_active_lock = False

        threading.Thread(target=_isolated_capture_and_api, daemon=True).start()

    def execute_vision_api_call(self, base64_img, prompt):
        """Routes the vision request to Groq or Gemini, and auto-rotates keys on 429/503 Errors."""
        import requests
        import time
        ai_mode = getattr(self.model, 'ai_mode', 'gemini').lower()
        
        if ai_mode == "groq":
            keys = getattr(self.model, 'groq_api_keys', [])
            if keys:
                for _ in range(len(keys)):
                    current_key = keys[self.model.groq_key_index]
                    try:
                        url = "https://api.groq.com/openai/v1/chat/completions"
                        headers = {"Authorization": f"Bearer {current_key}", "Content-Type": "application/json"}
                        
                        # 🛡️ GROQ VISION FIX: Upgraded to the new Qwen 3.8 27B Multimodal
                        payload = {
                            "model": "qwen/qwen3.8-27b", 
                            "messages": [{"role": "user", "content": [{"type": "text", "text": prompt}, {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{base64_img}"}}]}],
                            "temperature": 0.8, 
                            "max_tokens": 800
                        }
                        
                        with requests.Session() as session:
                            resp = session.post(url, headers=headers, json=payload, timeout=15)
                        
                        if resp.status_code == 200: 
                            raw_text = resp.json()["choices"][0]["message"]["content"].strip()
                            import re
                            clean_text = re.sub(r'<think>.*?(?:</think>|$)', '', raw_text, flags=re.IGNORECASE | re.DOTALL).strip()
                            if not clean_text: return "Whoa, look at that! That is wild."
                            return clean_text
                        elif resp.status_code in [429, 503]: 
                            print(f"[Groq Vision] API Busy (HTTP {resp.status_code}). Rotating key...")
                            self.model.groq_key_index = (self.model.groq_key_index + 1) % len(keys)
                            time.sleep(1)
                            continue
                        else: 
                            print(f"[Groq Vision Error] HTTP {resp.status_code}: {resp.text}")
                            break 
                    except Exception as e:
                        print(f"[Groq Vision Exception] {e}")
                        self.model.groq_key_index = (self.model.groq_key_index + 1) % len(keys)
                
                print("[System] ⚠️ Groq Vision failed. Attempting Gemini fallback...")

        # --- GEMINI FALLBACK ---
        keys = getattr(self.model, 'gemini_api_keys', [])
        if not keys: 
            print("[System Warning] ⚠️ Gemini fallback failed! (No Gemini API keys found).")
            return None
            
        # 🛡️ GEMINI 503 FIX: Added a retry loop so it doesn't give up on temporary traffic spikes!
        max_attempts = len(keys) * 2 
        for _ in range(max_attempts):
            current_key = keys[self.model.gemini_key_index]
            try:
                url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key={current_key}"
                payload = {"contents": [{"parts": [{"text": prompt}, {"inline_data": {"mime_type": "image/jpeg", "data": base64_img}}]}], "generationConfig": {"temperature": 0.8, "maxOutputTokens": 800}}
                with requests.Session() as session:
                    resp = session.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=15)
                
                if resp.status_code == 200: 
                    return resp.json()['candidates'][0]['content']['parts'][0]['text'].strip()
                elif resp.status_code in [429, 503]: 
                    print(f"[Gemini Vision] Server overloaded (HTTP {resp.status_code}). Retrying in 2s...")
                    self.model.gemini_key_index = (self.model.gemini_key_index + 1) % len(keys)
                    time.sleep(2)
                    continue
                else: 
                    print(f"[Gemini Vision Error] {resp.text}")
                    return None
            except Exception as e: 
                print(f"[Gemini Vision Exception] {e}")
                self.model.gemini_key_index = (self.model.gemini_key_index + 1) % len(keys)
                time.sleep(1)
                
        return None
       

    # --- SYSTEM & GUI TRIGGERS (Rebuilt Natively for Flawless Action) ---
    def trigger_hotkey_stats(self):
        try:
            if getattr(self, 'overlay_status_window', None) and hasattr(self.overlay_status_window, 'winfo_exists') and self.overlay_status_window.winfo_exists():
                self.saved_status_geo = self.overlay_status_window.geometry()
                self.overlay_status_window.destroy()
                self.overlay_status_window = None
                self._debounced_save()
                print("[System] Live Stats Closed")
                return

            print("[System] Live Stats Opening...")
            self.overlay_status_window = tk.Toplevel(self.root)
            self.overlay_status_window.title("Live Stats")
            safe_geo = self._clamp_geo(getattr(self, 'saved_status_geo', "250x100+100+100"))
            self.overlay_status_window.geometry(safe_geo if safe_geo else "250x100+100+100")
            self.overlay_status_window.configure(bg="#111111")
            self.overlay_status_window.attributes("-topmost", True)
            self.overlay_status_window.overrideredirect(True)
            self.overlay_status_window._is_ghost = False
            try: self.overlay_status_window.attributes("-alpha", getattr(self, 'overlay_opacity', 0.85))
            except: pass

            def start_move(event):
                self.overlay_status_window._drag_data = {'x': event.x, 'y': event.y}
            def stop_move(event):
                self.overlay_status_window._drag_data = None
                if getattr(self, 'overlay_status_window', None) and hasattr(self.overlay_status_window, 'winfo_exists') and self.overlay_status_window.winfo_exists():
                    self.saved_status_geo = self.overlay_status_window.geometry()
                    self._debounced_save()
            def do_move(event):
                if getattr(self.overlay_status_window, '_drag_data', None):
                    x = self.overlay_status_window.winfo_x() - self.overlay_status_window._drag_data['x'] + event.x
                    y = self.overlay_status_window.winfo_y() - self.overlay_status_window._drag_data['y'] + event.y
                    self.overlay_status_window.geometry(f"+{x}+{y}")
            
            content = tk.Frame(self.overlay_status_window, bg="#111111")
            content.pack(fill="both", expand=True, pady=0)
            
            content.columnconfigure(0, weight=1)
            content.columnconfigure(1, weight=1)
            content.columnconfigure(2, weight=1)
            content.rowconfigure(0, weight=1)
            
            f_view = tk.Frame(content, bg="#1a0000")
            f_view.grid(row=0, column=0, sticky="nsew", padx=1)
            l1 = tk.Label(f_view, text="VIEWERS", font=("Segoe UI", 9, "bold"), fg="#FF4444", bg="#1a0000")
            l1.pack(pady=(5,0))
            
            v_val = getattr(self.model, 'current_viewer_count', 0)
            l_val = getattr(self.model, 'current_like_count', 0)
            s_val = getattr(self.model, 'last_sub_count', -1)
            
            self.lbl_hk_viewers = tk.Label(f_view, text="--" if int(v_val) <= -1 else str(v_val), font=("Segoe UI", 24, "bold"), fg="white", bg="#1a0000")
            self.lbl_hk_viewers.pack(expand=True)

            f_likes = tk.Frame(content, bg="#000033")
            f_likes.grid(row=0, column=1, sticky="nsew", padx=1)
            l2 = tk.Label(f_likes, text="LIKES", font=("Segoe UI", 9, "bold"), fg="#0080FF", bg="#000033")
            l2.pack(pady=(5,0))
            self.lbl_hk_likes = tk.Label(f_likes, text="--" if int(l_val) <= -1 else str(l_val), font=("Segoe UI", 24, "bold"), fg="white", bg="#000033")
            self.lbl_hk_likes.pack(expand=True)
            
            f_sub = tk.Frame(content, bg="#1a1a00")
            f_sub.grid(row=0, column=2, sticky="nsew", padx=1)
            l3 = tk.Label(f_sub, text="SUBS", font=("Segoe UI", 9, "bold"), fg="#FFD700", bg="#1a1a00")
            l3.pack(pady=(5,0))
            self.lbl_hk_subs = tk.Label(f_sub, text="--" if int(s_val) <= -1 else str(s_val), font=("Segoe UI", 24, "bold"), fg="white", bg="#1a1a00")
            self.lbl_hk_subs.pack(expand=True)

            # Bind drag to all elements inside
            for widget in [content, f_view, l1, self.lbl_hk_viewers, f_likes, l2, self.lbl_hk_likes, f_sub, l3, self.lbl_hk_subs]:
                widget.bind("<ButtonPress-1>", start_move)
                widget.bind("<ButtonRelease-1>", stop_move)
                widget.bind("<B1-Motion>", do_move)

            # Add resize grip
            grip = tk.Frame(self.overlay_status_window, bg="#111111", cursor="bottom_right_corner")
            grip.place(relx=1.0, rely=1.0, anchor="se", width=15, height=15)
            tk.Frame(grip, bg="#555", width=4, height=4).place(x=8, y=8)
            tk.Frame(grip, bg="#555", width=4, height=4).place(x=4, y=8)
            tk.Frame(grip, bg="#555", width=4, height=4).place(x=8, y=4)
            
            def start_resize(event):
                self.overlay_status_window._resize_start_x = event.x_root
                self.overlay_status_window._resize_start_y = event.y_root
                self.overlay_status_window._resize_start_w = self.overlay_status_window.winfo_width()
                self.overlay_status_window._resize_start_h = self.overlay_status_window.winfo_height()

            def do_resize(event):
                dx = event.x_root - self.overlay_status_window._resize_start_x
                dy = event.y_root - self.overlay_status_window._resize_start_y
                new_w = max(150, self.overlay_status_window._resize_start_w + dx)
                new_h = max(60, self.overlay_status_window._resize_start_h + dy)
                self.overlay_status_window.geometry(f"{new_w}x{new_h}")
                
            grip.bind("<ButtonPress-1>", start_resize)
            grip.bind("<B1-Motion>", do_resize)
            grip.bind("<ButtonRelease-1>", lambda e: self._debounced_save())

            print("[System] Live Stats Opened")
        except Exception as e: print(f"[Stats Overlay Error] {e}")

    def trigger_hotkey_open_list(self):
        try:
            if getattr(self.view, 'selector_window', None) and hasattr(self.view.selector_window, 'winfo_exists') and self.view.selector_window.winfo_exists():
                self.view.saved_selector_geo = self.view.selector_window.geometry()
                self.view.selector_window.destroy()
                self.view.selector_window = None
                self._debounced_save()
                print("[System] Chat List Closed")
            else:
                if hasattr(self.view, 'open_chat_selector'):
                    self.view.open_chat_selector()
                elif hasattr(self.view, 'toggle_chat_selector'):
                    try: self.view.toggle_chat_selector(None)
                    except: self.view.toggle_chat_selector()
                
                if getattr(self.view, 'selector_window', None) and hasattr(self.view.selector_window, 'winfo_exists') and self.view.selector_window.winfo_exists():
                    safe_geo = self._clamp_geo(getattr(self.view, 'saved_selector_geo', ""))
                    if safe_geo: self.view.selector_window.geometry(safe_geo)
                    try: self.view.selector_window.attributes("-alpha", getattr(self, 'overlay_opacity', 0.85))
                    except: pass
                print("[System] Chat List Opened")
        except Exception as e: print(f"[Chat List Error] {e}")

    def trigger_hotkey_guide(self):
        try:
            if getattr(self, 'overlay_guide_window', None) and hasattr(self.overlay_guide_window, 'winfo_exists') and self.overlay_guide_window.winfo_exists():
                self.guide_geo_cache = self.overlay_guide_window.geometry()
                self.overlay_guide_window.destroy()
                self.overlay_guide_window = None
                self._debounced_save()
                print("[System] Hotkey Guide Closed")
                return

            print("[System] Hotkey Guide Opening...")
            self.overlay_guide_window = tk.Toplevel(self.root)
            self.overlay_guide_window.title("Hotkey Guide")
            
            safe_geo = self._clamp_geo(getattr(self, 'guide_geo_cache', "380x600+150+150"))
            self.overlay_guide_window.geometry(safe_geo if safe_geo else "380x600+150+150")
            
            BG_COLOR, FG_COLOR, SECTION_FG, LINE_COLOR, PILL_BG, PILL_FG = "#0C4B8E", "#FFFFFF", "#FFFFFF", "#2A70B6", "#FFFFFF", "#0C4B8E"
            self.overlay_guide_window.configure(bg=BG_COLOR)
            self.overlay_guide_window.overrideredirect(True)
            self.overlay_guide_window.attributes("-topmost", True)
            try: self.overlay_guide_window.attributes("-alpha", self.overlay_opacity)
            except: pass
            self.overlay_guide_window._is_ghost = False

            header = tk.Frame(self.overlay_guide_window, bg=BG_COLOR, height=40, cursor="fleur")
            header.pack(fill="x", side="top")
            header.pack_propagate(False)

            tk.Label(header, text="Keyboard Shortcuts", bg=BG_COLOR, fg=FG_COLOR, font=("Segoe UI", 13, "bold")).pack(side="left", padx=15, pady=5)
            tk.Button(header, text="✕", bg=BG_COLOR, fg=FG_COLOR, activebackground="red", activeforeground="white", bd=0, font=("Arial", 11, "bold"), command=self.trigger_hotkey_guide).pack(side="right", padx=10, pady=5)

            def start_drag(e): self.overlay_guide_window._drag_data = {'x': e.x, 'y': e.y}
            def stop_drag(e): 
                self.overlay_guide_window._drag_data = None
                if getattr(self, 'overlay_guide_window', None) and hasattr(self.overlay_guide_window, 'winfo_exists') and self.overlay_guide_window.winfo_exists():
                    self.guide_geo_cache = self.overlay_guide_window.geometry()
            def do_drag(e):
                if getattr(self.overlay_guide_window, '_drag_data', None):
                    x = self.overlay_guide_window.winfo_x() - self.overlay_guide_window._drag_data['x'] + e.x
                    y = self.overlay_guide_window.winfo_y() - self.overlay_guide_window._drag_data['y'] + e.y
                    self.overlay_guide_window.geometry(f"+{x}+{y}")
                    
            header.bind("<ButtonPress-1>", start_drag)
            header.bind("<ButtonRelease-1>", stop_drag)
            header.bind("<B1-Motion>", do_drag)

            self.hk_guide_container = tk.Frame(self.overlay_guide_window, bg=BG_COLOR)
            self.hk_guide_container.pack(fill="both", expand=True, padx=5, pady=5)

            sections_data = [
                ("Chat Reactions", [("Idle Chat", self.hk_idle), ("Thanks / Greet", self.hk_thanks), ("Game Question", self.hk_question), ("Ask for Help", self.hk_help), ("Death / Rage", self.hk_death), ("Thanks for Likes", self.hk_likes_thanks), ("BRB / AFK", self.hk_brb), ("Tech Issue", self.hk_tech_issue), ("Talk Trends", self.hk_talk_viewers), ("Attack Callout", self.hk_attack)]),
                ("Hype & Moments", [("Puzzle Solved", self.hk_puzzle), ("Boss Defeated", self.hk_boss_win), ("Feeling Good", self.hk_feeling_good), ("Feeling Bad", self.hk_feeling_bad), ("Clip That!", self.hk_clip_that), ("Panic/Scream", self.hk_panic), ("Shoutout Users", self.hk_shoutout_users)]),
                ("Media & YouTube", [("YT Play/Pause", self.hk_yt_play_pause), ("YT Next Video", self.hk_yt_next), ("YT Forward 10s", self.hk_yt_forward), ("YT Ghost Mode", self.hk_yt_ghost), ("MP3 Play/Pause", self.hk_mp3_play_pause), ("MP3 Next Track", self.hk_mp3_next)]),
                ("System Overrides", [("Reply Last Chat", self.hk_reply_last), ("Live Context", self.hk_live_context), ("Suspend Hotkeys", self.hk_suspend_hotkeys), ("Stop Audio", self.hk_stop_audio), ("Toggle AI Mute", self.hk_toggle_ai_mute), ("Toggle Stats Ghost", self.hk_stats_ghost), ("Toggle Guide Ghost", self.hk_guide_ghost), ("Toggle Strict", self.hk_strict_mode), ("Hide Overlays", self.hk_hide_overlays)])
            ]
            
            custom_hks = []
            for i in range(1, 16):
                hk = getattr(self, f"hk_custom_{i}", "")
                if hk:
                    prmpt = getattr(self, f"hk_custom_{i}_prompt", "")
                    cust = getattr(self, f"hk_custom_{i}_custom", "")
                    lbl = (cust if cust else (prmpt if prmpt else f"Custom Slot {i}"))[:22] + "..." if len(cust or prmpt) > 25 else (cust or prmpt or f"Custom Slot {i}")
                    custom_hks.append((lbl, hk))
            if custom_hks: sections_data.append(("Custom Hotkeys", custom_hks))

            self.guide_section_frames = []
            for title, hks in sections_data:
                sec_f = tk.Frame(self.hk_guide_container, bg=BG_COLOR)
                tk.Label(sec_f, text=title, bg=BG_COLOR, fg=SECTION_FG, font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(0, 5))
                for desc, key in hks:
                    if not key: continue
                    row = tk.Frame(sec_f, bg=BG_COLOR)
                    row.pack(fill="x", pady=2)
                    tk.Frame(sec_f, bg=LINE_COLOR, height=1).pack(fill="x", pady=(0, 2))
                    tk.Label(row, text=desc, bg=BG_COLOR, fg=FG_COLOR, font=("Segoe UI", 9)).pack(side="left", padx=2)
                    tk.Label(row, text=str(key).upper().replace("+", " + "), bg=PILL_BG, fg=PILL_FG, font=("Consolas", 8, "bold"), padx=6, pady=2, relief="flat").pack(side="right", padx=2)
                self.guide_section_frames.append(sec_f)

            def reflow(event=None):
                if not getattr(self, 'overlay_guide_window', None) or not hasattr(self.overlay_guide_window, 'winfo_exists') or not self.overlay_guide_window.winfo_exists(): return
                usable_w = self.overlay_guide_window.winfo_width() - 20
                col_width, cols = 320, max(1, usable_w // 320)
                cols = min(cols, len(self.guide_section_frames)) if cols > 0 else 1
                col_heights, actual_col_width = [0] * cols, usable_w // cols
                
                scroll_y = getattr(self.overlay_guide_window, '_scroll_y', 0)
                
                for sec in self.guide_section_frames:
                    min_col = col_heights.index(min(col_heights))
                    sec.place(x=10 + min_col * actual_col_width, y=col_heights[min_col] + scroll_y, width=actual_col_width - 15)
                    sec.update_idletasks() 
                    col_heights[min_col] += sec.winfo_reqheight() + 20 

            def debounce_reflow(e):
                if e.widget == getattr(self, 'overlay_guide_window', None):
                    if hasattr(self, '_reflow_timer') and self._reflow_timer: self.root.after_cancel(self._reflow_timer)
                    self._reflow_timer = self.root.after(30, reflow)

            self.overlay_guide_window.bind("<Configure>", debounce_reflow)
            
            self.overlay_guide_window._scroll_y = 0
            def _on_mousewheel(event):
                if not getattr(self, 'overlay_guide_window', None) or not hasattr(self.overlay_guide_window, 'winfo_exists') or not self.overlay_guide_window.winfo_exists(): return
                delta = int(event.delta / 120) * 35 
                self.overlay_guide_window._scroll_y = min(0, getattr(self.overlay_guide_window, '_scroll_y', 0) + delta)
                reflow()
            self.overlay_guide_window.bind("<MouseWheel>", _on_mousewheel)

            grip = tk.Frame(self.overlay_guide_window, bg=BG_COLOR, width=25, height=25)
            grip.place(relx=1.0, rely=1.0, anchor="se")
            tk.Frame(grip, bg=FG_COLOR, width=12, height=2).place(x=8, y=18)
            tk.Frame(grip, bg=FG_COLOR, width=18, height=2).place(x=2, y=22)
            
            def resize_drag(e):
                x = self.overlay_guide_window.winfo_pointerx() - self.overlay_guide_window.winfo_rootx()
                y = self.overlay_guide_window.winfo_pointery() - self.overlay_guide_window.winfo_rooty()
                self.overlay_guide_window.geometry(f"{max(330, x)}x{max(200, y)}")
                
            grip.bind("<B1-Motion>", resize_drag)
            grip.bind("<ButtonRelease-1>", lambda e: self._debounced_save())
            self.root.after(100, reflow)
            print("[System] Hotkey Guide Opened")
        except Exception as e: print(f"[Guide Overlay Error] {e}")

    def trigger_hide_overlays(self):
        try:
            self._overlays_hidden = not getattr(self, '_overlays_hidden', False)
            windows_to_toggle = []
            if getattr(self, 'overlay_guide_window', None) and hasattr(self.overlay_guide_window, 'winfo_exists') and self.overlay_guide_window.winfo_exists(): windows_to_toggle.append(self.overlay_guide_window)
            if getattr(self, 'overlay_status_window', None) and hasattr(self.overlay_status_window, 'winfo_exists') and self.overlay_status_window.winfo_exists(): windows_to_toggle.append(self.overlay_status_window)
            if getattr(self, 'sys_status_window', None) and hasattr(self.sys_status_window, 'winfo_exists') and self.sys_status_window.winfo_exists(): windows_to_toggle.append(self.sys_status_window)
            if getattr(self.view, 'selector_window', None) and hasattr(self.view.selector_window, 'winfo_exists') and self.view.selector_window.winfo_exists(): windows_to_toggle.append(self.view.selector_window)
            if getattr(self, 'overlay_music_window', None) and hasattr(self.overlay_music_window, 'winfo_exists') and self.overlay_music_window.winfo_exists(): windows_to_toggle.append(self.overlay_music_window)
            if getattr(self.view, 'music_window', None) and hasattr(self.view.music_window, 'winfo_exists') and self.view.music_window.winfo_exists(): windows_to_toggle.append(self.view.music_window)

            for w in windows_to_toggle:
                if self._overlays_hidden: w.withdraw()
                else: w.deiconify()
                    
            if self.yt_cmd_queue: self.yt_cmd_queue.put('hide' if self._overlays_hidden else 'show')
            print(f"[System] 👁️ All Overlays are now {'HIDDEN' if self._overlays_hidden else 'VISIBLE'}.")
        except Exception as e: print(f"[Hide Overlays Error] {e}")
    
    def trigger_hotkey_stats_ghost(self):
        if not getattr(self, 'overlay_status_window', None) or not hasattr(self.overlay_status_window, 'winfo_exists') or not self.overlay_status_window.winfo_exists(): return
        try:
            import ctypes, sys
            hwnd = self.overlay_status_window.winfo_id()
            user32 = ctypes.windll.user32
            LWA_ALPHA, WS_EX_LAYERED, GWL_EXSTYLE, WS_EX_TRANSPARENT = 0x00000002, 0x00080000, -20, 0x00000020

            try:
                gwl = user32.GetWindowLongPtrW
                swl = user32.SetWindowLongPtrW
            except AttributeError:
                gwl = user32.GetWindowLongW
                swl = user32.SetWindowLongW
                
            gwl.argtypes, swl.argtypes = [ctypes.c_void_p, ctypes.c_int], [ctypes.c_void_p, ctypes.c_int, ctypes.c_size_t]
            gwl.restype, swl.restype = ctypes.c_size_t, ctypes.c_size_t
                
            hwnd_root = user32.GetAncestor(hwnd, 2)
            style = gwl(ctypes.c_void_p(hwnd_root), GWL_EXSTYLE)
            if style is None: return
            
            is_ghost = getattr(self.overlay_status_window, '_is_ghost', False)

            if is_ghost:
                new_style = style & ~WS_EX_TRANSPARENT
                swl(ctypes.c_void_p(hwnd_root), GWL_EXSTYLE, new_style)
                user32.SetLayeredWindowAttributes(hwnd_root, 0, 255, LWA_ALPHA)
                self.overlay_status_window._is_ghost = False
                self.overlay_status_window.attributes("-topmost", True)
                print("[System] Live Stats Ghost Mode OFF")
            else:
                new_style = style | WS_EX_TRANSPARENT | WS_EX_LAYERED
                swl(ctypes.c_void_p(hwnd_root), GWL_EXSTYLE, new_style)
                opacity_byte = int(getattr(self, 'overlay_opacity', 0.7) * 255)
                user32.SetLayeredWindowAttributes(hwnd_root, 0, opacity_byte, LWA_ALPHA)
                self.overlay_status_window._is_ghost = True
                self.overlay_status_window.attributes("-topmost", True)
                print("[System] Live Stats Ghost Mode ON")
        except Exception as e: print(f"[Ghost Mode Error] {e}")

    def trigger_hotkey_guide_ghost(self):
        try:
            import ctypes, sys
            user32 = ctypes.windll.user32
            LWA_ALPHA, WS_EX_LAYERED, GWL_EXSTYLE, WS_EX_TRANSPARENT = 0x00000002, 0x00080000, -20, 0x00000020

            try:
                gwl = user32.GetWindowLongPtrW
                swl = user32.SetWindowLongPtrW
            except AttributeError:
                gwl = user32.GetWindowLongW
                swl = user32.SetWindowLongW
                
            gwl.argtypes, swl.argtypes = [ctypes.c_void_p, ctypes.c_int], [ctypes.c_void_p, ctypes.c_int, ctypes.c_size_t]
            gwl.restype, swl.restype = ctypes.c_size_t, ctypes.c_size_t
            
            opacity_byte = int(getattr(self, 'overlay_opacity', 0.7) * 255)

            if getattr(self, 'overlay_guide_window', None) and hasattr(self.overlay_guide_window, 'winfo_exists') and self.overlay_guide_window.winfo_exists():
                hwnd_guide = self.overlay_guide_window.winfo_id()
                hwnd_root_guide = user32.GetAncestor(hwnd_guide, 2)
                style_guide = gwl(ctypes.c_void_p(hwnd_root_guide), GWL_EXSTYLE)
                if style_guide is not None:
                    if getattr(self.overlay_guide_window, '_is_ghost', False):
                        swl(ctypes.c_void_p(hwnd_root_guide), GWL_EXSTYLE, style_guide & ~WS_EX_TRANSPARENT)
                        user32.SetLayeredWindowAttributes(hwnd_root_guide, 0, 255, LWA_ALPHA)
                        self.overlay_guide_window._is_ghost = False
                        self.overlay_guide_window.attributes("-topmost", True)
                    else:
                        swl(ctypes.c_void_p(hwnd_root_guide), GWL_EXSTYLE, style_guide | WS_EX_TRANSPARENT | WS_EX_LAYERED)
                        user32.SetLayeredWindowAttributes(hwnd_root_guide, 0, opacity_byte, LWA_ALPHA)
                        self.overlay_guide_window._is_ghost = True
                        self.overlay_guide_window.attributes("-topmost", True)
                        
            print("[System] Ghost Mode Toggled for Guide")
        except Exception as e: print(f"[Ghost Mode Error] {e}")

    def trigger_hotkey_open_hotkeys(self): 
        try:
            try: getattr(self.view, 'open_hotkeys_window')()
            except TypeError: getattr(self.view, 'open_hotkeys_window')(None)
        except Exception as e: print(f"[Hotkey Window Error] {e}")

    def trigger_hotkey_strict_mode(self): self.toggle_strict_mode()
    
    def trigger_hotkey_play_overlay(self): 
        self.launch_youtube_player()
    
    def trigger_hotkey_music_window(self): 
        try:
            if getattr(self, 'overlay_music_window', None) and hasattr(self.overlay_music_window, 'winfo_exists') and self.overlay_music_window.winfo_exists():
                self.music_geo_cache = self.overlay_music_window.geometry()
                self.overlay_music_window.destroy()
                self.overlay_music_window = None
                
                threading.Thread(target=self.stop_music_playback, daemon=True).start()
                self._debounced_save()
                print("[System] MP3 Player closed instantly and audio stopped.")
                return

            print("[System] MP3 Player Opening...")
            self.overlay_music_window = tk.Toplevel(self.root)
            self.overlay_music_window.title("StreamerBot Music")
            safe_geo = self._clamp_geo(getattr(self, 'music_geo_cache', "300x120+100+100"))
            self.overlay_music_window.geometry(safe_geo if safe_geo else "300x120+100+100")
            self.overlay_music_window.configure(bg="#000022")
            self.overlay_music_window.attributes("-topmost", True)
            self.overlay_music_window.overrideredirect(True)
            try: self.overlay_music_window.attributes("-alpha", getattr(self, 'overlay_opacity', 0.85))
            except: pass

            def start_move(event):
                self.overlay_music_window._drag_data = {'x': event.x, 'y': event.y}
            def stop_move(event):
                self.overlay_music_window._drag_data = None
                self.music_geo_cache = self.overlay_music_window.geometry()
                self._debounced_save()
            def do_move(event):
                if getattr(self.overlay_music_window, '_drag_data', None):
                    x = self.overlay_music_window.winfo_x() - self.overlay_music_window._drag_data['x'] + event.x
                    y = self.overlay_music_window.winfo_y() - self.overlay_music_window._drag_data['y'] + event.y
                    self.overlay_music_window.geometry(f"+{x}+{y}")

            main_f = tk.Frame(self.overlay_music_window, bg="#000022", highlightbackground="cyan", highlightthickness=1)
            main_f.pack(fill="both", expand=True)
            
            main_f.bind("<ButtonPress-1>", start_move)
            main_f.bind("<ButtonRelease-1>", stop_move)
            main_f.bind("<B1-Motion>", do_move)
            
            self.overlay_music_lbl_song = tk.Label(main_f, text="No Song Loaded", font=("Segoe UI", 9, "bold"), fg="cyan", bg="#000022")
            self.overlay_music_lbl_song.pack(pady=(5,0))
            self.overlay_music_lbl_song.bind("<ButtonPress-1>", start_move)
            self.overlay_music_lbl_song.bind("<ButtonRelease-1>", stop_move)
            self.overlay_music_lbl_song.bind("<B1-Motion>", do_move)
            
            ctrl_f = tk.Frame(main_f, bg="#000022")
            ctrl_f.pack(pady=5)
            
            def mk_btn(parent, txt, cmd, col):
                b = tk.Button(parent, text=txt, bg=col, fg="white", font=("Arial", 8, "bold"), borderwidth=0, width=4, command=cmd)
                b.pack(side="left", padx=2)
                return b

            mk_btn(ctrl_f, "📂", self.music_load_folder, "#444")
            mk_btn(ctrl_f, "⏮", self.music_prev, "#555")
            mk_btn(ctrl_f, "⏯", self.music_toggle_pause, "#008000")
            mk_btn(ctrl_f, "⏭", self.music_next, "#555")
            
            rep_mode = getattr(self.model, 'music_repeat_mode', 'none')
            txt = {"none": "🔁 Off", "one": "🔂 1", "all": "🔁 All"}.get(rep_mode, "🔁 Off")
            self.overlay_music_btn_repeat = tk.Button(ctrl_f, text=txt, bg="#444", fg="yellow", font=("Arial", 7, "bold"), borderwidth=0, width=6, command=self.music_toggle_repeat)
            self.overlay_music_btn_repeat.pack(side="left", padx=5)
            
            vol_f = tk.Frame(main_f, bg="#000022")
            vol_f.pack(fill="x", padx=10, pady=2)
            
            tk.Label(vol_f, text="Vol", fg="gray", bg="#000022", font=("Arial", 7)).pack(side="left")
            self.overlay_music_vol_scale = ttk.Scale(vol_f, from_=0.0, to=1.0, value=getattr(self.model, 'music_vol', 0.5), orient='horizontal', command=self.music_set_vol)
            self.overlay_music_vol_scale.pack(side="left", fill="x", expand=True, padx=5)
            
            if hasattr(self.model, 'music_playlist') and self.model.music_playlist:
                idx = getattr(self.model, 'music_index', 0)
                if idx < len(self.model.music_playlist):
                    song_name = os.path.basename(self.model.music_playlist[idx])
                    self.overlay_music_lbl_song.config(text=f"Playing: {song_name[:20]}")

        except Exception as e: print(f"[Music Window Error] {e}")
            
    def trigger_hotkey_toggle_ai_mute(self): self.toggle_global_ai_mute()

    # --- MEDIA TRIGGERS ---
    def trigger_yt_play_pause(self): 
        if self.yt_cmd_queue: self.yt_cmd_queue.put('play_pause')
    def trigger_yt_next(self): 
        if self.yt_cmd_queue: self.yt_cmd_queue.put('next')
    def trigger_yt_prev(self): 
        if self.yt_cmd_queue: self.yt_cmd_queue.put('prev')
    def trigger_yt_forward(self): 
        if self.yt_cmd_queue: self.yt_cmd_queue.put('forward')
    def trigger_yt_rewind(self): 
        if self.yt_cmd_queue: self.yt_cmd_queue.put('rewind')
    def trigger_yt_ghost(self): 
        if self.yt_cmd_queue: self.yt_cmd_queue.put('toggle_ghost')
        
    def trigger_mp3_play_pause(self): self.music_toggle_pause()
    def trigger_mp3_next(self): self.music_next()
    def trigger_mp3_prev(self): self.music_prev()
    def trigger_mp3_forward(self): 
        try:
            import pygame
            if pygame.mixer.get_init() and pygame.mixer.music.get_busy():
                pos = pygame.mixer.music.get_pos() / 1000.0
                pygame.mixer.music.set_pos(pos + 10)
        except: pass
        
    def trigger_mp3_rewind(self): 
        try:
            import pygame
            if pygame.mixer.get_init() and pygame.mixer.music.get_busy():
                pos = pygame.mixer.music.get_pos() / 1000.0
                new_pos = max(0, pos - 10)
                pygame.mixer.music.set_pos(new_pos)
        except: pass

    # --- SAMBANOVA API HANDLERS ---
    def test_and_save_sambanova_keys(self, keys, popup):
        """Validates SambaNova keys and saves them to the model."""
        if not keys: return messagebox.showerror("Error", "No keys provided!")
        print("[System] Validating SambaNova Keys...")
        valid_keys = []
        def _test():
            import requests
            for k in keys:
                try:
                    # SambaNova uses OpenAI-compatible headers
                    headers = {"Authorization": f"Bearer {k}"}
                    resp = requests.get("https://api.sambanova.ai/v1/models", headers=headers, timeout=10)
                    if resp.status_code == 200:
                        valid_keys.append(k)
                        print(f" -> Key ...{k[-4:]} Valid.")
                except Exception as e: print(f" -> Key ...{k[-4:]} Invalid: {e}")
            
            self.model.sambanova_api_keys = valid_keys
            self.root.after(0, lambda: self._finish_sambanova_save(valid_keys, popup))
        threading.Thread(target=_test, daemon=True).start()

    def _finish_sambanova_save(self, valid_keys, popup):
        if not valid_keys: messagebox.showerror("Error", "All keys failed validation.")
        else:
            self.set_ai_mode("sambanova")
            self.save_config()
            messagebox.showinfo("Success", f"Saved {len(valid_keys)} SambaNova keys!")
            popup.destroy()

    # --- BARK AI TTS ENGINE ---
    def play_bark_tts_audio(self, text, voice_preset):
        """Generates and plays TTS using Bark AI based on user toggles."""
        import os
        import sounddevice as sd
        import numpy as np
        
        # 1. Read the toggles you just added back to the UI
        try:
            import time
            import os
            
            print(f"[TTS] Generating Bark audio for: '{text[:30]}...' (Voice: {voice_preset})")
            
            # Generate the raw audio array (shared fast path, honours the Bark menu toggles)
            audio_array, SAMPLE_RATE = _bark_native_generate(self.model, text, voice_preset)
            if audio_array is None: raise RuntimeError("Bark returned no audio")
            
            # --- THE LIVEPORTRAIT INTEGRATION ---
            print("[LivePortrait] Handing audio to avatar animation engine...")
            
            output_dir = "outputs"
            os.makedirs(output_dir, exist_ok=True)
            bark_wav_path = os.path.join(output_dir, f"bark_temp_{int(time.time())}.wav")
            _write_wav_int16(bark_wav_path, audio_array, SAMPLE_RATE)
            
            avatar_path = "avatar.png"
            if not os.path.exists(avatar_path):
                print(f"[LivePortrait Error] Could not find '{avatar_path}' in the bot's folder! Playing audio only.")
                import sounddevice as sd
                sd.play(audio_array, SAMPLE_RATE)
                sd.wait()
            else:
                # Fire up the LivePortrait Engine safely!
                try:
                    from liveportrait_bridge import LivePortraitEngine
                    animator = LivePortraitEngine()
                    
                    # This will use your 4070 Ti to generate the .mp4 video
                    video_path = animator.generate_talking_head(bark_wav_path, avatar_path)
                    
                    if video_path:
                        print(f"[System] 🎬 Video Ready: {video_path}")
                        print("[System] Popping open the video player...")
                        # 🎬 THE FIX: Actually play the MP4 video instead of just raw audio!
                        # This opens the video in your default Windows Media Player automatically.
                        os.startfile(video_path)
                        
                        # We wait a few seconds so it doesn't instantly close or overlap
                        time.sleep(5) 
                    else:
                        print("[System] Video generation failed. Falling back to audio only.")
                        import sounddevice as sd
                        sd.play(audio_array, SAMPLE_RATE)
                        sd.wait()
                        
                except Exception as lp_err:
                    print(f"[LivePortrait System Error] {lp_err}")
                    import sounddevice as sd
                    sd.play(audio_array, SAMPLE_RATE)
                    sd.wait()
            
            print("[TTS] Bark generation and playback complete.")
            
        except ImportError:
            print("[TTS Error] Bark is not installed! Run: pip install git+https://github.com/suno-ai/bark.git")
        except Exception as e:
            print(f"[Bark TTS Error] Failed to generate/play audio: {e}")

    # ==========================================
    # SMART HOTKEY & MASTER MODE ENGINES
    # ==========================================
    def apply_new_hotkey(self, attr_name, new_key, friendly_name, ui_button):
        """Safely assigns a new hotkey from the UI listener, checking for conflicts."""
        from tkinter import messagebox
        if not new_key:
            return
            
        clean_key = str(new_key).strip().lower()
        conflict_name = None
        
        # 1. Check for conflicts against all active hotkeys
        # FIX: only compare against real key assignments. Previously it also compared against *_mode ("V"), *_prompt,
        # *_audio ... so binding a plain "v" (or any text equal to a setting) reported a bogus conflict.
        _non_key_suffixes = ('_mode', '_short', '_custom', '_prompt', '_audio', '_audio_enabled', '_mute_ai')
        for key, val in self.__dict__.items():
            if key.startswith('hk_') and key != attr_name and not key.endswith(_non_key_suffixes) and isinstance(val, str):
                if val.strip().lower() == clean_key:
                    conflict_name = key
                    break
                    
        if conflict_name:
            if ui_button and hasattr(ui_button, 'winfo_exists') and ui_button.winfo_exists():
                messagebox.showerror(
                    "Hotkey Conflict", 
                    f"The hotkey '{clean_key.upper()}' is already assigned to ({conflict_name})!", 
                    parent=self.root
                )
                old_val = getattr(self, attr_name, "UNASSIGNED")
                ui_button.config(text=str(old_val).upper(), bg="#444", fg="white", state="normal")
            return
            
        # 2. No conflicts! Assign it and save
        setattr(self, attr_name, clean_key)
        
        # 🛡️ THE FIX: Uses the correct baseline save function
        if hasattr(self, 'save_config'):
            self.save_config()
            
        # 3. Safely Update the UI Button
        if ui_button and hasattr(ui_button, 'winfo_exists') and ui_button.winfo_exists():
            ui_button.config(text=clean_key.upper(), bg="#008000", fg="white", state="normal")
            
        print(f"[System] ⌨️ '{friendly_name}' successfully bound to: {clean_key.upper()}")
        
        if hasattr(self, 'toggle_hotkeys_logic'):
            self.root.after(100, self.toggle_hotkeys_logic)

    def apply_master_mode(self, mode):
        """Applies a specific output mode (V, T, V+T) to ALL hotkeys instantly."""
        if mode not in ["V", "T", "V+T"]: return
        
        count = 0
        target_hks = getattr(self, 'hk_bases', [
            "hk_idle", "hk_thanks", "hk_question", "hk_help", "hk_death", "hk_likes_thanks", "hk_brb", 
            "hk_tech_issue", "hk_game_request", "hk_taunt", "hk_intro", "hk_frustration", "hk_attack", 
            "hk_talk_viewers", "hk_shoutout_users", "hk_puzzle", "hk_boss_win", "hk_feeling_good", 
            "hk_feeling_bad", "hk_clip_that", "hk_panic", "hk_reply_last"
        ] + [f"hk_custom_{i}" for i in range(1, 16)])

        # Apply to backend memory
        for hk in target_hks:
            mode_attr = f"{hk}_mode"
            setattr(self, mode_attr, mode)
            count += 1
            
            # If the UI is open, visually update the dropdown menus
            if hasattr(self, 'view') and hasattr(self.view, 'hk_var_refs'):
                for var, var_name in self.view.hk_var_refs:
                    if var_name == mode_attr:
                        try: var.set(mode)
                        except: pass
        
        self._debounced_save()
        print(f"[System] Master Mode applied: ALL hotkeys set to {mode} ({count} updated)")
        
    def save_jina_keys(self, keys_str):
        """Saves Jina API keys safely so the Hotkey menu can close without crashing!"""
        if hasattr(self, 'model'):
            self.model.jina_api_keys = [k.strip() for k in keys_str.split(",") if k.strip()]
        
        self._debounced_save()
        print(f"[System] 🌐 Jina AI Search Keys saved! ({len(keys_str.split(',')) if keys_str else 0} keys)")

    def submit_review(self, action):
        """Strictly enforces Review Mode and explicitly routes the output mode."""
        try:
            if not hasattr(self.view, 'popup_text') or not self.view.popup_text.winfo_exists():
                return
                
            final_text = self.view.popup_text.get("1.0", "end-1c").strip()
            
            if not final_text and action != "reject":
                if hasattr(self.view, '_close_review_safe'): self.view._close_review_safe()
                return

            if action == "reject":
                print(f"[System] ❌ Review Decision Sent: REJECTED")
                self.model.review_decision_queue.put(("reject", ""))
            else:
                # 🛡️ THE BYPASS FIX: Free the auto-reply thread, then push to the manual queue!
                # This guarantees that the V / T / V+T flags are strictly obeyed.
                self.model.review_decision_queue.put(("reject", ""))
                
                force_v = False
                force_t = False
                
                if action == "approve_V":
                    force_v = True
                elif action == "approve_T":
                    force_t = True
                elif action == "approve_V+T":
                    # FIX: both False meant "use the global bot mode", so text was skipped whenever the bot was in voice-only mode
                    force_v = True
                    force_t = True
                    
                print(f"[System] ✅ Review Send -> Text Only: {force_t} | Voice Only: {force_v}")
                self.model.manual_reply_queue.put({
                    'message': final_text,
                    'force_voice_only': force_v,
                    'force_text_only': force_t,
                    'force_fresh': True
                })

            if hasattr(self.view, '_close_review_safe'): self.view._close_review_safe()
        except Exception as e:
            print(f"[Review UI Error] {e}")

    def send_selector_text(self):
        """Strictly enforces Chatlist text sending without crashing the UI."""
        try:
            if not hasattr(self.view, 'selector_text') or not self.view.selector_text.winfo_exists():
                return
                
            text = self.view.selector_text.get("1.0", "end-1c").strip()
            if not text: 
                return
                
            self.view.selector_text.delete("1.0", "end")
            
            # Check the UI checkbox safely
            voice_only = False
            if hasattr(self.view, 'chat_selector_voice_only_var'):
                voice_only = self.view.chat_selector_voice_only_var.get()
            
            force_v = bool(voice_only)
            force_t = not bool(voice_only)
            
            print(f"[System] 💬 Chatlist Manual Send -> Text Forced: {force_t} | Voice Forced: {force_v}")
            
            # Safely push directly to the queue
            self.model.manual_reply_queue.put({
                'message': text,
                'force_voice_only': force_v,
                'force_text_only': force_t,
                'force_fresh': True
            })
        except Exception as e:
            print(f"[Chatlist UI Error] {e}")

    def save_channel(self, new_channel):
        """Saves the YouTube channel name from the UI."""
        self.channel_name = new_channel
        if hasattr(self, 'model'):
            self.model.channel_name = new_channel
            
        if hasattr(self, 'save_config'):
            self.save_config()
            
        print(f"[System] 📺 Channel updated to: {new_channel}")

if __name__ == "__main__":
    StreamerBotController()