@echo off
setlocal
title StreamerBot - Original Desktop
pushd "%~dp0"
if errorlevel 1 goto folder_error
if not exist "Start-Portable.ps1" goto missing_files
if not exist "windows\Portable-Runtime.ps1" goto missing_files
if not exist "windows\Portable-Original.ps1" goto missing_files
if not exist "windows\portable-runtimes.json" goto missing_files
echo Starting the original desktop app with ALL original controls.
 echo Checking portable dependencies. No browser dashboard.
echo First launch downloads dependencies. Keep this window open.
set "StreamerBotPowerShell=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "StreamerBotPowerShell=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%StreamerBotPowerShell%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Portable.ps1"
if errorlevel 1 goto failure
popd
exit /b 0

:missing_files
echo Extract the UPDATED complete project ZIP first.
echo This launcher needs Start-Portable.ps1 and the windows folder beside it.
:failure
popd
echo.
pause
exit /b 1

:folder_error
echo Could not open the project folder. Extract the ZIP to a local drive.
pause
exit /b 1
