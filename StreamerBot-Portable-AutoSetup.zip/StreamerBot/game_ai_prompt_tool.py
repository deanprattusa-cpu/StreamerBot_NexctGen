# ==============================================================================
# GAME AI PROMPT TOOL
# Generates game-specific "AI Prompt" text for every hotkey slot, plus a
# "real human gamer" chat directive, whenever the Game title changes.
#
# * Uses FREE API tiers with ROTATING KEYS (Groq, Gemini, OpenRouter, SambaNova)
# * Pure `requests` - no extra SDK needed
# * Standalone: knows nothing about tkinter. The controller owns the UI.
# ==============================================================================

import json
import re
import threading
import time

import requests

# ------------------------------------------------------------------------------
# Hotkey slots that have an "AI Prompt" box in the UI, with what each one is FOR.
# (hk_live_context / system keys have no prompt box, so they are not listed.)
# ------------------------------------------------------------------------------
SLOT_PURPOSES = {
    "hk_idle":           "Idle message - chat is quiet, streamer fills the silence while playing.",
    "hk_thanks":         "Thank the viewers for watching / supporting the stream.",
    "hk_likes_thanks":   "Thank viewers for likes and shares on the stream.",
    "hk_question":       "Ask the viewers a question about this game (mechanics, builds, strategy, opinions).",
    "hk_game_request":   "Ask viewers which game they want to see next after this one.",
    "hk_death":          "React to dying / failing / losing in this game.",
    "hk_help":           "Streamer is stuck and asks viewers for tips or help.",
    "hk_brb":            "Streamer needs to step away for a minute (BRB / bathroom).",
    "hk_tech_issue":     "Lag, stutter, crash or other technical issue during the game.",
    "hk_puzzle":         "Just solved a puzzle / figured out a tricky objective in this game.",
    "hk_boss_win":       "Just beat a hard boss / tough opponent / difficult round.",
    "hk_feeling_good":   "Feeling great, on a hot streak, playing well.",
    "hk_feeling_bad":    "Feeling down, tilted or discouraged about how the session is going.",
    "hk_clip_that":      "Something amazing just happened - tell viewers to clip it.",
    "hk_panic":          "Panic / scream moment - sudden danger or a close call.",
    "hk_shoutout_users": "Shout out the active viewers in chat.",
    "hk_taunt":          "Playfully taunt the game / the opponents for being too easy or too hard.",
    "hk_intro":          "Stream intro - welcome everyone and say what game is being played.",
    "hk_frustration":    "Frustration at the game's difficulty or a repeated failure.",
    "hk_attack":         "Aggressive hype while attacking / going on the offensive.",
    "hk_talk_viewers":   "Chat casually with the viewers while playing.",
}

# The custom slots have no fixed purpose, so they get 15 distinct, reusable streamer moments.
CUSTOM_SLOT_THEMES = [
    "Celebrate a small win.",
    "Share a quick tip or fun fact about this game.",
    "Joke about how badly the run is going.",
    "Hype up the viewers for the next section.",
    "Admit to a mistake in a funny way.",
    "Ask viewers to follow / subscribe in a natural, non-pushy way.",
    "React to a surprise or plot twist.",
    "Compliment a viewer's suggestion.",
    "Say you are focusing hard and need a moment.",
    "Brag a little about a cool play.",
    "Talk about what you want to do next in the game.",
    "Rant about something annoying in this game.",
    "Nostalgic or wholesome comment about the game.",
    "Dramatic reaction to a close call.",
    "Wrap up / talk about wanting to end the stream soon.",
]
for _i, _theme in enumerate(CUSTOM_SLOT_THEMES, start=1):
    SLOT_PURPOSES[f"hk_custom_{_i}"] = f"Custom slot {_i}: {_theme}"

CUSTOM_SLOT_KEYS = [f"hk_custom_{i}" for i in range(1, 16)]

# Default free-tier models. The app's own configured model names are passed in
# as hints (see GamePromptTool.model_hints) and take priority over these.
DEFAULT_MODELS = {
    "groq": "llama-3.3-70b-versatile",
    "gemini": "gemini-2.0-flash",
    "openrouter": "meta-llama/llama-3.3-70b-instruct:free",
    "sambanova": "Meta-Llama-3.3-70B-Instruct",
}

ENDPOINTS = {
    "groq": "https://api.groq.com/openai/v1",
    "openrouter": "https://openrouter.ai/api/v1",
    "sambanova": "https://api.sambanova.ai/v1",
}

_UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)


def detect_provider(key):
    """Guess the provider from a bare key's prefix. Returns None when unsure."""
    k = key.strip()
    if k.startswith("gsk_"): return "groq"
    if k.startswith("AIza"): return "gemini"
    if k.startswith("sk-or-"): return "openrouter"
    if _UUID_RE.match(k): return "sambanova"
    return None


def parse_key_lines(text_or_list):
    """
    Accepts a multi-line string or list. Each line is either
        provider:key        (groq / gemini / openrouter / sambanova)
        key                 (provider is auto-detected from its prefix)
    Returns a list of (provider, key) tuples. Unknown lines are skipped.
    """
    if isinstance(text_or_list, str):
        lines = re.split(r"[\n,]+", text_or_list)
    else:
        lines = list(text_or_list or [])
    out, seen = [], set()
    for line in lines:
        line = str(line).strip()
        if not line or line.startswith("#"): continue
        provider, key = None, line
        if ":" in line:
            head, tail = line.split(":", 1)
            if head.strip().lower() in DEFAULT_MODELS:
                provider, key = head.strip().lower(), tail.strip()
        if provider is None:
            provider = detect_provider(key)
        if provider and key and (provider, key) not in seen:
            seen.add((provider, key))
            out.append((provider, key))
    return out


class GamePromptTool:
    """Rotating-key AI client + prompt pack builder."""

    def __init__(self, log=print):
        self.log = log
        self._lock = threading.Lock()
        self._rr_index = 0
        self._cooldown = {}          # (provider, key) -> unix time when usable again
        self.model_hints = {}        # provider -> model name from the main app
        self._resolved_model = {}    # provider -> model that actually worked

    # ------------------------------------------------------------------ keys
    def _next_entries(self, entries):
        """Yield entries in round-robin order, skipping the ones cooling down."""
        n = len(entries)
        if n == 0: return
        with self._lock:
            start = self._rr_index % n
            self._rr_index += 1
        now = time.time()
        order = [entries[(start + i) % n] for i in range(n)]
        ready = [e for e in order if self._cooldown.get(e, 0) <= now]
        # If everything is cooling down, still try them (cooldowns can be wrong)
        return ready or order

    def _penalize(self, entry, seconds):
        self._cooldown[entry] = time.time() + seconds

    @staticmethod
    def _mask(key):
        return key[:6] + "..." + key[-3:] if len(key) > 10 else "***"

    # ------------------------------------------------------------- providers
    def _model_for(self, provider):
        return (self._resolved_model.get(provider)
                or self.model_hints.get(provider)
                or DEFAULT_MODELS[provider])

    def _call_openai_style(self, provider, key, system, user, max_tokens, temperature):
        base = ENDPOINTS[provider]
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        if provider == "openrouter":
            headers["HTTP-Referer"] = "http://localhost"
            headers["X-Title"] = "StreamerBot"
        model = self._model_for(provider)
        payload = {
            "model": model,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        r = requests.post(f"{base}/chat/completions", headers=headers, json=payload, timeout=60)

        # Model name rejected -> ask the provider which models exist and pick one, then retry once.
        if r.status_code in (400, 404):
            alt = self._discover_model(provider, key)
            if alt and alt != model:
                self.log(f"[Game AI] {provider}: model '{model}' rejected, switching to '{alt}'")
                self._resolved_model[provider] = alt
                payload["model"] = alt
                r = requests.post(f"{base}/chat/completions", headers=headers, json=payload, timeout=60)
        return r.status_code, r.text, (self._extract_openai_text(r) if r.status_code == 200 else None)

    @staticmethod
    def _extract_openai_text(resp):
        try:
            return resp.json()["choices"][0]["message"]["content"] or ""
        except Exception:
            return ""

    def _discover_model(self, provider, key):
        """Pick a sensible chat model from the provider's /models list."""
        try:
            r = requests.get(f"{ENDPOINTS[provider]}/models",
                             headers={"Authorization": f"Bearer {key}"}, timeout=20)
            ids = [m.get("id", "") for m in r.json().get("data", [])]
        except Exception:
            return None
        if provider == "openrouter":
            ids = [i for i in ids if i.endswith(":free")]
        bad = ("whisper", "guard", "embed", "tts", "vision", "audio", "image", "moderation")
        ids = [i for i in ids if not any(b in i.lower() for b in bad)]
        for pref in ("llama-3.3-70b", "llama-3.1-70b", "gpt-oss", "llama-3", "qwen", "gemma", "mistral"):
            for i in ids:
                if pref in i.lower():
                    return i
        return ids[0] if ids else None

    def _call_gemini(self, key, system, user, max_tokens, temperature):
        model = self._model_for("gemini")
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        payload = {
            "systemInstruction": {"parts": [{"text": system}]},
            "contents": [{"role": "user", "parts": [{"text": user}]}],
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
                "responseMimeType": "application/json",
            },
        }
        r = requests.post(url, params={"key": key}, json=payload, timeout=60)
        if r.status_code in (400, 404):
            alt = self._discover_gemini_model(key)
            if alt and alt != model:
                self.log(f"[Game AI] gemini: model '{model}' rejected, switching to '{alt}'")
                self._resolved_model["gemini"] = alt
                url = f"https://generativelanguage.googleapis.com/v1beta/models/{alt}:generateContent"
                r = requests.post(url, params={"key": key}, json=payload, timeout=60)
        text = None
        if r.status_code == 200:
            try:
                parts = r.json()["candidates"][0]["content"]["parts"]
                text = "".join(p.get("text", "") for p in parts)
            except Exception:
                text = ""
        return r.status_code, r.text, text

    def _discover_gemini_model(self, key):
        try:
            r = requests.get("https://generativelanguage.googleapis.com/v1beta/models",
                             params={"key": key}, timeout=20)
            names = [m["name"].split("/")[-1] for m in r.json().get("models", [])
                     if "generateContent" in m.get("supportedGenerationMethods", [])]
        except Exception:
            return None
        names = [n for n in names if "flash" in n and not any(b in n for b in ("image", "tts", "live", "thinking", "lite", "exp"))]
        return sorted(names)[-1] if names else None

    # ------------------------------------------------------------- main call
    def complete(self, entries, system, user, max_tokens=3000, temperature=0.8):
        """Try each key in rotation until one returns text. Returns text or None."""
        if not entries:
            return None
        tried = 0
        for entry in self._next_entries(entries):
            provider, key = entry
            tried += 1
            try:
                if provider == "gemini":
                    code, body, text = self._call_gemini(key, system, user, max_tokens, temperature)
                else:
                    code, body, text = self._call_openai_style(provider, key, system, user, max_tokens, temperature)
            except Exception as e:
                self.log(f"[Game AI] {provider} key {self._mask(key)} network error: {e}")
                self._penalize(entry, 20)
                continue

            if code == 200 and text and text.strip():
                return text
            if code == 429:
                self.log(f"[Game AI] {provider} key {self._mask(key)} rate-limited -> rotating to next key")
                self._penalize(entry, 90)
            elif code in (401, 403):
                self.log(f"[Game AI] {provider} key {self._mask(key)} rejected ({code}) -> rotating")
                self._penalize(entry, 3600)
            else:
                self.log(f"[Game AI] {provider} key {self._mask(key)} failed ({code}): {body[:160]}")
                self._penalize(entry, 30)
        self.log(f"[Game AI] All {tried} key(s) failed.")
        return None

    # ------------------------------------------------------------ JSON utils
    @staticmethod
    def _parse_json(text):
        if not text: return None
        t = re.sub(r"<think>.*?(?:</think>|$)", "", text, flags=re.S | re.I).strip()
        t = re.sub(r"^```(?:json)?|```$", "", t.strip(), flags=re.M).strip()
        a, b = t.find("{"), t.rfind("}")
        if a == -1 or b == -1 or b <= a: return None
        try:
            return json.loads(t[a:b + 1])
        except Exception:
            pass
        # Salvage: pull out "key": "value" pairs one by one
        out = {}
        for m in re.finditer(r'"([a-z_0-9]+)"\s*:\s*"((?:[^"\\]|\\.)*)"', t[a:b + 1]):
            try: out[m.group(1)] = json.loads(f'"{m.group(2)}"')
            except Exception: out[m.group(1)] = m.group(2)
        return {"slots": out} if out else None

    @staticmethod
    def _clean_line(s, limit=220):
        s = str(s or "")
        s = re.sub(r"[\*\[\]\(\)\n\r]+", " ", s)       # the app strips these in speech anyway
        s = re.sub(r"\s+", " ", s).strip().strip('"').strip()
        return s[:limit]

    # ---------------------------------------------------------- prompt pack
    def generate_pack(self, entries, game, channel, slot_keys, word_limit=15):
        """
        Returns dict: {"slots": {hk_x: text}, "directive_context": str, "game_known": bool}
        or None if every key failed.
        """
        is_chat = game.strip().lower() in ("", "just chatting", "none")
        game_desc = "a 'Just Chatting' stream (no game, talking with viewers)" if is_chat else f'the video game "{game}"'

        slot_lines = "\n".join(f'- "{k}": {SLOT_PURPOSES[k]}' for k in slot_keys)
        system = (
            "You write prompts for a live-streaming bot that speaks as a REAL HUMAN GAMER. "
            "You output ONLY one valid JSON object. No markdown, no commentary."
        )
        user = f"""The streamer{f' ("{channel}")' if channel else ''} is now streaming {game_desc}.

For EACH slot below, write ONE short situation description (max 22 words) that tells the bot what the streamer
is doing/feeling right now in THIS game. The bot will wrap it as: "I am currently doing this on stream: '<your text>'.
What do I say on the microphone right now?" - so write it as the situation, NOT as dialogue, and NOT as a command to an AI.

RULES:
- Make every prompt clearly specific to this game's genre, mechanics, vocabulary and general feel
  (e.g. use generic-but-correct terms like 'the final boss', 'ranked match', 'base', 'run', 'lobby' when they fit).
- The bot CANNOT see the screen. Never invent specific live events, scores, enemy/character/location names or numbers.
  Only mention names that are universally known parts of this game (the title itself, core mechanics).
- If you do not recognise the game, keep prompts genre-neutral and set "game_known" to false.
- No asterisks, no brackets, no emojis, no stage directions. Plain words only.
- Every slot must read differently from the others. Stay human, casual, streamer-like.
- Reply language of the prompts: English.

Also write "directive_context": 1-2 short sentences (max 45 words) of GENERAL background about this game or stream type
(genre, what players usually talk about, typical viewer topics) that helps the streamer answer chat convincingly.
No live events, no claims about what is on screen right now.

SLOTS:
{slot_lines}

Return exactly this JSON shape:
{{"game_known": true, "directive_context": "...", "slots": {{{", ".join(f'"{k}": "..."' for k in slot_keys[:2])}, ...}}}}"""

        raw = self.complete(entries, system, user, max_tokens=3500)
        data = self._parse_json(raw)
        if not data: return None

        slots = data.get("slots") if isinstance(data.get("slots"), dict) else {
            k: v for k, v in data.items() if k in SLOT_PURPOSES}
        clean = {k: self._clean_line(slots[k]) for k in slot_keys if k in slots and str(slots[k]).strip()}

        # One retry for slots the model skipped
        missing = [k for k in slot_keys if k not in clean]
        if missing and clean:
            self.log(f"[Game AI] {len(missing)} slot(s) missing, asking again...")
            retry_user = user.replace(slot_lines, "\n".join(f'- "{k}": {SLOT_PURPOSES[k]}' for k in missing))
            retry = self._parse_json(self.complete(entries, system, retry_user, max_tokens=2500))
            if retry:
                rslots = retry.get("slots") if isinstance(retry.get("slots"), dict) else retry
                for k in missing:
                    if k in rslots and str(rslots[k]).strip():
                        clean[k] = self._clean_line(rslots[k])

        if not clean: return None
        return {
            "slots": clean,
            "directive_context": self._clean_line(data.get("directive_context", ""), 320),
            "game_known": bool(data.get("game_known", True)),
        }

    @staticmethod
    def build_chat_directive(game, context, word_limit=15):
        """The 'real human gamer' chat directive, in the same style as the one already in the app."""
        is_chat = game.strip().lower() in ("", "just chatting", "none")
        if is_chat:
            intro = ("You are a real human streamer doing a Just Chatting live stream, talking with your viewers "
                     "while sitting at your PC.")
        else:
            intro = (f"You are a real human gamer actively live-streaming {game} to your viewers. "
                     f"You are currently playing {game} on pc using keyboard and mouse and focused on the game.")
        ctx = f" Background you naturally know: {context}" if context else ""
        return (f"{intro}{ctx} Respond directly to the viewer's chat message naturally and casually. "
                f"CRITICAL RULES: 1. NO ROLEPLAY. Absolutely NEVER use asterisks (like *laughs*) or brackets to "
                f"describe physical actions. 2. NO NARRATION. Do not announce what your character is doing on screen. "
                f"3. NO AI SPEAK. Never sound like an assistant. 4. KEEP IT SHORT. Reply length {word_limit} (words). "
                f"5. Speak exactly like a normal streamer talking into a microphone. "
                f"6. Reply in chat casually, never invent scenes or events of what you are doing.")
