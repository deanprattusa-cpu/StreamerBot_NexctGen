@echo off
title VTuber Avatar Overlay
color 0b

echo ===================================================
echo [System] Launching Avatar Overlay...
echo ===================================================

python avatar_overlay.py

pause