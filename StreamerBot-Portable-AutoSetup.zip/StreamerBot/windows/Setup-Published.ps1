[CmdletBinding()]
param([string]$Python = "py", [string[]]$PythonArguments = @("-3.12"))
$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "Worker")
& $Python @PythonArguments -c "import sys; assert (3,11) <= sys.version_info[:2] < (3,15), 'Python 3.11-3.14 required'"
if ($LASTEXITCODE -ne 0) { throw "Install 64-bit Python 3.12 or specify a supported Python executable." }
if (-not (Test-Path ".venv\Scripts\python.exe")) {
    & $Python @PythonArguments -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw "Could not create the Python environment." }
}
& .\.venv\Scripts\python.exe -m pip install --require-hashes -r requirements-port.txt
if ($LASTEXITCODE -ne 0) { throw "Could not install the locked engine dependencies." }
& .\.venv\Scripts\python.exe -m pip install --no-deps .
if ($LASTEXITCODE -ne 0) { throw "Could not install the engine." }
Write-Host "Ready. Open StreamerBot.Desktop.exe in the parent folder."
