using System.Net.Http.Json;
using System.Text.Json;
using StreamerBot.Host;

if (args.Length != 2) throw new ArgumentException("Usage: Host.Check <python executable> <worker directory>");
await using var worker = new WorkerHost();
using var http = new HttpClient();
http.DefaultRequestHeaders.Add("X-StreamerBot-Client", "dashboard");
var address = await worker.StartAsync(Path.GetFullPath(args[0]), Path.GetFullPath(args[1]), demo: true, port: 0);
using (var start = await http.PostAsJsonAsync(new Uri(address, "api/session/start"), new { }))
    start.EnsureSuccessStatusCode();
using (var status = await http.GetFromJsonAsync<JsonDocument>(new Uri(address, "api/state")))
{
    if (status is null || !status.RootElement.GetProperty("status").GetProperty("running").GetBoolean())
        throw new Exception("The C# host did not start a streaming session.");
}
await worker.StopAsync();
try
{
    using var response = await http.GetAsync(new Uri(address, "api/health"));
    throw new Exception("Worker remained reachable after shutdown.");
}
catch (HttpRequestException) { }
Console.WriteLine("PASS: C# readiness, API version, session start and owned-process shutdown.");
