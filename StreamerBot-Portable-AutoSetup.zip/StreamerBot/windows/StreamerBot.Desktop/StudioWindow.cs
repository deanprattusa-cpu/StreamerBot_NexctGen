using System.Diagnostics;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Microsoft.Web.WebView2.Core;
using StreamerBot.Host;
using Windows.Graphics;

namespace StreamerBot.Desktop;

internal sealed class StudioWindow : Window
{
    private readonly WorkerHost _worker = new();
    private readonly CancellationTokenSource _lifetime = new();
    private readonly Grid _root = new();
    private readonly StackPanel _loading = new() { Spacing = 18, MaxWidth = 650,
        HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
    private readonly TextBlock _message = new() { Text = "Starting your streaming studio…", FontSize = 18,
        TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true };
    private bool _closing;
    private Hotkeys? _hotkeys;
    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(5) };
    private readonly TextBlock _shortcuts = new() { FontSize = 11, Margin = new Thickness(18, 9, 18, 9), Opacity = .7,
        TextWrapping = TextWrapping.Wrap, Text = "Starting local engine…" };

    public StudioWindow()
    {
        Title = "StreamerBot Studio";
        AppWindow.Resize(new SizeInt32(1440, 1000));
        _root.RequestedTheme = ElementTheme.Dark;
        _root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        _root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        _root.Children.Add(_shortcuts);
        _root.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 17, 18, 20));
        _loading.Children.Add(new TextBlock { Text = "STREAMERBOT", FontSize = 30 });
        _loading.Children.Add(_message);
        _loading.Children.Add(new TextBlock { Text = "You play. Your AI brings the stream to life.", Opacity = .6 });
        _root.Children.Add(_loading);
        Grid.SetRow(_loading, 1);
        Content = _root;
        AppWindow.Closing += async (_, args) =>
        {
            if (_closing) return;
            args.Cancel = true;
            _closing = true;
            _lifetime.Cancel();
            _hotkeys?.Dispose();
            _http.Dispose();
            await _worker.DisposeAsync();
            Close();
        };
        _root.Loaded += async (_, _) => await BootAsync();
    }

    private async Task BootAsync()
    {
        try
        {
            var root = FindWorkerRoot();
            var python = Environment.GetEnvironmentVariable("STREAMERBOT_PYTHON");
            if (string.IsNullOrWhiteSpace(python))
            {
                var environment = Path.Combine(root, ".venv", "Scripts", "python.exe");
                python = File.Exists(environment) ? environment : "python.exe";
            }
            var address = await _worker.StartAsync(python, root, cancellationToken: _lifetime.Token);
            _lifetime.Token.ThrowIfCancellationRequested();
            var browser = new WebView2();
            Grid.SetRow(browser, 1);
            _root.Children.Add(browser);
            var profile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "StreamerBot", "WebView2");
            var environmentOptions = new CoreWebView2EnvironmentOptions();
            var webEnvironment = await CoreWebView2Environment.CreateWithOptionsAsync(null, profile, environmentOptions);
            _lifetime.Token.ThrowIfCancellationRequested();
            await browser.EnsureCoreWebView2Async(webEnvironment);
            _lifetime.Token.ThrowIfCancellationRequested();
            browser.CoreWebView2.Settings.IsStatusBarEnabled = false;
            browser.CoreWebView2.PermissionRequested += (_, request) => request.State = CoreWebView2PermissionState.Deny;
            browser.CoreWebView2.NavigationStarting += (_, navigation) =>
            {
                if (!Uri.TryCreate(navigation.Uri, UriKind.Absolute, out var uri) ||
                    uri.Scheme != address.Scheme || uri.Authority != address.Authority)
                    navigation.Cancel = true;
            };
            browser.CoreWebView2.NewWindowRequested += (_, request) =>
            {
                request.Handled = true;
                if (Uri.TryCreate(request.Uri, UriKind.Absolute, out var uri) &&
                    uri.Scheme == address.Scheme && uri.Authority == address.Authority)
                    Process.Start(new ProcessStartInfo(uri.AbsoluteUri) { UseShellExecute = true });
            };
            browser.Source = address;
            _loading.Visibility = Visibility.Collapsed;
            _lifetime.Token.ThrowIfCancellationRequested();
            _hotkeys = new Hotkeys(action => DispatcherQueue.TryEnqueue(async () => await ShortcutAsync(action)));
            _shortcuts.Text = _hotkeys.RegisteredCount == 7
                ? "Ctrl+Alt: 1 Died · 2 Won · 3 Close call · 4 Intro · M Mute · S Interrupt · F8 Start/stop"
                : $"{_hotkeys.RegisteredCount}/7 shortcuts available. Some are in use by another app. Dashboard controls remain available.";
        }
        catch (OperationCanceledException) when (_lifetime.IsCancellationRequested) { }
        catch (Exception error)
        {
            await _worker.StopAsync();
            if (_closing) return;
            _message.Text = "The studio could not start.\n\n" + error.Message +
                "\n\nRun Setup-Windows.ps1 from the project folder. WebView2 Runtime is also required.";
        }
    }

    private async Task ShortcutAsync(string action)
    {
        if (_worker.Address is not { } address || _closing) return;
        try
        {
            var path = "api/reaction";
            object body = new { kind = action };
            if (action is "mute" or "session")
            {
                using var state = await _http.GetFromJsonAsync<JsonDocument>(new Uri(address, "api/state"), _lifetime.Token);
                var status = state!.RootElement.GetProperty("status");
                if (action == "mute")
                {
                    path = "api/mute";
                    body = new { muted = !status.GetProperty("muted").GetBoolean() };
                }
                else
                {
                    path = status.GetProperty("running").GetBoolean() ? "api/session/stop" : "api/session/start";
                    body = new { };
                }
            }
            else if (action == "interrupt") { path = "api/interrupt"; body = new { }; }
            using var request = new HttpRequestMessage(HttpMethod.Post, new Uri(address, path));
            request.Headers.Add("X-StreamerBot-Client", "dashboard");
            request.Content = JsonContent.Create(body);
            using var response = await _http.SendAsync(request, _lifetime.Token);
        }
        catch (Exception error) when (error is HttpRequestException or OperationCanceledException or JsonException) { }
    }

    private static string FindWorkerRoot()
    {
        var packaged = Path.Combine(AppContext.BaseDirectory, "Worker");
        if (Directory.Exists(Path.Combine(packaged, "streamerbot"))) return packaged;
        for (var path = new DirectoryInfo(AppContext.BaseDirectory); path is not null; path = path.Parent)
            if (File.Exists(Path.Combine(path.FullName, "pyproject.toml")) &&
                Directory.Exists(Path.Combine(path.FullName, "streamerbot"))) return path.FullName;
        throw new DirectoryNotFoundException("The Python worker folder is missing. Restore the complete application folder.");
    }
}
