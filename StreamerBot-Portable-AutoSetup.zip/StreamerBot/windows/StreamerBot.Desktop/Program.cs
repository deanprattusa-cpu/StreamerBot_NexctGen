using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;

namespace StreamerBot.Desktop;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        WinRT.ComWrappersSupport.InitializeComWrappers();
        Application.Start(initialization =>
        {
            SynchronizationContext.SetSynchronizationContext(
                new DispatcherQueueSynchronizationContext(DispatcherQueue.GetForCurrentThread()));
            _ = new StudioApplication();
        });
    }
}

internal sealed class StudioApplication : Application
{
    private Window? _window;
    public StudioApplication()
    {
        Resources.MergedDictionaries.Add(new Microsoft.UI.Xaml.Controls.XamlControlsResources());
    }

    protected override void OnLaunched(LaunchActivatedEventArgs args)
    {
        _window = new StudioWindow();
        _window.Activate();
    }
}
