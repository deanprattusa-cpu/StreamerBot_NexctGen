using System.Runtime.InteropServices;

namespace StreamerBot.Desktop;

/// <summary>OS-registered shortcuts, without keyboard hooks or simulated game input.</summary>
internal sealed class Hotkeys : IDisposable
{
    private readonly Thread _thread;
    private readonly ManualResetEventSlim _ready = new();
    private readonly Action<string> _pressed;
    private uint _threadId;
    public int RegisteredCount { get; private set; }
    private static readonly (uint Key, string Action)[] Bindings =
    [
        (0x31, "death"), (0x32, "win"), (0x33, "close"), (0x34, "intro"),
        (0x4D, "mute"), (0x53, "interrupt"), (0x77, "session"), // M, S, F8
    ];

    public Hotkeys(Action<string> pressed)
    {
        _pressed = pressed;
        _thread = new Thread(Run) { IsBackground = true, Name = "StreamerBot shortcuts" };
        _thread.Start();
        _ready.Wait();
    }

    private void Run()
    {
        _threadId = GetCurrentThreadId();
        var registered = new List<int>();
        try
        {
            for (var index = 0; index < Bindings.Length; index++)
                if (RegisterHotKey(IntPtr.Zero, index + 1, 0x0001 | 0x0002 | 0x4000, Bindings[index].Key))
                    registered.Add(index + 1);
            RegisteredCount = registered.Count;
            // Ensure the message queue exists before Dispose can post WM_QUIT.
            PeekMessage(out _, IntPtr.Zero, 0, 0, 0);
            _ready.Set();
            while (GetMessage(out var message, IntPtr.Zero, 0, 0) > 0)
                if (message.MessageId == 0x0312 && (ulong)message.WParam is >= 1 and <= 7)
                    _pressed(Bindings[(int)message.WParam - 1].Action);
        }
        finally
        {
            foreach (var id in registered) UnregisterHotKey(IntPtr.Zero, id);
            _ready.Set();
        }
    }

    public void Dispose()
    {
        if (_thread.IsAlive)
        {
            PostThreadMessage(_threadId, 0x0012, UIntPtr.Zero, IntPtr.Zero);
            if (!_thread.Join(1000)) return;
        }
        _ready.Dispose();
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Message
    {
        public IntPtr Window;
        public uint MessageId;
        public UIntPtr WParam;
        public IntPtr LParam;
        public uint Time;
        public int X;
        public int Y;
        public uint Private;
    }

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool RegisterHotKey(IntPtr window, int id, uint modifiers, uint key);
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnregisterHotKey(IntPtr window, int id);
    [DllImport("user32.dll")]
    private static extern int GetMessage(out Message message, IntPtr window, uint minimum, uint maximum);
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool PeekMessage(out Message message, IntPtr window, uint minimum, uint maximum, uint remove);
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool PostThreadMessage(uint threadId, uint message, UIntPtr wParam, IntPtr lParam);
    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();
}
