using System.Diagnostics;
using System.Runtime.InteropServices;

internal static class Program
{
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int MessageBoxW(nint owner, string text, string caption, uint type);

    private static int Main()
    {
        if (!OperatingSystem.IsWindows()) return 1;
        try
        {
            var root = AppContext.BaseDirectory;
            foreach (var required in new[] { "controller.py", "model.py", "view.py", "Start-Portable.ps1" })
                if (!File.Exists(Path.Combine(root, required)))
                    throw new FileNotFoundException("Extract the complete project beside StreamerBot.exe. Missing: " + required);
            var powershell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),
                "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
            var setup = new ProcessStartInfo(powershell) { WorkingDirectory = root, UseShellExecute = false };
            foreach (var arg in new[] { "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", Path.Combine(root, "Start-Portable.ps1"), "-PrepareOnly" })
                setup.ArgumentList.Add(arg);
            using (var preparation = Process.Start(setup) ?? throw new IOException("Could not start portable preparation."))
            {
                preparation.WaitForExit();
                if (preparation.ExitCode != 0) throw new IOException("Portable setup failed. Run Start-StreamerBot.bat to see the setup error.");
            }
            var python = Path.Combine(root, ".portable", "original", "venv", "Scripts", "pythonw.exe");
            if (!File.Exists(python)) throw new FileNotFoundException("The original desktop Python runtime is missing. Run Start-StreamerBot.bat.");
            var app = new ProcessStartInfo(python) { WorkingDirectory = root, UseShellExecute = false, CreateNoWindow = true };
            app.ArgumentList.Add(Path.Combine(root, "controller.py"));
            var privateHome = Path.Combine(root, ".portable", "original");
            app.Environment["PATH"] = Path.GetDirectoryName(python) + Path.PathSeparator + Path.Combine(privateHome, "bin") +
                Path.PathSeparator + Environment.GetEnvironmentVariable("PATH");
            app.Environment["PLAYWRIGHT_BROWSERS_PATH"] = Path.Combine(privateHome, "browsers");
            var webview = Path.Combine(root, ".portable", "webview2");
            if (File.Exists(Path.Combine(webview, "msedgewebview2.exe")))
                app.Environment["WEBVIEW2_BROWSER_EXECUTABLE_FOLDER"] = webview;
            using var process = Process.Start(app) ?? throw new IOException("Could not start the original desktop app.");
            process.WaitForExit();
            if (process.ExitCode != 0) throw new IOException("The original desktop app exited with an error. Check CRASH_LOG.txt and FATAL_NATIVE_CRASH_LOG.txt in the project folder.");
            return 0;
        }
        catch (Exception error)
        {
            MessageBoxW(0, error.Message, "StreamerBot", 0x10);
            return 1;
        }
    }
}
