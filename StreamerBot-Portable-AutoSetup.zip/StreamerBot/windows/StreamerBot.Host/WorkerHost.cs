using System.Diagnostics;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text.Json;

namespace StreamerBot.Host;

/// <summary>Owns a Python worker, verifies its protocol, and stops only that process tree.</summary>
public sealed class WorkerHost : IAsyncDisposable
{
    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(4) };
    private readonly string _ownerToken = Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
    private Process? _process;
    private Task<string>? _stderr;
    public Uri? Address { get; private set; }

    public async Task<Uri> StartAsync(string python, string root, bool demo = false,
        string? dataDirectory = null, int port = 8765, CancellationToken cancellationToken = default)
    {
        if (_process is not null) throw new InvalidOperationException("Worker already started.");
        var info = new ProcessStartInfo(python)
        {
            WorkingDirectory = root,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
        };
        if (port < 0 || port > 65535) throw new ArgumentOutOfRangeException(nameof(port));
        foreach (var arg in new[] { "-u", "-m", "streamerbot", "--port", port.ToString() }) info.ArgumentList.Add(arg);
        if (demo) info.ArgumentList.Add("--demo");
        if (dataDirectory is not null)
        {
            info.ArgumentList.Add("--data-dir");
            info.ArgumentList.Add(dataDirectory);
        }
        var avatar = Path.Combine(root, "avatar.png");
        if (File.Exists(avatar))
        {
            info.ArgumentList.Add("--avatar");
            info.ArgumentList.Add(avatar);
        }
        info.Environment["SB_DESKTOP_TOKEN"] = _ownerToken;
        info.Environment["PYTHONIOENCODING"] = "utf-8";
        info.Environment["PYGAME_HIDE_SUPPORT_PROMPT"] = "1";
        _process = Process.Start(info) ?? throw new InvalidOperationException("Unable to start the Python engine.");
        _stderr = _process.StandardError.ReadToEndAsync();
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        deadline.CancelAfter(TimeSpan.FromSeconds(30));
        try
        {
            var line = await _process.StandardOutput.ReadLineAsync(deadline.Token);
            if (line is null)
            {
                var diagnostic = await _stderr.WaitAsync(deadline.Token);
                throw new InvalidOperationException("Python engine exited before readiness. Run Setup-Windows.ps1.\n" +
                                                    diagnostic[..Math.Min(diagnostic.Length, 2000)]);
            }
            using var ready = JsonDocument.Parse(line);
            var message = ready.RootElement;
            if (message.GetProperty("event").GetString() != "ready" || message.GetProperty("api_version").GetInt32() != 1)
                throw new InvalidOperationException("Unsupported Python engine protocol.");
            var address = new Uri(message.GetProperty("url").GetString()!);
            if (address.Scheme != "http" || address.Host != "127.0.0.1" || address.Port <= 0 ||
                address.AbsolutePath != "/" || address.UserInfo.Length != 0 || address.Query.Length != 0 || address.Fragment.Length != 0)
                throw new InvalidOperationException("The Python engine returned an invalid local address.");
            using var response = await _http.GetAsync(new Uri(address, "api/health"), deadline.Token);
            response.EnsureSuccessStatusCode();
            using var health = await JsonDocument.ParseAsync(await response.Content.ReadAsStreamAsync(deadline.Token),
                cancellationToken: deadline.Token);
            if (health.RootElement.GetProperty("api_version").GetInt32() != 1)
                throw new InvalidOperationException("Desktop and engine API versions do not match.");
            Address = address;
            // Optional engines may write informational output; keep their pipe drained.
            _ = _process.StandardOutput.ReadToEndAsync();
            return address;
        }
        catch
        {
            await StopAsync();
            throw;
        }
    }

    public async Task StopAsync()
    {
        var process = _process;
        _process = null;
        if (process is null) return;
        try
        {
            if (!process.HasExited && Address is not null)
            {
                using var request = new HttpRequestMessage(HttpMethod.Post, new Uri(Address, "api/shutdown"));
                request.Headers.Add("X-StreamerBot-Client", "dashboard");
                request.Headers.Add("X-StreamerBot-Owner", _ownerToken);
                request.Content = JsonContent.Create(new { });
                try { using var response = await _http.SendAsync(request); }
                catch (Exception error) when (error is HttpRequestException or TaskCanceledException) { }
            }
            if (!process.HasExited)
            {
                using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(4));
                try { await process.WaitForExitAsync(deadline.Token); }
                catch (OperationCanceledException)
                {
                    process.Kill(entireProcessTree: true);
                    await process.WaitForExitAsync();
                }
            }
        }
        finally
        {
            Address = null;
            process.Dispose();
        }
    }

    public async ValueTask DisposeAsync()
    {
        await StopAsync();
        _http.Dispose();
    }
}
