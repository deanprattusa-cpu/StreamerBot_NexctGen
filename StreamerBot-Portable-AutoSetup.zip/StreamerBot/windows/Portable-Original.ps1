# Prepare the preserved original desktop app. Never imports/reduces its settings.
function Initialize-PortableOriginal {
    param([string]$Root, [string]$HomePath, $Manifest, [switch]$Repair)
    $uv = Join-Path $HomePath 'uv/uv.exe'
    if ($Repair -or -not (Test-PortableTool $uv @('--version') -ExpectedOutput ("uv " + $Manifest.uv.version))) {
        $archive = Join-Path $HomePath 'downloads/uv.zip'
        Receive-PortableArchive $Manifest.uv $archive
        Expand-PortableZip $archive (Join-Path $HomePath 'uv')
        if (-not (Test-PortableTool $uv @('--version') -ExpectedOutput ("uv " + $Manifest.uv.version))) { throw 'Portable uv could not run.' }
    }
    $original = Join-Path $HomePath 'original'
    New-Item -ItemType Directory -Path $original -Force | Out-Null
    $env:UV_PYTHON_INSTALL_DIR = Join-Path $HomePath 'python'
    $env:UV_CACHE_DIR = Join-Path $HomePath 'cache/uv'
    $install = @('python', 'install', $Manifest.original_python, '--no-bin', '--no-registry')
    if ($Repair) { $install += '--reinstall' }
    Invoke-PortableTool $uv $install
    $python = Join-Path $original 'venv/Scripts/python.exe'
    $probe = @('-c', 'import sys, struct, tkinter, ssl, sqlite3; assert sys.version_info[:2] == (3,11) and struct.calcsize(''P'') == 8')
    if (-not (Test-PortableTool $python $probe)) {
        Invoke-PortableTool $uv @('venv', '--seed', '--clear', '--managed-python', '--python', $Manifest.original_python, (Join-Path $original 'venv'))
    }
    $env:PLAYWRIGHT_BROWSERS_PATH = Join-Path $original 'browsers'
    $env:PIP_CACHE_DIR = Join-Path $original 'pip-cache'
    $env:PATH = (Join-Path $original 'venv/Scripts') + ';' + (Join-Path $original 'bin') + ';' + $env:PATH
    $args = @((Join-Path $Root 'windows/prepare_original.py'), '--state-dir', $original)
    if ($Repair) { $args += '--repair' }
    Invoke-PortableTool $python $args
    # WebView is only used by the original YouTube/embedded-service windows.
    try { $env:WEBVIEW2_BROWSER_EXECUTABLE_FOLDER = Initialize-PortableWebView $HomePath $Manifest.webview2 -Repair:$Repair }
    catch { Write-Warning ("The original desktop UI can open, but WebView2-dependent windows need repair: " + $_.Exception.Message) }
    return $python
}
