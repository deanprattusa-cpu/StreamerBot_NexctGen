"""Shows what voice clips exist in your cache folders, so you can see why 'Force Cache Only' is silent.
Run it from your StreamerBot folder:   python cache_doctor.py [hotkey_name]
Example:                               python cache_doctor.py death
"""
import json
import os
import sys
from collections import defaultdict

want = sys.argv[1].replace("hk_", "") if len(sys.argv) > 1 else None
cfg = {}
try:
    cfg = json.load(open("bot_config.json", encoding="utf-8"))
except Exception:
    pass

print("=" * 64)
print("StreamerBot cache doctor  (folder: %s)" % os.getcwd())
print("=" * 64)
for key in ("tts_mode", "game_name", "channel_name", "force_cache_only", "volume_level"):
    if key in cfg:
        print(f"  config {key}: {cfg[key]}")

caches = sorted(d for d in os.listdir(".") if d.endswith("_cache") and os.path.isdir(d))
if not caches:
    print("\nNO *_cache folders here. Run this from the same folder as controller.py.\n"
          "If it IS the right folder, you have never generated any cached voice clips.")
    sys.exit(0)

total = 0
for cdir in caches:
    tree = defaultdict(lambda: defaultdict(int))        # (channel, game, voice) -> category -> count
    for root, _, files in os.walk(cdir):
        wavs = [f for f in files if f.lower().endswith(".wav")]
        if not wavs:
            continue
        parts = os.path.relpath(root, cdir).split(os.sep)
        cat = parts[-1]
        ctx = tuple(parts[:-1]) or ("(legacy)",)
        tree[ctx][cat] += len(wavs)
        total += len(wavs)
    n = sum(sum(v.values()) for v in tree.values())
    print(f"\n[{cdir}]  {n} clips")
    for ctx, cats in sorted(tree.items()):
        print("   " + " / ".join(ctx))
        for cat, count in sorted(cats.items()):
            mark = "  <-- the hotkey you asked about" if want and cat == want else ""
            print(f"        {cat:<22}{count:>4}{mark}")

if want:
    hits = [c for c in caches if any(os.path.basename(r) == want and any(f.lower().endswith('.wav') for f in fs)
                                      for r, _, fs in os.walk(c))]
    print("\n" + ("'%s' clips exist in: %s" % (want, ", ".join(hits)) if hits else
                  "NO clips for '%s' exist in any cache folder. That is why Force Cache is silent for it." % want))
print(f"\nTotal clips: {total}")
print("The app only plays from the cache folder of the voice engine currently selected (e.g. bark -> bark_cache).")
