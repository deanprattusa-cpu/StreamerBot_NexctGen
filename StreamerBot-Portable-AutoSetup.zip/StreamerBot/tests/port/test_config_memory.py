import copy
import hashlib
import json
import os
import tempfile
import unittest
from pathlib import Path

from streamerbot.config import DEFAULTS, ConfigStore, validate
from streamerbot.memory import Memory


class ConfigTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.root = Path(self.directory.name)
        self.store = ConfigStore(self.root / "new")

    def tearDown(self):
        self.directory.cleanup()

    def test_defaults_are_independent(self):
        self.store.value["capture"]["monitor"] = 2
        self.assertEqual(DEFAULTS["capture"]["monitor"], 1)

    def test_keys_are_redacted_retained_and_explicitly_clearable(self):
        providers = copy.deepcopy(DEFAULTS["providers"])
        providers[0]["keys"] = ["synthetic-local-key"]
        public = self.store.update({"providers": providers})
        self.assertNotIn("synthetic-local-key", json.dumps(public))
        self.assertEqual(public["providers"][0]["key_count"], 1)
        self.store.update({"providers": public["providers"]})
        self.assertEqual(self.store.value["providers"][0]["keys"], ["synthetic-local-key"])
        public["providers"][0]["keys"] = []
        self.store.update({"providers": public["providers"]})
        self.assertEqual(self.store.value["providers"][0]["keys"], [])

    def test_invalid_update_does_not_change_memory_or_file(self):
        self.store.update({"game_name": "Before"})
        before = self.store.path.read_bytes()
        with self.assertRaises(ValueError):
            self.store.update({"game_name": "After", "capture": {"monitor": 0}})
        self.assertEqual(self.store.value["game_name"], "Before")
        self.assertEqual(self.store.path.read_bytes(), before)

    def test_round_trip_and_private_file_permissions(self):
        self.store.update({"streamer_name": "テスト"})
        self.assertEqual(ConfigStore(self.store.directory).value["streamer_name"], "テスト")
        if os.name != "nt":
            self.assertEqual(self.store.path.stat().st_mode & 0o777, 0o600)

    def test_migration_preserves_source_and_records_unported_voice(self):
        source = self.root / "legacy.json"
        source.write_text(
            json.dumps(
                {
                    "game_name": "Test Game",
                    "persona": "English",
                    "groq_keys": [{"key": "synthetic-key"}],
                    "groq_model": "test-model",
                    "ai_mode": "groq",
                    "tts_mode": "bark",
                }
            ),
            "utf-8",
        )
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        result = self.store.import_legacy(source)
        self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(), digest)
        self.assertEqual(result["mode"], "demo")
        self.assertEqual(result["providers"][0]["id"], "groq")
        self.assertTrue(result["providers"][0]["enabled"])
        self.assertEqual(result["speech"]["engine"], "sapi")
        self.assertTrue(any("bark" in note for note in result["migration"]["notes"]))
        with self.assertRaises(ValueError):
            self.store.import_legacy(source)

    def test_v2_keys_and_voice_migrate_without_enabling_live(self):
        source = self.root / "v2.json"
        source.write_text(
            json.dumps(
                {
                    "keys": {"gemini": ["synthetic-key"]},
                    "tts": {"engine": "edge", "voices": {"edge": "test-voice"}},
                }
            ),
            "utf-8",
        )
        result = self.store.import_legacy(source)
        self.assertEqual(result["providers"][0]["key_count"], 1)
        self.assertEqual(result["speech"]["voice"], "test-voice")
        self.assertEqual(result["mode"], "demo")

    def test_validation_rejects_unsafe_urls_and_invalid_numbers(self):
        for url in [
            "http://example.com/v1",
            "https://user:secret@example.com/v1",
            "file:///tmp/model",
            "https://example.com?key=bad",
        ]:
            config = copy.deepcopy(DEFAULTS)
            config["providers"][0]["base_url"] = url
            with self.subTest(url=url), self.assertRaises(ValueError):
                validate(config)
        for value in [True, float("nan"), float("inf"), 1.5, 0, 31]:
            config = copy.deepcopy(DEFAULTS)
            config["capture"]["max_calls_per_min"] = value
            with self.subTest(value=value), self.assertRaises(ValueError):
                validate(config)

    def test_rejects_unknown_fields_and_duplicate_providers(self):
        with self.assertRaises(ValueError):
            self.store.update({"unexpected": 1})
        providers = copy.deepcopy(DEFAULTS["providers"])
        providers.append(providers[0])
        with self.assertRaises(ValueError):
            self.store.update({"providers": providers})


class MemoryTests(unittest.TestCase):
    def test_history_is_persistent_game_scoped_and_parameterized(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "memory.sqlite3"
            memory = Memory(path)
            name = "Game'; DROP TABLE events; --"
            memory.add(name, "commentary", {"text": "First"})
            memory.add("Other", "commentary", {"text": "Other game"})
            memory.add(name, "commentary", {"text": "Second"})
            memory.close()
            reopened = Memory(path)
            self.assertEqual([r["payload"]["text"] for r in reopened.recent(name)], ["First", "Second"])
            self.assertEqual(reopened.recent(name, 1)[0]["payload"]["text"], "Second")
            reopened.close()
