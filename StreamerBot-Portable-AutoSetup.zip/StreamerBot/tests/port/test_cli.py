"""Verify browser launch crosses the real worker readiness boundary."""

import argparse
import asyncio
import contextlib
import io
import json
import os
import tempfile
import unittest
import urllib.request
from unittest.mock import patch

from streamerbot.__main__ import serve


class CliTests(unittest.IsolatedAsyncioTestCase):
    async def test_browser_opens_only_when_worker_accepts_requests(self):
        visited = []

        def browser_open(url):
            with urllib.request.urlopen(url + "api/health", timeout=3) as response:
                self.assertEqual(json.load(response)["api_version"], 1)
            visited.append(url)
            request = urllib.request.Request(
                url + "api/shutdown",
                data=b"{}",
                headers={
                    "Content-Type": "application/json",
                    "X-StreamerBot-Client": "dashboard",
                    "X-StreamerBot-Owner": "synthetic-cli-owner",
                },
            )
            with urllib.request.urlopen(request, timeout=3) as response:
                self.assertEqual(response.status, 200)
            return True

        with tempfile.TemporaryDirectory() as directory:
            args = argparse.Namespace(
                demo=True,
                data_dir=directory,
                import_legacy=None,
                public_preview=False,
                avatar=None,
                host="127.0.0.1",
                port=0,
                open_browser=True,
            )
            output = io.StringIO()
            with (
                patch.dict(os.environ, {"SB_DESKTOP_TOKEN": "synthetic-cli-owner"}),
                patch("streamerbot.__main__.webbrowser.open", side_effect=browser_open),
                contextlib.redirect_stdout(output),
            ):
                await asyncio.wait_for(serve(args), timeout=10)
            ready = json.loads(output.getvalue().splitlines()[0])
            self.assertEqual(ready["event"], "ready")
            self.assertEqual(visited, [ready["url"]])
