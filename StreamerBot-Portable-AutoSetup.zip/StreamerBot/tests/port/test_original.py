"""Protect original behavior and isolated preparation at the new Windows entry point."""

import hashlib
import importlib.util
import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("prepare_original", ROOT / "windows/prepare_original.py")
prepare = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prepare)


class OriginalTests(unittest.TestCase):
    def test_complete_original_source_remains_identical(self):
        baseline = json.loads((ROOT / "windows/original-parity.json").read_text())
        for name, expected in baseline["original_files_sha256"].items():
            with self.subTest(file=name):
                self.assertEqual(hashlib.sha256((ROOT / name).read_bytes()).hexdigest(), expected)
        self.assertEqual(len(baseline["voice_engines"]), 13)
        self.assertTrue(
            {"bark", "rvc", "soprano", "kokoro", "typecast"}.issubset(
                engine["id"] for engine in baseline["voice_engines"]
            )
        )

    def test_legacy_installer_adapter_does_not_install_into_user_python(self):
        with patch.object(prepare, "run") as run:
            prepare.pip(["install", "--user", "keyboard"])
        command = run.call_args.args[0]
        self.assertNotIn("--user", command)
        self.assertIn("--isolated", command)
        self.assertIn("--cache-dir", command)
        self.assertIn(str(prepare.CONSTRAINTS), command)

    def test_optional_inventory_and_state_remain_separate_from_original_files(self):
        state = ROOT / ".portable/original"
        installer = prepare.load_installer(state)
        self.assertEqual(Path(installer.REQ_FILE), ROOT / "requirements.txt")
        self.assertEqual(Path(installer.STATE_FILE), state / "dependency-state.json")
        self.assertEqual(Path(installer.CONSTRAINTS), prepare.CONSTRAINTS)
        original = {name.lower() for name, _, _ in installer.parse_requirements(installer.REQ_FILE)}
        self.assertTrue({"suno-bark", "rvc-python", "kokoro", "playwright", "keyboard"}.issubset(original))


class CudaRepairTests(unittest.TestCase):
    def test_windows_nvidia_discovery_without_path_tool_or_vendor_name(self):
        def execute(command, **kwargs):
            if "-EncodedCommand" in command:
                return subprocess.CompletedProcess(
                    command,
                    0,
                    json.dumps([{"Name": "Microsoft Basic Display Adapter", "PNPDeviceID": r"PCI\VEN_10DE"}]),
                    "",
                )
            raise FileNotFoundError("NVSMI not installed")

        with (
            patch.object(prepare.sys, "platform", "win32"),
            patch.object(prepare.shutil, "which", return_value=None),
            patch.object(prepare.subprocess, "run", side_effect=execute),
        ):
            report = prepare.detect_nvidia()
        self.assertTrue(report["nvidia"])
        self.assertEqual(report["source"], "Windows video controllers")

    def test_cpu_build_on_nvidia_is_replaced_with_exact_cuda_wheels(self):
        good = {"status": "passed", "torch": "2.5.1+cu124", "device": "Synthetic RTX 4070 Ti"}
        with (
            patch.object(
                prepare, "detect_nvidia", return_value={"nvidia": True, "source": "CIM", "devices": []}
            ),
            patch.object(
                prepare, "probe_torch", side_effect=[{"status": "failed", "torch": "2.5.1+cpu"}, good]
            ) as probe,
            patch.object(prepare, "pip") as install,
        ):
            report = prepare.prepare_torch(False)
        self.assertEqual(report["status"], "passed")
        self.assertTrue(report["cuda_requested"])
        self.assertTrue(all(call.args[0] is True for call in probe.call_args_list))
        command = install.call_args.args[0]
        for wheel in ("torch==2.5.1+cu124", "torchvision==0.20.1+cu124", "torchaudio==2.5.1+cu124"):
            self.assertIn(wheel, command)
        self.assertIn("https://download.pytorch.org/whl/cu124", command)
        self.assertIn("--force-reinstall", command)
        self.assertIn("--no-cache-dir", command)

    def test_failed_cuda_install_never_substitutes_cpu(self):
        with (
            patch.object(prepare, "detect_nvidia", return_value={"nvidia": True, "source": "CIM"}),
            patch.object(prepare, "pip", side_effect=RuntimeError("download interrupted")) as install,
        ):
            report = prepare.prepare_torch(True, "cuda")
        self.assertEqual(report["status"], "failed")
        self.assertTrue(report["cuda_requested"])
        install.assert_called_once()
        self.assertNotIn("https://download.pytorch.org/whl/cpu", install.call_args.args[0])

    def test_unknown_windows_inventory_does_not_silently_choose_cpu(self):
        with (
            patch.object(prepare, "detect_nvidia", return_value={"nvidia": None, "source": "unavailable"}),
            patch.object(prepare, "probe_torch", return_value={"status": "passed"}) as probe,
        ):
            report = prepare.prepare_torch(False)
        probe.assert_called_once_with(True, False)
        self.assertTrue(report["cuda_requested"])

    def test_explicit_cpu_mode_is_supported_without_changing_settings(self):
        with (
            patch.object(prepare, "detect_nvidia", return_value={"nvidia": True, "source": "CIM"}),
            patch.object(prepare, "probe_torch", return_value={"status": "passed"}) as probe,
            patch.object(prepare, "pip") as install,
        ):
            report = prepare.prepare_torch(False, "cpu")
        probe.assert_called_once_with(False, True)
        install.assert_not_called()
        self.assertFalse(report["cuda_requested"])

    def test_optional_installer_cannot_leave_cpu_replacement_unchecked(self):
        original = {"status": "passed", "cuda_requested": True}
        repaired = {"status": "passed", "cuda_requested": True, "torch": "2.5.1+cu124"}
        with (
            patch.object(
                prepare, "probe_torch", return_value={"status": "failed", "reason": "CPU-only build"}
            ),
            patch.object(prepare, "prepare_torch", return_value=repaired) as repair,
        ):
            self.assertEqual(prepare.finalize_torch(original, "auto"), repaired)
        repair.assert_called_once_with(True, "auto")

    def test_driver_or_kernel_failure_is_not_reported_as_passed(self):
        result = subprocess.CompletedProcess(
            [], 1, '{"status":"failed","reason":"CUDA driver unavailable"}', ""
        )
        with patch.object(prepare.subprocess, "run", return_value=result):
            report = prepare.probe_torch(True)
        self.assertEqual(report["status"], "failed")
        self.assertIn("driver", report["reason"])

    def test_targeted_gpu_failure_returns_nonzero_without_full_installer(self):
        with (
            tempfile.TemporaryDirectory() as folder,
            patch.object(prepare.sys, "prefix", folder),
            patch.object(prepare.sys, "base_prefix", folder + "-base"),
            patch.object(prepare, "prepare_torch", return_value={"status": "failed", "reason": "No driver"}),
            patch.object(prepare, "load_installer") as optional,
        ):
            self.assertEqual(prepare.main(["--state-dir", folder, "--repair-gpu", "--gpu-mode", "cuda"]), 1)
            self.assertEqual(json.loads((Path(folder) / "gpu-report.json").read_text())["status"], "failed")
        optional.assert_not_called()

    def test_full_preparation_stops_on_failed_final_gpu_probe(self):
        class Installer:
            def main(self):
                pass

            def load_state(self):
                return {"failed": {}}

        with (
            tempfile.TemporaryDirectory() as folder,
            patch.object(prepare.sys, "prefix", folder),
            patch.object(prepare.sys, "base_prefix", folder + "-base"),
            patch.object(prepare, "pip"),
            patch.object(prepare, "prepare_torch", return_value={"status": "failed", "cuda_requested": True}),
            patch.object(
                prepare, "probe_torch", return_value={"status": "failed", "reason": "CPU build replaced CUDA"}
            ),
            patch.object(prepare, "load_installer", return_value=Installer()),
            patch.object(prepare, "missing_core", return_value=[]),
            patch.object(prepare, "run", return_value=subprocess.CompletedProcess([], 0)),
        ):
            self.assertEqual(prepare.main(["--state-dir", folder, "--gpu-mode", "cuda"]), 1)
            report = json.loads((Path(folder) / "dependency-report.json").read_text())
            self.assertEqual(report["pytorch"]["status"], "failed")

    def test_real_probe_process_rejects_cpu_build_and_checks_tensor_result(self):
        with tempfile.TemporaryDirectory() as folder:
            fixture = Path(folder)
            for name, version in (("torchvision", "0.20.1+cu124"), ("torchaudio", "2.5.1+cu124")):
                (fixture / (name + ".py")).write_text(f"__version__={version!r}\n")
            cpu = "from types import SimpleNamespace\n__version__='2.5.1+cpu'\nversion=SimpleNamespace(cuda=None)\n"
            (fixture / "torch.py").write_text(cpu)
            with patch.dict(prepare.os.environ, {"PYTHONPATH": folder, "PYTHONDONTWRITEBYTECODE": "1"}):
                result = prepare.probe_torch(True)
                self.assertEqual(result["status"], "failed")
                self.assertIn("CUDA 12.4", result["reason"])
                cuda = """from types import SimpleNamespace
__version__='2.5.1+cu124'
version=SimpleNamespace(cuda='12.4')
cuda=SimpleNamespace(is_available=lambda:True, get_device_name=lambda i:'Synthetic GPU', synchronize=lambda:None)
class Tensor:
    def __matmul__(self, other): return self
    def sum(self): return self
    def item(self): return 512
ones=lambda *a,**k:Tensor()
"""
                (fixture / "torch.py").write_text(cuda)
                result = prepare.probe_torch(True)
                self.assertEqual(result["status"], "passed")
                self.assertEqual(result["device"], "Synthetic GPU")
                (fixture / "torch.py").write_text(cuda.replace("return 512", "return 511"))
                result = prepare.probe_torch(True)
                self.assertEqual(result["status"], "failed")
                self.assertIn("tensor operation", result["reason"])
