import asyncio
import base64
import io
import sys
import types
import unittest
from unittest.mock import AsyncMock, patch

from PIL import Image

from streamerbot.capture import ScreenCapture
from streamerbot.youtube import YouTubeChat


class CaptureTests(unittest.TestCase):
    def test_capture_is_resized_and_detects_unchanged_frames(self):
        shot = types.SimpleNamespace(size=(1920, 1080), rgb=bytes([70, 80, 90]) * (1920 * 1080))

        class Screens:
            monitors = [{}, {"left": 0}]

            def __enter__(self):
                return self

            def __exit__(self, *args):
                pass

            def grab(self, monitor):
                return shot

        capture = ScreenCapture()
        with patch.dict(sys.modules, {"mss": types.SimpleNamespace(mss=Screens)}):
            frame, first_change = capture.frame(1)
            _, second_change = capture.frame(1)
            self.assertEqual(Image.open(io.BytesIO(base64.b64decode(frame))).size, (960, 540))
            self.assertEqual(first_change, 1)
            self.assertEqual(second_change, 0)
            with self.assertRaisesRegex(RuntimeError, "monitor"):
                capture.frame(2)


class YouTubeTests(unittest.IsolatedAsyncioTestCase):
    async def test_initial_batch_is_skipped_and_only_new_text_messages_are_submitted(self):
        def item(identity, text):
            return {
                "id": identity,
                "snippet": {"type": "textMessageEvent", "displayMessage": text},
                "authorDetails": {"displayName": "Synthetic Viewer"},
            }

        responses = [
            {"items": [item("old", "historical")], "nextPageToken": "next", "pollingIntervalMillis": 1000},
            {
                "items": [item("old", "historical"), item("new", "hello")],
                "nextPageToken": "last",
                "pollingIntervalMillis": 1000,
            },
        ]

        class Response:
            status = 200

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

            async def json(self):
                return responses.pop(0)

        class Session:
            def get(self, *args, **kwargs):
                return Response()

        submit = AsyncMock()
        errors = AsyncMock()
        client = YouTubeChat(Session(), submit, errors)
        client._credentials = lambda _: types.SimpleNamespace(token="synthetic-token")
        calls = 0

        async def sleep(seconds):
            nonlocal calls
            self.assertGreaterEqual(seconds, 1)
            calls += 1
            if calls == 2:
                raise asyncio.CancelledError

        with patch("streamerbot.youtube.asyncio.sleep", sleep), self.assertRaises(asyncio.CancelledError):
            await client.run({"token_file": "synthetic-token.json", "live_chat_id": "synthetic-chat"})
        submit.assert_awaited_once_with("Synthetic Viewer", "hello", source="youtube")
        errors.assert_not_awaited()
