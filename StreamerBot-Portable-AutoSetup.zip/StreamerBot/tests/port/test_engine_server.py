import asyncio
import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock

import aiohttp
from aiohttp.test_utils import TestClient, TestServer

from streamerbot.config import DEFAULTS, ConfigStore
from streamerbot.engine import Engine
from streamerbot.memory import Memory
from streamerbot.providers import Providers
from streamerbot.server import create_app
from streamerbot.speech import Speech


class EngineServerTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.store = ConfigStore(Path(self.directory.name))
        self.memory = Memory(Path(self.directory.name) / "test.sqlite3")
        self.session = aiohttp.ClientSession()
        self.providers = Providers(self.session)
        self.providers.complete = AsyncMock(side_effect=AssertionError("Demo must not use a provider"))
        self.engine = Engine(self.store, self.memory, self.providers)
        self.client = TestClient(
            TestServer(create_app(self.engine, shutdown=asyncio.Event(), owner_token="synthetic-owner"))
        )
        await self.client.start_server()
        self.headers = {"X-StreamerBot-Client": "dashboard"}

    async def asyncTearDown(self):
        await self.engine.stop()
        await self.client.close()
        await self.session.close()
        self.memory.close()
        self.directory.cleanup()

    async def post(self, path, body=None, headers=None):
        return await self.client.post(
            path, json={} if body is None else body, headers=self.headers if headers is None else headers
        )

    async def test_demo_session_caption_events_and_idempotent_lifecycle(self):
        socket = await self.client.ws_connect("/api/events")
        snapshot = await socket.receive_json()
        self.assertEqual(snapshot["kind"], "snapshot")
        self.assertEqual((await self.post("/api/session/start")).status, 200)
        self.assertEqual((await self.post("/api/session/start")).status, 200)
        received = []
        async with asyncio.timeout(3):
            while "speech_start" not in received:
                received.append((await socket.receive_json())["kind"])
        self.assertIn("observation", received)
        self.assertIn("commentary", received)
        self.providers.complete.assert_not_awaited()
        await self.engine.stop()
        self.assertFalse(self.engine.running)
        self.assertFalse(self.engine.speaking)
        self.assertFalse(self.engine.tasks)
        self.assertEqual((await self.post("/api/session/stop")).status, 200)
        await socket.close()

    async def test_request_boundaries_and_no_cors(self):
        self.assertEqual((await self.post("/api/session/start", headers={})).status, 403)
        hostile = {**self.headers, "Origin": "https://evil.example"}
        self.assertEqual((await self.post("/api/session/start", headers=hostile)).status, 403)
        self.assertEqual(
            (await self.client.get("/api/settings", headers={"Host": "evil.example"})).status, 403
        )
        response = await self.client.options("/api/session/start", headers={"Origin": "https://evil.example"})
        self.assertNotIn("Access-Control-Allow-Origin", response.headers)

    async def test_live_start_requires_models_and_credentials(self):
        self.store.update({"mode": "live"})
        response = await self.post("/api/session/start")
        self.assertEqual(response.status, 400)
        self.assertIn("commentary model", (await response.json())["error"])
        self.assertFalse(self.engine.running)

    async def test_settings_cannot_change_during_session(self):
        await self.engine.start()
        response = await self.client.put("/api/settings", json={"game_name": "Changed"}, headers=self.headers)
        self.assertEqual(response.status, 400)
        self.assertEqual(self.store.value["game_name"], "My game")

    async def test_chat_reaction_and_mute(self):
        self.assertEqual((await self.post("/api/chat", {"text": "hello"})).status, 400)
        await self.engine.start()
        self.assertEqual((await self.post("/api/chat", {"author": "Viewer", "text": "hello"})).status, 200)
        self.assertEqual((await self.post("/api/reaction", {"kind": "win"})).status, 200)
        self.assertEqual((await self.post("/api/reaction", {"kind": "unknown"})).status, 400)
        self.assertEqual((await self.post("/api/mute", {"muted": "yes"})).status, 400)
        self.assertEqual((await self.post("/api/mute", {"muted": True})).status, 200)
        self.assertTrue(self.engine.muted)
        self.assertFalse(self.engine.speaking)

    async def test_stop_cancels_inflight_generation_without_late_commentary(self):
        self.store.value["mode"] = "live"
        self.store.value["capture"]["enabled"] = False
        provider = self.store.value["providers"][-1]
        provider.update(enabled=True, model="synthetic-model")
        entered = asyncio.Event()

        async def wait_forever(*args):
            entered.set()
            await asyncio.Event().wait()

        self.providers.comment = wait_forever
        await self.engine.start()
        await self.engine.reaction("win")
        await asyncio.wait_for(entered.wait(), timeout=1)
        await asyncio.wait_for(self.engine.stop(), timeout=1)
        self.assertFalse(any(e["kind"] == "commentary" for e in self.engine.log))

    async def test_slow_subscribers_are_bounded(self):
        queue = asyncio.Queue(maxsize=2)
        self.engine.listeners.add(queue)
        for i in range(20):
            await self.engine.publish("notice", {"text": str(i)})
        self.assertEqual(queue.qsize(), 2)
        self.assertEqual((await queue.get())["payload"]["text"], "18")

    async def test_settings_redaction_and_owner_shutdown(self):
        providers = copy.deepcopy(DEFAULTS["providers"])
        providers[0]["keys"] = ["synthetic-secret"]
        self.store.update({"providers": providers})
        response = await self.client.get("/api/settings")
        self.assertNotIn("synthetic-secret", await response.text())
        self.assertEqual((await self.post("/api/shutdown")).status, 403)
        self.assertEqual(
            (
                await self.post(
                    "/api/shutdown", headers={**self.headers, "X-StreamerBot-Owner": "synthetic-owner"}
                )
            ).status,
            200,
        )

    async def test_history_is_scoped_and_static_paths_are_not_exposed(self):
        self.memory.add("My game", "commentary", {"text": "Visible"})
        self.memory.add("Other game", "commentary", {"text": "Hidden"})
        response = await self.client.get("/api/history")
        body = await response.text()
        self.assertIn("Visible", body)
        self.assertNotIn("Hidden", body)
        self.assertEqual((await self.client.get("/assets/config.py")).status, 404)
        self.assertEqual((await self.client.get("/avatar")).status, 200)
        response = await self.client.get("/overlay")
        self.assertEqual(response.status, 200)
        self.assertIn("script-src 'self'", response.headers["Content-Security-Policy"])

    async def test_preview_cannot_switch_to_live_or_add_credentials(self):
        preview = TestClient(TestServer(create_app(self.engine, public_preview=True, demo_locked=True)))
        await preview.start_server()
        try:
            for data in [{"mode": "live"}, {"providers": []}, {"youtube": {"enabled": True}}]:
                response = await preview.put("/api/settings", json=data, headers=self.headers)
                self.assertEqual(response.status, 400)
        finally:
            await preview.close()

    async def test_invalid_request_shapes_return_400(self):
        for path, value in [
            ("/api/chat", []),
            ("/api/chat", {"text": 1}),
            ("/api/reaction", {"kind": []}),
            ("/api/mute", None),
        ]:
            response = await self.client.post(
                path, data=json.dumps(value), headers={**self.headers, "Content-Type": "application/json"}
            )
            self.assertEqual(response.status, 400)

    async def test_import_is_explicit_non_overwriting_and_redacted(self):
        old = {"game_name": "Imported game", "groq_keys": ["synthetic-import-key"]}
        response = await self.post("/api/import", {"name": "legacy.json", "settings": old})
        self.assertEqual(response.status, 200)
        self.assertNotIn("synthetic-import-key", await response.text())
        self.assertEqual(self.store.value["game_name"], "Imported game")
        self.assertEqual(
            (await self.post("/api/import", {"name": "again.json", "settings": old})).status, 400
        )

    async def test_interrupt_discards_inflight_commentary(self):
        self.store.value["mode"] = "live"
        self.store.value["capture"]["enabled"] = False
        self.store.value["providers"][-1].update(enabled=True, model="synthetic-model")
        entered, release = asyncio.Event(), asyncio.Event()

        async def delayed(*args):
            entered.set()
            await release.wait()
            return "An outdated line"

        self.providers.comment = delayed
        await self.engine.start()
        await self.engine.reaction("win")
        await asyncio.wait_for(entered.wait(), 1)
        await self.engine.interrupt()
        release.set()
        await asyncio.sleep(0.01)
        self.assertFalse(any(e["kind"] == "commentary" for e in self.engine.log))


class SpeechTests(unittest.IsolatedAsyncioTestCase):
    async def test_urgent_speech_interrupts_current_and_mute_clears_output(self):
        events = []
        entered = asyncio.Event()
        released = asyncio.Event()

        async def publish(kind, payload):
            events.append((kind, payload))

        speech = Speech(publish, AsyncMock())

        async def fake_speak(text, emotion, config):
            events.append(("started", {"text": text}))
            if text == "ordinary":
                entered.set()
                await asyncio.Event().wait()
            else:
                released.set()

        speech._speak = fake_speak
        speech.start()
        try:
            speech.enqueue("ordinary", "neutral", 3, {})
            await asyncio.wait_for(entered.wait(), 1)
            speech.enqueue("urgent", "hype", 1, {})
            await asyncio.wait_for(released.wait(), 1)
            await speech.interrupt()
            self.assertEqual([p["text"] for k, p in events if k == "started"], ["ordinary", "urgent"])
            self.assertEqual(speech.pending, [])
        finally:
            await speech.close()

    async def test_queue_bound_and_expiration(self):
        speech = Speech(AsyncMock(), AsyncMock())
        spoken = []

        async def speak(text, emotion, config):
            spoken.append(text)

        speech._speak = speak
        for i in range(20):
            speech.enqueue(f"stale {i}", "neutral", 4, {}, ttl=-1)
        self.assertEqual(len(speech.pending), 8)
        speech.enqueue("urgent", "hype", 1, {})
        self.assertEqual(len(speech.pending), 8)
        speech.start()
        try:
            async with asyncio.timeout(1):
                while speech.pending or speech.current:
                    await asyncio.sleep(0.01)
            self.assertEqual(spoken, ["urgent"])
        finally:
            await speech.close()
