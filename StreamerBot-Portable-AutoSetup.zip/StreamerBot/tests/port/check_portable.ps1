# Standard-library-only provisioning checks. No downloads or Windows binaries run.
$ErrorActionPreference = 'Stop'
$Repository = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$Library = Join-Path $Repository 'windows/Portable-Runtime.ps1'
$Scratch = Join-Path ([IO.Path]::GetTempPath()) ('streamerbot-portable-check-' + [guid]::NewGuid())
New-Item -ItemType Directory -Path $Scratch | Out-Null
$script:Passed = 0
function Assert([bool]$Condition, [string]$Message) { if (-not $Condition) { throw $Message } }
function Assert-Throws([scriptblock]$Action, [string]$Message) {
    $caught = $false
    try { & $Action } catch {
        $caught = $true
        if ($Message -and $_.Exception.Message -notlike "*$Message*") { throw }
    }
    Assert $caught 'Expected operation to fail.'
}
function Check([string]$Name, [scriptblock]$Action) {
    & $Action
    $script:Passed++
    Write-Host "PASS: $Name"
}
try {
    Check 'Runtime probes accept official version suffixes and reject mismatched versions' {
        . $Library
        $tool = Join-Path $Scratch 'probe.ps1'
        Set-Content $tool 'Write-Output "uv 0.12.19 (x86_64-pc-windows-msvc)"; $global:LASTEXITCODE = 0'
        Assert (Test-PortableTool $tool @() -ExpectedOutput 'uv 0.12.19') 'Official version suffix rejected.'
        Assert (-not (Test-PortableTool $tool @() -ExpectedOutput 'uv 0.12.18')) 'Wrong version accepted.'
        Assert (Test-PortableTool $tool @()) 'Unversioned health probe failed.'
        Set-Content $tool '$global:LASTEXITCODE = 1'
        Assert (-not (Test-PortableTool $tool @())) 'Failed process accepted.'
    }
    Check 'Verified download cache is reused without network' {
        . $Library
        $file = Join-Path $Scratch 'cached.zip'
        [IO.File]::WriteAllText($file, 'verified bytes')
        $spec = [pscustomobject]@{url='https://example.test/runtime.zip'; algorithm='SHA256'; hash=(Get-FileHash $file).Hash}
        function Invoke-WebRequest { throw 'Network must not be called for a valid archive.' }
        Receive-PortableArchive $spec $file
    }
    Check 'Corrupt cache is replaced; partial network failure retries' {
        . $Library
        $file = Join-Path $Scratch 'retried.zip'
        $good = Join-Path $Scratch 'good.zip'
        [IO.File]::WriteAllText($good, 'correct replacement')
        [IO.File]::WriteAllText($file, 'corrupt cache')
        $spec = [pscustomobject]@{url='https://example.test/runtime.zip'; algorithm='SHA256'; hash=(Get-FileHash $good).Hash}
        $script:Attempts = 0
        function Start-Sleep { param($Seconds) }
        function Invoke-WebRequest {
            param([switch]$UseBasicParsing, $Uri, $OutFile, $TimeoutSec)
            $script:Attempts++
            if ($script:Attempts -eq 1) {
                [IO.File]::WriteAllText($OutFile, 'partial')
                throw 'Synthetic connection failure.'
            }
            [IO.File]::WriteAllText($OutFile, 'correct replacement')
        }
        Receive-PortableArchive $spec $file
        Assert ($script:Attempts -eq 2) 'Download did not retry once.'
        Assert ((Get-FileHash $file).Hash -eq $spec.hash) 'Replacement content differs.'
        Assert (-not (Test-Path "$file.partial")) 'Partial download was retained.'
    }
    Check 'Hash mismatch never reaches runtime extraction' {
        . $Library
        $file = Join-Path $Scratch 'rejected.zip'
        $spec = [pscustomobject]@{url='https://example.test/runtime.zip'; algorithm='SHA256'; hash=('0' * 64)}
        $script:Attempts = 0
        function Start-Sleep { param($Seconds) }
        function Invoke-WebRequest {
            param([switch]$UseBasicParsing, $Uri, $OutFile, $TimeoutSec)
            $script:Attempts++
            [IO.File]::WriteAllText($OutFile, 'tampered')
        }
        Assert-Throws { Receive-PortableArchive $spec $file } 'checksum'
        Assert ($script:Attempts -eq 3) 'Download retry bound differs.'
        Assert (-not (Test-Path $file) -and -not (Test-Path "$file.partial")) 'Rejected download was retained.'
    }
    Check 'Non-HTTPS download is rejected' {
        . $Library
        $spec = [pscustomobject]@{url='http://example.test/runtime.zip'; algorithm='SHA256'; hash=('0' * 64)}
        Assert-Throws { Receive-PortableArchive $spec (Join-Path $Scratch 'http.zip') } 'HTTPS'
    }
    Check 'ZIP extraction replaces runtime only after successful extraction' {
        . $Library
        $source = Join-Path $Scratch 'source'
        $destination = Join-Path $Scratch 'installed'
        New-Item -ItemType Directory -Path $source, $destination | Out-Null
        Set-Content (Join-Path $source 'tool.txt') 'new runtime'
        Set-Content (Join-Path $destination 'old.txt') 'old runtime'
        $archive = Join-Path $Scratch 'valid.zip'
        Compress-Archive -Path (Join-Path $source '*') -DestinationPath $archive
        Expand-PortableZip $archive $destination
        Assert (Test-Path (Join-Path $destination 'tool.txt')) 'New runtime missing.'
        Assert (-not (Test-Path (Join-Path $destination 'old.txt'))) 'Old runtime retained.'
        $bad = Join-Path $Scratch 'invalid.zip'
        Set-Content $bad 'not a zip'
        Assert-Throws { Expand-PortableZip $bad $destination } ''
        Assert (Test-Path (Join-Path $destination 'tool.txt')) 'Failed extraction removed the previous runtime.'
    }
    Check 'Source fingerprint ignores generated output and detects edits' {
        . $Library
        $root = Join-Path $Scratch 'fingerprint'
        New-Item -ItemType Directory -Path (Join-Path $root 'windows/bin'), (Join-Path $root 'streamerbot/__pycache__') -Force | Out-Null
        foreach ($name in @('pyproject.toml','uv.lock','requirements-port.txt','avatar.png','global.json','windows/Setup-Published.ps1','windows/App.cs','streamerbot/__main__.py')) {
            Set-Content -LiteralPath (Join-Path $root $name) 'original'
        }
        $first = Get-PortableBuildHash $root
        Set-Content (Join-Path $root 'windows/bin/Generated.cs') 'generated'
        Set-Content (Join-Path $root 'streamerbot/__pycache__/cached.py') 'cached'
        Assert ((Get-PortableBuildHash $root) -eq $first) 'Generated output changed fingerprint.'
        Set-Content (Join-Path $root 'windows/App.cs') 'modified'
        Assert ((Get-PortableBuildHash $root) -ne $first) 'Source edit did not change fingerprint.'
    }
    Check 'Desktop check detects missing files and stale build stamp' {
        . $Library
        $folder = Join-Path $Scratch 'desktop'
        New-Item -ItemType Directory -Path (Join-Path $folder 'Worker/streamerbot') -Force | Out-Null
        foreach ($name in @('StreamerBot.Desktop.exe','Microsoft.UI.Xaml.dll','StreamerBot.Desktop.dll','StreamerBot.Desktop.runtimeconfig.json','Worker/streamerbot/__main__.py')) {
            Set-Content -LiteralPath (Join-Path $folder $name) 'synthetic'
        }
        $desktop = Join-Path $folder 'StreamerBot.Desktop.exe'
        $stamp = Join-Path $folder 'stamp'
        Set-Content $stamp 'current'
        Assert (Test-PortableDesktop $desktop $stamp 'current') 'Complete desktop rejected.'
        Assert (-not (Test-PortableDesktop $desktop $stamp 'stale')) 'Stale desktop accepted.'
        Remove-Item (Join-Path $folder 'Microsoft.UI.Xaml.dll')
        Assert (-not (Test-PortableDesktop $desktop $stamp 'current')) 'Missing DLL accepted.'
    }
    Check 'Python package repair retries once and avoids Python registry/bin installation' {
        . $Library
        $script:Calls = [Collections.Generic.List[object]]::new()
        $script:ImportChecks = 0
        function Test-PortableTool {
            param($File, $Arguments, $ExpectedOutput)
            if (($Arguments -join ' ') -like '*from streamerbot import server*') {
                $script:ImportChecks++
                return ($script:ImportChecks -gt 1)
            }
            return $true
        }
        function Find-PortablePython { param($Uv, $Version) return 'synthetic-base-python' }
        function Invoke-PortableTool { param($File, $Arguments, $ExpectedOutput) $script:Calls.Add(@($Arguments)) }
        $manifest = [pscustomobject]@{python='3.12.12'; uv=[pscustomobject]@{version='0.12.19'}}
        $python = Initialize-PortablePython $Repository (Join-Path $Scratch 'python') $manifest
        $installs = @($script:Calls | Where-Object { $_[0] -eq 'python' })
        Assert ($installs.Count -eq 1 -and $installs[0] -contains '--no-bin' -and $installs[0] -contains '--no-registry') 'Python would modify user installation.'
        $syncs = @($script:Calls | Where-Object { $_[0] -eq 'sync' })
        Assert ($syncs.Count -eq 2 -and $syncs[1] -contains '--reinstall') 'Package repair did not force reinstall.'
        Assert ($syncs[0] -contains '--frozen' -and $syncs[0] -contains '--no-dev') 'Locked production install was not used.'
        Assert ($python -like '*venv*python.exe') 'Unexpected Python location.'
    }
    Check 'Broken virtual environment is recreated only in the portable folder' {
        . $Library
        $script:Calls = [Collections.Generic.List[object]]::new()
        function Test-PortableTool { param($File, $Arguments, $ExpectedOutput) return ($File -notlike '*venv*python.exe' -or ($Arguments -join ' ') -like '*from streamerbot import server*') }
        function Find-PortablePython { param($Uv, $Version) return 'synthetic-base-python' }
        function Invoke-PortableTool { param($File, $Arguments, $ExpectedOutput) $script:Calls.Add(@($Arguments)) }
        $null = Initialize-PortablePython $Repository (Join-Path $Scratch 'broken') ([pscustomobject]@{python='3.12.12'; uv=[pscustomobject]@{version='0.12.19'}})
        $venvs = @($script:Calls | Where-Object { $_[0] -eq 'venv' })
        Assert ($venvs.Count -eq 1 -and $venvs[0] -contains '--clear') 'Broken environment was not recreated.'
        Assert ($venvs[0][-1] -eq (Join-Path $Scratch 'broken/venv')) 'Repair would target another environment.'
    }
    Check 'A damaged Python runtime lookup triggers a reinstall and fresh lookup' {
        . $Library
        $script:Finds = 0
        $script:Reinstalls = 0
        function Test-PortableTool { param($File, $Arguments, $ExpectedOutput) return $true }
        function Find-PortablePython {
            param($Uv, $Version)
            $script:Finds++
            if ($script:Finds -eq 1) { throw 'Damaged interpreter cannot be queried' }
            return 'synthetic-base-python'
        }
        function Invoke-PortableTool {
            param($File, $Arguments)
            if ($Arguments[0] -eq 'python' -and $Arguments -contains '--reinstall') { $script:Reinstalls++ }
        }
        $null = Initialize-PortablePython $Repository (Join-Path $Scratch 'base-repair') ([pscustomobject]@{python='3.12.12'; uv=[pscustomobject]@{version='0.12.19'}})
        Assert ($script:Finds -eq 2 -and $script:Reinstalls -eq 1) 'Damaged Python lookup not repaired.'
    }
    Check 'Failed dependency synchronization retries with a full reinstall' {
        . $Library
        $script:Syncs = 0
        function Test-PortableTool { param($File, $Arguments, $ExpectedOutput) return $true }
        function Find-PortablePython { param($Uv, $Version) return 'synthetic-base-python' }
        function Invoke-PortableTool {
            param($File, $Arguments)
            if ($Arguments[0] -eq 'sync') {
                $script:Syncs++
                if ($script:Syncs -eq 1) { throw 'Synthetic damaged dependency state' }
                Assert ($Arguments -contains '--reinstall') 'Retry did not request reinstall.'
            }
        }
        $null = Initialize-PortablePython $Repository (Join-Path $Scratch 'sync-repair') ([pscustomobject]@{python='3.12.12'; uv=[pscustomobject]@{version='0.12.19'}})
        Assert ($script:Syncs -eq 2) 'Dependency synchronization not retried.'
    }
    Check 'Persistent Python import failure is surfaced after one reinstall' {
        . $Library
        function Test-PortableTool { param($File, $Arguments, $ExpectedOutput) return (($Arguments -join ' ') -notlike '*from streamerbot import server*') }
        function Find-PortablePython { param($Uv, $Version) return 'synthetic-base-python' }
        function Invoke-PortableTool { param($File, $Arguments, $ExpectedOutput) }
        Assert-Throws { Initialize-PortablePython $Repository (Join-Path $Scratch 'failed') ([pscustomobject]@{python='3.12.12'; uv=[pscustomobject]@{version='0.12.19'}}) } 'still fail after repair'
    }
    Check 'Desktop preparation failure falls back to browser with portable Python' {
        . (Join-Path $Repository 'Start-Portable.ps1')
        $root = Join-Path $Scratch 'fallback'
        New-Item -ItemType Directory -Path (Join-Path $root 'windows') -Force | Out-Null
        Set-Content (Join-Path $root 'windows/portable-runtimes.json') '{}'
        Set-Content (Join-Path $root 'Launch-Dashboard.ps1') 'param($Python, [switch]$OpenBrowser); if ($Python -ne "portable-python" -or -not $OpenBrowser) { throw "Wrong dashboard arguments" }; Set-Content (Join-Path $PSScriptRoot "dashboard-started") "yes"'
        function Assert-PortablePlatform { param($Root) }
        function Initialize-PortablePython { param($Root,$HomePath,$Manifest,[switch]$Repair) return 'portable-python' }
        function Initialize-PortableDesktop { param($Root,$HomePath,$Manifest,[switch]$Repair) throw 'Synthetic build failure' }
        Start-PortableStudio $root -Studio
        Assert (Test-Path (Join-Path $root 'dashboard-started')) 'Dashboard fallback not invoked.'
        # Lock must be released even after preparation failure or launch completion.
        $lock = [IO.File]::Open((Join-Path $root '.portable/launcher.lock'), 'Open', 'ReadWrite', 'None')
        $lock.Dispose()
        Assert-Throws { Start-PortableStudio $root -Studio -PrepareOnly } 'Synthetic build failure'
    }
    Check 'WebView2 extraction, sandbox ACLs and missing-file repair' {
        . $Library
        $portableHome = Join-Path $Scratch 'webview-check'
        New-Item -ItemType Directory -Path (Join-Path $portableHome 'downloads') -Force | Out-Null
        $oldSystemRoot = $env:SystemRoot
        $env:SystemRoot = Join-Path $Scratch 'system'
        $script:Downloads = 0
        $script:AclChecks = 0
        function Receive-PortableArchive { param($Spec, $Destination) $script:Downloads++ }
        function Invoke-PortableTool {
            param($File, $Arguments)
            if ((Split-Path -Leaf $File) -eq 'expand.exe') {
                $folder = Join-Path $Arguments[2] 'Microsoft.WebView2.FixedVersionRuntime.synthetic.x64'
                New-Item -ItemType Directory -Path $folder -Force | Out-Null
                Set-Content (Join-Path $folder 'msedgewebview2.exe') 'synthetic'
                Set-Content (Join-Path $folder 'msedge.dll') 'synthetic'
            } else {
                Assert ($Arguments -contains '*S-1-15-2-2:(OI)(CI)(RX)' -and $Arguments -contains '*S-1-15-2-1:(OI)(CI)(RX)') 'Required sandbox ACLs missing.'
                $script:AclChecks++
            }
        }
        try {
            $spec = [pscustomobject]@{version='synthetic'}
            $folder = Initialize-PortableWebView $portableHome $spec
            $null = Initialize-PortableWebView $portableHome $spec
            Assert ($script:Downloads -eq 1 -and $script:AclChecks -eq 2) 'Cached runtime not reused.'
            Remove-Item (Join-Path $folder 'msedge.dll')
            $null = Initialize-PortableWebView $portableHome $spec
            Assert ($script:Downloads -eq 2) 'Missing WebView2 DLL not repaired.'
        } finally { $env:SystemRoot = $oldSystemRoot }
    }
    Check 'Native launch failure falls back and a running launcher holds its lock' {
        . (Join-Path $Repository 'Start-Portable.ps1')
        $root = Join-Path $Scratch 'native'
        New-Item -ItemType Directory -Path (Join-Path $root 'windows') -Force | Out-Null
        Set-Content (Join-Path $root 'windows/portable-runtimes.json') '{"webview2":{}}'
        Set-Content (Join-Path $root 'Launch-Studio.ps1') 'throw "Synthetic native runtime failure"'
        Set-Content (Join-Path $root 'Launch-Dashboard.ps1') 'param($Python, [switch]$OpenBrowser); Set-Content (Join-Path $PSScriptRoot "fallback-started") "yes"'
        function Assert-PortablePlatform { param($Root) }
        function Initialize-PortablePython { param($Root,$HomePath,$Manifest,[switch]$Repair) return 'portable-python' }
        function Initialize-PortableDesktop { param($Root,$HomePath,$Manifest,[switch]$Repair) return 'desktop.exe' }
        function Initialize-PortableWebView { param($HomePath,$Spec,[switch]$Repair) return 'portable-webview' }
        Start-PortableStudio $root -Studio
        Assert (Test-Path (Join-Path $root 'fallback-started')) 'Native failure did not invoke fallback.'
        $lock = [IO.File]::Open((Join-Path $root '.portable/launcher.lock'), 'Open', 'ReadWrite', 'None')
        try { Assert-Throws { Start-PortableStudio $root -Studio } 'Another portable launcher' }
        finally { $lock.Dispose() }
    }
    Check 'Default launch preserves original profiles and never invokes Studio' {
        . (Join-Path $Repository 'Start-Portable.ps1')
        $root = Join-Path $Scratch 'original-default'
        New-Item -ItemType Directory -Path (Join-Path $root 'windows') -Force | Out-Null
        Set-Content (Join-Path $root 'windows/portable-runtimes.json') '{}'
        Set-Content (Join-Path $root 'bot_config.json') '{"hk_custom_15":"ctrl+alt+9","tts_mode":"bark","untouched_setting":true}'
        $before = (Get-FileHash (Join-Path $root 'bot_config.json')).Hash
        Set-Content (Join-Path $root 'Launch-Windows.ps1') 'param($Python); if ($Python -ne "original-python") { throw "Wrong Python" }; Set-Content (Join-Path $PSScriptRoot "original-opened") "yes"'
        function Assert-PortablePlatform { param($Root) }
        function Initialize-PortableOriginal { param($Root,$HomePath,$Manifest,[switch]$Repair) return 'original-python' }
        function Initialize-PortablePython { throw 'Experimental preparation must not run by default' }
        Start-PortableStudio $root
        Assert (Test-Path (Join-Path $root 'original-opened')) 'Default did not open the original app.'
        Assert ((Get-FileHash (Join-Path $root 'bot_config.json')).Hash -eq $before) 'Original profile changed during preparation.'
    }
    Check 'Original setup failure is surfaced without a reduced-dashboard replacement' {
        . (Join-Path $Repository 'Start-Portable.ps1')
        $root = Join-Path $Scratch 'original-failure'
        New-Item -ItemType Directory -Path (Join-Path $root 'windows') -Force | Out-Null
        Set-Content (Join-Path $root 'windows/portable-runtimes.json') '{}'
        function Assert-PortablePlatform { param($Root) }
        function Initialize-PortableOriginal { param($Root,$HomePath,$Manifest,[switch]$Repair) throw 'Original dependency failure' }
        function Initialize-PortablePython { throw 'Experimental fallback must not run' }
        Assert-Throws { Start-PortableStudio $root } 'Original dependency failure'
    }
    Write-Host "Portable provisioning checks passed: $script:Passed"
} finally {
    Remove-Item -LiteralPath $Scratch -Recurse -Force -ErrorAction SilentlyContinue
}
