import copy
import json
import unittest

import aiohttp
from aiohttp import web
from aiohttp.test_utils import TestServer

from streamerbot.config import DEFAULTS
from streamerbot.providers import ProviderError, Providers, parse_observation


class ProviderTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.calls = []
        self.handler = None

        async def completion(request):
            body = await request.json()
            self.calls.append({"body": body, "key": request.headers.get("Authorization")})
            return await self.handler(request, body)

        app = web.Application()
        app.router.add_post("/chat/completions", completion)
        self.server = TestServer(app)
        await self.server.start_server()
        self.session = aiohttp.ClientSession()
        self.providers = Providers(self.session)
        self.config = copy.deepcopy(DEFAULTS)
        self.config["providers"] = [
            {
                "id": "local",
                "base_url": str(self.server.make_url("/")),
                "model": "synthetic-model",
                "vision_model": "synthetic-vision",
                "keys": [],
                "enabled": True,
            }
        ]

    async def asyncTearDown(self):
        await self.session.close()
        await self.server.close()

    async def test_completion_and_vision_image_transport(self):
        async def handler(request, body):
            return web.json_response(
                {
                    "choices": [
                        {
                            "message": {
                                "content": json.dumps(
                                    {
                                        "facts": ["A health bar is visible."],
                                        "noteworthy": True,
                                        "emotion": "panic",
                                    }
                                )
                            }
                        }
                    ]
                }
            )

        self.handler = handler
        facts = await self.providers.observe(self.config, "synthetic-base64-image")
        self.assertEqual(facts["emotion"], "panic")
        body = self.calls[0]["body"]
        self.assertEqual(body["model"], "synthetic-vision")
        self.assertTrue(
            body["messages"][0]["content"][1]["image_url"]["url"].startswith("data:image/jpeg;base64,")
        )

    async def test_key_rotation_and_cooldown(self):
        self.config["providers"][0]["keys"] = ["synthetic-exhausted", "synthetic-working"]

        async def handler(request, body):
            if request.headers["Authorization"].endswith("exhausted"):
                return web.json_response(
                    {"error": "secret response"}, status=429, headers={"Retry-After": "10"}
                )
            return web.json_response({"choices": [{"message": {"content": "A grounded reply."}}]})

        self.handler = handler
        self.assertEqual(await self.providers.complete(self.config, []), "A grounded reply.")
        await self.providers.complete(self.config, [])
        self.assertEqual(len(self.calls), 3)
        self.assertEqual(self.calls[-1]["key"], "Bearer synthetic-working")

    async def test_fallback_provider_and_sanitized_errors(self):
        first = self.config["providers"][0]
        first["keys"] = ["synthetic-rejected"]
        second = copy.deepcopy(first)
        second.update(id="groq", keys=["synthetic-working"])
        self.config["providers"].append(second)

        async def handler(request, body):
            if request.headers["Authorization"].endswith("rejected"):
                return web.Response(status=401, text="synthetic-rejected private-provider-body")
            return web.json_response({"choices": [{"message": {"content": "Fallback worked."}}]})

        self.handler = handler
        self.assertEqual(await self.providers.complete(self.config, []), "Fallback worked.")
        self.assertEqual(self.providers.last["provider"], "groq")
        self.config["providers"] = [first]
        with self.assertRaises(ProviderError) as error:
            await self.providers.complete(self.config, [])
        self.assertNotIn("synthetic-rejected", str(error.exception))
        self.assertNotIn("private-provider-body", str(error.exception))

    async def test_chunked_response_is_read_to_completion(self):
        async def handler(request, body):
            response = web.StreamResponse(headers={"Content-Type": "application/json"})
            await response.prepare(request)
            for chunk in [b'{"choices":', b'[{"message":', b'{"content":"Complete."}}]}']:
                await response.write(chunk)
            await response.write_eof()
            return response

        self.handler = handler
        self.assertEqual(await self.providers.complete(self.config, []), "Complete.")

    async def test_no_redirects_with_provider_credentials(self):
        async def handler(request, body):
            return web.Response(status=307, headers={"Location": "https://example.invalid/credentials"})

        self.handler = handler
        with self.assertRaises(ProviderError):
            await self.providers.complete(self.config, [])
        self.assertEqual(len(self.calls), 1)

    async def test_vision_budget_counts_fallback_requests(self):
        self.config["capture"]["max_calls_per_min"] = 1
        first = self.config["providers"][0]
        second = copy.deepcopy(first)
        second.update(id="groq", keys=["synthetic-key"])
        self.config["providers"].append(second)

        async def handler(request, body):
            return web.Response(status=503)

        self.handler = handler
        with self.assertRaisesRegex(ProviderError, "limit reached"):
            await self.providers.complete(self.config, [], vision=True)
        self.assertEqual(len(self.calls), 1)

    async def test_commentary_grounding_prompt_and_word_limit(self):
        async def handler(request, body):
            return web.json_response(
                {"choices": [{"message": {"content": "one two three four five six seven"}}]}
            )

        self.handler = handler
        self.config["max_words"] = 5
        line = await self.providers.comment(self.config, {"facts": ["Checkpoint reached"]}, [])
        self.assertEqual(line, "one two three four five")
        prompt = self.calls[0]["body"]["messages"][0]["content"]
        self.assertIn("never invent", prompt)
        self.assertIn("answer honestly", prompt)

    def test_observer_rejects_invalid_shapes(self):
        for data in [
            "[]",
            "not json",
            '{"facts":"boss","noteworthy":true}',
            '{"facts":[1],"noteworthy":true}',
            '{"facts":[],"noteworthy":"yes"}',
        ]:
            with self.subTest(data=data), self.assertRaises(ProviderError):
                parse_observation(data)
        valid = parse_observation('```json\n{"facts":[],"noteworthy":false,"emotion":[]}\n```')
        self.assertEqual(valid["emotion"], "neutral")
