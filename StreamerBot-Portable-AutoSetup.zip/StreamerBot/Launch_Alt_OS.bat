@echo off
TITLE Streamer Bot - Secondary OS Launcher

:: 1. Auto-Request Administrator Privileges
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process '%~dpnx0' -Verb RunAs"
    exit /b
)

:: 2. Setup the AI Model Cache Portal (Symlink)
echo Checking AI Model Cache Portal...
if not exist "C:\Users\Edu\.cache" (
    echo Creating cache portal to I: drive...
    mklink /J "C:\Users\Edu\.cache" "I:\Users\Edu\.cache"
) else (
    echo Cache portal already exists or folder is present.
)

:: 3. Navigate to your Bot Directory
cd /d "H:\Streamer_Bot"

:: 4. Setup the Alternative Virtual Environment
if not exist "venv_alt\Scripts\activate.bat" (
    echo Creating new virtual environment with Python 3.11...
    py -3.11 -m venv venv_alt
)

:: 5. Activate Environment and Verify Packages
echo Activating environment...
call venv_alt\Scripts\activate.bat

echo Checking requirements...
pip install -r requirements.txt

:: 6. Launch the Application
echo.
echo ========================================
echo Launching Streamer Bot Controller...
echo ========================================
python controller.py

pause