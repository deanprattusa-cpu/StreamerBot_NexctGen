[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
try {
    if ([Environment]::OSVersion.Platform -ne 'Win32NT' -or -not [Environment]::Is64BitProcess) {
        throw 'CUDA repair requires 64-bit Windows PowerShell.'
    }
    $privateHome = Join-Path $PSScriptRoot '.portable/original'
    $python = Join-Path $privateHome 'venv/Scripts/python.exe'
    if (-not (Test-Path -LiteralPath $python)) {
        Write-Host 'Preparing the missing private environment first...'
        $env:STREAMERBOT_GPU_MODE = 'cuda'
        & (Join-Path $PSScriptRoot 'Start-Portable.ps1') -PrepareOnly
        if ($LASTEXITCODE -ne 0) { throw 'Private preparation failed. See the setup output.' }
    }
    # The same venv is used by StreamerBot.exe. Never target a global/user Python installation.
    Write-Host ("Repairing CUDA in: " + $python)
    & $python -u (Join-Path $PSScriptRoot 'windows/prepare_original.py') --state-dir $privateHome --repair-gpu --gpu-mode cuda
    if ($LASTEXITCODE -ne 0) { throw 'CUDA package installation or real GPU tensor test failed. See .portable/original/gpu-report.json.' }
    Write-Host 'Verified CUDA PyTorch and a GPU tensor operation. Launch StreamerBot.exe from this folder.'
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
