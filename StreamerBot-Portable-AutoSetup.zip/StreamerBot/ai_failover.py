"""ai_failover: never-pause AI text backend for StreamerBot v1.

What it does
  * Tries the provider you selected first (Groq, Gemini, OpenRouter, SambaNova ...), then falls through
    a chain of other providers when one is rate-limited, down, out of quota, or its model was retired.
    Cerebras, Mistral and NVIDIA are new fallback-only providers (free tiers).
  * Rotates every API key of every provider. A 429 puts just that key+model on cooldown (it reads
    Retry-After / "try again in 1m3s"), so a rate-limited key is skipped instantly instead of the
    whole bot sleeping and retrying.
  * AUTO-HEAL: when a provider answers "model not found / decommissioned", it asks that provider's live
    /models list what exists right now, ranks the models (newest first, preferred families first),
    switches to the best one and remembers it (ai_failover_state.json). Also re-checks every few hours
    and runs a quick self-test of each provider at startup.
  * A hard time budget per reply, so the stream never freezes waiting on a dead backend.

Keys: the existing Groq/Gemini/OpenRouter/SambaNova key lists are reused. Extra keys (any provider)
live in ai_fallback.json, or in env vars like CEREBRAS_API_KEY (comma separated for several).
"""
import json
import os
import random
import re
import threading
import time

try:
    import requests
except ImportError:                                  # pragma: no cover
    requests = None

STATE_FILE = "ai_failover_state.json"
KEYS_FILE = "ai_fallback.json"

_EXCLUDE = (r"whisper|tts|embed|guard|moderat|orpheus|imagen|veo|audio|rerank|transcri|aqa|bison|gecko|"
            r"safety|playai|speech|live|dall|flux|sdxl|diffusion|ocr|robotics|computer-use|image|vision-only")

PROVIDERS = {
    "groq": dict(label="Groq", base="https://api.groq.com/openai/v1",
                 defaults=["openai/gpt-oss-20b", "openai/gpt-oss-120b", "llama-3.3-70b-versatile"],
                 prefer=[r"gpt-oss-120b", r"gpt-oss-20b", r"llama-3\.3-70b", r"llama-4", r"kimi", r"qwen"], exclude=_EXCLUDE),
    "cerebras": dict(label="Cerebras", base="https://api.cerebras.ai/v1",
                     defaults=["gpt-oss-120b", "llama-3.3-70b", "llama3.1-8b"],
                     prefer=[r"gpt-oss", r"llama-?3\.3", r"qwen", r"llama"], exclude=_EXCLUDE),
    "gemini": dict(label="Google Gemini", base="https://generativelanguage.googleapis.com/v1beta/openai",
                   defaults=["gemini-2.5-flash", "gemini-2.5-flash-lite"],
                   prefer=[r"gemini-[\d.]+-flash(?!-lite)", r"gemini-[\d.]+-flash-lite", r"gemini-[\d.]+-pro"],
                   exclude=_EXCLUDE + r"|gemma|learnlm|thinking"),
    "mistral": dict(label="Mistral", base="https://api.mistral.ai/v1",
                    defaults=["mistral-small-latest", "open-mistral-nemo"],
                    prefer=[r"mistral-small", r"mistral-medium", r"mistral-large", r"open-mistral"], exclude=_EXCLUDE + r"|codestral|pixtral|ministral-3b"),
    "sambanova": dict(label="SambaNova", base="https://api.sambanova.ai/v1",
                      defaults=["Meta-Llama-3.3-70B-Instruct", "gpt-oss-120b"],
                      prefer=[r"Llama-3\.3-70B", r"gpt-oss", r"DeepSeek-V3", r"Llama"], exclude=_EXCLUDE),
    "openrouter": dict(label="OpenRouter", base="https://openrouter.ai/api/v1", needs_key_for_models=False,
                       defaults=["meta-llama/llama-3.3-70b-instruct:free", "openai/gpt-oss-20b:free"],
                       prefer=[r"llama-3\.3-70b", r"gpt-oss", r"qwen", r"gemma", r"mistral"], exclude=_EXCLUDE),
    "nvidia": dict(label="NVIDIA NIM", base="https://integrate.api.nvidia.com/v1",
                   defaults=["meta/llama-3.3-70b-instruct", "meta/llama-3.1-70b-instruct"],
                   prefer=[r"llama-3\.3-70b", r"llama-3\.1-70b", r"nemotron", r"mistral"], exclude=_EXCLUDE + r"|vila|neva|kosmos|paligemma|deplot|fuyu"),
}
DEFAULT_ORDER = ["groq", "cerebras", "gemini", "mistral", "sambanova", "openrouter", "nvidia"]
FILLERS = ["Whoa!", "Let's go!", "Haha!", "Alright!", "Okay then."]


def _ver(s):
    return tuple(float(x) for x in re.findall(r"\d+(?:\.\d+)?", s)) or (0.0,)


def rank_models(provider, ids):
    """Live model ids -> best-first list: preferred families first, newest version first, previews last."""
    info = PROVIDERS[provider]
    ex = re.compile(info["exclude"], re.I)
    ids = [i for i in ids if i and not ex.search(i)]
    if provider == "openrouter":
        ids = [i for i in ids if i.endswith(":free")]
    out = []
    for pat in info["prefer"]:
        rx = re.compile(pat, re.I)
        hit = [i for i in ids if rx.search(i) and i not in out]
        hit.sort(key=lambda i: (("preview" in i.lower() or "exp" in i.lower()), tuple(-x for x in _ver(i))))
        out += hit
    return out + [i for i in ids if i not in out][:6]


def clean_reply(raw):
    """Same cleanup the original Groq path does: strip <think>, dig dialogue out of quotes, kill prompt echoes."""
    raw = raw or ""
    text = re.sub(r"<think>.*?(?:</think>|$)", "", raw, flags=re.DOTALL | re.IGNORECASE).strip()
    if not text:
        quotes = re.findall(r'"([^"]*)"', raw)
        text = quotes[-1] if quotes else raw.replace("<think>", "").replace("</think>", "").strip()
    if "What do I say on the microphone right now" in text or "SCENARIO:" in text:
        return random.choice(FILLERS)
    return text.strip()


def _retry_after(resp):
    """Seconds to wait, from the Retry-After header or Groq-style 'try again in 1m2.5s' text."""
    try:
        h = resp.headers.get("retry-after") or resp.headers.get("Retry-After")
        if h:
            return float(h)
    except Exception:
        pass
    body = ""
    try:
        body = resp.text or ""
    except Exception:
        pass
    m = re.search(r"try again in\s*(?:(\d+)h)?\s*(?:(\d+)m(?!s))?\s*(?:(\d+(?:\.\d+)?)s)?\s*(?:(\d+)ms)?", body, re.I)
    if m and any(m.groups()):
        h_, m_, s_, ms_ = m.groups()
        return int(h_ or 0) * 3600 + int(m_ or 0) * 60 + float(s_ or 0) + int(ms_ or 0) / 1000.0
    return None


class Failover:
    def __init__(self, model=None, base_dir=None, on_heal=None, budget=28.0, base_urls=None):
        self.model = model
        self.dir = base_dir or os.getcwd()
        self.on_heal = on_heal
        self.budget = budget
        self.bases = {p: i["base"] for p, i in PROVIDERS.items()}
        if base_urls:
            self.bases.update(base_urls)
        self.lock = threading.RLock()
        self.cool = {}            # (provider, key, model) -> until ; key "*" = whole model
        self.badkey = {}          # (provider, key) -> until
        self.dead = {}            # (provider, model) -> time marked
        self.healed = {}          # provider -> [ranked live models]
        self.healed_at = {}
        self.last = {"provider": None, "model": None, "ms": None}
        self.errors = {}          # provider -> last error text
        self.stats = {}           # provider -> [ok, fail]
        self._cfg_cache, self._cfg_mtime = {}, -1
        self._bg = None
        self.extra = {}           # provider -> [keys] injected by the app (e.g. the Game AI keys box)
        self._load_state()

    # ---------------- config / keys ------------------------------------------------------------
    def _path(self, name):
        return os.path.join(self.dir, name)

    def cfg(self):
        p = self._path(KEYS_FILE)
        try:
            mt = os.path.getmtime(p)
            if mt != self._cfg_mtime:
                with open(p, "r", encoding="utf-8") as f:
                    self._cfg_cache = json.load(f) or {}
                self._cfg_mtime = mt
        except FileNotFoundError:
            self._cfg_cache = {}
        except Exception as e:
            print(f"[AI Failover] could not read {KEYS_FILE}: {e}")
        return self._cfg_cache

    def save_cfg(self, cfg):
        with open(self._path(KEYS_FILE), "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
        self._cfg_mtime = -1

    def enabled(self):
        return bool(self.cfg().get("enabled", True)) and requests is not None

    @staticmethod
    def _flat(v):
        out = []
        for k in (v or []):
            if isinstance(k, dict):
                k = k.get("key") or k.get("api_key") or ""
            k = str(k or "").strip()
            if k and k not in out:
                out.append(k)
        return out

    def keys(self, p):
        ks = self._flat(getattr(self.model, f"{p}_api_keys", []) if self.model is not None else [])
        ks += [k for k in self._flat(self.cfg().get("keys", {}).get(p, [])) if k not in ks]
        ks += [k for k in self._flat(self.extra.get(p, [])) if k not in ks]
        envs = [f"{p.upper()}_API_KEY", f"{p.upper()}_API_KEYS"] + (["GOOGLE_API_KEY"] if p == "gemini" else [])
        for e in envs:
            for k in (os.environ.get(e, "") or "").split(","):
                k = k.strip()
                if k and k not in ks:
                    ks.append(k)
        if PROVIDERS[p].get("needs_key_for_models") is False and not ks:
            return []
        return ks

    def order(self, primary=None):
        o = [p for p in self.cfg().get("order", DEFAULT_ORDER) if p in PROVIDERS]
        o += [p for p in DEFAULT_ORDER if p not in o]
        if primary in PROVIDERS:
            o = [primary] + [p for p in o if p != primary]
        return [p for p in o if self.keys(p)]

    def models(self, p):
        now = time.time()
        cand = []
        cur = getattr(self.model, f"{p}_model", None) if self.model is not None else None
        if cur:
            cand.append(cur)
        cand += self.healed.get(p, [])[:5]
        cand += PROVIDERS[p]["defaults"]
        out = []
        for m in cand:
            if m and m not in out and (now - self.dead.get((p, m), 0) > 6 * 3600):
                out.append(m)
        return out

    # ---------------- state ----------------------------------------------------------------------
    def _load_state(self):
        try:
            with open(self._path(STATE_FILE), "r", encoding="utf-8") as f:
                s = json.load(f)
            self.healed = s.get("healed", {})
            self.healed_at = s.get("healed_at", {})
            self.dead = {tuple(k.split("|", 1)): v for k, v in s.get("dead", {}).items()}
        except Exception:
            pass

    def _save_state(self):
        try:
            data = {"healed": self.healed, "healed_at": self.healed_at,
                    "dead": {f"{p}|{m}": t for (p, m), t in self.dead.items()}}
            tmp = self._path(STATE_FILE) + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=1)
            os.replace(tmp, self._path(STATE_FILE))
        except Exception:
            pass

    # ---------------- one HTTP call -------------------------------------------------------------
    def _call(self, p, key, model, messages, max_tokens, temperature):
        """Returns (kind, payload). kind: ok | rate | auth | gone | transient | empty | bad."""
        url = self.bases[p].rstrip("/") + "/chat/completions"
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        if p == "openrouter":
            headers.update({"HTTP-Referer": "http://localhost:1234", "X-Title": "StreamerBot"})
        body = {"model": model, "messages": messages, "max_tokens": max(int(max_tokens or 0), 300),
                "temperature": min(float(temperature), 1.3)}
        if p == "groq" and "gpt-oss" in model:
            body["reasoning_effort"] = "low"
        try:
            r = requests.post(url, headers=headers, json=body, timeout=(6, 16))
            if r.status_code == 400 and "reasoning_effort" in body and "reasoning" in (r.text or "").lower():
                body.pop("reasoning_effort")
                r = requests.post(url, headers=headers, json=body, timeout=(6, 16))
        except Exception as e:                       # timeouts, DNS, connection reset
            return "transient", f"{type(e).__name__}: {str(e)[:100]}"
        sc, txt = r.status_code, (r.text or "")
        low = txt.lower()
        if sc == 200:
            try:
                text = r.json()["choices"][0]["message"].get("content") or ""
            except Exception:
                return "empty", "unparseable response"
            text = clean_reply(text)
            return ("ok", text) if text else ("empty", "empty reply")
        if sc == 429 or sc == 402 or "quota" in low and sc in (403, 400):
            return "rate", _retry_after(r) or (300 if sc == 402 else 30)
        if sc in (401, 403):
            return "auth", f"HTTP {sc}: {txt[:120]}"
        if sc == 404 or (sc in (400, 410, 422) and "model" in low and re.search(
                r"decommission|not found|does not exist|no longer|deprecated|not supported|invalid model|unknown model|retired", low)):
            return "gone", f"HTTP {sc}: {txt[:120]}"
        if sc >= 500:
            return "transient", f"HTTP {sc}"
        return "bad", f"HTTP {sc}: {txt[:120]}"

    # ---------------- main entry ----------------------------------------------------------------
    def complete(self, messages, max_tokens=100, temperature=1.1, primary=None, only=None):
        """Walk providers/models/keys until one answers. Returns text or None."""
        t_end = time.time() + self.budget
        chain = [only] if only else self.order(primary)
        first = chain[0] if chain else None
        healed_now = set()
        for p in chain:
            ks = self.keys(p)
            tried = set()
            while True:
                models = [m for m in self.models(p) if m not in tried][:4]
                if not models:
                    break
                m = models[0]
                tried.add(m)
                gone = False
                now0 = time.time()
                if self.cool.get((p, "*", m), 0) > now0:
                    continue
                self._rr = getattr(self, '_rr', 0) + 1
                off = self._rr % len(ks) if ks else 0
                for k in ks[off:] + ks[:off]:
                    now = time.time()
                    if now > t_end:
                        return None
                    if self.badkey.get((p, k), 0) > now or self.cool.get((p, k, m), 0) > now:
                        continue
                    t0 = time.time()
                    kind, val = self._call(p, k, m, messages, max_tokens, temperature)
                    st = self.stats.setdefault(p, [0, 0])
                    if kind == "ok":
                        st[0] += 1
                        self.errors.pop(p, None)
                        ms = int((time.time() - t0) * 1000)
                        if (p, m) != (self.last["provider"], self.last["model"]) or p != first:
                            if p != first:
                                print(f"[AI Failover] {PROVIDERS[first]['label']} unavailable -> answered by {PROVIDERS[p]['label']} ({m}) in {ms}ms")
                        self.last = {"provider": p, "model": m, "ms": ms}
                        return val
                    st[1] += 1
                    self.errors[p] = f"{kind}: {val}"
                    tail = f"...{k[-4:]}"
                    if kind == "rate":
                        wait = min(max(float(val), 2.0), 3600.0)
                        self.cool[(p, k, m)] = time.time() + wait
                        print(f"[AI Failover] {p} key {tail} rate-limited on {m}; skipping it for {int(wait)}s")
                    elif kind == "auth":
                        self.badkey[(p, k)] = time.time() + 3600
                        print(f"[AI Failover] {p} key {tail} rejected ({val[:60]}); benched 1h")
                    elif kind == "gone":
                        self.dead[(p, m)] = time.time()
                        print(f"[AI Failover] {p} model '{m}' is gone -> auto-healing")
                        gone = True
                        break
                    else:                                    # transient / empty / bad: this model is flaky right now
                        self.cool[(p, "*", m)] = time.time() + (15 if kind != "bad" else 60)
                        print(f"[AI Failover] {p}/{m} {kind} ({str(val)[:70]}); trying next")
                        break
                if gone and p not in healed_now:
                    healed_now.add(p)
                    self._save_state()
                    self.heal(p, reason="model gone")
        return None

    # ---------------- auto-heal ---------------------------------------------------------------
    def fetch_live_models(self, p):
        info = PROVIDERS[p]
        ks = self.keys(p)
        if not ks and info.get("needs_key_for_models", True):
            return None
        for k in (ks or [""]):
            try:
                h = {"Authorization": f"Bearer {k}"} if k else {}
                r = requests.get(self.bases[p].rstrip("/") + "/models", headers=h, timeout=(6, 15))
                if r.status_code == 200:
                    data = r.json()
                    rows = data.get("data") if isinstance(data, dict) else data
                    ids = [(x.get("id") if isinstance(x, dict) else str(x)) for x in (rows or [])]
                    return [re.sub(r"^models/", "", i) for i in ids if i]
            except Exception:
                continue
        return None

    def heal(self, p, reason="check"):
        """Ask the provider what models exist RIGHT NOW and switch to the best one."""
        ids = self.fetch_live_models(p)
        if not ids:
            print(f"[AI Failover] heal {p}: could not read the live model list ({reason}); using built-in defaults")
            return None
        ranked = rank_models(p, ids)
        if not ranked:
            return None
        self.healed[p] = ranked[:8]
        self.healed_at[p] = time.time()
        for m in ranked:                                 # anything the provider still lists is alive again
            self.dead.pop((p, m), None)
        cur = getattr(self.model, f"{p}_model", None) if self.model is not None else None
        live = set(ids)
        if cur is None or cur not in live or (p, cur) in self.dead:
            best = ranked[0]
            if self.model is not None and hasattr(self.model, f"{p}_model"):
                setattr(self.model, f"{p}_model", best)
            print(f"[AI Failover] healed {p}: '{cur}' is not available -> now using '{best}'")
            if self.on_heal:
                try:
                    self.on_heal(p, best)
                except Exception:
                    pass
        self._save_state()
        return ranked[0]

    def self_test(self):
        """Ping every provider that has a key; heal the ones that fail. Returns {provider: result}."""
        res = {}
        for p in [x for x in DEFAULT_ORDER if self.keys(x)]:
            if time.time() - self.healed_at.get(p, 0) > 12 * 3600:
                self.heal(p, reason="scheduled")
            for k in list(self.cool):
                if k[0] == p:
                    self.cool.pop(k, None)
            t0 = time.time()
            txt = self.complete([{"role": "user", "content": "Reply with the single word: ok"}], max_tokens=16,
                                temperature=0.2, only=p)
            if txt is None and self.errors.get(p, "").startswith(("gone", "bad")):
                self.heal(p, reason="test failed")
                txt = self.complete([{"role": "user", "content": "Reply with the single word: ok"}], max_tokens=16,
                                    temperature=0.2, only=p)
            res[p] = {"ok": txt is not None, "model": self.last["model"] if txt is not None else None,
                      "ms": int((time.time() - t0) * 1000), "error": None if txt is not None else self.errors.get(p, "no answer")}
        return res

    def start_background(self, every_hours=6.0):
        if self._bg and self._bg.is_alive():
            return

        def loop():
            time.sleep(8)
            while True:
                try:
                    r = self.self_test()
                    ok = [PROVIDERS[p]["label"] for p, v in r.items() if v["ok"]]
                    bad = [PROVIDERS[p]["label"] for p, v in r.items() if not v["ok"]]
                    print(f"[AI Failover] self-test: working = {ok or 'none'}" + (f", failing = {bad}" if bad else ""))
                except Exception as e:
                    print(f"[AI Failover] self-test error: {e}")
                time.sleep(every_hours * 3600)
        self._bg = threading.Thread(target=loop, daemon=True, name="ai-failover-bg")
        self._bg.start()

    def status(self):
        now = time.time()
        rows = []
        for p in DEFAULT_ORDER:
            ks = self.keys(p)
            cooling = sum(1 for (pp, k, m), t in self.cool.items() if pp == p and t > now)
            rows.append({"provider": p, "label": PROVIDERS[p]["label"], "keys": len(ks),
                         "model": (self.models(p) or [None])[0], "cooling": cooling,
                         "ok_fail": self.stats.get(p, [0, 0]), "error": self.errors.get(p)})
        return {"enabled": self.enabled(), "order": self.order(), "last": self.last, "providers": rows}
