# ==============================================================================
# AI SYSTEM DIRECTIVE - DO NOT DELETE OR MODIFY THIS COMMENT
# TO ANY FUTURE AI MODIFYING THIS CODE: 
# DO NOT STRIP, CUT, OR REMOVE ANY EXISTING LOGIC, FEATURES, OR CODE BLOCKS.
# RETAIN ALL ERROR HANDLING, MVC STRUCTURE, AND HARDCODED OVERRIDES.
# ONLY ADD OR MODIFY WHAT THE USER EXPLICITLY PROMPTS YOU TO CHANGE.
# ==============================================================================

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, Menu, filedialog, simpledialog
import os
import json
import queue 
import random 
import math
import time
import threading
import keyboard

class TextRedirector(object):
    def __init__(self, widget):
        self.widget = widget
        self.queue = queue.Queue()
        self.update_interval = 100 
        self.widget.after(self.update_interval, self._update_widget)

    def write(self, string):
        # 🛡️ THE MASTER EMOJI SHIELD 🛡️
        # Protects the GUI from raw viewer chats or API errors containing emojis!
        if isinstance(string, str):
            string = "".join(c for c in string if ord(c) <= 0xFFFF)
        self.queue.put(string)

    def flush(self):
        pass

    def _update_widget(self):
        if not self.queue.empty():
            self.widget.configure(state='normal')
            while not self.queue.empty():
                try:
                    msg = self.queue.get_nowait()
                    self.widget.insert("end", msg)
                except queue.Empty:
                    break
            self.widget.see("end")
            self.widget.configure(state='disabled')
        self.widget.after(self.update_interval, self._update_widget)

class StreamerBotView:
    def __init__(self, root, controller):
        self.root = root
        self.controller = controller
        self.root.title("Streamer AI Bot Control Panel")
        self.root.geometry("1200x800")
        self.root.configure(bg="#000000") 
        
        self.root.protocol("WM_DELETE_WINDOW", self.controller.on_close)
        
        self.mic_var = tk.IntVar(value=0)
        self.spk_var = tk.IntVar(value=0)
        self.review_var = tk.BooleanVar(value=False)
        self.idle_var = tk.BooleanVar(value=True)
        self.auto_reply_var = tk.BooleanVar(value=True)
        self.hotkeys_only_var = tk.BooleanVar(value=False) 
        self.chat_text_only_var = tk.BooleanVar(value=False) 
        self.greet_viewers_var = tk.BooleanVar(value=True) 
        self.tts_var = tk.StringVar(value="edge")
        self.stt_var = tk.StringVar(value="google") 
        self.out_var = tk.IntVar(value=3)
        self.volume_level = tk.DoubleVar(value=1.0)
        self.overlay_opacity_var = tk.DoubleVar(value=0.7) 
        
        self.bark_voice_var = tk.StringVar(value="v2/en_speaker_6")
        self.edge_voice_var = tk.StringVar(value="en-US-SteffanNeural")
        self.google_voice_var = tk.StringVar(value="en-US-Wavenet-I")
        self.kokoro_voice_var = tk.StringVar(value="am_adam") 
        self.soprano_voice_var = tk.StringVar(value="Default (Female)")
        self.tiktok_voice_var = tk.StringVar(value="en_us_002") 
        self.voicebox_voice_var = tk.StringVar(value="default")
        
        self.hotkeys_active = tk.BooleanVar(value=False)
        self.ai_backend_var = tk.StringVar(value="local") 
        self.groq_model_var = tk.StringVar(value="llama-3.1-8b-instant")
        
        self.game_var = tk.StringVar(value="Just Chatting")

        self.chat_selector_voice_only_var = tk.BooleanVar(value=False)
        self.hide_bot_chat_var = tk.BooleanVar(value=False) 
        
        self.review_window = None
        self.popup_text = None
        self.selector_window = None
        self.selector_text = None 
        self.chat_tree = None
        self.hotkey_window = None
        self.guide_window = None
        self.status_window = None
        self.music_window = None 
        self.music_lbl_song = None 
        self.music_btn_repeat = None 
        self.groq_window = None
        self.gemini_window = None
        self.openrouter_window = None
        self.sambanova_window = None
        self.groq_text_area = None
        self.gemini_text_area = None
        self.openrouter_text_area = None
        self.sambanova_text_area = None
        self.lbl_stat_viewers_val = None
        self.lbl_stat_likes_val = None
        self.lbl_stat_subs_val = None
        self.lbl_guide_filename = None
        self.guide_results_text = None
        self.guide_status_lbl = None
        self.btn_next_match = None
        self.guide_url_entry = None 
        self.rvc_window = None
        self.fish_window = None
        self.mk1_window = None
        
        self.sel_progress = None
        self.btn_sel_improve = None
        self.btn_sel_send = None
        
        self.HOTKEY_BASES = [
            "hk_idle", "hk_thanks", "hk_question", "hk_help", "hk_death", "hk_likes_thanks", "hk_brb", 
            "hk_tech_issue", "hk_game_request", "hk_taunt", "hk_intro", "hk_frustration", "hk_attack", 
            "hk_talk_viewers", "hk_shoutout_users", "hk_puzzle", "hk_boss_win", "hk_feeling_good", 
            "hk_feeling_bad", "hk_clip_that", "hk_panic"
        ] + [f"hk_custom_{i}" for i in range(1, 16)]
        
        self.GUI_HOTKEYS = [
            "hk_reply_last", "hk_open_list", "hk_stats", "hk_stats_ghost", "hk_hotkeys_window", "hk_strict_mode", 
            "hk_play_overlay", "hk_music_window", "hk_toggle_ai_mute", "hk_yt_play_pause", "hk_yt_next", 
            "hk_yt_prev", "hk_yt_forward", "hk_yt_rewind", "hk_yt_ghost", "hk_mp3_play_pause", "hk_mp3_next", 
            "hk_mp3_prev", "hk_mp3_forward", "hk_mp3_rewind", "hk_guide", "hk_guide_ghost",
            "hk_hide_overlays", "hk_open_context_window", "hk_suspend_hotkeys", "hk_stop_audio",
            "hk_sys_status", "hk_sys_status_ghost", "hk_toggle_cache_mode", "hk_vision", "hk_vision_mode", 
            "hk_vision_toggle"
        ]

        for hk in self.HOTKEY_BASES + self.GUI_HOTKEYS:
            setattr(self, f"{hk}_var", tk.StringVar())
        
        for hk in self.HOTKEY_BASES:
            setattr(self, f"{hk}_mode_var", tk.StringVar(value="V+T"))
            setattr(self, f"{hk}_short_var", tk.BooleanVar(value=False))
            
        self.hk_reply_last_mode_var = tk.StringVar(value="V+T")
        self.hk_reply_last_short_var = tk.BooleanVar(value=False)
        
        self.saved_selector_geo = ""
        self.saved_status_geo = ""

        self.setup_styles()
        
        try:
            with open("bot_config.json", "r") as f:
                cfg = json.load(f)
                if 'global_directive_enabled' in cfg:
                    setattr(self.controller, 'global_directive_enabled', cfg['global_directive_enabled'])
                    setattr(self.controller.model, 'global_directive_enabled', cfg['global_directive_enabled'])
                if 'global_directive_text' in cfg:
                    setattr(self.controller, 'global_directive_text', cfg['global_directive_text'])
                    setattr(self.controller.model, 'global_directive_text', cfg['global_directive_text'])
                
                # 🛡️ THE FIX: Aggressively preload ALL hotkeys from the JSON config into the active controller memory
                for key, val in cfg.items():
                    if key.startswith('hk_'):
                        setattr(self.controller, key, val)
                        if hasattr(self.controller, 'model'):
                            setattr(self.controller.model, key, val)
        except: pass

        self.create_widgets()
        self._setup_auto_hotkey_suspend()
        
        def override_monkey_patch():
            try:
                menubar = self.root.nametowidget(self.root['menu'])
                for child_id in menubar.children:
                    menu_item = menubar.children[child_id]
                    last_idx = menu_item.index("end")
                    if last_idx is not None:
                        for i in range(last_idx + 1):
                            try:
                                if menu_item.type(i) == "command" and ("Keybind" in menu_item.entrycget(i, "label") or "Hotkey" in menu_item.entrycget(i, "label")):
                                    menu_item.entryconfigure(i, command=self.open_hotkeys_window)
                            except: pass
            except: pass
        self.root.after(1000, override_monkey_patch)
        self.refresh_elevenlabs_presets_ui()

        # Force a UI sync 500ms after boot to ensure saved hotkeys load
        self.root.after(500, self.refresh_ui_from_state)

    def _setup_auto_hotkey_suspend(self):
        self._auto_suspended = False
        def _check_focus(event=None):
            def _do_check():
                try:
                    fw = self.root.focus_displayof()
                    should_suspend = False
                    if fw and fw.winfo_exists():
                        w_class = fw.winfo_class()
                        if w_class in ('Entry', 'TCombobox', 'Spinbox', 'TSpinbox'):
                            should_suspend = True
                        elif w_class == 'Text':
                            if fw not in (getattr(self, 'console_text', None), getattr(self, 'chat_preview_text', None)):
                                type_parent = str(fw.winfo_parent())
                                if not 'review_window' in type_parent:
                                    should_suspend = True
                    
                    if should_suspend:
                        self._auto_suspended = True
                        setattr(self.controller, 'hotkeys_suspended', True)
                    else:
                        self._auto_suspended = False
                        setattr(self.controller, 'hotkeys_suspended', False)
                except: 
                    self._auto_suspended = False
                    setattr(self.controller, 'hotkeys_suspended', False)
            
            self.root.after(50, _do_check)

        self.root.bind_all("<FocusIn>", _check_focus, add="+")
        self.root.bind_all("<FocusOut>", _check_focus, add="+")
        self.root.bind_all("<Destroy>", lambda e: self.root.after(100, _check_focus), add="+")

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam') 
        BG_COLOR = "#000000"
        FG_COLOR = "#FFFFFF"
        ACCENT_CYAN = "#00FFFF"
        ACCENT_GREEN = "#00FF00"
        BTN_GREEN = "#008000"
        BTN_RED = "#B00000"
        BTN_BLUE = "#0080FF"
        
        style.configure("TFrame", background=BG_COLOR)
        style.configure("TLabelframe", background=BG_COLOR, foreground=ACCENT_CYAN)
        style.configure("TLabelframe.Label", background=BG_COLOR, foreground=ACCENT_CYAN, font=("Segoe UI", 10, "bold"))
        style.configure("TPanedwindow", background="#222222")
        style.configure("TLabel", background=BG_COLOR, foreground=FG_COLOR, font=("Segoe UI", 10))
        style.configure("Green.TLabel", foreground=ACCENT_GREEN, font=("Segoe UI", 10, "bold"))
        style.configure("Cyan.TLabel", foreground=ACCENT_CYAN, font=("Segoe UI", 12, "bold"))
        style.configure("Start.TButton", background=BTN_GREEN, foreground="white", font=("Segoe UI", 10, "bold"), borderwidth=0)
        style.map("Start.TButton", background=[('active', '#00A000')])
        style.configure("Stop.TButton", background=BTN_RED, foreground="white", font=("Segoe UI", 10, "bold"), borderwidth=0)
        style.map("Stop.TButton", background=[('active', '#D00000')])
        style.configure("Blue.TButton", background=BTN_BLUE, foreground="white", font=("Segoe UI", 10, "bold"), borderwidth=0)
        style.map("Blue.TButton", background=[('active', '#00AFF')])
        style.configure("TButton", background="#333333", foreground="white")
        style.map("TButton", background=[('active', '#555555')])
        style.configure("Horizontal.TProgressbar", background=ACCENT_GREEN, troughcolor="#333333", bordercolor="#333333")
        style.configure("TSizegrip", background="#000000")
        
        style.configure("Treeview", background="#111111", foreground="white", fieldbackground="#111111", rowheight=25, borderwidth=0)
        style.configure("Treeview.Heading", background="#222222", foreground="#00FFFF", font=("Segoe UI", 9, "bold"), borderwidth=0)
        style.map('Treeview', background=[('selected', '#333333')])

    def create_widgets(self):
        menubar = Menu(self.root)
        self.root.config(menu=menubar)

        file_menu = Menu(menubar, tearoff=0)
        file_menu.add_command(label="💾 Save Config", command=self.controller.save_config)
        file_menu.add_command(label="📂 Load Config", command=self.controller.load_config)
        file_menu.add_separator()
        file_menu.add_command(label="📄 Save Session Log", command=self.controller.save_session_log)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.controller.on_close)
        menubar.add_cascade(label="File", menu=file_menu)

        ai_menu = Menu(menubar, tearoff=0)
        ai_menu.add_radiobutton(label="Use LM Studio (Local)", variable=self.ai_backend_var, value="local", command=lambda: self.controller.set_ai_mode("local"))
        ai_menu.add_radiobutton(label="Use Groq (Cloud)", variable=self.ai_backend_var, value="groq", command=lambda: self.controller.set_ai_mode("groq"))
        ai_menu.add_radiobutton(label="Use Google Gemini (Cloud)", variable=self.ai_backend_var, value="gemini", command=lambda: self.controller.set_ai_mode("gemini"))
        ai_menu.add_radiobutton(label="Use OpenRouter (Cloud)", variable=self.ai_backend_var, value="openrouter", command=lambda: self.controller.set_ai_mode("openrouter"))
        ai_menu.add_radiobutton(label="Use SambaNova (Cloud)", variable=self.ai_backend_var, value="sambanova", command=lambda: self.controller.set_ai_mode("sambanova"))
        ai_menu.add_separator()
        
        groq_model_menu = Menu(ai_menu, tearoff=0)
        ai_menu.add_cascade(label="☁️ Groq Model Selection", menu=groq_model_menu)
        
        # 🛡️ FIX: Replace dead models with the real working ones
        groq_models = [
            ("Qwen 3.6 27B (Smart & Free)", "qwen/qwen3.6-27b"),
            ("GPT-OSS 20B (Fast)", "openai/gpt-oss-20b")
        ]
        
        for label, val in groq_models:
            groq_model_menu.add_radiobutton(label=label, variable=self.groq_model_var, value=val, command=lambda v=val: self.controller.set_groq_model(v))

        ai_menu.add_separator()
        ai_menu.add_command(label="⚙️ Configure Groq Keys", command=self.open_groq_settings_window)
        ai_menu.add_command(label="⚙️ Configure Gemini Keys", command=self.open_gemini_settings_window)
        ai_menu.add_command(label="⚙️ Configure OpenRouter Keys", command=self.open_openrouter_settings_window)
        ai_menu.add_command(label="⚙️ Configure SambaNova Keys", command=self.open_sambanova_settings_window)
        menubar.add_cascade(label="AI Backend", menu=ai_menu)

        bot_menu = Menu(menubar, tearoff=0)
        bot_menu.add_checkbutton(label="Review Mode", command=self.controller.toggle_review, variable=self.review_var)
        bot_menu.add_checkbutton(label="Idle Chat", command=self.controller.toggle_idle, variable=self.idle_var)
        bot_menu.add_checkbutton(label="Enable Global Auto-Replies", command=self.controller.toggle_auto_reply, variable=self.auto_reply_var)
        bot_menu.add_checkbutton(label="Auto-Greet New Viewers", variable=self.greet_viewers_var, command=self.controller.toggle_viewer_greeting)
        bot_menu.add_separator()
        bot_menu.add_checkbutton(label="🔥 Hotkeys Only Mode", command=self.controller.toggle_hotkeys_only_mode, variable=self.hotkeys_only_var)
        bot_menu.add_separator()
        
        BARK_VOICES_LIST = [f"v2/en_speaker_{i}" for i in range(10)]
        EDGE_VOICES_LIST = ["en-US-SteffanNeural", "en-US-GuyNeural", "en-US-ChristopherNeural", "en-US-AriaNeural", "en-US-JennyNeural", "en-US-MichelleNeural", "en-PH-JamesNeural", "en-PH-RosaNeural", "en-GB-RyanNeural", "en-GB-SoniaNeural", "en-US-AnaNeural", "tl-PH-AngeloNeural", "tl-PH-BlessicaNeural"]
        GOOGLE_VOICES_LIST = ["en-US-Wavenet-A", "en-US-Wavenet-B", "en-US-Wavenet-C", "en-US-Wavenet-D", "en-US-Wavenet-E", "en-US-Wavenet-F", "en-US-Wavenet-I", "en-US-Wavenet-J", "fil-PH-Wavenet-A", "fil-PH-Wavenet-B", "fil-PH-Wavenet-C", "fil-PH-Wavenet-D"]
        KOKORO_VOICES_LIST = {'am_adam': 'Gamer Guy (Adam)', 'am_michael': 'Pro Streamer (Michael)', 'am_onyx': 'Realistic Deep (Onyx)', 'am_puck': 'Energetic (Puck)', 'am_fenrir': 'Deep Voice (Fenrir)', 'af_bella': 'Streamer Girl (Bella)', 'af_sarah': 'Calm Girl (Sarah)', 'af_nicole': 'Standard (Nicole)', 'af_sky': 'Soft (Sky)', 'af_jessica': 'Realistic (Jessica)'}

        tts_menu = Menu(bot_menu, tearoff=0)
        tts_menu.add_radiobutton(label="ElevenLabs (Multilingual V2)", variable=self.tts_var, value="elevenlabs", command=self.controller.set_tts_mode)
        tts_menu.add_radiobutton(label="Fish Speech (Local Voice Clone)", variable=self.tts_var, value="fish", command=self.controller.set_tts_mode)
        tts_menu.add_radiobutton(label="Kokoro TTS (GPU High-Quality)", variable=self.tts_var, value="kokoro", command=self.controller.set_tts_mode)
        tts_menu.add_radiobutton(label="Voicebox (Pinokio Local)", variable=self.tts_var, value="voicebox", command=self.controller.set_tts_mode)
        tts_menu.add_radiobutton(label="TikTok TTS (Cloud Fast)", variable=self.tts_var, value="tiktok", command=self.controller.set_tts_mode)
        tts_menu.add_radiobutton(label="Typecast (Browser Macro)", variable=self.tts_var, value="typecast", command=self.controller.set_tts_mode)
        tts_menu.add_radiobutton(label="ElevenLabs Ghost (Free Stealth)", variable=self.tts_var, value="elevenlabs_ghost", command=self.controller.set_tts_mode)
        tts_menu.add_radiobutton(label="RVC (Voice Cloning Local)", variable=self.tts_var, value="rvc", command=self.controller.set_tts_mode)
        tts_menu.add_radiobutton(label="Soprano TTS (Local Pytorch Model)", variable=self.tts_var, value="soprano", command=self.controller.set_tts_mode)
        tts_menu.add_radiobutton(label="Edge TTS (Cloud Free)", variable=self.tts_var, value="edge", command=self.controller.set_tts_mode)
        tts_menu.add_radiobutton(label="Google Cloud TTS (Paid)", variable=self.tts_var, value="google", command=self.controller.set_tts_mode)
        tts_menu.add_radiobutton(label="Bark AI (GPU)", variable=self.tts_var, value="bark", command=self.controller.set_tts_mode)
        tts_menu.add_radiobutton(label="Offline (Windows Default)", variable=self.tts_var, value="offline", command=self.controller.set_tts_mode)
        bot_menu.add_cascade(label="🗣️ TTS Engine", menu=tts_menu)
        
        # 🛡️ THE NEW GHOST BROWSER SETUP BUTTON
        def _run_typecast_setup():
            import threading
            def _setup():
                from typecast_bridge import TypecastGhostEngine
                engine = TypecastGhostEngine()
                engine.setup_login()
            threading.Thread(target=_setup, daemon=True).start()
            
        def _run_elevenlabs_ghost_setup():
            import threading
            def _setup():
                from elevenlabs_ghost_bridge import ElevenLabsGhostEngine
                engine = ElevenLabsGhostEngine()
                engine.setup_login()
            threading.Thread(target=_setup, daemon=True).start()
            
        bot_menu.add_command(label="⚙️ Setup Typecast Ghost Login", command=_run_typecast_setup)
        bot_menu.add_command(label="⚙️ Setup ElevenLabs Ghost Browser", command=_run_elevenlabs_ghost_setup)
        
        stt_menu = Menu(bot_menu, tearoff=0)
        stt_menu.add_radiobutton(label="Google Speech Rec (Cloud/Default)", variable=self.stt_var, value="google", command=self.controller.set_stt_mode)
        stt_menu.add_radiobutton(label="Whisper AI (GPU - High Accuracy)", variable=self.stt_var, value="whisper", command=self.controller.set_stt_mode)
        bot_menu.add_cascade(label="🎙️ Mic/STT Engine", menu=stt_menu)

        menubar.add_cascade(label="Bot Controls", menu=bot_menu)

        tools_menu = Menu(menubar, tearoff=0)
        tools_menu.add_command(label="⌨ Keybinds & Hotkeys", command=self.open_hotkeys_window)
        tools_menu.add_command(label="📂 Chat List / Manual Reply", command=self.open_chat_selector)
        tools_menu.add_command(label="📚 Game Guide Manager", command=self.open_guide_window)
        tools_menu.add_command(label="📊 Live Stats", command=self.open_status_window)
        tools_menu.add_separator()
        
        safe_launch_yt = getattr(self.controller, 'launch_youtube_player', lambda: messagebox.showwarning("Missing Feature", "launch_youtube_player is missing from your controller.py! Please ensure you copied the complete file."))
        tools_menu.add_command(label="📺 Standalone YouTube Overlay", command=safe_launch_yt)
        tools_menu.add_command(label="🎵 Overlay Music Player", command=self.open_music_player_window)
        menubar.add_cascade(label="Tools", menu=tools_menu)

        audio_menu = Menu(menubar, tearoff=0)
        self.mic_menu = Menu(audio_menu, tearoff=0)
        self.spk_menu = Menu(audio_menu, tearoff=0)
        
        audio_menu.add_cascade(label="Mic Input", menu=self.mic_menu)
        audio_menu.add_cascade(label="Speaker Output", menu=self.spk_menu)
        audio_menu.add_separator()
        
        audio_menu.add_command(label="Configure Voicebox (Pinokio) API", command=self.open_voicebox_settings)
        audio_menu.add_command(label="Fish Speech Setup (.wav Cloning)", command=self.open_fish_setup_window)
        audio_menu.add_command(label="RVC Setup (.pth Voice Cloning)", command=self.open_rvc_setup_window)
        audio_menu.add_separator()
        
        self.voice_settings_menu = Menu(audio_menu, tearoff=0)
        audio_menu.add_cascade(label="Voice Selection", menu=self.voice_settings_menu)
        
        self.tiktok_menu = Menu(self.voice_settings_menu, tearoff=0)
        self.voice_settings_menu.add_cascade(label="TikTok Voices", menu=self.tiktok_menu)
        
        tt_en_menu = Menu(self.tiktok_menu, tearoff=0)
        tt_char_menu = Menu(self.tiktok_menu, tearoff=0)
        tt_sing_menu = Menu(self.tiktok_menu, tearoff=0)
        tt_intl_menu = Menu(self.tiktok_menu, tearoff=0)

        self.tiktok_menu.add_cascade(label="English (US/UK/AU)", menu=tt_en_menu)
        self.tiktok_menu.add_cascade(label="Characters (Disney/Movies)", menu=tt_char_menu)
        self.tiktok_menu.add_cascade(label="Singing & Special", menu=tt_sing_menu)
        self.tiktok_menu.add_cascade(label="International", menu=tt_intl_menu)
        
        for v_code, v_name in {
            "en_us_001": "US Female 1", "en_us_002": "US Female 2 (Jessie)", "en_us_006": "US Male 1",
            "en_us_007": "US Male 2", "en_us_009": "US Male 3", "en_us_010": "US Male 4",
            "en_uk_001": "UK Male 1", "en_uk_003": "UK Male 2", "en_au_001": "AU Female", "en_au_002": "AU Male"
        }.items(): tt_en_menu.add_radiobutton(label=v_name, variable=self.tiktok_voice_var, value=v_code)
        
        for v_code, v_name in {
            "en_us_ghostface": "Ghostface (Scream)", "en_us_chewbacca": "Chewbacca", "en_us_c3po": "C-3PO",
            "en_us_stitch": "Stitch", "en_us_stormtrooper": "Stormtrooper", "en_us_rocket": "Rocket Raccoon", "en_us_deadpool": "Deadpool",
            "blackmythwukong-male": "Wukong (Black Myth)"
        }.items(): tt_char_menu.add_radiobutton(label=v_name, variable=self.tiktok_voice_var, value=v_code)
        
        for v_code, v_name in {
            "en_male_narration": "Narrator", "en_male_funny": "Funny / Wacky", "en_female_emotional": "Peaceful / Emotional",
            "en_female_f08_salut_damour": "Singing (Alto)", "en_male_m03_lobby": "Singing (Tenor)",
            "en_female_f08_warmy_breeze": "Singing (Warm Breeze)", "en_male_m03_sunshine_soon": "Singing (Sunshine Soon)"
        }.items(): tt_sing_menu.add_radiobutton(label=v_name, variable=self.tiktok_voice_var, value=v_code)
        
        for v_code, v_name in {
            "fr_001": "French Male 1", "de_001": "German Female", "es_002": "Spanish Male", "es_mx_002": "Spanish MX Male",
            "br_005": "Portuguese BR Male", 
            "id_001": "Indonesian / Pinoy Accent (Female)", 
            "jp_001": "Japanese Female 1", "jp_006": "Japanese Male", 
            "kr_003": "Korean Female", "kr_002": "Korean Male"
        }.items(): tt_intl_menu.add_radiobutton(label=v_name, variable=self.tiktok_voice_var, value=v_code)
        
        self.kokoro_menu = Menu(self.voice_settings_menu, tearoff=0)
        self.voice_settings_menu.add_cascade(label="Kokoro Voices", menu=self.kokoro_menu)
        for v_code, v_name in KOKORO_VOICES_LIST.items():
            self.kokoro_menu.add_radiobutton(label=v_name, variable=self.kokoro_voice_var, value=v_code)
            
        self.soprano_menu = Menu(self.voice_settings_menu, tearoff=0)
        self.voice_settings_menu.add_cascade(label="Soprano Local Pytorch Model", menu=self.soprano_menu)
        for v in ["Default (Female)", "Male (Pitch Down)"]:
            self.soprano_menu.add_radiobutton(label=v, variable=self.soprano_voice_var, value=v)
            
        self.bark_menu = Menu(self.voice_settings_menu, tearoff=0)
        self.voice_settings_menu.add_cascade(label="Bark AI Voices", menu=self.bark_menu)
        
        self.bark_use_cpu_var = tk.BooleanVar(value=getattr(self.controller.model, 'bark_use_cpu', False))
        self.bark_small_models_var = tk.BooleanVar(value=getattr(self.controller.model, 'bark_small_models', False))
        self.bark_low_vram_var = tk.BooleanVar(value=getattr(self.controller.model, 'bark_low_vram', False))
        
        def _update_bark_cpu(): 
            self.controller.model.bark_use_cpu = self.bark_use_cpu_var.get()
            self.controller.save_config()
            if hasattr(self.controller, 'set_tts_mode'): self.controller.set_tts_mode()
            
        def _update_bark_small(): 
            self.controller.model.bark_small_models = self.bark_small_models_var.get()
            self.controller.save_config()
            if hasattr(self.controller, 'set_tts_mode'): self.controller.set_tts_mode()

        def _update_bark_low_vram(): 
            self.controller.model.bark_low_vram = self.bark_low_vram_var.get()
            self.controller.save_config()
            if hasattr(self.controller, 'set_tts_mode'): self.controller.set_tts_mode()
            
        self.bark_menu.add_checkbutton(label="⚙️ Use CPU (Slower, Saves VRAM)", variable=self.bark_use_cpu_var, command=_update_bark_cpu)
        self.bark_menu.add_checkbutton(label="⚡ Use Small Models (Faster)", variable=self.bark_small_models_var, command=_update_bark_small)
        self.bark_menu.add_checkbutton(label="📉 1GB VRAM (Aggressive Offload)", variable=self.bark_low_vram_var, command=_update_bark_low_vram)
        def _bark_gpu_check():
            try:
                from bark_fast import gpu_report
                rep = gpu_report(print_it=True)
                (messagebox.showinfo if rep["cuda"] else messagebox.showwarning)("Bark GPU check", rep["message"])
            except Exception as e:
                messagebox.showerror("Bark GPU check", f"Could not check: {e}")
        self.bark_menu.add_command(label="🔍 Check GPU status (why 'No GPU'?)", command=_bark_gpu_check)
        self.bark_menu.add_separator()

        for v in BARK_VOICES_LIST:
            self.bark_menu.add_radiobutton(label=v, variable=self.bark_voice_var, value=v)
            
        self.edge_menu = Menu(self.voice_settings_menu, tearoff=0)
        self.voice_settings_menu.add_cascade(label="Edge TTS Voices", menu=self.edge_menu)
        for v in EDGE_VOICES_LIST:
            self.edge_menu.add_radiobutton(label=v, variable=self.edge_voice_var, value=v)

        self.google_v_menu = Menu(self.voice_settings_menu, tearoff=0)
        self.voice_settings_menu.add_cascade(label="Google TTS Voices", menu=self.google_v_menu)
        for v in GOOGLE_VOICES_LIST:
            self.google_v_menu.add_radiobutton(label=v, variable=self.google_voice_var, value=v)
            
        self.el_v_menu = Menu(self.voice_settings_menu, tearoff=0)
        self.voice_settings_menu.add_cascade(label="ElevenLabs Voices", menu=self.el_v_menu)
        safe_prompt_el = getattr(self.controller, 'prompt_elevenlabs_voice', lambda: simpledialog.askstring("ElevenLabs Voice", "Enter Voice ID:", initialvalue=getattr(self.controller.model, 'elevenlabs_voice', 'Pinoy Gamer Streamer'), parent=self.root))
        self.el_v_menu.add_command(label="Set ElevenLabs Voice ID", command=safe_prompt_el)
        self.el_v_menu.add_command(label="⚙️ Manage Voice Presets", command=self.open_elevenlabs_setup_window)

        # --- VOICEBOX VOICE MENU ---
        self.vb_v_menu = Menu(self.voice_settings_menu, tearoff=0)
        self.voice_settings_menu.add_cascade(label="Voicebox Voices", menu=self.vb_v_menu)
        
        def prompt_voicebox_voice():
            from tkinter import simpledialog
            v = simpledialog.askstring("Voicebox Setup", "Enter Voicebox Profile ID:", initialvalue=self.voicebox_voice_var.get(), parent=self.root)
            if v is not None:
                self.voicebox_voice_var.set(v.strip())
                if hasattr(self.controller, 'model'):
                    self.controller.model.voicebox_voice = v.strip()
                if hasattr(self.controller, 'save_config'):
                    self.controller.save_config()
                print(f"[System] Voicebox Voice ID set to: {v.strip()}")
                
        self.vb_v_menu.add_command(label="Set Voicebox Profile ID", command=prompt_voicebox_voice)

        audio_menu.add_separator()
        
        safe_tts_test = getattr(self.controller, 'run_tts_test', lambda: messagebox.showwarning("Warning", "run_tts_test is missing in controller.py"))
        safe_mic_test = getattr(self.controller, 'run_mic_test', lambda: messagebox.showwarning("Warning", "run_mic_test is missing in controller.py"))
        safe_refresh = getattr(self.controller, 'refresh_audio_menus', lambda: messagebox.showwarning("Warning", "refresh_audio_menus is missing in controller.py"))
        
        audio_menu.add_command(label="Test TTS Voice", command=safe_tts_test)
        audio_menu.add_command(label="Test Mic (Rec + Text)", command=safe_mic_test)
        audio_menu.add_command(label="Refresh Devices", command=safe_refresh)
        menubar.add_cascade(label="Audio", menu=audio_menu)

        toolbar = ttk.Frame(self.root)
        toolbar.pack(fill="x", padx=5, pady=5)

        ttk.Label(toolbar, text="Channel:", style="Green.TLabel").pack(side="left", padx=(5, 2))
        self.channel_combo = ttk.Combobox(toolbar, width=15, state="readonly")
        self.channel_combo.pack(side="left", padx=2)

        ttk.Button(toolbar, text="+", width=2, command=self.open_add_channel_popup).pack(side="left", padx=2)
        ttk.Button(toolbar, text="🔑", width=3, command=self.open_cred_manager).pack(side="left", padx=2)

        ttk.Label(toolbar, text="Persona:", style="Green.TLabel").pack(side="left", padx=(10, 2))
        personas_list = ["Default (Casual)", "Friendly (Wholesome)", "Roasting (Toxic/Savage)", "Joker (Funny)", "Serious (Pro Gamer)", "Genius (Know-It-All)", "Pinoy (Taglish)", "Kid (Gen Alpha)"]
        self.persona_combo = ttk.Combobox(toolbar, width=18, state="readonly", values=personas_list)
        self.persona_combo.current(0)
        self.persona_combo.pack(side="left", padx=2)
        
        safe_persona = getattr(self.controller, 'on_persona_change', lambda e: None)
        self.persona_combo.bind("<<ComboboxSelected>>", safe_persona)

        tk.Label(toolbar, text="Game:", bg="#252525", fg="#00FF00", font=("Arial", 8, "bold")).pack(side="left", padx=(10,2))
        
        self.game_entry = tk.Entry(toolbar, width=15, bg="#111", fg="white", insertbackground="white")
        self.game_entry.pack(side="left", padx=5)

        ttk.Label(toolbar, text="Vol:", style="Green.TLabel").pack(side="left", padx=(10, 2))
        self.vol_scale = ttk.Scale(toolbar, from_=0.0, to=1.0, variable=self.volume_level, orient='horizontal', length=70)
        self.vol_scale.pack(side="left", padx=2)

        ttk.Label(toolbar, text="Opacity:", style="Green.TLabel").pack(side="left", padx=(10, 2))
        self.opacity_scale = ttk.Scale(toolbar, from_=0.1, to=1.0, variable=self.overlay_opacity_var, orient='horizontal', length=70)
        self.opacity_scale.pack(side="left", padx=2)

        controls_frame = ttk.Frame(toolbar)
        controls_frame.pack(side="left", padx=(15, 5))
        
        safe_start = getattr(self.controller, 'start_bot', lambda: messagebox.showwarning("Warning", "start_bot missing!"))
        safe_sim = getattr(self.controller, 'start_simulation', lambda: messagebox.showwarning("Warning", "start_simulation missing!"))
        safe_stop = getattr(self.controller, 'stop_bot', lambda: messagebox.showwarning("Warning", "stop_bot missing!"))
        
        self.start_btn = ttk.Button(controls_frame, text="▶ START", style="Start.TButton", command=safe_start)
        self.start_btn.pack(side="left", padx=2)
        
        self.sim_btn = ttk.Button(controls_frame, text="🧪 SIMULATE", style="Blue.TButton", command=safe_sim)
        self.sim_btn.pack(side="left", padx=2)
        
        self.stop_btn = ttk.Button(controls_frame, text="⏹ STOP", style="Stop.TButton", command=safe_stop, state="disabled")
        self.stop_btn.pack(side="left", padx=2)

        status_frame = ttk.Frame(toolbar)
        status_frame.pack(side="right", padx=10)
        self.lbl_viewers = ttk.Label(status_frame, text="👁️ --", font=("Segoe UI", 10, "bold"), foreground="#FF0000")
        self.lbl_viewers.pack(side="right", padx=10)

        self.main_paned = ttk.PanedWindow(self.root, orient=tk.VERTICAL, style="TPanedwindow")
        self.main_paned.pack(fill="both", expand=True, padx=10, pady=5)

        chat_wrapper = ttk.Frame(self.main_paned)
        header_frame = ttk.Frame(chat_wrapper)
        header_frame.pack(fill="x", pady=(0, 2))
        ttk.Label(header_frame, text="LIVE CHAT FEED", style="Cyan.TLabel").pack(side="left")
        
        self.ai_status_lbl = ttk.Label(header_frame, text="(Backend: Local)", font=("Segoe UI", 9), foreground="gray")
        self.ai_status_lbl.pack(side="left", padx=10)

        ttk.Button(header_frame, text="Clear Chat", command=self.clear_chat_preview, width=10).pack(side="right", padx=5)
        
        self.chat_preview_text = scrolledtext.ScrolledText(chat_wrapper, state='disabled', font=("Segoe UI", 11), bg="#000000", fg="#FFFFFF", insertbackground="white")
        self.chat_preview_text.pack(fill="both", expand=True)
        self.chat_preview_text.tag_config("author", foreground="#00BFFF", font=("Segoe UI", 11, "bold")) 
        self.chat_preview_text.tag_config("bot", foreground="#00FF00", font=("Segoe UI", 11, "bold")) 
        self.chat_preview_text.tag_config("msg", foreground="#E0E0E0") 
        self.main_paned.add(chat_wrapper, weight=3)

        log_wrapper = ttk.Frame(self.main_paned)
        log_header = ttk.Frame(log_wrapper)
        log_header.pack(fill="x", pady=(2, 2))
        ttk.Label(log_header, text="System Log", style="Cyan.TLabel").pack(side="left")
        self.console_text = scrolledtext.ScrolledText(log_wrapper, state='disabled', font=("Consolas", 9), bg="#111111", fg="#00FF00", insertbackground="white")
        self.console_text.pack(fill="both", expand=True)
        self.main_paned.add(log_wrapper, weight=1)

    def make_window_taskbar_visible(self, window):
        try:
            import ctypes
            hwnd = int(window.wm_frame(), 16)
            style = ctypes.windll.user32.GetWindowLongW(hwnd, -20)
            ctypes.windll.user32.SetWindowLongW(hwnd, -20, (style & ~0x00000080) | 0x00040000)
            window.withdraw()
            window.after(10, window.deiconify)
        except: pass

    def open_voicebox_settings(self):
        from tkinter import simpledialog, messagebox
        
        current_url = getattr(self.controller.model, 'voicebox_url', "http://127.0.0.1:17493")
        
        new_url = simpledialog.askstring(
            "Voicebox API Settings", 
            "Enter your Voicebox (Pinokio) API URL:", 
            initialvalue=current_url, 
            parent=self.root
        )
        
        if new_url is not None:
            self.controller.model.voicebox_url = new_url.strip()
            self.controller.save_config()
            messagebox.showinfo("Saved", f"Voicebox API URL saved successfully:\n{new_url.strip()}", parent=self.root)
            print(f"[System] Voicebox API URL updated to: {new_url.strip()}")

    def open_fish_setup_window(self):
        if hasattr(self, 'fish_window') and self.fish_window and self.fish_window.winfo_exists():
            self.fish_window.lift()
            return
            
        win = tk.Toplevel(self.root)
        self.fish_window = win
        win.title("Fish Speech Voice Cloning Setup")
        win.geometry("500x480")
        win.configure(bg="#222")
        win.attributes("-topmost", True)
        
        ttk.Label(win, text="Fish Speech (Zero-Shot Voice Cloning)", style="Cyan.TLabel", background="#222").pack(pady=10)
        
        safe_select_audio = getattr(self.controller, 'select_fish_audio', lambda: messagebox.showwarning("Warning", "Controller missing select_fish_audio!"))
        safe_select_text = getattr(self.controller, 'select_fish_text', lambda: messagebox.showwarning("Warning", "Controller missing select_fish_text!"))
        
        f1 = tk.Frame(win, bg="#222")
        f1.pack(fill="x", padx=15, pady=5)
        tk.Button(f1, text="1. Select Ref Audio (.wav)", command=safe_select_audio, bg="#444", fg="white", width=22).pack(side="left")
        self.lbl_fish_audio = tk.Label(f1, text=os.path.basename(self.controller.model.fish_audio_path) if getattr(self.controller.model, 'fish_audio_path', "") else "None", bg="#222", fg="lime")
        self.lbl_fish_audio.pack(side="left", padx=10)

        f2 = tk.Frame(win, bg="#222")
        f2.pack(fill="x", padx=15, pady=5)
        tk.Button(f2, text="2. Select Ref Text (.txt)", command=safe_select_text, bg="#444", fg="white", width=22).pack(side="left")
        self.lbl_fish_text = tk.Label(f2, text=os.path.basename(self.controller.model.fish_text_path) if getattr(self.controller.model, 'fish_text_path', "") else "None", bg="#222", fg="lime")
        self.lbl_fish_text.pack(side="left", padx=10)
        
        ttk.Separator(win, orient='horizontal').pack(fill='x', padx=15, pady=15)
        tk.Label(win, text="Saved Presets", bg="#222", fg="cyan", font=("Arial", 10, "bold")).pack()
        
        preset_f = tk.Frame(win, bg="#222")
        preset_f.pack(fill="x", padx=15, pady=5)
        
        tk.Label(preset_f, text="Save As:", bg="#222", fg="white").grid(row=0, column=0, padx=5, pady=5)
        self.fish_preset_name_var = tk.StringVar()
        tk.Entry(preset_f, textvariable=self.fish_preset_name_var, width=15).grid(row=0, column=1, padx=5, pady=5)
        
        safe_save_preset = getattr(self.controller, 'save_fish_preset', lambda: None)
        tk.Button(preset_f, text="💾 Save", bg="green", fg="white", command=safe_save_preset).grid(row=0, column=2, padx=5, pady=5)
        
        tk.Label(preset_f, text="Load:", bg="#222", fg="white").grid(row=1, column=0, padx=5, pady=10)
        self.fish_preset_combo = ttk.Combobox(preset_f, state="readonly", width=13)
        self.fish_preset_combo.grid(row=1, column=1, padx=5, pady=10)
        
        safe_load_preset = getattr(self.controller, 'load_fish_preset', lambda n: None)
        def on_preset_select(e):
            safe_load_preset(self.fish_preset_combo.get())
            
        self.fish_preset_combo.bind("<<ComboboxSelected>>", on_preset_select)
        
        safe_del_preset = getattr(self.controller, 'delete_fish_preset', lambda: None)
        tk.Button(preset_f, text="🗑️ Del", bg="red", fg="white", command=safe_del_preset).grid(row=1, column=2, padx=5, pady=10)
        
        if hasattr(self.controller, 'refresh_fish_presets_ui'):
            self.controller.refresh_fish_presets_ui() 
        
        tk.Label(win, text="* Make sure to select 'Fish Speech' in the TTS Engine menu.", bg="#222", fg="gray", font=("Arial", 9)).pack(side="bottom", pady=15)

    def open_rvc_setup_window(self):
        if hasattr(self, 'rvc_window') and self.rvc_window and self.rvc_window.winfo_exists():
            self.rvc_window.lift()
            return
            
        win = tk.Toplevel(self.root)
        self.rvc_window = win
        win.title("RVC Voice Cloning Setup")
        win.geometry("500x480")
        win.configure(bg="#222")
        win.attributes("-topmost", True)
        
        ttk.Label(win, text="RVC (Voice Cloning) Setup", style="Cyan.TLabel", background="#222").pack(pady=10)
        
        safe_rvc_model = getattr(self.controller, 'select_rvc_model', lambda: None)
        safe_rvc_index = getattr(self.controller, 'select_rvc_index', lambda: None)
        safe_rvc_pitch = getattr(self.controller, 'set_rvc_pitch', lambda v: None)
        
        f1 = tk.Frame(win, bg="#222")
        f1.pack(fill="x", padx=15, pady=5)
        tk.Button(f1, text="1. Select .pth Model", command=safe_rvc_model, bg="#444", fg="white", width=20).pack(side="left")
        self.lbl_rvc_model = tk.Label(f1, text=os.path.basename(self.controller.model.rvc_model_path) if getattr(self.controller.model, 'rvc_model_path', "") else "None", bg="#222", fg="lime")
        self.lbl_rvc_model.pack(side="left", padx=10)

        f2 = tk.Frame(win, bg="#222")
        f2.pack(fill="x", padx=15, pady=5)
        tk.Button(f2, text="2. Select .index (Optional)", command=safe_rvc_index, bg="#444", fg="white", width=20).pack(side="left")
        self.lbl_rvc_index = tk.Label(f2, text=os.path.basename(self.controller.model.rvc_index_path) if getattr(self.controller.model, 'rvc_index_path', "") else "None", bg="#222", fg="lime")
        self.lbl_rvc_index.pack(side="left", padx=10)
        
        f3 = tk.Frame(win, bg="#222")
        f3.pack(fill="x", padx=15, pady=15)
        tk.Label(f3, text="Pitch Shift (+/- semitones):", bg="#222", fg="white").pack(side="left")
        self.rvc_pitch_var = tk.IntVar(value=getattr(self.controller.model, 'rvc_pitch', 0))
        pitch_scale = tk.Scale(f3, from_=-24, to=24, orient="horizontal", variable=self.rvc_pitch_var, bg="#222", fg="white", highlightthickness=0, command=lambda v: safe_rvc_pitch(v))
        pitch_scale.pack(side="left", fill="x", expand=True, padx=10)
        
        ttk.Separator(win, orient='horizontal').pack(fill='x', padx=15, pady=10)
        tk.Label(win, text="Saved Presets", bg="#222", fg="cyan", font=("Arial", 10, "bold")).pack()
        
        preset_f = tk.Frame(win, bg="#222")
        preset_f.pack(fill="x", padx=15, pady=5)
        
        tk.Label(preset_f, text="Save As:", bg="#222", fg="white").grid(row=0, column=0, padx=5, pady=5)
        self.rvc_preset_name_var = tk.StringVar()
        tk.Entry(preset_f, textvariable=self.rvc_preset_name_var, width=15).grid(row=0, column=1, padx=5, pady=5)
        
        safe_save_rvc = getattr(self.controller, 'save_rvc_preset', lambda: None)
        tk.Button(preset_f, text="💾 Save", bg="green", fg="white", command=safe_save_rvc).grid(row=0, column=2, padx=5, pady=5)
        
        tk.Label(preset_f, text="Load:", bg="#222", fg="white").grid(row=1, column=0, padx=5, pady=10)
        self.rvc_preset_combo = ttk.Combobox(preset_f, state="readonly", width=13)
        self.rvc_preset_combo.grid(row=1, column=1, padx=5, pady=10)
        
        safe_load_rvc = getattr(self.controller, 'load_rvc_preset', lambda x: None)
        def on_preset_select(e):
            safe_load_rvc(self.rvc_preset_combo.get())
            
        self.rvc_preset_combo.bind("<<ComboboxSelected>>", on_preset_select)
        
        safe_del_rvc = getattr(self.controller, 'delete_rvc_preset', lambda: None)
        tk.Button(preset_f, text="🗑️ Del", bg="red", fg="white", command=safe_del_rvc).grid(row=1, column=2, padx=5, pady=10)
        
        if hasattr(self.controller, 'refresh_rvc_presets_ui'):
            self.controller.refresh_rvc_presets_ui() 
        
        tk.Label(win, text="* Make sure to select 'RVC (Voice Cloning Local)' in the TTS Engine menu.", bg="#222", fg="gray", font=("Arial", 9)).pack(side="bottom", pady=15)

    def open_elevenlabs_setup_window(self):
        if hasattr(self, 'elevenlabs_window') and self.elevenlabs_window and self.elevenlabs_window.winfo_exists():
            self.elevenlabs_window.lift()
            return
            
        win = tk.Toplevel(self.root)
        self.elevenlabs_window = win
        win.title("ElevenLabs Presets Setup")
        # Made the window slightly taller and wider to fit the new text boxes
        win.geometry("900x220") 
        win.configure(bg="#222")
        win.attributes("-topmost", True)

        el_preset_frame = tk.LabelFrame(win, text="ElevenLabs Voice Presets", bg="#1e1e1e", fg="#00FFFF", font=("Arial", 10, "bold"))
        el_preset_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # The 4 variables that the Controller needs to save!
        self.elevenlabs_preset_name_var = tk.StringVar()
        self.elevenlabs_preset_id_var = tk.StringVar() 
        self.elevenlabs_api_key_var = tk.StringVar() 
        self.elevenlabs_email_var = tk.StringVar() 

        row1 = tk.Frame(el_preset_frame, bg="#1e1e1e")
        row1.pack(fill="x", padx=5, pady=5)
        
        tk.Label(row1, text="Saved Presets:", bg="#1e1e1e", fg="white").pack(side="left")
        self.elevenlabs_preset_combo = ttk.Combobox(row1, state="readonly", width=20)
        self.elevenlabs_preset_combo.pack(side="left", padx=5)
        
        safe_load_el = getattr(self.controller, 'load_elevenlabs_preset', lambda n: None)
        safe_delete_el = getattr(self.controller, 'delete_elevenlabs_preset', lambda: None)
        safe_save_el = getattr(self.controller, 'save_elevenlabs_preset', lambda: None)

        tk.Button(row1, text="Load", bg="#444", fg="white", cursor="hand2", command=lambda: safe_load_el(self.elevenlabs_preset_combo.get())).pack(side="left", padx=2)
        tk.Button(row1, text="Delete", bg="#800000", fg="white", cursor="hand2", command=safe_delete_el).pack(side="left", padx=2)

        # ROW 2: Identity (Preset Name & Voice ID)
        row2 = tk.Frame(el_preset_frame, bg="#1e1e1e")
        row2.pack(fill="x", padx=5, pady=5)
        
        tk.Label(row2, text="Preset Name:", bg="#1e1e1e", fg="white").pack(side="left")
        tk.Entry(row2, textvariable=self.elevenlabs_preset_name_var, width=20, bg="#333", fg="white", insertbackground="white").pack(side="left", padx=5)

        tk.Label(row2, text="Voice ID:", bg="#1e1e1e", fg="white").pack(side="left", padx=(10, 0))
        tk.Entry(row2, textvariable=self.elevenlabs_preset_id_var, width=30, bg="#333", fg="white", insertbackground="white").pack(side="left", padx=5)

        # ROW 3: Credentials (API Key, Email & Save Button)
        row3 = tk.Frame(el_preset_frame, bg="#1e1e1e")
        row3.pack(fill="x", padx=5, pady=5)

        tk.Label(row3, text="API Key:", bg="#1e1e1e", fg="#FF00FF").pack(side="left")
        tk.Entry(row3, textvariable=self.elevenlabs_api_key_var, width=40, bg="#333", fg="white", insertbackground="white").pack(side="left", padx=5)

        tk.Label(row3, text="Email:", bg="#1e1e1e", fg="gray").pack(side="left", padx=(10, 0))
        tk.Entry(row3, textvariable=self.elevenlabs_email_var, width=25, bg="#333", fg="white", insertbackground="white").pack(side="left", padx=5)
        
        tk.Button(row3, text="💾 Save Preset", bg="#006400", fg="white", cursor="hand2", command=safe_save_el).pack(side="left", padx=(15, 0))
        
        self.refresh_elevenlabs_presets_ui()

    def open_groq_settings_window(self):
        if self.groq_window and self.groq_window.winfo_exists():
            self.groq_window.lift()
            return
        self.groq_window = tk.Toplevel(self.root)
        self.groq_window.title("Groq AI Settings")
        self.groq_window.geometry("500x500")
        self.groq_window.configure(bg="#222")
        self.groq_window.attributes("-topmost", True)

        ttk.Label(self.groq_window, text="Groq Cloud API Settings", style="Cyan.TLabel", background="#222").pack(pady=10)
        
        tk.Label(self.groq_window, text="Enter API Keys (One per line):", bg="#222", fg="white", anchor="w").pack(fill="x", padx=10)
        self.groq_text_area = scrolledtext.ScrolledText(self.groq_window, height=10, bg="#111", fg="#00FF00", font=("Consolas", 10), insertbackground="white")
        self.groq_text_area.pack(fill="both", expand=True, padx=10, pady=5)
        
        current_keys = "\n".join(self.controller.model.groq_api_keys)
        self.groq_text_area.insert("1.0", current_keys)
        
        btn_frame = tk.Frame(self.groq_window, bg="#222")
        btn_frame.pack(fill="x", pady=10)
        
        safe_save_groq = getattr(self.controller, 'test_and_save_groq_keys', lambda k, w: None)
        def _save():
            raw = self.groq_text_area.get("1.0", "end").strip()
            keys = [k.strip() for k in raw.split("\n") if k.strip()]
            safe_save_groq(keys, self.groq_window)

        tk.Button(btn_frame, text="✅ Test & Save Keys", bg="green", fg="white", command=_save).pack(side="right", padx=10)
        tk.Button(btn_frame, text="❌ Cancel", bg="red", fg="white", command=self.groq_window.destroy).pack(side="right", padx=10)

    def open_gemini_settings_window(self):
        if self.gemini_window and self.gemini_window.winfo_exists():
            self.gemini_window.lift()
            return
        self.gemini_window = tk.Toplevel(self.root)
        self.gemini_window.title("Google Gemini AI Settings")
        self.gemini_window.geometry("500x500")
        self.gemini_window.configure(bg="#222")
        self.gemini_window.attributes("-topmost", True)

        ttk.Label(self.gemini_window, text="Google Gemini API Settings", style="Cyan.TLabel", background="#222").pack(pady=10)
        
        tk.Label(self.gemini_window, text="Enter API Keys (One per line):", bg="#222", fg="white", anchor="w").pack(fill="x", padx=10)
        self.gemini_text_area = scrolledtext.ScrolledText(self.gemini_window, height=10, bg="#111", fg="#00FF00", font=("Consolas", 10), insertbackground="white")
        self.gemini_text_area.pack(fill="both", expand=True, padx=10, pady=5)
        
        current_keys = "\n".join(self.controller.model.gemini_api_keys)
        self.gemini_text_area.insert("1.0", current_keys)
        
        btn_frame = tk.Frame(self.gemini_window, bg="#222")
        btn_frame.pack(fill="x", pady=10)
        
        safe_save_gemini = getattr(self.controller, 'test_and_save_gemini_keys', lambda k, w: None)
        def _save():
            raw = self.gemini_text_area.get("1.0", "end").strip()
            keys = [k.strip() for k in raw.split("\n") if k.strip()]
            safe_save_gemini(keys, self.gemini_window)

        tk.Button(btn_frame, text="✅ Test & Save Keys", bg="green", fg="white", command=_save).pack(side="right", padx=10)
        tk.Button(btn_frame, text="❌ Cancel", bg="red", fg="white", command=self.gemini_window.destroy).pack(side="right", padx=10)

    def open_openrouter_settings_window(self):
        if hasattr(self, 'openrouter_window') and self.openrouter_window and self.openrouter_window.winfo_exists():
            self.openrouter_window.lift()
            return
        self.openrouter_window = tk.Toplevel(self.root)
        self.openrouter_window.title("OpenRouter AI Settings")
        self.openrouter_window.geometry("500x500")
        self.openrouter_window.configure(bg="#222")
        self.openrouter_window.attributes("-topmost", True)

        ttk.Label(self.openrouter_window, text="OpenRouter API Settings", style="Cyan.TLabel", background="#222").pack(pady=10)
        
        tk.Label(self.openrouter_window, text="Enter API Keys (One per line):", bg="#222", fg="white", anchor="w").pack(fill="x", padx=10)
        self.openrouter_text_area = scrolledtext.ScrolledText(self.openrouter_window, height=10, bg="#111", fg="#00FF00", font=("Consolas", 10), insertbackground="white")
        self.openrouter_text_area.pack(fill="both", expand=True, padx=10, pady=5)
        
        current_keys = "\n".join(getattr(self.controller.model, 'openrouter_api_keys', []))
        self.openrouter_text_area.insert("1.0", current_keys)
        
        btn_frame = tk.Frame(self.openrouter_window, bg="#222")
        btn_frame.pack(fill="x", pady=10)
        
        safe_save_openrouter = getattr(self.controller, 'test_and_save_openrouter_keys', lambda k, w: None)
        def _save():
            raw = self.openrouter_text_area.get("1.0", "end").strip()
            keys = [k.strip() for k in raw.split("\n") if k.strip()]
            safe_save_openrouter(keys, self.openrouter_window)

        tk.Button(btn_frame, text="✅ Test & Save Keys", bg="green", fg="white", command=_save).pack(side="right", padx=10)
        tk.Button(btn_frame, text="❌ Cancel", bg="red", fg="white", command=self.openrouter_window.destroy).pack(side="right", padx=10)

    def open_sambanova_settings_window(self):
        if hasattr(self, 'sambanova_window') and self.sambanova_window and self.sambanova_window.winfo_exists():
            self.sambanova_window.lift()
            return
        self.sambanova_window = tk.Toplevel(self.root)
        self.sambanova_window.title("SambaNova AI Settings")
        self.sambanova_window.geometry("500x500")
        self.sambanova_window.configure(bg="#222")
        self.sambanova_window.attributes("-topmost", True)

        ttk.Label(self.sambanova_window, text="SambaNova API Settings", style="Cyan.TLabel", background="#222").pack(pady=10)
        
        tk.Label(self.sambanova_window, text="Enter API Keys (One per line):", bg="#222", fg="white", anchor="w").pack(fill="x", padx=10)
        self.sambanova_text_area = scrolledtext.ScrolledText(self.sambanova_window, height=10, bg="#111", fg="#00FF00", font=("Consolas", 10), insertbackground="white")
        self.sambanova_text_area.pack(fill="both", expand=True, padx=10, pady=5)
        
        current_keys = "\n".join(getattr(self.controller.model, 'sambanova_api_keys', []))
        self.sambanova_text_area.insert("1.0", current_keys)
        
        btn_frame = tk.Frame(self.sambanova_window, bg="#222")
        btn_frame.pack(fill="x", pady=10)
        
        safe_save_sambanova = getattr(self.controller, 'test_and_save_sambanova_keys', lambda k, w: None)
        def _save():
            raw = self.sambanova_text_area.get("1.0", "end").strip()
            keys = [k.strip() for k in raw.split("\n") if k.strip()]
            safe_save_sambanova(keys, self.sambanova_window)

        tk.Button(btn_frame, text="✅ Test & Save Keys", bg="green", fg="white", command=_save).pack(side="right", padx=10)
        tk.Button(btn_frame, text="❌ Cancel", bg="red", fg="white", command=self.sambanova_window.destroy).pack(side="right", padx=10)

    def clear_chat_preview(self):
        self.chat_preview_text.configure(state='normal')
        self.chat_preview_text.delete('1.0', tk.END)
        self.chat_preview_text.configure(state='disabled')

    def open_add_channel_popup(self):
        popup = tk.Toplevel(self.root)
        popup.title("Add New Channel")
        popup.geometry("450x300")
        popup.configure(bg="#222")
        popup.attributes("-topmost", True)
        ttk.Label(popup, text="Add New YouTube Channel", style="Cyan.TLabel", background="#222").pack(pady=10)
        tk.Label(popup, text="Channel Name (Display Name):", bg="#222", fg="white").pack(pady=(5, 0), anchor="w", padx=20)
        entry_name = tk.Entry(popup, width=40)
        entry_name.pack(pady=5, padx=20)
        tk.Label(popup, text="Channel ID (e.g., UC123abc...):", bg="#222", fg="white").pack(pady=(10, 0), anchor="w", padx=20)
        entry_id = tk.Entry(popup, width=40)
        entry_id.pack(pady=5, padx=20)
        
        safe_save_chan = getattr(self.controller, 'save_new_channel_to_env', lambda n, c, p: None)
        def _save():
            name, cid = entry_name.get().strip(), entry_id.get().strip()
            if not name or not cid: return
            safe_save_chan(name, cid, popup)
        ttk.Button(popup, text="💾 Save to .env", command=_save).pack(pady=10)

    def open_cred_manager(self):
        popup = tk.Toplevel(self.root)
        popup.title("Credential & Paths Manager")
        popup.geometry("540x700") # Made taller to fit the new directory setting
        popup.configure(bg="#222")
        popup.attributes("-topmost", True)
        self.cred_popup = popup
        
        ttk.Label(popup, text="API Credentials & Paths Setup", style="Cyan.TLabel", background="#222").pack(pady=10)
        tk.Label(popup, text="1. Google/YouTube API (client_secret.json)", bg="#222", fg="#00FF00", font=("Arial", 10, "bold")).pack(anchor="w", padx=20, pady=(5,0))
        
        f_google_btns = tk.Frame(popup, bg="#222")
        f_google_btns.pack(anchor="w", fill="x", padx=20, pady=5)
        
        safe_import_json = getattr(self.controller, 'import_json_credential', lambda p: None)
        tk.Button(f_google_btns, text="📂 Import Google JSON", command=lambda: safe_import_json(popup)).pack(side="left", padx=(0, 5))
        
        ttk.Separator(popup, orient='horizontal').pack(fill='x', padx=20, pady=10)
        tk.Label(popup, text="2. Hugging Face Token (Fixes Bark Speed Warning)", bg="#222", fg="#00FF00", font=("Arial", 10, "bold")).pack(anchor="w", padx=20, pady=(5,0))
        tk.Label(popup, text="Token (Starts with 'hf_...'):", bg="#222", fg="white").pack(anchor="w", padx=20)
        
        entry_hf = tk.Entry(popup, width=50)
        entry_hf.pack(pady=5, padx=20)
        if os.environ.get("HF_TOKEN", ""): entry_hf.insert(0, os.environ.get("HF_TOKEN", ""))
        
        safe_save_hf = getattr(self.controller, 'save_hf_token', lambda t: None)
        def _save_hf():
            token = entry_hf.get().strip()
            if not token and "HF_TOKEN" in os.environ: del os.environ["HF_TOKEN"]
            elif token: os.environ["HF_TOKEN"] = token
            safe_save_hf(token)
            messagebox.showinfo("Saved", "Hugging Face Token saved.\nRestart app for full effect on Bark.", parent=popup)

        tk.Button(popup, text="💾 Save Token", bg="green", fg="white", command=_save_hf).pack(pady=5)
        
        ttk.Separator(popup, orient='horizontal').pack(fill='x', padx=20, pady=10)
        tk.Label(popup, text="3. TikTok TTS (sessionid cookie)", bg="#222", fg="#00FF00", font=("Arial", 10, "bold")).pack(anchor="w", padx=20, pady=(5,0))
        entry_tiktok = tk.Entry(popup, width=50)
        entry_tiktok.pack(pady=5, padx=20)
        
        if os.environ.get("TIKTOK_SESSION_ID", ""): entry_tiktok.insert(0, os.environ.get("TIKTOK_SESSION_ID", ""))
        
        safe_save_tiktok = getattr(self.controller, 'save_tiktok_session', lambda t: None)
        def _save_tiktok():
            token = entry_tiktok.get().strip()
            if not token and "TIKTOK_SESSION_ID" in os.environ: del os.environ["TIKTOK_SESSION_ID"]
            elif token: os.environ["TIKTOK_SESSION_ID"] = token
            safe_save_tiktok(token)
            messagebox.showinfo("Saved", "TikTok Session ID saved.", parent=popup)

        tk.Button(popup, text="💾 Save TikTok Session", bg="green", fg="white", command=_save_tiktok).pack(pady=5)

        ttk.Separator(popup, orient='horizontal').pack(fill='x', padx=20, pady=10)
        tk.Label(popup, text="4. Jina AI Search API Keys (One per line for rotation)", bg="#222", fg="#00FF00", font=("Arial", 10, "bold")).pack(anchor="w", padx=20, pady=(5,0))
        
        text_jina = scrolledtext.ScrolledText(popup, height=3, width=50, bg="#333", fg="white", insertbackground="white", font=("Arial", 9))
        text_jina.pack(pady=5, padx=20)
        
        existing_keys = os.environ.get("JINA_API_KEYS", os.environ.get("JINA_API_KEY", ""))
        if existing_keys:
            text_jina.insert("1.0", existing_keys.replace(",", "\n"))
        
        safe_save_jina = getattr(self.controller, 'save_jina_keys', lambda t: None)
        def _save_jina():
            raw_keys = text_jina.get("1.0", "end-1c").strip()
            keys_list = [k.strip() for k in raw_keys.split("\n") if k.strip()]
            keys_str = ",".join(keys_list)
            
            if not keys_str and "JINA_API_KEYS" in os.environ: del os.environ["JINA_API_KEYS"]
            elif keys_str: os.environ["JINA_API_KEYS"] = keys_str
            safe_save_jina(keys_str)
            messagebox.showinfo("Saved", f"Saved {len(keys_list)} Jina AI Keys for rotation.", parent=popup)

        tk.Button(popup, text="💾 Save Search Keys", bg="green", fg="white", command=_save_jina).pack(pady=5)
        
        ttk.Separator(popup, orient="horizontal").pack(fill="x", pady=10)
        
        # --- NEW SECTION: GLOBAL MODEL PATH ---
        tk.Label(popup, text="5. Global AI Models Cache Path (Bark/HuggingFace)", bg="#222", fg="#FFD700", font=("Arial", 10, "bold")).pack(anchor="w", padx=20, pady=(5,0))
        path_frame = tk.Frame(popup, bg="#222")
        path_frame.pack(fill="x", padx=20, pady=5)
        
        entry_model_path = tk.Entry(path_frame, width=42, bg="#333", fg="white", insertbackground="white")
        entry_model_path.pack(side="left", padx=(0, 5))
        
        if getattr(self.controller.model, 'global_model_path', ""):
            entry_model_path.insert(0, getattr(self.controller.model, 'global_model_path', ""))
            
        def _browse_path():
            d = filedialog.askdirectory(parent=popup, title="Select Folder to save AI Models")
            if d:
                entry_model_path.delete(0, "end")
                entry_model_path.insert(0, d)
                
        tk.Button(path_frame, text="📁 Browse", bg="#555", fg="white", command=_browse_path).pack(side="left")
        
        safe_save_path = getattr(self.controller, 'save_global_model_path', lambda p: None)
        def _save_path():
            p = entry_model_path.get().strip()
            safe_save_path(p)
            messagebox.showinfo("Saved", f"Model Path saved!\n\nIMPORTANT: You MUST close and restart the Streamer Bot for this change to take effect.", parent=popup)
            
        tk.Button(popup, text="💾 Save Models Path", bg="#B8860B", fg="white", font=("Arial", 9, "bold"), command=_save_path).pack(pady=(0, 10))
        
        ttk.Separator(popup, orient="horizontal").pack(fill="x", pady=10)

        tk.Label(popup, text="6. ElevenLabs API Keys (One per line for rotation)", bg="#222", fg="#FF00FF", font=("Arial", 10, "bold")).pack(anchor="w", padx=20, pady=(5,0))
        el_text = scrolledtext.ScrolledText(popup, height=3, width=50, bg="#333", fg="white", insertbackground="white", font=("Arial", 9))
        if getattr(self.controller.model, 'elevenlabs_api_keys', []): el_text.insert("1.0", "\n".join(self.controller.model.elevenlabs_api_keys))
        el_text.pack(fill="x", padx=20, pady=5)
        
        def save_el():
            keys = [k.strip() for k in el_text.get("1.0", "end-1c").split("\n") if k.strip()]
            self.controller.model.elevenlabs_api_keys = keys
            self.controller.save_config()
            messagebox.showinfo("Saved", f"Saved {len(keys)} ElevenLabs keys!", parent=popup)
        tk.Button(popup, text="💾 Save ElevenLabs Keys", bg="#800080", fg="white", font=("Arial", 10, "bold"), command=save_el).pack(pady=(5, 15))
        
        ttk.Separator(popup, orient='horizontal').pack(fill='x', padx=20, pady=10)
        
        safe_open_console = getattr(self.controller, 'open_google_console', lambda: None)
        ttk.Button(popup, text="🌐 Open Google Cloud Console", command=safe_open_console).pack(pady=5)

    def toggle_chat_selector(self):
        if self.selector_window and self.selector_window.winfo_exists():
            self.saved_selector_geo = self.selector_window.geometry()
            self.selector_window.destroy()
            self.selector_window = None
        else:
            self.open_chat_selector()

    def open_chat_selector(self):
        def widget_focus():
            try:
                if not self.selector_window or not self.selector_window.winfo_exists(): return
                self.selector_window.update_idletasks()
                import ctypes
                hwnd = int(self.selector_window.wm_frame(), 16)
                ctypes.windll.user32.keybd_event(0x12, 0, 0, 0)
                ctypes.windll.user32.keybd_event(0x12, 0, 2, 0)
                ctypes.windll.user32.SetForegroundWindow(hwnd)
                ctypes.windll.user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 19)
                self.selector_text.focus_force()
            except: pass

        self.selector_window = tk.Toplevel(self.root)
        self.selector_window.title("StreamerBot Chat List")
        self.selector_window.geometry(self.saved_selector_geo or "500x700")
        self.selector_window.configure(bg="#000000")
        self.selector_window.attributes("-topmost", True)
        self.selector_window.overrideredirect(True)
        self.selector_window.attributes("-alpha", 0.85) 

        def start_move(event):
            if not getattr(self, 'selector_window', None) or not self.selector_window.winfo_exists(): return
            self.selector_window.start_x = event.x_root
            self.selector_window.start_y = event.y_root
            self.selector_window.win_x = self.selector_window.winfo_x()
            self.selector_window.win_y = self.selector_window.winfo_y()

        def do_move(event):
            if not getattr(self, 'selector_window', None) or not self.selector_window.winfo_exists(): return
            win_x = getattr(self.selector_window, 'win_x', None)
            start_x = getattr(self.selector_window, 'start_x', None)
            if win_x is None or start_x is None: return
            x = win_x + (event.x_root - start_x)
            y = getattr(self.selector_window, 'win_y', 0) + (event.y_root - getattr(self.selector_window, 'start_y', 0))
            self.selector_window.geometry(f"+{x}+{y}")

        header_frame = tk.Frame(self.selector_window, bg="#1a1a1a", height=25, cursor="fleur")
        header_frame.pack(fill="x", side="top")
        title_lbl = tk.Label(header_frame, text=" ≡ LIVE CHAT (Must be Borderless Windowed)", bg="#1a1a1a", fg="#ffaa00", font=("Arial", 9, "bold"), cursor="fleur")
        title_lbl.pack(side="left", padx=10)
        tk.Button(header_frame, text="✖", bg="#1a1a1a", fg="gray", borderwidth=0, command=self.toggle_chat_selector, width=3).pack(side="right", fill="y")
        
        header_frame.bind("<Button-1>", start_move)
        header_frame.bind("<B1-Motion>", do_move)
        title_lbl.bind("<Button-1>", start_move)
        title_lbl.bind("<B1-Motion>", do_move)

        bottom_container = tk.Frame(self.selector_window, bg="#0a0a0a")
        bottom_container.pack(side="bottom", fill="x", padx=5, pady=5)
        
        tools_frame = tk.Frame(bottom_container, bg="#0a0a0a")
        tools_frame.pack(fill="x", pady=(0, 4))
        
        safe_start_ptt = getattr(self.controller, 'start_ptt_mic', lambda b, t: None)
        safe_stop_ptt = getattr(self.controller, 'stop_ptt_mic', lambda b, t: None)
        safe_improve = getattr(self.controller, 'improve_selector_text', lambda: None)
        safe_req_hist = getattr(self.controller, 'request_chat_history', lambda: None)
        safe_reply_sel = getattr(self.controller, 'reply_to_selected_chat', lambda: None)
        safe_send_sel = getattr(self.controller, 'send_selector_text', lambda: None)
        
        self.mic_btn = tk.Button(tools_frame, text="🎤 Hold", bg="#333", fg="white", font=("Arial", 8, "bold"), borderwidth=0, width=8)
        self.mic_btn.pack(side="left", padx=(0, 5))
        self.mic_btn.bind("<ButtonPress-1>", lambda e: safe_start_ptt(self.mic_btn, self.selector_text))
        self.mic_btn.bind("<ButtonRelease-1>", lambda e: safe_stop_ptt(self.mic_btn, self.selector_text))
        
        tk.Button(tools_frame, text="✨ Improve", bg="#5500aa", fg="white", font=("Arial", 8), borderwidth=0, command=safe_improve).pack(side="left")
        
        tk.Checkbutton(tools_frame, text="🔊 Voice Only", variable=self.chat_selector_voice_only_var, bg="#0a0a0a", fg="#00FFFF", selectcolor="#222").pack(side="left", padx=5)
        tk.Checkbutton(tools_frame, text="👤 Hide Bots", variable=self.hide_bot_chat_var, bg="#0a0a0a", fg="#FFD700", selectcolor="#222", command=safe_req_hist).pack(side="left", padx=5)
        
        ttk.Button(tools_frame, text="🔄 Refresh", command=safe_req_hist).pack(side="right")
        ttk.Button(tools_frame, text="💬 Reply", command=safe_reply_sel).pack(side="right", padx=5)

        input_frame = tk.Frame(bottom_container, bg="#0a0a0a")
        input_frame.pack(fill="x")
        self.selector_text = tk.Text(input_frame, height=2, font=("Segoe UI", 11), bg="#1e1e1e", fg="white", insertbackground="white", borderwidth=0)
        self.selector_text.pack(side="left", fill="both", expand=True, padx=(0, 5))
        self.btn_sel_send = tk.Button(input_frame, text="Send\n(Enter)", bg="#008000", fg="white", font=("Arial", 9, "bold"), borderwidth=0, width=8, command=safe_send_sel)
        self.btn_sel_send.pack(side="right", fill="y")
        
        def _on_enter(event):
            if not event.state & 0x0001: safe_send_sel(); return "break"
        self.selector_text.bind("<Return>", _on_enter)

        chat_wrapper = tk.Frame(self.selector_window, bg="#0a0a0a")
        chat_wrapper.pack(side="top", fill="both", expand=True, padx=5, pady=(0, 5))
        
        tk.Label(chat_wrapper, text="💡 Double-click any chat message below to edit it before clicking Reply", bg="#0a0a0a", fg="#00FFFF", font=("Arial", 8, "italic")).pack(side="top", anchor="w", pady=(0, 3))
        
        self.chat_tree = ttk.Treeview(chat_wrapper, columns=("Time", "User", "Message"), show="headings")
        self.chat_tree.heading("Time", text="Time")
        self.chat_tree.heading("User", text="User")
        self.chat_tree.heading("Message", text="Message")
        self.chat_tree.column("Time", width=70, stretch=False)
        self.chat_tree.column("User", width=100, stretch=False)
        self.chat_tree.column("Message", width=300, stretch=True)
        
        scrollbar = ttk.Scrollbar(chat_wrapper, orient="vertical", command=self.chat_tree.yview)
        self.chat_tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.chat_tree.pack(fill="both", expand=True)
        
        def _on_tree_double_click(event):
            selected = self.chat_tree.selection()
            if not selected: return
            item_id = selected[0]
            vals = self.chat_tree.item(item_id, "values")
            if vals and len(vals) >= 3:
                current_name = vals[1]
                current_msg = vals[2]
                
                new_name = simpledialog.askstring("Edit Viewer Name", "Enter Viewer Name:", initialvalue=current_name, parent=self.selector_window)
                if new_name is not None:
                    new_msg = simpledialog.askstring("Edit Message", f"Edit message for {new_name}:", initialvalue=current_msg, parent=self.selector_window)
                    if new_msg is not None and new_msg.strip():
                        self.chat_tree.item(item_id, values=(vals[0], new_name.strip(), new_msg.strip()))

        self.chat_tree.bind("<Double-1>", _on_tree_double_click)
        
        grip = ttk.Sizegrip(self.selector_window)
        grip.place(relx=1.0, rely=1.0, anchor="se")
        
        def start_resize(event):
            if not self.selector_window or not self.selector_window.winfo_exists(): return
            self.selector_window.start_w = self.selector_window.winfo_width()
            self.selector_window.start_h = self.selector_window.winfo_height()
            self.selector_window.start_rx = event.x_root
            self.selector_window.start_ry = event.y_root

        def do_resize(event):
            if not self.selector_window or not self.selector_window.winfo_exists() or not hasattr(self.selector_window, 'start_w'): return
            new_w = max(300, self.selector_window.start_w + (event.x_root - self.selector_window.start_rx))
            new_h = max(250, self.selector_window.start_h + (event.y_root - self.selector_window.start_ry))
            self.selector_window.geometry(f"{new_w}x{new_h}+{self.selector_window.winfo_x()}+{self.selector_window.winfo_y()}")
            
        grip.bind("<Button-1>", start_resize)
        grip.bind("<B1-Motion>", do_resize)
        
        safe_check_hist = getattr(self.controller, 'check_history_queue', lambda: None)
        self.root.after(100, safe_check_hist)
        self.selector_window.after(200, widget_focus)

    def refresh_chat_tree(self):
        if not self.chat_tree or not self.chat_tree.winfo_exists(): return
        for item in self.chat_tree.get_children(): self.chat_tree.delete(item)
        
        safe_buf = getattr(self.controller, 'chat_history_buffer', [])
        self._append_new_messages_to_tree(safe_buf)

    def _append_new_messages_to_tree(self, messages):
        if not self.chat_tree or not self.chat_tree.winfo_exists(): return
        
        hide_bots = False
        if hasattr(self, 'hide_bot_chat_var'):
            hide_bots = self.hide_bot_chat_var.get()
            
        bot_names = ["nightbot", "streamlabs", "streamelements", "system", getattr(self.controller.model, 'channel_name', '').lower()]
        
        for msg in messages:
            raw_author = str(msg.get('author', 'Unknown'))
            raw_text = str(msg.get('message', ''))
            
            author = "".join(c for c in raw_author if ord(c) <= 0xFFFF)
            text = "".join(c for c in raw_text if ord(c) <= 0xFFFF)
            time_str = msg.get('publishedAt', '')
            
            if time_str and len(time_str) >= 5:
                if 'T' in time_str: time_str = time_str.split('T')[1][:5]
                else: time_str = time_str[-14:-9]
            
            if hide_bots and author.lower() in bot_names:
                continue
            
            self.chat_tree.insert("", "end", values=(time_str, author, text))
        
        if self.chat_tree.get_children():
            self.chat_tree.yview_moveto(1.0)

    def close_guide_window(self):
        if getattr(self, 'guide_window', None) and self.guide_window.winfo_exists():
            self.controller.guide_geo_cache = self.guide_window.geometry()
            self.guide_window.destroy()
            self.guide_window = None

    def open_guide_window(self):
        if self.guide_window and self.guide_window.winfo_exists(): return self.guide_window.lift()
        
        self.guide_window = tk.Toplevel(self.root)
        self.guide_window.title("Game Walkthrough & Context Setter")
        self.guide_window.geometry(getattr(self.controller, 'guide_geo_cache', "700x700+100+100")) 
        self.guide_window.configure(bg="#111")
        self.guide_window.attributes("-topmost", True)
        self.guide_window.attributes("-alpha", getattr(self.controller, 'overlay_opacity', 0.85))
        self.guide_window.protocol("WM_DELETE_WINDOW", self.close_guide_window)
        
        ttk.Label(self.guide_window, text="Walkthrough Guide Manager", style="Cyan.TLabel", background="#111").pack(pady=10)
        
        file_frame = tk.LabelFrame(self.guide_window, text="Local Guide File (.txt)", bg="#111", fg="white")
        file_frame.pack(fill="x", padx=10, pady=5)
        self.lbl_guide_filename = tk.Label(file_frame, text="No file loaded (Using AI Gen)", fg="gray", bg="#111", width=40, anchor="w")
        self.lbl_guide_filename.pack(side="left", padx=5)
        
        f_btns = tk.Frame(file_frame, bg="#111")
        f_btns.pack(side="right", padx=5, pady=5)
        
        safe_open_guide = getattr(self.controller, 'open_local_guide_file', lambda: None)
        safe_unload_guide = getattr(self.controller, 'unload_local_guide_file', lambda: None)
        tk.Button(f_btns, text="📂 Load .txt", bg="#444", fg="white", command=safe_open_guide).pack(side="left", padx=2)
        tk.Button(f_btns, text="🗑️ Unload", bg="#B00000", fg="white", command=safe_unload_guide).pack(side="left", padx=2)
        
        url_frame = tk.LabelFrame(self.guide_window, text="Web URL Context (Articles/Wikis)", bg="#111", fg="white")
        url_frame.pack(fill="x", padx=10, pady=5)
        self.guide_url_entry = tk.Entry(url_frame, width=50, bg="#333", fg="white", insertbackground="white")
        self.guide_url_entry.pack(side="left", padx=5, pady=5, fill="x", expand=True)
        self.guide_url_entry.insert(0, "https://")
        
        safe_fetch_url = getattr(self.controller, 'fetch_url_context', lambda: None)
        tk.Button(url_frame, text="🌐 Fetch URL", bg="#0080FF", fg="white", command=safe_fetch_url).pack(side="right", padx=5, pady=5)
        
        input_frame = tk.Frame(self.guide_window, bg="#111")
        input_frame.pack(fill="x", padx=10, pady=10)
        tk.Label(input_frame, text=f"Current Game: {getattr(self.controller.model, 'game_name', 'Just Chatting')}", fg="lime", bg="#111", font=("Arial", 10, "bold")).pack(anchor="w")
        tk.Label(input_frame, text="Objective Keyword:", fg="white", bg="#111").pack(anchor="w", pady=(5,0))
        self.guide_query_entry = tk.Entry(input_frame, width=50, bg="#333", fg="white", insertbackground="white")
        self.guide_query_entry.pack(fill="x", pady=5)
        
        safe_run_guide = getattr(self.controller, 'run_guide_search', lambda: None)
        self.guide_query_entry.bind("<Return>", lambda e: safe_run_guide())
        
        btn_frame = tk.Frame(input_frame, bg="#111")
        btn_frame.pack(fill="x", pady=5)
        self.btn_search_guide = tk.Button(btn_frame, text="🔍 Search / Generate", bg="#0080FF", fg="white", command=safe_run_guide)
        self.btn_search_guide.pack(side="left", fill="x", expand=True, padx=2)
        
        safe_next_match = getattr(self.controller, 'find_next_match', lambda: None)
        self.btn_next_match = tk.Button(btn_frame, text="XY Next Match", bg="#555", fg="white", state="disabled", command=safe_next_match)
        self.btn_next_match.pack(side="left", padx=5)
        
        safe_clear_guide = getattr(self.controller, 'clear_guide_context', lambda: None)
        tk.Button(btn_frame, text="❌ Clear Context", bg="#B00000", fg="white", command=safe_clear_guide).pack(side="right", padx=2)
        
        self.guide_status_lbl = tk.Label(self.guide_window, text="Status: Ready.", fg="gray", bg="#111", font=("Arial", 9, "italic"))

    def toggle_music_window(self, completely_stop=True, hide_only=False):
        if getattr(self, 'music_window', None) and self.music_window.winfo_exists():
            if hide_only:
                if self.music_window.winfo_viewable(): self.music_window.withdraw()
                else: self.music_window.deiconify()
            else:
                self.controller.music_geo_cache = self.music_window.geometry()
                self.music_window.destroy()
                self.music_window = None
                if completely_stop:
                    try:
                        self.controller.stop_music_playback()
                        self.controller.model.music_playlist = []
                    except: pass
        else:
            if hide_only and getattr(self, 'music_window', None):
                self.music_window.deiconify()
            else:
                self.open_music_player_window()

    def open_music_player_window(self):
        if getattr(self, 'music_window', None) and self.music_window.winfo_exists():
            self.music_window.deiconify()
            self.music_window.lift()
            return
            
        def widget_focus():
            try:
                if not self.music_window or not self.music_window.winfo_exists(): return
                self.music_window.update_idletasks()
                import ctypes
                hwnd = int(self.music_window.wm_frame(), 16)
                ctypes.windll.user32.keybd_event(0x12, 0, 0, 0)
                ctypes.windll.user32.keybd_event(0x12, 0, 2, 0)
                ctypes.windll.user32.SetForegroundWindow(hwnd)
                ctypes.windll.user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 19)
                self.dummy_focus_music.focus_force() 
            except: pass
        
        self.music_window = tk.Toplevel(self.root)
        self.music_window.title("StreamerBot Music")
        self.music_window.geometry(getattr(self.controller, 'music_geo_cache', "300x120+100+100"))
        self.music_window.configure(bg="#000000")
        self.music_window.attributes("-topmost", True)
        self.music_window.overrideredirect(True)
        self.music_window.attributes("-alpha", getattr(self.controller, 'overlay_opacity', 0.85))
        
        self.dummy_focus_music = tk.Text(self.music_window, height=1, width=1)
        self.dummy_focus_music.place(x=-100, y=-100)

        def start_move(event):
            if not getattr(self, 'music_window', None) or not self.music_window.winfo_exists(): return
            self.music_window.start_x = event.x_root
            self.music_window.start_y = event.y_root
            self.music_window.win_x = self.music_window.winfo_x()
            self.music_window.win_y = self.music_window.winfo_y()

        def do_move(event):
            if not getattr(self, 'music_window', None) or not self.music_window.winfo_exists(): return
            win_x = getattr(self.music_window, 'win_x', None)
            start_x = getattr(self.music_window, 'start_x', None)
            if win_x is None or start_x is None: return
            x = win_x + (event.x_root - start_x)
            y = self.music_window.win_y + (event.y_root - getattr(self.music_window, 'start_y', 0))
            self.music_window.geometry(f"+{x}+{y}")
            
        def bind_drag(w):
            w.bind("<Button-1>", start_move)
            w.bind("<B1-Motion>", do_move)
            w.bind("<Double-Button-1>", lambda e: self.toggle_music_window(completely_stop=False, hide_only=True))

        main_f = tk.Frame(self.music_window, bg="#000022", highlightbackground="cyan", highlightthickness=1)
        main_f.pack(fill="both", expand=True)
        bind_drag(main_f)
        
        self.music_lbl_song = tk.Label(main_f, text="No Song Loaded", font=("Segoe UI", 9, "bold"), fg="cyan", bg="#000022")
        self.music_lbl_song.pack(pady=(5,0))
        bind_drag(self.music_lbl_song)
        
        ctrl_f = tk.Frame(main_f, bg="#000022")
        ctrl_f.pack(pady=5)
        bind_drag(ctrl_f)
        
        def mk_btn(parent, txt, cmd, col):
            b = tk.Button(parent, text=txt, bg=col, fg="white", font=("Arial", 8, "bold"), borderwidth=0, width=4, command=cmd)
            b.pack(side="left", padx=2)
            return b

        safe_mus_load = getattr(self.controller, 'music_load_folder', lambda: None)
        safe_mus_prev = getattr(self.controller, 'music_prev', lambda: None)
        safe_mus_pause = getattr(self.controller, 'music_toggle_pause', lambda: None)
        safe_mus_next = getattr(self.controller, 'music_next', lambda: None)
        safe_mus_rep = getattr(self.controller, 'music_toggle_repeat', lambda: None)
        
        mk_btn(ctrl_f, "📂", safe_mus_load, "#444")
        mk_btn(ctrl_f, "⏮", safe_mus_prev, "#555")
        mk_btn(ctrl_f, "⏯", safe_mus_pause, "#008000")
        mk_btn(ctrl_f, "⏭", safe_mus_next, "#555")
        
        self.music_btn_repeat = tk.Button(ctrl_f, text="🔁 Off", bg="#444", fg="yellow", font=("Arial", 7, "bold"), borderwidth=0, width=6, command=safe_mus_rep)
        self.music_btn_repeat.pack(side="left", padx=5)
        
        vol_f = tk.Frame(main_f, bg="#000022")
        vol_f.pack(fill="x", padx=10, pady=2)
        bind_drag(vol_f)
        
        safe_mus_vol = getattr(self.controller, 'music_set_vol', lambda v: None)
        
        tk.Label(vol_f, text="Vol", fg="gray", bg="#000022", font=("Arial", 7)).pack(side="left")
        ttk.Scale(vol_f, from_=0.0, to=1.0, value=self.controller.model.music_vol, orient='horizontal', command=safe_mus_vol).pack(side="left", fill="x", expand=True, padx=5)
        
        self.music_window.after(200, widget_focus)

    def toggle_status_window(self):
        if self.status_window and self.status_window.winfo_exists():
            self.saved_status_geo = self.status_window.geometry()
            self.status_window.destroy()
            self.status_window = None
        else:
            self.open_status_window()

    def open_status_window(self):
        def widget_focus():
            try:
                if not self.status_window or not self.status_window.winfo_exists(): return
                self.status_window.update_idletasks()
                import ctypes
                hwnd = int(self.status_window.wm_frame(), 16)
                ctypes.windll.user32.keybd_event(0x12, 0, 0, 0)
                ctypes.windll.user32.keybd_event(0x12, 0, 2, 0)
                ctypes.windll.user32.SetForegroundWindow(hwnd)
                ctypes.windll.user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 19)
                self.dummy_focus_stat.focus_force() 
            except: pass

        self.status_window = tk.Toplevel(self.root)
        self.status_window.title("StreamerBot Status") 
        self.status_window.geometry(self.saved_status_geo or "300x120+50+50")
        self.status_window.configure(bg="#000000")
        self.status_window.attributes("-topmost", True)
        self.status_window.overrideredirect(True)
        self.status_window.attributes("-alpha", getattr(self.controller, 'overlay_opacity', 0.85))
        
        self.dummy_focus_stat = tk.Text(self.status_window, height=1, width=1)
        self.dummy_focus_stat.place(x=-100, y=-100)

        def start_move_stat(event):
            if not getattr(self, 'status_window', None) or not self.status_window.winfo_exists(): return
            self.status_window.start_x = event.x_root
            self.status_window.start_y = event.y_root
            self.status_window.win_x = self.status_window.winfo_x()
            self.status_window.win_y = self.status_window.winfo_y()

        def do_move_stat(event):
            if not getattr(self, 'status_window', None) or not self.status_window.winfo_exists(): return
            win_x = getattr(self.status_window, 'win_x', None)
            start_x = getattr(self.status_window, 'start_x', None)
            if win_x is None or start_x is None: return
            x = win_x + (event.x_root - start_x)
            y = getattr(self.status_window, 'win_y', 0) + (event.y_root - getattr(self.status_window, 'start_y', 0))
            self.status_window.geometry(f"+{x}+{y}")

        def bind_drag_stat(widget):
            widget.bind("<Button-1>", start_move_stat)
            widget.bind("<B1-Motion>", do_move_stat)
            widget.bind("<Double-Button-1>", lambda e: self.toggle_status_window()) 

        self.status_window.columnconfigure(0, weight=1)
        self.status_window.columnconfigure(1, weight=1)
        self.status_window.columnconfigure(2, weight=1)
        self.status_window.rowconfigure(0, weight=1)
        
        f_view = tk.Frame(self.status_window, bg="#1a0000") 
        f_view.grid(row=0, column=0, sticky="nsew", padx=2, pady=2)
        tk.Label(f_view, text="VIEWERS", font=("Segoe UI", 8, "bold"), fg="#FF4444", bg="#1a0000").pack(pady=(5,0))
        self.lbl_stat_viewers_val = tk.Label(f_view, text="--", font=("Segoe UI", 20, "bold"), fg="white", bg="#1a0000")
        self.lbl_stat_viewers_val.pack()

        f_likes = tk.Frame(self.status_window, bg="#000033")
        f_likes.grid(row=0, column=1, sticky="nsew", padx=2, pady=2)
        tk.Label(f_likes, text="LIKES", font=("Segoe UI", 8, "bold"), fg="#0080FF", bg="#000033").pack(pady=(5,0))
        self.lbl_stat_likes_val = tk.Label(f_likes, text="--", font=("Segoe UI", 20, "bold"), fg="white", bg="#000033")
        self.lbl_stat_likes_val.pack()
        
        f_sub = tk.Frame(self.status_window, bg="#1a1a00")
        f_sub.grid(row=0, column=2, sticky="nsew", padx=2, pady=2)
        tk.Label(f_sub, text="SUBS", font=("Segoe UI", 8, "bold"), fg="#FFD700", bg="#1a1a00").pack(pady=(5,0))
        self.lbl_stat_subs_val = tk.Label(f_sub, text="--", font=("Segoe UI", 20, "bold"), fg="white", bg="#1a1a00")
        self.lbl_stat_subs_val.pack()
        
        bind_drag_stat(self.status_window)
        for child in self.status_window.winfo_children():
            bind_drag_stat(child)
            for subchild in child.winfo_children(): bind_drag_stat(subchild)
            
        self.status_window.after(200, widget_focus)

    def show_review_ui(self, text, context_msg):
        if self.review_window and self.review_window.winfo_exists(): return self.review_window.lift()
        self.review_window = tk.Toplevel(self.root)
        self.review_window.title("AI Reply Review")
        
        saved_geo = getattr(self.controller, 'review_geo_cache', "650x520+100+100")
        self.review_window.geometry(saved_geo if saved_geo else "650x520+100+100")
        
        self.current_review_context = context_msg 
        
        safe_submit = getattr(self.controller, 'submit_review', lambda x: None)
        self.review_window.protocol("WM_DELETE_WINDOW", lambda: safe_submit("reject"))
        
        self.review_window.attributes("-topmost", True)
        self.review_window.configure(bg="#222")
        tk.Label(self.review_window, text=f"Replying to: {context_msg}", font=("Arial", 9, "italic"), bg="#222", fg="#00FFFF").pack(pady=(10, 5), padx=10, anchor="w")
        
        self.popup_text = tk.Text(self.review_window, height=8, width=60, wrap="word", font=("Arial", 11), bg="#333", fg="white", insertbackground="white")
        self.popup_text.pack(padx=10, pady=5, fill="both", expand=True)
        self.popup_text.insert("1.0", text)
        
        self.rev_progress = ttk.Progressbar(self.review_window, mode='indeterminate')
        
        btn_frame = tk.Frame(self.review_window, bg="#222")
        btn_frame.pack(pady=15, fill="x", padx=5)
        
        self.btn_rev_send_vt = tk.Button(btn_frame, text="✅ SEND (V+T)", bg="green", fg="white", font=("Arial", 9, "bold"), command=lambda: safe_submit("approve_V+T"))
        self.btn_rev_send_vt.pack(side="left", padx=2, expand=True, fill="x")
        
        self.btn_rev_send_v = tk.Button(btn_frame, text="🔊 SEND (V)", bg="#0080FF", fg="white", font=("Arial", 9, "bold"), command=lambda: safe_submit("approve_V"))
        self.btn_rev_send_v.pack(side="left", padx=2, expand=True, fill="x")
        
        self.btn_rev_send_t = tk.Button(btn_frame, text="💬 SEND (T)", bg="#b8860b", fg="white", font=("Arial", 9, "bold"), command=lambda: safe_submit("approve_T"))
        self.btn_rev_send_t.pack(side="left", padx=2, expand=True, fill="x")

        safe_improve_curr = getattr(self.controller, 'improve_current_text', lambda: None)
        self.btn_rev_improve = tk.Button(btn_frame, text="✨ REVISE", bg="#5500aa", fg="white", font=("Arial", 9, "bold"), command=safe_improve_curr)
        self.btn_rev_improve.pack(side="left", padx=2, expand=True, fill="x")
        
        self.btn_rev_reject = tk.Button(btn_frame, text="❌ REJECT", bg="red", fg="white", font=("Arial", 9, "bold"), command=lambda: safe_submit("reject"))
        self.btn_rev_reject.pack(side="left", padx=2, expand=True, fill="x")
        
        self.rev_buttons = [self.btn_rev_send_vt, self.btn_rev_send_v, self.btn_rev_send_t, self.btn_rev_improve, self.btn_rev_reject]

    def _close_review_safe(self):
        try:
            if getattr(self, 'review_window', None) and self.review_window.winfo_exists():
                self.controller.review_geo_cache = self.review_window.geometry()
                if hasattr(self, 'rev_progress'): self.rev_progress.stop()
                self.review_window.destroy()
                self.review_window = None
                self.controller._debounced_save()
        except Exception as e: print(f"[Review Close Error] {e}")

    def improve_current_text(self):
        curr_text = getattr(self, 'popup_text', None)
        if not curr_text: return
        curr_val = curr_text.get("1.0", tk.END).strip()
        if not curr_val or getattr(self, 'is_generating', False): return
        self.is_generating = True
        
        viewer_context = getattr(self, 'current_review_context', "Unknown Chat")
        
        if hasattr(self, 'btn_rev_improve'): self.btn_rev_improve.config(text="⏳ Wait...")
        if hasattr(self, 'review_window'): self.review_window.update_idletasks()
        
        def _imp():
            try:
                msgs = [
                    {"role": "system", "content": f"You are {self.controller.model.channel_name}. A viewer just said: '{viewer_context}'. The current draft reply is: '{curr_val}'. REWRITE the reply to make complete sense as a direct response to the viewer's chat. If the draft makes no sense, completely replace it with a short, friendly reply to the viewer. DO NOT hallucinate fake gameplay events. Reply ONLY with the final text."},
                    {"role": "user", "content": "Rewrite the response to fit the viewer's chat perfectly."}
                ]
                reply = self.controller.model.generate_ai_completion(msgs, max_tokens=60, temperature=0.7)
                if reply:
                    self.root.after(0, lambda: curr_text.delete("1.0", tk.END))
                    self.root.after(0, lambda: curr_text.insert("1.0", reply))
            except Exception as e: print(f"[Revise Error] {e}")
            finally:
                self.is_generating = False
                if hasattr(self, 'btn_rev_improve'): self.root.after(0, lambda: self.btn_rev_improve.config(text="✨ REVISE"))
        threading.Thread(target=_imp, daemon=True).start()

    def close_mk1_overlay(self):
        if getattr(self, 'mk1_window', None) and self.mk1_window.winfo_exists():
            self.controller.mk1_geo_cache = self.mk1_window.geometry()
            self.mk1_window.destroy()
            self.mk1_window = None

    def open_mk1_overlay(self):
        if hasattr(self, 'mk1_window') and self.mk1_window and self.mk1_window.winfo_exists():
            self.mk1_window.lift()
            return
            
        self.mk1_window = tk.Toplevel(self.root)
        self.mk1_window.title("MK1 Moves & Fatalities Overlay")
        self.mk1_window.geometry(getattr(self.controller, 'mk1_geo_cache', "380x600+150+150"))
        self.mk1_window.configure(bg="#000000")
        self.mk1_window.attributes("-topmost", True)
        self.mk1_window.overrideredirect(True)
        self.mk1_window.protocol("WM_DELETE_WINDOW", self.close_mk1_overlay)
        self.mk1_window.attributes("-alpha", getattr(self.controller, 'overlay_opacity', 0.85))

        def start_move(event):
            self.mk1_window.start_x = event.x_root
            self.mk1_window.start_y = event.y_root
            self.mk1_window.win_x = self.mk1_window.winfo_x()
            self.mk1_window.win_y = self.mk1_window.winfo_y()

        def do_move(event):
            x = self.mk1_window.win_x + (event.x_root - self.mk1_window.start_x)
            y = self.mk1_window.win_y + (event.y_root - self.mk1_window.start_y)
            self.mk1_window.geometry(f"+{x}+{y}")

        header = tk.Frame(self.mk1_window, bg="#8B0000", cursor="fleur")
        header.pack(fill="x")
        lbl = tk.Label(header, text="🥋 MK1 Moves & Fatalities", bg="#8B0000", fg="white", font=("Arial", 10, "bold"), cursor="fleur")
        lbl.pack(side="left", padx=5, pady=2)
        tk.Button(header, text="✖", bg="#8B0000", fg="white", bd=0, command=self.close_mk1_overlay, width=3).pack(side="right")
        
        header.bind("<Button-1>", start_move)
        header.bind("<B1-Motion>", do_move)
        lbl.bind("<Button-1>", start_move)
        lbl.bind("<B1-Motion>", do_move)

        txt = scrolledtext.ScrolledText(self.mk1_window, bg="#111", fg="#00FF00", font=("Consolas", 10), bd=0)
        txt.pack(fill="both", expand=True, padx=2, pady=2)
        
        mk1_text = """=== BASIC ATTACKS ===
1: Front Punch (Square/X)
2: Back Punch (Triangle/Y)
3: Front Kick (X/A)
4: Back Kick (Circle/B)

=== UNIVERSAL MECHANICS ===
Block: R2 / RT
Kameo: R1 / RB
Throw: L1 / LB
Flip Stance: L2 / LT
Fatal Blow: L2 + R2 (< 30% HP)

=== CUSTOM MOVES / FATALITIES ===
Edit this text directly to paste your character's combos and fatalities.
(It stays here while this window is open!)
"""
        txt.insert("1.0", mk1_text)

    def create_smart_hotkey_row(self, parent_frame, label_text, base_attr, options_level=2):
        import tkinter as tk
        from tkinter import ttk, filedialog
        import threading
        import keyboard
        
        if not hasattr(self, 'hk_var_refs'):
            self.hk_var_refs = []
            
        if not hasattr(self, 'hotkey_buttons'):
            self.hotkey_buttons = {}
            
        hk_container = tk.Frame(parent_frame, bg="#252525", bd=1, relief="ridge")
        hk_container.pack(fill="x", pady=4, padx=10)
        
        row1 = tk.Frame(hk_container, bg="#252525")
        row1.pack(fill="x", padx=5, pady=4)
        
        tk.Label(row1, text=label_text, width=22, anchor="w", bg="#252525", fg="white", font=("Arial", 9, "bold")).pack(side="left")
        
        current_val = getattr(self.controller, base_attr, "UNASSIGNED")
        if not current_val: current_val = "UNASSIGNED"
        
        btn = tk.Button(row1, text=str(current_val).upper(), width=15, cursor="hand2", bg="#444" if current_val == "UNASSIGNED" else "#008000", fg="white", borderwidth=0)
        btn.pack(side="left", padx=5)
        self.hotkey_buttons[base_attr] = btn

        def _sync_val(attr_name, val):
            setattr(self.controller, attr_name, val)
            if hasattr(self.controller, 'model'):
                setattr(self.controller.model, attr_name, val)
        
        def start_listen():
            if hasattr(self, 'hotkey_buttons'):
                for attr, b in self.hotkey_buttons.items():
                    if b.cget('text') == "Listening...":
                        val = str(getattr(self.controller, attr, "UNASSIGNED")).upper()
                        b.config(text=val, bg="#008000" if val != "UNASSIGNED" else "#444", fg="white", state="normal")

            btn.config(text="Listening...", bg="yellow", fg="black", state="disabled")
            
            def listen_thread():
                new_key = None
                try:
                    self.controller._rebinding = True      # existing hotkeys are ignored while you press the new combo
                    new_key = keyboard.read_hotkey(suppress=False)
                except Exception as e:
                    print(f"[Keybind] Could not read key: {e}")
                finally:
                    self.controller._rebinding = False
                
                def _safe_apply():
                    if btn.cget('text') != "Listening...":
                        return 
                    # ESC (or a failed read) cancels instead of leaving the button stuck on "Listening..."
                    if not new_key or str(new_key).lower() == 'esc':
                        old_val = str(getattr(self.controller, base_attr, "UNASSIGNED")).upper()
                        btn.config(text=old_val, bg="#008000" if old_val != "UNASSIGNED" else "#444", fg="white", state="normal")
                        return
                    if hasattr(self.controller, 'apply_new_hotkey'):
                        self.controller.apply_new_hotkey(base_attr, new_key, label_text, btn)
                    else:
                        btn.config(text=str(new_key).upper(), bg="#008000", fg="white", state="normal")
                        _sync_val(base_attr, new_key)
                
                # Tk is not thread-safe: hand the work to the main thread through the controller's UI queue
                ui_q = getattr(self.controller, 'ui_action_queue', None)
                if ui_q is not None: ui_q.put(_safe_apply)
                else: self.root.after(0, _safe_apply)
                
            threading.Thread(target=listen_thread, daemon=True).start()
            
        btn.config(command=start_listen)
        
        if options_level >= 1:
            mode_attr = f"{base_attr}_mode"
            var_mode = tk.StringVar(master=self.root, value=getattr(self.controller, mode_attr, "V+T"))
            self.hk_var_refs.append((var_mode, mode_attr))
            var_mode.trace_add("write", lambda *a, v=var_mode, attr=mode_attr: _sync_val(attr, v.get()))
            ttk.Combobox(row1, textvariable=var_mode, values=["V+T", "V", "T"], width=5, state="readonly").pack(side="left", padx=3)
            
            short_attr = f"{base_attr}_short"
            var_short = tk.BooleanVar(master=self.root, value=getattr(self.controller, short_attr, False))
            self.hk_var_refs.append((var_short, short_attr))
            var_short.trace_add("write", lambda *a, v=var_short, attr=short_attr: _sync_val(attr, v.get()))
            tk.Checkbutton(row1, text="Short", variable=var_short, bg="#252525", fg="gray", selectcolor="#111").pack(side="left", padx=(2, 5))
            
        if options_level >= 2:
            row2 = tk.Frame(hk_container, bg="#252525")
            row2.pack(fill="x", padx=5, pady=(0, 4))
            
            btn_frame = tk.Frame(row2, bg="#252525")
            btn_frame.pack(side="right", padx=5)

            mute_attr = f"{base_attr}_mute_ai"
            var_mute = tk.BooleanVar(master=self.root, value=getattr(self.controller, mute_attr, False))
            if hasattr(self, 'hk_var_refs'): self.hk_var_refs.append((var_mute, mute_attr))
            var_mute.trace_add("write", lambda *a, v=var_mute, attr=mute_attr: _sync_val(attr, v.get()))
            tk.Checkbutton(btn_frame, text="Mute AI", variable=var_mute, bg="#252525", fg="#ff4444", selectcolor="#111").pack(side="left", padx=5)

            audio_attr = f"{base_attr}_audio"
            en_attr = f"{base_attr}_audio_enabled"
            
            var_audio_en = tk.BooleanVar(master=self.root, value=getattr(self.controller, en_attr, False))
            if hasattr(self, 'hk_var_refs'): self.hk_var_refs.append((var_audio_en, en_attr))
            var_audio_en.trace_add("write", lambda *a, v=var_audio_en, attr=en_attr: _sync_val(attr, v.get()))
            audio_enabled_cb = tk.Checkbutton(btn_frame, text="Enable MP3", variable=var_audio_en, bg="#252525", fg="#00FF00", selectcolor="#111")
            
            audio_val = getattr(self.controller, audio_attr, "")
            audio_btn = tk.Button(btn_frame, text="🎵 Sound" if not audio_val else "🔊 MP3", bg="#444" if not audio_val else "#008000", fg="white", borderwidth=0, font=("Arial", 8, "bold"), width=8)
            
            if audio_val: audio_enabled_cb.pack(side="left", padx=(0, 2))
            audio_btn.pack(side="left")
            
            clear_btn = tk.Button(btn_frame, text="✖", bg="#B00000", fg="white", borderwidth=0, font=("Arial", 8, "bold"))
            if audio_val: clear_btn.pack(side="left", padx=(2,0))

            def _pick_audio(btn=audio_btn, cbtn=clear_btn, attr=audio_attr, cb=audio_enabled_cb, e_var=var_audio_en):
                from tkinter import filedialog
                p = filedialog.askopenfilename(filetypes=[("Audio Files", "*.mp3 *.wav *.ogg")])
                if p:
                    _sync_val(attr, p)
                    e_var.set(True)
                    btn.config(text="🔊 MP3", bg="#008000")
                    cb.pack(side="left", before=btn, padx=(0, 2))
                    cbtn.pack(side="left", padx=(2,0))
                    
            def _clear_audio(btn=audio_btn, cbtn=clear_btn, attr=audio_attr, cb=audio_enabled_cb, e_var=var_audio_en):
                _sync_val(attr, "")
                e_var.set(False)
                btn.config(text="🎵 Sound", bg="#444")
                cb.pack_forget()
                cbtn.pack_forget()

            audio_btn.config(command=_pick_audio)
            clear_btn.config(command=_clear_audio)

            tk.Label(row2, text="Override:", bg="#252525", fg="gray").pack(side="left", padx=(5, 2))
            custom_attr = f"{base_attr}_custom"
            var_custom = tk.StringVar(master=self.root, value=getattr(self.controller, custom_attr, ""))
            if hasattr(self, 'hk_var_refs'): self.hk_var_refs.append((var_custom, custom_attr))
            var_custom.trace_add("write", lambda *a, v=var_custom, attr=custom_attr: _sync_val(attr, v.get().strip()))
            tk.Entry(row2, textvariable=var_custom, width=10, bg="#111", fg="#00FFFF", insertbackground="white").pack(side="left", fill="x", expand=True, padx=2)

            tk.Label(row2, text="AI Prompt:", bg="#252525", fg="gray").pack(side="left", padx=(10, 2))
            prompt_attr = f"{base_attr}_prompt"
            var_prompt = tk.StringVar(master=self.root, value=getattr(self.controller, prompt_attr, ""))
            if hasattr(self, 'hk_var_refs'): self.hk_var_refs.append((var_prompt, prompt_attr))
            var_prompt.trace_add("write", lambda *a, v=var_prompt, attr=prompt_attr: _sync_val(attr, v.get().strip()))
            tk.Entry(row2, textvariable=var_prompt, width=10, bg="#111", fg="#FFD700", insertbackground="white").pack(side="left", fill="x", expand=True, padx=2)

        return hk_container

    def build_hotkeys_menu(self, parent_frame):
        import tkinter as tk
        
        hotkey_frame = tk.LabelFrame(parent_frame, text="Smart Keybinds", font=("Arial", 10, "bold"), bg="#1e1e1e", fg="white")
        hotkey_frame.pack(fill='both', expand=True, padx=10, pady=10)

        self.create_smart_hotkey_row(hotkey_frame, "Vision Walkthrough Toggle", "hk_vision_toggle", options_level=0)
        self.create_smart_hotkey_row(hotkey_frame, "Idle Message", "hk_idle")
        self.create_smart_hotkey_row(hotkey_frame, "Thanks Message", "hk_thanks")
        self.create_smart_hotkey_row(hotkey_frame, "Likes/Shares Thanks", "hk_likes_thanks")
        self.create_smart_hotkey_row(hotkey_frame, "Game Question", "hk_question")
        self.create_smart_hotkey_row(hotkey_frame, "Game Request", "hk_game_request")
        self.create_smart_hotkey_row(hotkey_frame, "Death Reaction", "hk_death")
        self.create_smart_hotkey_row(hotkey_frame, "Help/Stuck Message", "hk_help")
        self.create_smart_hotkey_row(hotkey_frame, "BRB / Bathroom", "hk_brb")
        self.create_smart_hotkey_row(hotkey_frame, "Tech Issue / Lag", "hk_tech_issue")

    def build_hype_moments_menu(self, parent_frame):
        import tkinter as tk
        
        hype_frame = tk.LabelFrame(parent_frame, text="Hype & Moments", font=("Arial", 10, "bold"), bg="#1e1e1e", fg="white")
        hype_frame.pack(fill='both', expand=True, padx=10, pady=10)

        self.create_smart_hotkey_row(hype_frame, "Puzzle Solved", "hk_puzzle", options_level=2)
        self.create_smart_hotkey_row(hype_frame, "Boss Defeated", "hk_boss_win", options_level=2)
        self.create_smart_hotkey_row(hype_frame, "Feeling Good", "hk_feeling_good", options_level=2)
        self.create_smart_hotkey_row(hype_frame, "Feeling Bad/Sad", "hk_feeling_bad", options_level=2)
        self.create_smart_hotkey_row(hype_frame, "Clip That!", "hk_clip_that", options_level=2)
        self.create_smart_hotkey_row(hype_frame, "Panic / Scream", "hk_panic", options_level=2)
        self.create_smart_hotkey_row(hype_frame, "Shoutout Active Users", "hk_shoutout_users", options_level=2)
        self.create_smart_hotkey_row(hype_frame, "Taunt", "hk_taunt", options_level=2)
        self.create_smart_hotkey_row(hype_frame, "Intro", "hk_intro", options_level=2)
        self.create_smart_hotkey_row(hype_frame, "Frustration", "hk_frustration", options_level=2)
        self.create_smart_hotkey_row(hype_frame, "Attack", "hk_attack", options_level=2)
        self.create_smart_hotkey_row(hype_frame, "Talk Viewers", "hk_talk_viewers", options_level=2)

    def build_custom_slots_menu(self, parent_frame):
        import tkinter as tk
        
        custom_frame = tk.LabelFrame(parent_frame, text="Custom Command Slots", font=("Arial", 10, "bold"), bg="#1e1e1e", fg="white")
        custom_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        for i in range(1, 16):
            self.create_smart_hotkey_row(custom_frame, f"Custom Slot {i}", f"hk_custom_{i}", options_level=2)

    def build_system_hotkeys_menu(self, parent_frame):
        import tkinter as tk
        
        sys_frame = tk.LabelFrame(parent_frame, text="System & Overlays", font=("Arial", 10, "bold"), bg="#1e1e1e", fg="white")
        sys_frame.pack(fill='both', expand=True, padx=10, pady=10)

        self.create_smart_hotkey_row(sys_frame, "AI Screen Vision", "hk_vision", options_level=1)
        self.create_smart_hotkey_row(sys_frame, "Live Context", "hk_live_context", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Reply Last", "hk_reply_last", options_level=1)
        self.create_smart_hotkey_row(sys_frame, "Open Keybinds", "hk_hotkeys_window", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Suspend Hotkeys", "hk_suspend_hotkeys", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Stop Audio", "hk_stop_audio", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Toggle Global AI Mute", "hk_toggle_ai_mute", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Toggle Anti-Repeat", "hk_strict_mode", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Toggle Cache Playback Mode", "hk_toggle_cache_mode", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Open Chat List", "hk_open_list", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Open Context Window", "hk_open_context_window", options_level=0)
        
        self.create_smart_hotkey_row(sys_frame, "Open Stats", "hk_stats", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Toggle Stats Ghost", "hk_stats_ghost", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Open Guide", "hk_guide", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Toggle Guide Ghost", "hk_guide_ghost", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Sys Status", "hk_sys_status", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Sys Status Ghost", "hk_sys_status_ghost", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Hide All Overlays", "hk_hide_overlays", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Open YouTube", "hk_play_overlay", options_level=0)
        
        self.create_smart_hotkey_row(sys_frame, "YT Play/Pause", "hk_yt_play_pause", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "YT Next Video", "hk_yt_next", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "YT Prev Video", "hk_yt_prev", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "YT Forward", "hk_yt_forward", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "YT Rewind", "hk_yt_rewind", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "YT Ghost Mode", "hk_yt_ghost", options_level=0)
        
        self.create_smart_hotkey_row(sys_frame, "MP3 Play/Pause", "hk_mp3_play_pause", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "MP3 Next Track", "hk_mp3_next", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "MP3 Prev Track", "hk_mp3_prev", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "MP3 Forward (10s)", "hk_mp3_forward", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "MP3 Rewind (10s)", "hk_mp3_rewind", options_level=0)
        self.create_smart_hotkey_row(sys_frame, "Open Music Window", "hk_music_window", options_level=0)

    def open_hotkeys_window(self, event=None):
        if hasattr(self, 'hotkey_window') and self.hotkey_window and self.hotkey_window.winfo_exists():
            self.hotkey_window.focus()
            return
            
        self.hk_var_refs = []
        self.hotkey_window = tk.Toplevel(self.root)
        self.hotkey_window.title("Keybind, Soundboard & Overrides Manager")
        self.hotkey_window.geometry("1150x850")
        self.hotkey_window.minsize(700, 500) 
        self.hotkey_window.configure(bg="#1e1e1e")
        self.hotkey_window.attributes("-topmost", True)
        
        safe_toggle = getattr(self.controller, 'toggle_hotkeys_logic', lambda: None)
        self.hotkey_window.protocol("WM_DELETE_WINDOW", lambda: (safe_toggle(), self.hotkey_window.destroy()))

        container = tk.Frame(self.hotkey_window, bg="#1e1e1e")
        container.pack(fill="both", expand=True)
        
        canvas = tk.Canvas(container, bg="#1e1e1e", highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="#1e1e1e")
        
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas_frame_id = canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        def _on_canvas_resize(event):
            canvas.itemconfig(canvas_frame_id, width=event.width)
        canvas.bind("<Configure>", _on_canvas_resize)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.hotkey_window.bind("<MouseWheel>", lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

        tk.Label(scrollable_frame, text="Global Hotkeys & Custom Soundboard", font=("Segoe UI", 16, "bold"), bg="#1e1e1e", fg="#00FF00").pack(pady=(10, 0))
        tk.Label(scrollable_frame, text="Leave Override/Prompt blank for default dynamic AI text/voice generation. Auto-Saves instantly.", font=("Arial", 10), bg="#1e1e1e", fg="gray").pack()
        tk.Label(scrollable_frame, text="💡 TIP: Use [SEARCH: keywords] instructions... to fetch precise web facts!", font=("Arial", 9, "bold"), bg="#1e1e1e", fg="#00FFFF").pack(pady=(0, 10))

        directive_frame = tk.Frame(scrollable_frame, bg="#2a2a2a", bd=1, relief="solid")
        directive_frame.pack(fill="x", padx=20, pady=(0, 10))
        var_dir_en = tk.BooleanVar(master=self.root, value=getattr(self.controller, 'global_directive_enabled', False))
        self.hk_var_refs.append((var_dir_en, 'global_directive_enabled'))
        lbl_f = tk.Frame(directive_frame, bg="#2a2a2a")
        lbl_f.pack(fill="x", padx=10, pady=(10, 0))
        tk.Checkbutton(lbl_f, text="👑 ENABLE AI DIRECTIVE (For Hotkeys & Events)", variable=var_dir_en, bg="#2a2a2a", fg="#FFD700", selectcolor="#111", font=("Arial", 10, "bold")).pack(side="left")
        self.text_directive = tk.Text(directive_frame, height=3, bg="#111", fg="#00FFFF", insertbackground="white", font=("Consolas", 10), wrap="word")
        self.text_directive.pack(fill="x", expand=True, padx=10, pady=10)
        self.text_directive.insert("1.0", getattr(self.controller, 'global_directive_text', ""))
        
        chat_directive_frame = tk.Frame(scrollable_frame, bg="#1a2b3c", bd=1, relief="solid")
        chat_directive_frame.pack(fill="x", padx=20, pady=(0, 15))
        var_chat_dir_en = tk.BooleanVar(master=self.root, value=getattr(self.controller, 'chat_directive_enabled', False))
        self.hk_var_refs.append((var_chat_dir_en, 'chat_directive_enabled'))
        c_lbl_f = tk.Frame(chat_directive_frame, bg="#1a2b3c")
        c_lbl_f.pack(fill="x", padx=10, pady=(10, 0))
        tk.Checkbutton(c_lbl_f, text="💬 ENABLE AI DIRECTIVE (For Auto-Chat Replies Only)", variable=var_chat_dir_en, bg="#1a2b3c", fg="#00FFCC", selectcolor="#111", font=("Arial", 10, "bold")).pack(side="left")
        self.text_chat_directive = tk.Text(chat_directive_frame, height=3, bg="#111", fg="#00FFCC", insertbackground="white", font=("Consolas", 10), wrap="word")
        self.text_chat_directive.pack(fill="x", expand=True, padx=10, pady=10)
        self.text_chat_directive.insert("1.0", getattr(self.controller, 'chat_directive_text', ""))

        mk1_cmd = getattr(self.controller, 'trigger_mk1_guide', lambda: messagebox.showinfo("Info", "MK1 Guide not available."))
        tk.Button(scrollable_frame, text="🐉 OPEN MK1 MOVES & FATALITIES GUIDE", bg="#8B0000", fg="white", font=("Arial", 10, "bold"), command=mk1_cmd).pack(fill="x", padx=20, pady=(0, 10))

        vol_frame = tk.Frame(scrollable_frame, bg="#1e1e1e")
        vol_frame.pack(fill="x", padx=20, pady=(0, 5))
        tk.Label(vol_frame, text="🔊 Soundboard MP3 Volume:", bg="#1e1e1e", fg="white", font=("Arial", 10, "bold")).pack(side="left")
        self.sb_vol_var = tk.DoubleVar(master=self.root, value=getattr(self.controller, 'soundboard_volume', 1.0))
        self.hk_var_refs.append((self.sb_vol_var, 'soundboard_volume'))
        ttk.Scale(vol_frame, from_=0.0, to=1.0, variable=self.sb_vol_var, orient='horizontal', length=150, command=lambda val: setattr(self.controller, 'soundboard_volume', float(val))).pack(side="left", padx=10)

        var_fc = tk.BooleanVar(master=self.root, value=getattr(self.controller, 'force_cache_only', False))
        self.hk_var_refs.append((var_fc, 'force_cache_only'))
        def _update_fc(*a):
            val = var_fc.get()
            setattr(self.controller, 'force_cache_only', val)
            if hasattr(self.controller, 'model'):
                self.controller.model.force_cache_only = val
            if hasattr(self.controller, 'set_tts_mode'): 
                self.controller.set_tts_mode() 
        var_fc.trace_add("write", _update_fc)
        tk.Checkbutton(vol_frame, text="⚡ FORCE CACHE ONLY (All Hotkeys instantly use Cache)", variable=var_fc, bg="#1e1e1e", fg="#FFD700", selectcolor="#333", font=("Arial", 9, "bold")).pack(side="right", padx=10)

        len_frame = tk.Frame(scrollable_frame, bg="#1e1e1e")
        len_frame.pack(fill="x", padx=20, pady=(0, 15))
        
        var_vibe = tk.BooleanVar(master=self.root, value=getattr(self.controller, 'vibe_check_enabled', True))
        self.hk_var_refs.append((var_vibe, 'vibe_check_enabled'))
        var_vibe.trace_add("write", lambda *a: setattr(self.controller, 'vibe_check_enabled', var_vibe.get()))
        tk.Checkbutton(len_frame, text="🎭 Enable Vibe Check (Random AI Moods)", variable=var_vibe, bg="#1e1e1e", fg="#FFD700", selectcolor="#333", font=("Arial", 9, "bold")).pack(side="right", padx=10)

        var_len_en = tk.BooleanVar(master=self.root, value=getattr(self.controller, 'custom_length_enabled', False))
        self.hk_var_refs.append((var_len_en, 'custom_length_enabled'))
        var_len_val = tk.IntVar(master=self.root, value=getattr(self.controller, 'custom_length_val', 30))
        self.hk_var_refs.append((var_len_val, 'custom_length_val'))
        def _update_len_en(*a): setattr(self.controller, 'custom_length_enabled', var_len_en.get())
        def _update_len_val(*a): 
            try: setattr(self.controller, 'custom_length_val', var_len_val.get())
            except: pass
        var_len_en.trace_add("write", _update_len_en)
        var_len_val.trace_add("write", _update_len_val)
        tk.Checkbutton(len_frame, text="📏 Force Custom AI Reply Length (Words):", variable=var_len_en, bg="#1e1e1e", fg="#00E5FF", selectcolor="#333", font=("Arial", 9, "bold")).pack(side="left")
        tk.Spinbox(len_frame, from_=1, to=500, textvariable=var_len_val, width=5, bg="#333", fg="white", font=("Arial", 10, "bold")).pack(side="left", padx=5)

        jina_frame = tk.Frame(scrollable_frame, bg="#2a2a2a", bd=1, relief="solid")
        jina_frame.pack(fill="x", padx=20, pady=(0, 15))
        jina_lbl_frame = tk.Frame(jina_frame, bg="#2a2a2a")
        jina_lbl_frame.pack(side="left", padx=10, pady=10)
        tk.Label(jina_lbl_frame, text="🌐 Jina AI Search Keys:", bg="#2a2a2a", fg="#00FFFF", font=("Arial", 10, "bold")).pack(anchor="w")
        from tkinter import scrolledtext
        self.text_jina = scrolledtext.ScrolledText(jina_frame, height=3, width=50, bg="#111", fg="white", insertbackground="white", font=("Consolas", 9))
        self.text_jina.pack(side="left", fill="x", expand=True, padx=10, pady=10)
        existing_keys = os.environ.get("JINA_API_KEYS", os.environ.get("JINA_API_KEY", ""))
        if existing_keys: self.text_jina.insert("1.0", existing_keys.replace(",", "\n"))

        ttk.Separator(scrollable_frame, orient="horizontal").pack(fill="x", pady=10)
        
        output_modes_frame = tk.Frame(scrollable_frame, bg="#1a1a1a", bd=1, relief="solid")
        output_modes_frame.pack(fill="x", pady=(0, 10), padx=10)

        auto_frame = tk.Frame(output_modes_frame, bg="#1a1a1a")
        auto_frame.pack(fill="x", pady=(8, 4), padx=10)
        
        tk.Label(auto_frame, text="🤖 Chat Auto-Replies Output Mode:", bg="#1a1a1a", fg="#00FFCC", font=("Arial", 10, "bold")).pack(side="left")
        
        self.auto_reply_mode_var = tk.StringVar(master=self.root, value=getattr(self.controller, 'auto_reply_output_mode', 'V+T'))
        self.hk_var_refs.append((self.auto_reply_mode_var, 'auto_reply_output_mode'))
        self.auto_reply_mode_var.trace_add("write", lambda *a: setattr(self.controller, 'auto_reply_output_mode', self.auto_reply_mode_var.get()))
        
        auto_reply_combo = ttk.Combobox(auto_frame, textvariable=self.auto_reply_mode_var, values=["V+T", "V", "T"], width=8, state="readonly")
        auto_reply_combo.pack(side="left", padx=10)

        master_frame = tk.Frame(output_modes_frame, bg="#1a1a1a")
        master_frame.pack(fill="x", pady=(4, 8), padx=10)

        tk.Label(master_frame, text="👑 Master Output Mode (Changes ALL Keys):", bg="#1a1a1a", fg="#FFD700", font=("Arial", 10, "bold")).pack(side="left")

        def _apply_master_mode(*args):
            new_mode = master_var.get()
            if not new_mode: return
            
            if hasattr(self, 'hk_var_refs'):
                for var, attr_name in self.hk_var_refs:
                    if attr_name.endswith("_mode") and isinstance(var, tk.StringVar) and attr_name != 'auto_reply_output_mode':
                        try: var.set(new_mode)
                        except: pass
                        
            print(f"[System] 👑 Master Mode applied: ALL hotkeys set to {new_mode}")

        master_var = tk.StringVar(value="")
        master_combo = ttk.Combobox(master_frame, textvariable=master_var, values=["V+T", "V", "T"], width=8, state="readonly")
        master_combo.pack(side="left", padx=10)
        master_var.trace_add("write", _apply_master_mode)
        
        self.build_hotkeys_menu(scrollable_frame)
        
        ttk.Separator(scrollable_frame, orient="horizontal").pack(fill="x", pady=10)
        tk.Label(scrollable_frame, text="🔥 Hype & Moments", bg="#1e1e1e", fg="#FF4500", font=("Arial", 11, "bold")).pack(anchor="w", padx=10)
        self.build_hype_moments_menu(scrollable_frame)

        ttk.Separator(scrollable_frame, orient="horizontal").pack(fill="x", pady=10)
        tk.Label(scrollable_frame, text="📝 Custom Hotkeys", bg="#1e1e1e", fg="#FFFF00", font=("Arial", 11, "bold")).pack(anchor="w", padx=10)
        self.build_custom_slots_menu(scrollable_frame)

        ttk.Separator(scrollable_frame, orient="horizontal").pack(fill="x", pady=10)
        tk.Label(scrollable_frame, text="⚙️ System, Overlays & Media", bg="#1e1e1e", fg="gray", font=("Arial", 11, "bold")).pack(anchor="w", padx=10)
        self.build_system_hotkeys_menu(scrollable_frame)

        def _save_all():
            self.controller.global_directive_enabled = var_dir_en.get()
            self.controller.global_directive_text = self.text_directive.get("1.0", "end-1c").strip()
            
            self.controller.chat_directive_enabled = var_chat_dir_en.get()
            self.controller.chat_directive_text = self.text_chat_directive.get("1.0", "end-1c").strip()
            
            try:
                self.controller.model.global_directive_enabled = self.controller.global_directive_enabled
                self.controller.model.global_directive_text = self.controller.global_directive_text
                self.controller.model.chat_directive_enabled = self.controller.chat_directive_enabled
                self.controller.model.chat_directive_text = self.controller.chat_directive_text
            except: pass

            raw_keys = self.text_jina.get("1.0", "end-1c").strip()
            keys_str = ",".join([k.strip() for k in raw_keys.split("\n") if k.strip()])
            import os
            if not keys_str and "JINA_API_KEYS" in os.environ: del os.environ["JINA_API_KEYS"]
            elif keys_str: os.environ["JINA_API_KEYS"] = keys_str
            
            if hasattr(self.controller, 'save_jina_keys'):
                self.controller.save_jina_keys(keys_str)

            orig_save = getattr(self.controller, '_gather_config_data', None)
            if orig_save:
                def patched_gather():
                    data = orig_save()
                    data['global_directive_enabled'] = getattr(self.controller, 'global_directive_enabled', False)
                    data['global_directive_text'] = getattr(self.controller, 'global_directive_text', "")
                    data['chat_directive_enabled'] = getattr(self.controller, 'chat_directive_enabled', False)
                    data['chat_directive_text'] = getattr(self.controller, 'chat_directive_text', "")
                    data['auto_reply_output_mode'] = getattr(self.controller, 'auto_reply_output_mode', "V+T") 
                    
                    keys_to_save = list(self.controller.__dict__.keys())
                    if hasattr(self.controller, 'model'):
                        keys_to_save.extend(list(self.controller.model.__dict__.keys()))
                    for k in set(keys_to_save):
                        if k.startswith('hk_'):
                            val = getattr(self.controller, k, getattr(self.controller.model, k, None))
                            # 🛡️ THE FIX: Only allow basic Python data types to be saved to the JSON file!
                            # This prevents "Object of type Frame is not JSON serializable" crashes.
                            if isinstance(val, (str, int, float, bool, type(None))):
                                data[k] = val
                            elif isinstance(val, list) and all(isinstance(i, (str, int, float, bool)) for i in val):
                                data[k] = val
                    return data
                self.controller._gather_config_data = patched_gather
            
            if hasattr(self.controller, 'save_config'): self.controller.save_config()
            if orig_save: self.controller._gather_config_data = orig_save

            if hasattr(self.controller, 'toggle_hotkeys_logic'): self.controller.toggle_hotkeys_logic()
            self.hotkey_window.destroy()

        tk.Button(scrollable_frame, text="💾 Save Changes & Re-Bind", bg="#008000", fg="white", font=("Arial", 12, "bold"), command=_save_all).pack(pady=20, fill="x", padx=100)

    def refresh_elevenlabs_presets_ui(self):
        """Updates the Combobox dropdown with the latest saved ElevenLabs presets."""
        try:
            if hasattr(self.controller.model, 'elevenlabs_presets'):
                presets = list(self.controller.model.elevenlabs_presets.keys())
                if hasattr(self, 'elevenlabs_preset_combo') and self.elevenlabs_preset_combo.winfo_exists():
                    self.elevenlabs_preset_combo['values'] = presets
                    if presets and not self.elevenlabs_preset_combo.get():
                        self.elevenlabs_preset_combo.current(0)
        except Exception as e:
            print(f"[UI Error] Could not refresh ElevenLabs presets: {e}")

    def open_voicebox_settings(self):
        from tkinter import simpledialog, messagebox
        
        current_url = getattr(self.controller.model, 'voicebox_url', "http://127.0.0.1:17493")
        
        new_url = simpledialog.askstring(
            "Voicebox API Settings", 
            "Enter your Voicebox (Pinokio) API URL:", 
            initialvalue=current_url, 
            parent=self.root
        )
        
        if new_url is not None:
            self.controller.model.voicebox_url = new_url.strip()
            self.controller.save_config()
            messagebox.showinfo("Saved", f"Voicebox API URL saved successfully:\n{new_url.strip()}", parent=self.root)
            print(f"[System] Voicebox API URL updated to: {new_url.strip()}")

    def refresh_ui_from_state(self):
        """Forces the UI to visually match the exact data in the controller safely."""
        import tkinter as tk

        if hasattr(self.controller, 'model'):
            for hk in self.HOTKEY_BASES + getattr(self, 'GUI_HOTKEYS', []):
                if hasattr(self.controller.model, hk):
                    setattr(self.controller, hk, getattr(self.controller.model, hk))
                for sfx in ["_mode", "_short", "_mute_ai", "_audio", "_audio_enabled", "_custom", "_prompt"]:
                    attr = f"{hk}{sfx}"
                    if hasattr(self.controller.model, attr):
                        setattr(self.controller, attr, getattr(self.controller.model, attr))

        if hasattr(self, 'channel_entry') and hasattr(self.channel_entry, 'winfo_exists') and self.channel_entry.winfo_exists():
            self.channel_entry.delete(0, 'end')
            self.channel_entry.insert(0, getattr(self.controller.model, 'channel_name', ''))
            
        if hasattr(self, 'game_entry') and hasattr(self.game_entry, 'winfo_exists') and self.game_entry.winfo_exists():
            self.game_entry.delete(0, 'end')
            saved_game = getattr(self.controller.model, 'game_name', 'Just Chatting')
            self.game_entry.insert(0, saved_game)

        if hasattr(self, 'hotkey_buttons'):
            dead_keys = []
            for attr_name, btn in self.hotkey_buttons.items():
                try:
                    if not btn.winfo_exists():
                        dead_keys.append(attr_name)
                        continue

                    val = getattr(self.controller, attr_name, "UNASSIGNED")
                    if not val or val == "UNASSIGNED":
                        btn.config(text="UNASSIGNED", bg="#444", fg="white")
                    else:
                        btn.config(text=str(val).upper(), bg="#008000", fg="white")
                except Exception:
                    dead_keys.append(attr_name)

            for k in dead_keys:
                del self.hotkey_buttons[k]

        if hasattr(self, 'hk_var_refs'):
            for var, attr_name in self.hk_var_refs:
                try:
                    val = getattr(self.controller, attr_name, None)
                    if val is not None:
                        var.set(val)
                    elif isinstance(var, tk.BooleanVar):
                        var.set(False)
                    else:
                        var.set("")
                except Exception:
                    pass