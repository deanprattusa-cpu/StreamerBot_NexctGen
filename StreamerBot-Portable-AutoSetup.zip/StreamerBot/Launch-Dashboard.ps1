[CmdletBinding()]
param([switch]$Demo, [switch]$OpenBrowser, [string]$Python)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$VenvPython = $Python
if (-not $VenvPython) { $VenvPython = Join-Path $PSScriptRoot ".portable\venv\Scripts\python.exe" }
if (-not (Test-Path -LiteralPath $VenvPython)) { $VenvPython = Join-Path $PSScriptRoot ".venv\Scripts\python.exe" }
if (-not (Test-Path $VenvPython)) { throw "Run Start-Portable.ps1 -Dashboard to prepare the portable dashboard." }
$EngineArguments = @("-m", "streamerbot", "--avatar", (Join-Path $PSScriptRoot "avatar.png"))
if ($Demo) { $EngineArguments += "--demo" }
if ($OpenBrowser) { $EngineArguments += "--open-browser" }
Write-Host "Dashboard: http://127.0.0.1:8765/"
Write-Host "OBS overlay: http://127.0.0.1:8765/overlay"
& $VenvPython @EngineArguments
if ($LASTEXITCODE -ne 0) { throw "The engine stopped with an error." }
