import os
import sys
import subprocess
import time

def setup_and_run():
    print("="*50)
    print("   STREAMER BOT - AUTO INSTALLER & LAUNCHER")
    print("="*50)
    
    # 1. Check/Rename .txt files to .py
    print("\n[1/6] Checking file integrity...")
    files_to_rename = {
        "controller.txt": "controller.py",
        "model.txt": "model.py",
        "view.txt": "view.py",
        "typecast_bridge.txt": "typecast_bridge.py" # Auto-rename the ghost browser script too!
    }
    
    for src, dst in files_to_rename.items():
        if os.path.exists(src):
            try:
                # If target exists (e.g. older version), remove it first to ensure overwrite
                if os.path.exists(dst):
                    os.remove(dst)
                os.rename(src, dst)
                print(f"   [Fix] Renamed {src} -> {dst}")
            except Exception as e:
                print(f"   [Error] Could not rename {src}: {e}")

    if not os.path.exists("controller.py"):
        print("\n[CRITICAL ERROR] 'controller.py' is missing!")
        print("Please ensure controller.py, model.py, and view.py are in this folder.")
        input("\nPress Enter to exit...")
        sys.exit(1)
    else:
        print("   [OK] Main files found.")

    # 2. Create requirements.txt
    print("\n[2/6] Checking requirements list...")
    req_file = "requirements.txt"
    # Always recreate to ensure it matches the current code needs
    requirements_content = """tk
pyaudio
sounddevice
SpeechRecognition
pydub
scipy
soundfile
pyttsx3
edge-tts
google-cloud-texttospeech
kokoro
openai
groq
google-generativeai
python-dotenv
keyboard
numpy
requests
google-auth
google-auth-oauthlib
google-auth-httplib2
google-api-python-client
pywebview
playwright
playwright-stealth
pyautogui
pyperclip
PyGetWindow
imageio
imageio-ffmpeg
--extra-index-url https://download.pytorch.org/whl/cu121
torch
torchaudio
"""
    try:
        with open(req_file, "w") as f:
            f.write(requirements_content)
        print("   [OK] requirements.txt created/updated.")
    except Exception as e:
        print(f"   [Error] Could not write requirements.txt: {e}")
        input("Press Enter to exit...")
        sys.exit(1)

    # 3. Create Virtual Environment
    print("\n[3/6] Setting up Virtual Environment (venv)...")
    venv_dir = "venv"
    
    # Determine the python executable path in the venv
    if sys.platform == "win32":
        venv_python = os.path.join(venv_dir, "Scripts", "python.exe")
    else:
        venv_python = os.path.join(venv_dir, "bin", "python")

    if not os.path.exists(venv_python):
        try:
            # Use the current python executable to create venv
            subprocess.check_call([sys.executable, "-m", "venv", venv_dir])
            print("   [OK] venv created successfully.")
        except subprocess.CalledProcessError:
            print("   [Error] Failed to create virtual environment.")
            input("Press Enter to exit...")
            sys.exit(1)
    else:
        print("   [OK] venv already exists.")

    # 4. Install Dependencies
    print("\n[4/6] Installing dependencies (This may take a few minutes)...")
    print("   Please wait...")
    try:
        # Upgrade pip first
        subprocess.check_call([venv_python, "-m", "pip", "install", "--upgrade", "pip"], stdout=subprocess.DEVNULL)
        # Install requirements
        subprocess.check_call([venv_python, "-m", "pip", "install", "-r", req_file])
        print("   [OK] Dependencies installed.")
    except subprocess.CalledProcessError as e:
        print(f"\n[Error] Failed to install dependencies. Error code: {e.returncode}")
        print("Check your internet connection.")
        input("Press Enter to exit...")
        sys.exit(1)

    # 5. Install Playwright Browser Binaries (CRITICAL FOR GHOST MACRO)
    print("\n[5/6] Installing Ghost Browser (Playwright Chromium)...")
    try:
        # This downloads the hidden Chromium browser so Typecast works on any PC
        subprocess.check_call([venv_python, "-m", "playwright", "install", "chromium"])
        print("   [OK] Ghost Browser is ready.")
    except subprocess.CalledProcessError as e:
        print(f"\n[Warning] Failed to install Playwright browser. Ghost Macro may not work. Error code: {e.returncode}")

    # 6. Launch the Bot
    print("\n[6/6] Launching Streamer Bot...")
    print("="*50)
    print("\n")
    try:
        subprocess.check_call([venv_python, "controller.py"])
    except KeyboardInterrupt:
        print("\n[System] Stopping...")
    except Exception as e:
        print(f"\n[Crash] The application crashed: {e}")
        input("Press Enter to exit...")

if __name__ == "__main__":
    # Force working directory to script location
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    setup_and_run()