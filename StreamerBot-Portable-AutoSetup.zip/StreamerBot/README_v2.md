# StreamerBot v2: live AI co-streamer

You play. The AI watches your screen, hears your game and your voice, reads chat, and reacts out loud as if it were the one playing.
v2 is a new package (`sbv2/`) that sits next to your v1 files. v1 still runs; nothing was deleted.

## Run it
1. Copy this folder's contents into your existing StreamerBot folder (so `avatar.png`, `bot_config.json`, `credentials/` and `typecast_bridge.py` are found).
2. `run_v2.bat`  (first run installs dependencies and creates `sbv2_config.json`).
3. Open **http://127.0.0.1:8765/** (dashboard). Put API keys in `sbv2_config.json` under `"keys"`, **or do nothing**: keys are imported from your v1 `bot_config.json`.
4. OBS: add a **Browser Source** with URL `http://127.0.0.1:8765/overlay`, 800x800. It has a real transparent background (no green screen) and live captions (`?captions=0` to hide).

## How it works
```
 screen (2 fps ring buffer) --change score--+
 game audio spikes ---------------------------+--> DIRECTOR --look--> OBSERVER (vision LLM -> JSON facts)
 your mic (VAD, shout, speech-to-text) -------+        |                         |
 YouTube chat / dashboard chat ---------------+        |                         v
                                                       +--> TALKER (text LLM, grounded in facts + memory)
                                                                     |
        instant "reflex" interjections (pre-rendered) ---------------+--> SPEECH MANAGER --> speakers + avatar overlay
```
* **Two-stage brain.** The vision model only reports *facts* (scene, intensity, events). A separate text model turns facts into a line. Nothing is invented because the talker is told to use only the listed facts.
* **Budgeted vision.** Looks speed up in busy scenes and slow down on static screens. Routine looks use at most 80% of `vision.max_calls_per_min`; the rest is a reserve for urgent looks (audio spike, your shout).
* **Latency masking.** A loud game sound or your shout plays a pre-rendered "Oh!/No way!" instantly, then the real line follows 2-5 s later.
* **Speech manager.** Priorities (death/win > reaction > chat/you > idle), stale lines are dropped, urgent lines interrupt boring ones, it waits while *you* are talking, and it knows when it is really speaking.
* **Memory.** Per-game deaths/wins, notable moments, recent lines (anti-repetition), viewers. Saved in `sbv2_data/`.
* **Providers.** Gemini, Groq, OpenRouter, SambaNova, local LM Studio, with key rotation, 429 cooldowns and a circuit breaker. Order is set in `providers`.

## Avatar
Works with your existing `avatar.png` (it squashes/stretches with the voice, bobs, shakes when scared, bounces when hyped). For more, drop PNGs in `avatar_assets/`:
`idle.png`, `talk.png` (mouth open), `blink.png`, `emotion_hype.png`, `emotion_panic.png`, ... (`neutral hype panic funny sad awe salty scared proud confused`).

## Tips
* Use **borderless windowed** mode; exclusive fullscreen often captures black (the bot warns you).
* To let the loopback detector work, play the AI voice on a different device (e.g. VB-Cable) than the game, or accept that the bot ignores spikes while it talks.
* `tts.engine`: `edge` (default, free), `kokoro` (local), `elevenlabs` (API key + voice_id), `typecast` (your existing ghost bridge), `sapi` (offline fallback).
* YouTube: set `youtube.enabled=true`. Chat polling and posting spend API quota; the default posts nothing unless `post_to_chat` is true.
* `ai_disclosure` (default true): if someone sincerely asks, it says it is an AI. Check your platform's rules on synthetic-voice/AI-content disclosure.

## What is NOT carried over from v1 (use v1 for these)
Tk GUI, hotkey soundboard + cached-category system, music player, Bark/RVC/Fish/Soprano/TikTok/Voicebox/Google TTS engines, SadTalker/LivePortrait rendered videos, quest-walkthrough vision mode. Those can be ported on request; the live-reaction core is what v2 replaces.

## Tests
`python tests/test_all.py` (23 offline tests, fake LLM/audio) and `python tests/soak.py`.
Not yet exercised against live APIs, a real game, or Windows audio devices: expect to tune `vision.*` and `audio.spike_ratio` on first run.

## Bark (fast)
Set `"tts": {"engine": "bark", "voices": {"bark": "v2/en_speaker_6"}}`. `bark_fast.py` keeps Bark loaded and warmed, and the instant filler reactions are pre-rendered in Bark's own voice. v1 users: replace `model.py` with `model_bark_fast.py` (back up first) to get sentence-streamed Bark in the old app.
