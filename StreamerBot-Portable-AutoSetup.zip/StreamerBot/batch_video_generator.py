import os
import shutil
import tkinter as tk
from tkinter import filedialog
import time

# Try importing the bridge we made for the main bot
try:
    from sadtalker_bridge import SadTalkerEngine
except ImportError:
    print("[Error] Could not find sadtalker_bridge.py!")
    print("Please ensure this script is in the same folder as your Streamer Bot files.")
    exit(1)

def main():
    print("===================================================")
    print("🎬 Batch Video Cache Generator")
    print("===================================================")
    
    avatar_path = os.path.abspath("avatar.png")
    if not os.path.exists(avatar_path):
        print(f"[Error] Could not find {avatar_path}!")
        print("Please make sure your avatar.png is in this folder.")
        input("Press Enter to exit...")
        return

    # Hide the main tkinter window, we only want the folder dialog
    root = tk.Tk()
    root.withdraw()
    
    print("\nPlease select the folder containing your cached .wav files...")
    # This opens the Windows folder picker
    folder_path = filedialog.askdirectory(title="Select Cache Folder with .wav files")
    
    if not folder_path:
        print("No folder selected. Exiting.")
        return
        
    print(f"\nScanning: {folder_path}")
    
    wav_files = []
    # Walk through the directory and all subdirectories to find all .wav files
    for root_dir, dirs, files in os.walk(folder_path):
        for file in files:
            # FIX: Made it case-insensitive to catch .WAV files too
            if file.lower().endswith(".wav"):
                wav_files.append(os.path.join(root_dir, file))
                
    if not wav_files:
        print("No .wav files found in the selected folder.")
        input("Press Enter to exit...")
        return
        
    print(f"Found {len(wav_files)} audio files. Checking for missing videos...\n")
    
    animator = SadTalkerEngine()
    success_count = 0
    skip_count = 0
    fail_count = 0
    
    for i, wav_path in enumerate(wav_files, 1):
        # FIX: Bulletproof way to swap extensions without breaking folder paths
        base_name, _ = os.path.splitext(wav_path)
        mp4_path = base_name + ".mp4"
        
        # If the video already exists, skip it to save time!
        if os.path.exists(mp4_path):
            print(f"[{i}/{len(wav_files)}] ⏭️ Skipped (Already exists): {os.path.basename(mp4_path)}")
            skip_count += 1
            continue
            
        print(f"[{i}/{len(wav_files)}] ⏳ Generating video for: {os.path.basename(wav_path)}")
        
        try:
            # Generate the video using the exact same engine the bot uses
            generated_video = animator.generate_talking_head(wav_path, avatar_path)
            
            if generated_video and os.path.exists(generated_video):
                # Move and rename the generated video to match the audio file perfectly
                shutil.move(generated_video, mp4_path)
                print(f"[{i}/{len(wav_files)}] ✅ Success: {os.path.basename(mp4_path)}")
                success_count += 1
            else:
                print(f"[{i}/{len(wav_files)}] ❌ Failed: Video engine did not return a file.")
                fail_count += 1
        except Exception as e:
            print(f"[{i}/{len(wav_files)}] ❌ Error generating video: {e}")
            fail_count += 1
            
    print("\n===================================================")
    print("🎉 Batch Processing Complete!")
    print(f"Total files checked: {len(wav_files)}")
    print(f"Videos generated: {success_count}")
    print(f"Videos skipped: {skip_count}")
    print(f"Errors: {fail_count}")
    print("===================================================")
    input("Press Enter to close...")

if __name__ == "__main__":
    main()