@echo off
title StreamerBot v2
cd /d "%~dp0"
python --version >nul 2>&1 || (echo [ERROR] Python is not on PATH & pause & exit /b)
if not exist .v2_deps_ok (
  echo Installing dependencies...
  python -m pip install --user -r requirements_v2.txt && echo ok> .v2_deps_ok
)
if not exist sbv2_config.json copy sbv2_config.example.json sbv2_config.json >nul
echo Starting StreamerBot v2 ...
echo Dashboard: http://127.0.0.1:8765/    OBS overlay: http://127.0.0.1:8765/overlay
python -m sbv2
pause
