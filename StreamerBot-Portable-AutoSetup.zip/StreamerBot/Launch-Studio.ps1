[CmdletBinding()]
param()
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$VenvPython = $env:STREAMERBOT_PYTHON
if (-not $VenvPython) { $VenvPython = Join-Path $PSScriptRoot ".portable\venv\Scripts\python.exe" }
if (-not (Test-Path -LiteralPath $VenvPython)) { $VenvPython = Join-Path $PSScriptRoot ".venv\Scripts\python.exe" }
$Desktop = Join-Path $PSScriptRoot "windows\StreamerBot.Desktop\bin\Release\net10.0-windows10.0.19041.0\win-x64\StreamerBot.Desktop.exe"
if (-not (Test-Path $VenvPython) -or -not (Test-Path $Desktop)) {
    throw "Double-click Start-StreamerBot.bat to prepare and launch the portable app."
}
$env:STREAMERBOT_PYTHON = $VenvPython
$PortableWebView = Join-Path $PSScriptRoot ".portable\webview2"
if (Test-Path -LiteralPath (Join-Path $PortableWebView "msedgewebview2.exe")) {
    $env:WEBVIEW2_BROWSER_EXECUTABLE_FOLDER = $PortableWebView
}
$App = Start-Process -FilePath $Desktop -PassThru -Wait
if ($App.ExitCode -ne 0) { throw "The desktop app exited with code $($App.ExitCode). Run Start-Portable.ps1 -Repair." }
