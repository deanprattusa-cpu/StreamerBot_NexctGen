"""reaction_hotkeys: data + AI helpers for the "Instant Reactions" hotkey section.

Reaction keys are for the tiny sounds a real gamer makes mid-game: "uh-oh!", a gasp, a grunt, "hyaah!",
"ow!". They fire the moment the key goes down (no tap-wait, no AI call) and say one random short phrase from
the slot, played from the voice cache when it exists so it is instant.

Each slot's "Override" box holds its phrases separated by |   e.g.  Uh-oh! | Oh no... | Uh oh
Each slot's "AI Prompt" box holds a plain description of the sound (used to ask the AI for new phrases).
"""
import json
import random
import re

N_SLOTS = 12

# (label, default phrases, what-it-is description for the AI, default key)
SLOTS = [
    ("Uh-oh!",            "Uh-oh! | Uh oh... | Oh no.",                    "an 'uh-oh' moment: something just went slightly wrong",             "ctrl+alt+1"),
    ("Surprise / Gasp",   "[gasps] Whoa! | Oh! | Wait, what?!",            "sudden surprise or a gasp",                                         "ctrl+alt+2"),
    ("Grunt / Effort",    "Hnngh! | Ugh! | Hrrgh!",                        "a physical effort grunt while pushing, lifting or climbing",        "ctrl+alt+3"),
    ("Attack / Thrust",   "Hyaah! | Hah! | Take that!",                    "a quick attack effort shout when striking or thrusting a weapon", "ctrl+alt+4"),
    ("Hit / Pain",        "Ow! | Ooof! | Agh!",                            "getting hit or hurt in the game",                                   "ctrl+alt+5"),
    ("Laugh",             "[laughs] Haha! | Hehe! | Ha!",                  "a short laugh at something funny",                                  "ctrl+alt+6"),
    ("Sigh / Annoyed",    "[sighs] Aww man. | Ugh, really? | Seriously?",  "a tired or annoyed reaction",                                       "ctrl+alt+7"),
    ("Scared",            "Ahh! No no no! | Eek! | Nope nope nope.",       "getting scared by a jump scare or a nasty enemy",                   "ctrl+alt+8"),
    ("Hype / Yes!",       "Yesss! | Let's go! | Woo!",                     "a quick celebration after a win or a great play",                   "ctrl+alt+9"),
    ("Confused",          "Huh? | Wait, what? | Hmm?",                     "being confused about what just happened",                           "ctrl+alt+0"),
    ("Nice / Impressed",  "Nice! | Ooh, clean. | Oh, that's good.",        "a short impressed 'nice' at something cool",                        "ctrl+alt+-"),
    ("Oof / Cringe",      "Oof. | Yikes. | Ohh no.",                       "a cringe at a fail or an awkward moment",                           "ctrl+alt+="),
]

TAG_RE = re.compile(r"\[(?:laughs|laughter|sighs|screams|gasps|clears throat|smacks lips|cries|hesitates)\]", re.I)


def bases():
    return [f"hk_react_{i}" for i in range(1, N_SLOTS + 1)]


def parse_phrases(text):
    """'Uh-oh! | Oh no' (or one per line) -> ['Uh-oh!', 'Oh no']."""
    parts = re.split(r"\s*\|\s*|\r?\n", str(text or ""))
    out = []
    for p in parts:
        p = p.strip()
        if p and p not in out:
            out.append(p)
    return out


def join_phrases(phrases):
    return " | ".join(phrases)


def pick(phrases, last=None):
    """Random phrase, never the same one twice in a row when there is a choice."""
    if not phrases:
        return ""
    pool = [p for p in phrases if p != last] or phrases
    return random.choice(pool)


def strip_tags(text):
    return re.sub(r"\s+", " ", TAG_RE.sub("", text or "")).strip()


# ---------------------------------------------------------------------------------------------------
# AI: ask for game-specific reaction phrases
# ---------------------------------------------------------------------------------------------------
def build_messages(game, channel, slots, allow_tags, per_slot=4):
    """slots: list of (n, label, description)."""
    lines = "\n".join(f"react_{n}: {label} - {desc}" for n, label, desc in slots)
    tags = ("You MAY start a few phrases with one of these tags: [laughs] [sighs] [gasps] [screams]. Use them sparingly."
            if allow_tags else "Do NOT use any [brackets] or tags. Plain words and sounds only.")
    sys = ("You write the tiny instant sounds and exclamations of a real human gamer live-streaming. "
           "Never explain. Never use emojis. Never use hashtags.")
    user = (f"The streamer{' ' + channel if channel else ''} is playing: {game}.\n"
            f"For EACH reaction below write {per_slot} different VERY SHORT reactions (1 to 4 words each) that fit this game's "
            f"setting, enemies, tone and mechanics where it feels natural, otherwise just natural gamer sounds "
            f"(grunts, gasps, 'uh-oh!', 'hyaah!', 'oof').\n{tags}\n"
            f"Reply in EXACTLY this format, one line per reaction, phrases separated by |, nothing else:\n"
            f"react_1: phrase | phrase | phrase | phrase\n\nReactions:\n{lines}")
    return [{"role": "system", "content": sys}, {"role": "user", "content": user}]


def _clean_phrase(p, allow_tags):
    p = re.sub(r"^[\s\-\*\d\.\)\"'`]+|[\s\"'`]+$", "", p or "").strip()
    p = re.sub(r"[\U0001F000-\U0001FAFF☀-➿]", "", p)            # emojis
    if not allow_tags:
        p = strip_tags(p)
    p = re.sub(r"\s+", " ", p).strip()
    body = TAG_RE.sub("", p).strip()
    if not body or len(body.split()) > 6 or len(body) > 40:
        return ""
    return p


def parse_reply(text, allow_tags=False, max_per_slot=5):
    """AI reply -> {n: [phrases]}. Accepts the line format or JSON."""
    text = str(text or "")
    text = re.sub(r"<think>.*?(?:</think>|$)", "", text, flags=re.DOTALL | re.I)
    res = {}
    for m in re.finditer(r"react[_ ]?(\d+)\s*[:=\-]\s*(.+)", text, re.I):
        n = int(m.group(1))
        if 1 <= n <= N_SLOTS:
            ph = [_clean_phrase(x, allow_tags) for x in re.split(r"\s*\|\s*", m.group(2))]
            ph = [x for x in ph if x]
            if ph:
                res[n] = list(dict.fromkeys(ph))[:max_per_slot]
    if not res:                                                          # JSON fallback
        try:
            mm = re.search(r"\{.*\}", text, re.S)
            data = json.loads(mm.group(0)) if mm else {}
            for k, v in data.items():
                n = int(re.sub(r"\D", "", str(k)) or 0)
                if 1 <= n <= N_SLOTS:
                    arr = v if isinstance(v, list) else re.split(r"\s*\|\s*", str(v))
                    ph = [x for x in (_clean_phrase(a, allow_tags) for a in arr) if x]
                    if ph:
                        res[n] = list(dict.fromkeys(ph))[:max_per_slot]
        except Exception:
            pass
    return res
