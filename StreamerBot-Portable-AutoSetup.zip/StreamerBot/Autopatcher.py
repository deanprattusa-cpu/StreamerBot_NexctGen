import sys

try:
    import tkinter as tk
    from tkinter import ttk, scrolledtext, filedialog, messagebox
    import os
    import shutil
    import re

    class SmartCodePatcher:
        def __init__(self, root):
            self.root = root
            self.root.title("AI Smart Code Patcher (Ultra-Fuzzy Edition)")
            self.root.geometry("1000x850")
            self.root.configure(bg="#121212")
            
            self.file_path_var = tk.StringVar()
            self.fuzzy_var = tk.BooleanVar(value=True)
            self.smart_override_var = tk.BooleanVar(value=True) 
            
            self.setup_ui()

        def setup_ui(self):
            # --- Header ---
            header_frame = tk.Frame(self.root, bg="#1a1a1a", pady=15)
            header_frame.pack(fill="x")
            
            tk.Label(header_frame, text="🧠 AI ULTRA-FUZZY PATCHER", font=("Segoe UI", 18, "bold"), bg="#1a1a1a", fg="#00FFCC").pack()
            tk.Label(header_frame, text="Ignores indentation, spaces, and blank lines. Guaranteed to find your code.", font=("Segoe UI", 10), bg="#1a1a1a", fg="#888").pack()

            # --- File Selector ---
            file_frame = tk.Frame(self.root, bg="#121212", pady=15)
            file_frame.pack(fill="x", padx=30)
            
            tk.Label(file_frame, text="1. Select File to Patch:", font=("Segoe UI", 11, "bold"), bg="#121212", fg="white").pack(anchor="w")
            
            entry_frame = tk.Frame(file_frame, bg="#121212")
            entry_frame.pack(fill="x", pady=5)
            tk.Entry(entry_frame, textvariable=self.file_path_var, bg="#1e1e1e", fg="white", font=("Consolas", 11), insertbackground="white", borderwidth=1, relief="solid").pack(side="left", fill="x", expand=True, ipady=5)
            tk.Button(entry_frame, text="📂 Browse", bg="#0066CC", fg="white", font=("Segoe UI", 10, "bold"), borderwidth=0, padx=15, command=self.browse_file).pack(side="left", padx=(10, 0))
            tk.Button(entry_frame, text="⏮ Undo Patch", bg="#660000", fg="white", font=("Segoe UI", 10, "bold"), borderwidth=0, padx=15, command=self.restore_backup).pack(side="left", padx=10)

            # --- Options ---
            opt_frame = tk.Frame(self.root, bg="#121212")
            opt_frame.pack(fill="x", padx=30, pady=(0, 10))
            tk.Checkbutton(opt_frame, text="🧠 AI Fuzzy Match (Ignore Whitespace)", variable=self.fuzzy_var, bg="#121212", fg="#FFCC00", selectcolor="#222", activebackground="#121212", font=("Segoe UI", 9, "bold")).pack(side="left")
            tk.Checkbutton(opt_frame, text="⚡ Smart Override (Class Method Support)", variable=self.smart_override_var, bg="#121212", fg="#00FF00", selectcolor="#222", activebackground="#121212", font=("Segoe UI", 9, "bold")).pack(side="left", padx=20)

            # --- Split View ---
            paned = ttk.PanedWindow(self.root, orient=tk.VERTICAL)
            paned.pack(fill="both", expand=True, padx=30, pady=5)

            f1 = tk.Frame(paned, bg="#121212")
            tk.Label(f1, text="2. Old Code to REMOVE (Target Block):", font=("Segoe UI", 10, "bold"), bg="#121212", fg="#FF6666").pack(anchor="w", pady=5)
            self.txt_target = scrolledtext.ScrolledText(f1, bg="#0a0a0a", fg="#FF9999", font=("Consolas", 10), insertbackground="white", undo=True, borderwidth=0)
            self.txt_target.pack(fill="both", expand=True)
            paned.add(f1, weight=1)

            f2 = tk.Frame(paned, bg="#121212")
            tk.Label(f2, text="3. New Code to INSERT (Fixed Block):", font=("Segoe UI", 10, "bold"), bg="#121212", fg="#66FF66").pack(anchor="w", pady=5)
            self.txt_replace = scrolledtext.ScrolledText(f2, bg="#0a0a0a", fg="#99FF99", font=("Consolas", 10), insertbackground="white", undo=True, borderwidth=0)
            self.txt_replace.pack(fill="both", expand=True)
            paned.add(f2, weight=1)

            # --- Footer Button ---
            tk.Button(self.root, text="✨ APPLY SMART PATCH ✨", bg="#008033", fg="white", font=("Segoe UI", 14, "bold"), borderwidth=0, command=self.apply_patch).pack(fill="x", padx=30, pady=20, ipady=10)

        def browse_file(self):
            filepath = filedialog.askopenfilename(filetypes=[("Python Files", "*.py"), ("All Files", "*.*")])
            if filepath: self.file_path_var.set(filepath)

        def restore_backup(self):
            filepath = self.file_path_var.get().strip()
            if not filepath: return
            bak = filepath + ".bak"
            if os.path.exists(bak):
                shutil.copy2(bak, filepath)
                messagebox.showinfo("Restored", "File rolled back successfully!")
            else: messagebox.showerror("Error", "No backup found.")

        def apply_patch(self):
            filepath = self.file_path_var.get().strip()
            target_code = self.txt_target.get("1.0", "end").strip()
            new_code = self.txt_replace.get("1.0", "end").strip("\n")

            if not filepath or not os.path.exists(filepath): return messagebox.showerror("Error", "Select a valid file.")
            if not new_code: return messagebox.showerror("Error", "Paste the new code.")

            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    content = f.read()

                # Normalize everything to Unix line endings for safety
                content = content.replace("\r\n", "\n")
                match_found = False
                final_content = ""

                # STEP 1: ULTRA-FUZZY MATCH
                if target_code:
                    # Escape all special regex chars, but turn every sequence of whitespace into \s+
                    tokens = target_code.split()
                    escaped_tokens = [re.escape(t) for t in tokens]
                    pattern = r'\s+'.join(escaped_tokens)
                    match = re.search(pattern, content, re.MULTILINE | re.DOTALL)
                    
                    if match:
                        final_content = content[:match.start()] + new_code + content[match.end():]
                        match_found = True

                # STEP 2: SMART OVERRIDE (Replaces entire method/function if block fails)
                if not match_found and "def " in target_code and self.smart_override_var.get():
                    func_name_match = re.search(r'def\s+([a-zA-Z0-9_]+)', target_code)
                    if func_name_match:
                        name = func_name_match.group(1)
                        # [FIX: Robust regex to find the method even with indentation]
                        # Finds a line with optional whitespace, 'def name', then captures everything until 
                        # a line starts with the SAME or LESS indentation.
                        pattern = rf'^([ \t]*)def\s+{name}\s*\(.*?\):.*?(?=\n\1(?!\s)|\Z)'
                        func_match = re.search(pattern, content, re.DOTALL | re.MULTILINE)
                        
                        if func_match:
                            if messagebox.askyesno("Logic Override", f"Patcher found the function '{name}' in your file, but the internal code doesn't match your snippet.\n\nOverwrite the existing function with the fix?"):
                                final_content = content[:func_match.start()] + new_code + "\n" + content[func_match.end():]
                                match_found = True

                # STEP 3: FINAL FALLBACK (Force)
                if not match_found:
                    msg = "Match failed.\n\nWould you like to FORCE APPLY by appending this to the bottom of the file?\n(Safe for small helper functions, risky for main logic)."
                    if messagebox.askyesno("Match Failed", msg):
                        final_content = content + "\n\n" + new_code + "\n"
                        match_found = True
                    else: return

                # Save & Backup
                shutil.copy2(filepath, filepath + ".bak")
                with open(filepath, "w", encoding="utf-8", newline="\n") as f:
                    f.write(final_content)

                messagebox.showinfo("Success 🎉", "Patch applied perfectly!\n\nA backup (.bak) was created.")
                self.txt_target.delete("1.0", "end")
                self.txt_replace.delete("1.0", "end")

            except Exception as e: messagebox.showerror("Critical Error", str(e))

    if __name__ == "__main__":
        root = tk.Tk()
        app = SmartCodePatcher(root)
        root.mainloop()

except Exception as e:
    import traceback
    print(traceback.format_exc())
    input("Crash! Press Enter to exit...")