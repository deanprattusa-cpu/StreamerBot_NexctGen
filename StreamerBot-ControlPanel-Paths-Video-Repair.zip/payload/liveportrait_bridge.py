import os
import subprocess
import time
import sys
from pathlib import Path
import resource_paths
import imageio_ffmpeg
import shutil
from PIL import Image

class LivePortraitEngine:
    def __init__(self, liveportrait_path=None):
        self.liveportrait_path = liveportrait_path or resource_paths.path("liveportrait_path", r"D:\BARKAIMODELS\FasterLivePortrait")
        
    def generate_talking_head(self, audio_path, image_path, output_dir="outputs"):
        if not os.path.exists(self.liveportrait_path):
            print(f"[ERROR] FasterLivePortrait not found at {self.liveportrait_path}!")
            return None

        # Absolute paths for safety
        abs_audio_path = os.path.abspath(audio_path)
        abs_image_path = os.path.abspath(image_path)
        
        print(f"[LivePortrait] 🎬 Initializing Real-Time Audio-to-Video Rendering...")
        start_time = time.time()
        
        env = os.environ.copy()
        env["OMP_NUM_THREADS"] = "1"
        env["KMP_DUPLICATE_LIB_OK"] = "TRUE"
        env["MKL_NUM_THREADS"] = "1"
        
        # FIX: Point to the default driving video included with FasterLivePortrait
        # This will prove if the rendering engine works when it gets valid data.
        test_video_path = os.path.join(self.liveportrait_path, "assets", "examples", "driving", "d0.mp4")
        
        if not os.path.exists(test_video_path):
             print(f"[ERROR] Test video not found at {test_video_path}")
             return None

        # Change back to --dri_video and use the test video
        selected_python = resource_paths.path("liveportrait_python_path")
        if not selected_python:
            candidates = [Path(self.liveportrait_path) / env / "Scripts/python.exe" for env in ("venv", ".venv", "env")]
            selected_python = str(next((p for p in candidates if p.is_file()), Path(sys.executable)))
        command = [
            selected_python, "run.py",
            "--src_image", abs_image_path,
            "--dri_video", test_video_path, 
            "--cfg", "configs/onnx_infer.yaml"
        ]
        
        try:
            # We leave capture_output OUT so you can see exactly what it's doing in the console!
            result = subprocess.run(command, cwd=self.liveportrait_path, env=env)
                
            if result.returncode != 0:
                print(f"\n[LivePortrait Error] GPU Rendering Failed (Exit Code {result.returncode})")
                return None
                
            elapsed = round(time.time() - start_time, 1)
            print(f"\n[LivePortrait] ✅ Video Rendered Successfully in {elapsed} seconds!")
            
            return self._get_latest_mp4(os.path.join(self.liveportrait_path, "results"))
            
        except Exception as e:
            print(f"[LivePortrait Error] Process Failed: {e}")
            return None

    def _get_latest_mp4(self, directory):
        """Finds the newly generated video file."""
        if not os.path.exists(directory):
            return None
            
        files = []
        for dirpath, _, filenames in os.walk(directory):
            for f in filenames:
                if f.endswith('.mp4'):
                    files.append(os.path.join(dirpath, f))
        
        if not files:
            return None
            
        latest_file = max(files, key=os.path.getctime)
        return latest_file