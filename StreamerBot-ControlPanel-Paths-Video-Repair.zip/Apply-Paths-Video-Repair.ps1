[CmdletBinding()]
param([string]$TargetFolder)
$ErrorActionPreference='Stop'
if (-not $TargetFolder) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description='Select the ORIGINAL StreamerBot control-panel folder containing controller.py and view.py'
    if ($dialog.ShowDialog() -ne 'OK') { exit 1 }
    $TargetFolder=$dialog.SelectedPath
}
$TargetFolder=[IO.Path]::GetFullPath($TargetFolder)
if (-not (Test-Path (Join-Path $TargetFolder 'view.py')) -or -not (Test-Path (Join-Path $TargetFolder 'controller.py'))) {
    throw 'Select the original Python control-panel folder. For the new native C# app use its updated Windows installer.'
}
function Get-NormalizedHash([string]$File) {
    $content=[IO.File]::ReadAllText($File).Replace("`r`n","`n")
    $sha=[Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($content)))).Replace('-','').ToLowerInvariant() }
    finally { $sha.Dispose() }
}
$items=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'repair-manifest.json') -Raw | ConvertFrom-Json
foreach ($item in $items) {
    $source=Join-Path (Join-Path $PSScriptRoot 'payload') $item.Name
    if ((Get-NormalizedHash $source) -ne $item.NewHash) { throw ('Repair payload checksum failed: '+$item.Name) }
    $target=Join-Path $TargetFolder $item.Name
    if (Test-Path -LiteralPath $target) {
        $hash=Get-NormalizedHash $target
        if ($hash -ne $item.OldHash -and $hash -ne $item.NewHash) { throw ('Customized or different-version file detected: '+$item.Name+'. No files were changed. Keep your custom version and merge the repair manually.') }
    }
}
$backup=Join-Path (Join-Path $TargetFolder 'RepairBackups') ((Get-Date).ToUniversalTime().ToString('yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
foreach ($item in $items) {
    $target=Join-Path $TargetFolder $item.Name
    if (Test-Path -LiteralPath $target) { Copy-Item -LiteralPath $target -Destination (Join-Path $backup $item.Name) }
}
$changed=New-Object System.Collections.Generic.List[string]
$temporary=$null
try {
    foreach ($item in $items) {
        $target=Join-Path $TargetFolder $item.Name
        $temporary=$target+'.repair-'+[Guid]::NewGuid().ToString('N')+'.tmp'
        Copy-Item -LiteralPath (Join-Path (Join-Path $PSScriptRoot 'payload') $item.Name) -Destination $temporary
        if (Test-Path -LiteralPath $target) { [IO.File]::Replace($temporary,$target,(Join-Path $backup $item.Name)) } else { [IO.File]::Move($temporary,$target) }
        $temporary=$null
        $changed.Add($item.Name)
    }
} catch {
    foreach ($name in $changed) {
        $saved=Join-Path $backup $name
        if (Test-Path -LiteralPath $saved) { Copy-Item -LiteralPath $saved -Destination (Join-Path $TargetFolder $name) -Force }
        else { Remove-Item -LiteralPath (Join-Path $TargetFolder $name) -Force }
    }
    throw
} finally { if ($temporary -and (Test-Path -LiteralPath $temporary)) { Remove-Item -LiteralPath $temporary -Force } }
Write-Host "Repair applied. Backups: $backup"
Write-Host 'Restart the app. Open Tools -> Paths and select SadTalker, its Python, checkpoints, avatar and video output.'
Write-Host 'Profiles, credentials, existing models and caches were preserved.'
