@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Apply-Paths-Video-Repair.ps1"
if errorlevel 1 echo Repair failed. Read the error above.
pause
