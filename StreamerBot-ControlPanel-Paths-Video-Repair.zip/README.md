# Original control-panel paths and SadTalker repair

This patch is for the original black/green Python control panel shown in your screenshot.
For the fresh C# / WinUI app, use the updated native Windows installer instead.

1. Close the original app. Extract this ZIP into a SEPARATE folder.
2. Run Apply-Paths-Video-Repair.bat and select the original app folder.
3. The script checks file versions and makes backups before replacing code.
   Customized/unrecognized versions are rejected before any changes.
4. Restart the app and open Tools -> Paths. Select the SadTalker folder containing
   inference.py, its GPU-enabled Python in venv/Scripts/python.exe, avatar image,
   optional checkpoints, FFmpeg and output folder. Other drives are supported.
5. Toggle_Video_Rendering.bat switches new video rendering on/off.

No profiles, API keys, tokens, models or existing caches are replaced. Path choices
are saved in resource_paths.json beside the original app. A selected folder does
not install missing engines/dependencies/models. The renderer checks CUDA in its
selected Python and saves real error details to renderer.log under the selected
video output folder. GPU/model inference still needs testing on your PC.

If repair reports a customized file, do not force an overwrite; merge the supplied
changes into your version. Original code backups are in RepairBackups.
