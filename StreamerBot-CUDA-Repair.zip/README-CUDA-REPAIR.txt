StreamerBot CUDA repair - for the existing Python desktop package

This is NOT the full C#/.NET application rewrite. The existing EXE
launches the original Python/Tkinter app; that architecture is unchanged.

1. Close StreamerBot.
2. Extract this ZIP INTO your complete existing app folder, replacing
   the included setup helper/compatibility constraints. Repair-CUDA.bat
   must sit beside StreamerBot.exe and Start-Portable.ps1.
3. Double-click Repair-CUDA.bat. Keep its console open. Internet and
   several GB of download/disk space are needed.
4. Wait for CUDA tensor test passed, then start StreamerBot.exe from
   THIS SAME folder. Original run.bat may select a different Python.

Repairs ONLY .portable/original/venv, used by the packaged EXE. Installs
matched Torch2.5.1+cu124/vision0.20.1+cu124/audio2.5.1+cu124 and checks a
real GPU matrix operation. A failed test returns an error; CUDA repair
never substitutes CPU wheels. Check .portable/original/gpu-report.json
for Torch/CUDA build, GPU name or the failure reason.

Updated normal setup detects NVIDIA through Windows video controllers
and vendor IDs as well as nvidia-smi, then validates Torch again after
optional dependencies finish. Private networkx2.8.8 remains consistent
with the original requirements.

Your configurations, model weights, voice settings and other Python
installations are preserved. If Bark's Use CPU option is enabled,
change it yourself in the original app to use the GPU.

An installed CPU-only Torch build does not show that the NVIDIA driver
or system CUDA toolkit was removed. This repairs the Python CUDA runtime
packages, not display drivers or the CUDA development toolkit. A working
compatible NVIDIA driver is required. Failure details remain visible.

Target Windows x64/Python3.11. Actual Windows/GPU installation cannot
be run in the Linux build sandbox. Regression tests and Windows wheel
resolution passed; your PC must pass the real tensor probe before any
GPU success claim. No profiles, credentials or models are in this ZIP.
